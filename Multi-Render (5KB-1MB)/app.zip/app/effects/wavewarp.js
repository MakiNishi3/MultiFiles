/* global define, require */
(function (root, factory) {
'use strict';
if (typeof define === 'function' && define.amd) {
define(['seriously'], factory);
} else if (typeof exports === 'object') {
factory(require('seriously'));
} else {
if (!root.Seriously) {
root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
}
factory(root.Seriously);
}
}(window, function (Seriously) {
'use strict';

Seriously.plugin('wavewarp', {
commonShader: true,
shader: function (inputs, shaderSource) {
shaderSource.vertex = [
'precision mediump float;',
'attribute vec3 position;',
'attribute vec2 texCoord;',
'varying vec2 vTexCoord;',
'void main(void) {',
'vTexCoord = texCoord;',
'gl_Position = vec4(position, 1.0);',
'}'
].join('\n');

shaderSource.fragment = [
'precision mediump float;',
'varying vec2 vTexCoord;',
'uniform sampler2D source;',
'uniform float angle;',
'uniform float amount;',
'uniform float speed;',
'uniform float time;',
'void main(void) {',
'float rad = radians(angle);',
'vec2 dir = vec2(cos(rad), sin(rad));',
'float wave = sin(dot(vTexCoord, dir) * 10.0 + time * speed) * (amount / 200.0);',
'vec2 uv = vTexCoord + dir * wave * 0.05;',
'gl_FragColor = texture2D(source, uv);',
'}'
].join('\n');

return shaderSource;
},
inputs: {
source: {
type: 'image',
uniform: 'source'
},
angle: {
type: 'number',
uniform: 'angle',
defaultValue: 0,
min: 0,
max: 360
},
amount: {
type: 'number',
uniform: 'amount',
defaultValue: 0,
min: 0,
max: 200
},
speed: {
type: 'number',
uniform: 'speed',
defaultValue: 1,
min: 1,
max: 20
},
time: {
type: 'number',
uniform: 'time',
defaultValue: 0
}
},
title: 'Wave Warp'
});

}));```