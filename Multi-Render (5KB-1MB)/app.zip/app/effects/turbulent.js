(function (root, factory) {
'use strict';
if (typeof define === 'function' && define.amd) {
define(['seriously'], factory);
} else if (typeof exports === 'object') {
factory(require('seriously'));
} else {
if (!root.Seriously) {
root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
}
factory(root.Seriously);
}
}(window, function (Seriously) {
'use strict';

Seriously.plugin('turbulentDisplace', {
shader: function (inputs, shaderSource) {
shaderSource.vertex = [
'precision mediump float;',
'attribute vec2 position;',
'varying vec2 vTexCoord;',
'void main(void) {',
'vTexCoord = position * 0.5 + 0.5;',
'gl_Position = vec4(position, 0.0, 1.0);',
'}'
].join('\n');

shaderSource.fragment = [
'precision mediump float;',
'varying vec2 vTexCoord;',
'uniform sampler2D source;',
'uniform float amount;',
'uniform float frequency;',
'uniform float speed;',
'uniform float time;',

'float rand(vec2 co){',
'return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);',
'}',

'float noise(vec2 p){',
'vec2 i = floor(p);',
'vec2 f = fract(p);',
'float a = rand(i);',
'float b = rand(i + vec2(1.0, 0.0));',
'float c = rand(i + vec2(0.0, 1.0));',
'float d = rand(i + vec2(1.0, 1.0));',
'vec2 u = f * f * (3.0 - 2.0 * f);',
'return mix(a, b, u.x) +',
'(c - a)* u.y * (1.0 - u.x) +',
'(d - b) * u.x * u.y;',
'}',

'void main(void) {',
'float t = time * speed * 0.01;',
'vec2 uv = vTexCoord;',
'float n = noise(uv * frequency * 0.05 + t);',
'float n2 = noise((uv + 5.0) * frequency * 0.05 - t);',
'vec2 disp = vec2(n, n2) * (amount * 0.002);',
'vec2 finalUV = uv + disp;',
'gl_FragColor = texture2D(source, finalUV);',
'}'
].join('\n');

return shaderSource;
},

inputs: {
source: {
type: 'image',
uniform: 'source'
},
amount: {
type: 'number',
uniform: 'amount',
defaultValue: 0,
min: 0,
max: 200
},
frequency: {
type: 'number',
uniform: 'frequency',
defaultValue: 0,
min: 0,
max: 200
},
speed: {
type: 'number',
uniform: 'speed',
defaultValue: 0,
min: 0,
max: 200
},
time: {
type: 'number',
uniform: 'time',
defaultValue: 0
}
},

title: 'Turbulent Displace'
});

}));```