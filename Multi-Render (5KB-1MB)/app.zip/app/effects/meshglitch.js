/* global define, require */
(function (root, factory) {
'use strict';
if (typeof define === 'function' && define.amd) {
define(['seriously'], factory);
} else if (typeof exports === 'object') {
factory(require('seriously'));
} else {
if (!root.Seriously) {
root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
}
factory(root.Seriously);
}
}(window, function (Seriously) {
'use strict';

Seriously.plugin('meshglitch', {
shader: function (inputs, shaderSource) {
shaderSource.vertex = [
'precision mediump float;',
'attribute vec3 position;',
'attribute vec2 texCoord;',
'uniform float amount;',
'uniform float frequency;',
'uniform float speed;',
'uniform float time;',
'varying vec2 vTexCoord;',
'float rand(vec2 co){',
'return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);',
'}',
'void main(void) {',
'vec3 pos = position;',
'float t = time * speed * 0.01;',
'float f = frequency * 0.01;',
'float a = amount * 0.01;',
'float noise = rand(vec2(pos.y * f, t));',
'pos.x += (noise - 0.5) * a;',
'pos.y += (rand(vec2(pos.x * f, t)) - 0.5) * a;',
'gl_Position = vec4(pos, 1.0);',
'vTexCoord = texCoord;',
'}'
].join('\n');

shaderSource.fragment = [
'precision mediump float;',
'uniform sampler2D source;',
'varying vec2 vTexCoord;',
'void main(void) {',
'gl_FragColor = texture2D(source, vTexCoord);',
'}'
].join('\n');

return shaderSource;
},
inputs: {
source: {
type: 'image'
},
amount: {
type: 'number',
min: 0,
max: 200,
defaultValue: 0
},
frequency: {
type: 'number',
min: 0,
max: 200,
defaultValue: 0
},
speed: {
type: 'number',
min: 0,
max: 200,
defaultValue: 0
},
time: {
type: 'number',
uniform: 'time',
shaderDirty: false
}
},
title: 'Mesh Glitch'
});

}));```