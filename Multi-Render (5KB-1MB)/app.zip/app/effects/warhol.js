/* global define, require */
(function (root, factory) {
	'use strict';
	if (typeof define === 'function' && define.amd) {
		define(['seriously'], factory);
	} else if (typeof exports === 'object') {
		factory(require('seriously'));
	} else {
		if (!root.Seriously) {
			root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
		}
		factory(root.Seriously);
	}
}(window, function (Seriously) {
	'use strict';
	Seriously.plugin('warhol', {
		geometries: {},
		inputs: {
			source: { type: 'image', uniform: 'source' },
			amount: { type: 'number', uniform: 'amount', defaultValue: 100, min: 0, max: 200 }
		},
		shader: [
			'precision mediump float;',
			'uniform sampler2D source;',
			'uniform float amount;',
			'varying vec2 vTexCoord;',
			'void main(void) {',
			'  vec4 color = texture2D(source, vTexCoord);',
			'  float r = mod(color.r * 255.0 + amount, 256.0) / 255.0;',
			'  float g = mod(color.g * 255.0 + amount, 256.0) / 255.0;',
			'  float b = mod(color.b * 255.0 + amount, 256.0) / 255.0;',
			'  gl_FragColor = vec4(r, g, b, color.a);',
			'}'
		]
	});
}));