/* global define, require */
(function (root, factory) {
    'use strict';
    if (typeof define === 'function' && define.amd) {
        define(['seriously'], factory);
    } else if (typeof exports === 'object') {
        factory(require('seriously'));
    } else {
        if (!root.Seriously) {
            root.Seriously = {
                plugin: function (name, opt) { this[name] = opt; }
            };
        }
        factory(root.Seriously);
    }
}(window, function (Seriously) {
    'use strict';
    Seriously.plugin('rotateCube', {
        shader: function (inputs, shaderSource) {
            shaderSource.fragment = `
            precision mediump float;
            uniform float time;
            uniform sampler2D source;
            varying vec2 vTexCoord;

            mat2 rotate(float angle) {
                float s = sin(angle);
                float c = cos(angle);
                return mat2(c, -s, s, c);
            }

            void main(void) {
                vec2 uv = vTexCoord - 0.5;
                uv = rotate(time) * uv;
                uv += 0.5;
                gl_FragColor = texture2D(source, uv);
            }`;
        },
        inPlace: false,
        inputs: {
            source: {
                type: 'image',
                uniform: 'source'
            },
            speed: {
                type: 'number',
                uniform: 'time',
                defaultValue: 0,
                min: 0,
                max: 200
            }
        },
        update: function (inputs, shaderSource, frameBuffer, width, height, time) {
            this.uniforms.time = (time * inputs.speed * 0.001);
        }
    });
}));