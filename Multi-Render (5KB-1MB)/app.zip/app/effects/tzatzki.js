/* global define, require */
(function (root, factory) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define(['seriously'], factory);
  } else if (typeof exports === 'object') {
    factory(require('seriously'));
  } else {
    if (!root.Seriously) {
      root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
    }
    factory(root.Seriously);
  }
}(window, function (Seriously) {
  'use strict';

  Seriously.plugin('tzatzkiLens', {
    commonShader: true,
    inputs: {
      source: {
        type: 'image',
        uniform: 'source'
      },
      amount: {
        type: 'number',
        uniform: 'amount',
        defaultValue: 0,
        min: 0,
        max: 100
      },
      vignette: {
        type: 'number',
        uniform: 'vignette',
        defaultValue: 0,
        min: 0,
        max: 100
      }
    },
    shader: function () {
      return {
        uniforms: {
          source: { type: 'sampler2D' },
          amount: { type: 'f' },
          vignette: { type: 'f' }
        },
        vertex: [
          'precision mediump float;',
          'attribute vec2 position;',
          'attribute vec2 texCoord;',
          'varying vec2 vTexCoord;',
          'void main(void) {',
          'vTexCoord = texCoord;',
          'gl_Position = vec4(position, 0.0, 1.0);',
          '}'
        ].join('\n'),
        fragment: [
          'precision mediump float;',
          'uniform sampler2D source;',
          'uniform float amount;',
          'uniform float vignette;',
          'varying vec2 vTexCoord;',
          'void main(void) {',
          'vec2 uv = vTexCoord;',
          'vec2 center = vec2(0.5, 0.5);',
          'vec2 delta = uv - center;',
          'float dist = length(delta);',
          'float strength = amount / 100.0;',
          'float lens = 1.0 + strength * dist * dist;',
          'uv = center + delta * lens;',
          'vec4 color = texture2D(source, uv);',
          'float vig = vignette / 100.0;',
          'float vignetteFactor = smoothstep(0.8, 0.2, dist * (1.0 + vig));',
          'color.rgb *= vignetteFactor;',
          'gl_FragColor = color;',
          '}'
        ].join('\n')
      };
    }
  });

}));