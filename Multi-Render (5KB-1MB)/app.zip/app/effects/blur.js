/* global define, require */
(function (root, factory) {
'use strict';
if (typeof define === 'function' && define.amd) {
define(['seriously'], factory);
} else if (typeof exports === 'object') {
factory(require('seriously'));
} else {
if (!root.Seriously) {
root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
}
factory(root.Seriously);
}
}(window, function (Seriously) {
'use strict';

Seriously.plugin('blur44', {
shader: function (inputs, shaderSource) {
shaderSource.vertex = [
'precision mediump float;',
'attribute vec2 position;',
'varying vec2 vTexCoord;',
'void main(void) {',
'vTexCoord = (position + 1.0) * 0.5;',
'gl_Position = vec4(position, 0.0, 1.0);',
'}'
].join('\n');

shaderSource.fragment = [
'precision mediump float;',
'uniform sampler2D source;',
'uniform float intensity;',
'varying vec2 vTexCoord;',
'void main(void) {',
'vec2 texel = vec2(1.0) / vec2(textureSize(source, 0));',
'float radius = clamp(intensity, 0.0, 44.0);',
'vec4 color = vec4(0.0);',
'float total = 0.0;',
'for (int x = -44; x <= 44; x++) {',
'for (int y = -44; y <= 44; y++) {',
'float fx = float(x);',
'float fy = float(y);',
'float weight = exp(-(fx*fx + fy*fy) / (2.0 * radius * radius + 0.0001));',
'vec2 offset = vec2(fx, fy) * texel;',
'color += texture2D(source, vTexCoord + offset) * weight;',
'total += weight;',
'}',
'}',
'gl_FragColor = color / total;',
'}'
].join('\n');

return shaderSource;
},
inputs: {
source: {
type: 'image'
},
intensity: {
type: 'number',
min: 0,
max: 44,
defaultValue: 0
}
},
title: 'Blur'
});

}));