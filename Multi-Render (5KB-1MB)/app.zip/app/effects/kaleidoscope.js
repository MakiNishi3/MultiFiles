(function (root, factory) {
'use strict';
if (typeof define === 'function' && define.amd) {
define(['seriously'], factory);
} else if (typeof exports === 'object') {
factory(require('seriously'));
} else {
if (!root.Seriously) {
root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
}
factory(root.Seriously);
}
}(window, function (Seriously) {
'use strict';

Seriously.plugin('kaleidoscope', {
commonShader: true,
inputs: {
source: {
type: 'image',
uniform: 'source'
},
angle: {
type: 'number',
uniform: 'angle',
defaultValue: 0,
min: 0,
max: 360
},
segments: {
type: 'number',
uniform: 'segments',
defaultValue: 6,
min: 2,
max: 24,
step: 1
}
},
shader: function () {
return {
vertex: [
'precision mediump float;',
'attribute vec2 position;',
'varying vec2 vTexCoord;',
'void main(void) {',
'vTexCoord = position * 0.5 + 0.5;',
'gl_Position = vec4(position, 0.0, 1.0);',
'}'
].join('\n'),
fragment: [
'precision mediump float;',
'varying vec2 vTexCoord;',
'uniform sampler2D source;',
'uniform float angle;',
'uniform float segments;',
'const float PI = 3.141592653589793;',
'void main(void) {',
'vec2 uv = vTexCoord * 2.0 - 1.0;',
'float r = length(uv);',
'float a = atan(uv.y, uv.x) + radians(angle);',
'float seg = 2.0 * PI / segments;',
'a = mod(a, seg);',
'a = abs(a - seg * 0.5);',
'vec2 newUV = vec2(cos(a), sin(a)) * r;',
'newUV = newUV * 0.5 + 0.5;',
'gl_FragColor = texture2D(source, newUV);',
'}'
].join('\n')
};
}
});

}));