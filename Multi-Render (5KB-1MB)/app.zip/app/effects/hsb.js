/* global define, require */
(function (root, factory) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define(['seriously'], factory);
  } else if (typeof exports === 'object') {
    factory(require('seriously'));
  } else {
    if (!root.Seriously) {
      root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
    }
    factory(root.Seriously);
  }
}(window, function (Seriously) {
  'use strict';

  Seriously.plugin('hslSlider', {
    shader: function (inputs, shaderSource) {
      return `
      precision mediump float;
      varying vec2 vTexCoord;
      uniform sampler2D source;
      uniform float hue;
      uniform float saturation;
      uniform float brightness;

      vec3 rgb2hsv(vec3 c) {
        vec4 K = vec4(0., -1./3., 2./3., -1.);
        vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
        vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
        float d = q.x - min(q.w, q.y);
        float e = 1.0e-10;
        return vec3(abs(q.z + (q.w - q.y)/(6.*d+e)), d/(q.x+e), q.x);
      }

      vec3 hsv2rgb(vec3 c) {
        vec3 p = abs(fract(c.xxx + vec3(0., 1./3., 2./3.))*6. - 3.);
        return c.z * mix(vec3(1.), clamp(p - 1., 0., 1.), c.y);
      }

      void main(void) {
        vec4 color = texture2D(source, vTexCoord);
        vec3 hsv = rgb2hsv(color.rgb);
        hsv.x += hue/360.0;
        hsv.y += saturation/360.0;
        hsv.z += brightness/360.0;
        hsv = clamp(hsv, 0.0, 1.0);
        gl_FragColor = vec4(hsv2rgb(hsv), color.a);
      }
      `;
    },
    in: {
      source: { type: 'image' },
      hue: { type: 'number', min: -360, max: 360, default: 0 },
      saturation: { type: 'number', min: -360, max: 360, default: 0 },
      brightness: { type: 'number', min: -360, max: 360, default: 0 }
    },
    out: { type: 'image' }
  });

}));