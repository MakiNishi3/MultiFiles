/* global define, require */ 
(function (root, factory) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define(['seriously'], factory);
  } else if (typeof exports === 'object') {
    factory(require('seriously'));
  } else {
    if (!root.Seriously) {
      root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
    }
    factory(root.Seriously);
  }
}(window, function (Seriously) {
  'use strict';
  Seriously.plugin('bloom', {
    shader: function (inputs, shaderSource) {
      return {
        fragment: `
          precision mediump float;
          varying vec2 vTexCoord;
          uniform sampler2D source;
          uniform float amount;
          const float offset = 1.0 / 512.0;
          void main() {
            vec4 c = texture2D(source, vTexCoord);
            vec4 bloom = vec4(0.0);
            bloom += texture2D(source, vTexCoord + vec2(-offset, -offset));
            bloom += texture2D(source, vTexCoord + vec2(-offset, offset));
            bloom += texture2D(source, vTexCoord + vec2(offset, -offset));
            bloom += texture2D(source, vTexCoord + vec2(offset, offset));
            bloom *= 0.25;
            gl_FragColor = mix(c, bloom, amount / 200.0);
          }
        `
      };
    },
    inputs: {
      source: { type: 'image', uniform: 'source' },
      amount: { type: 'number', uniform: 'amount', defaultValue: 0, min: 0, max: 200 }
    }
  });
}));