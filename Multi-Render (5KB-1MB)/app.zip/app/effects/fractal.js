/* global define, require */
(function (root, factory) {
'use strict';
if (typeof define === 'function' && define.amd) {
define(['seriously'], factory);
} else if (typeof exports === 'object') {
factory(require('seriously'));
} else {
if (!root.Seriously) {
root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
}
factory(root.Seriously);
}
}(window, function (Seriously) {
'use strict';

Seriously.plugin('fractalWarp', {
inputs: {
source: {
type: 'image',
uniform: 'source'
},
amount: {
type: 'number',
uniform: 'amount',
defaultValue: 0,
min: 0,
max: 200
},
frequency: {
type: 'number',
uniform: 'frequency',
defaultValue: 0,
min: 0,
max: 200
},
speed: {
type: 'number',
uniform: 'speed',
defaultValue: 0,
min: 0,
max: 200
},
time: {
type: 'number',
uniform: 'time',
defaultValue: 0
}
},
shader: function (inputs, shaderSource) {
shaderSource.fragment = [
'precision mediump float;',
'varying vec2 vTexCoord;',
'uniform sampler2D source;',
'uniform float amount;',
'uniform float frequency;',
'uniform float speed;',
'uniform float time;',
'float noise(vec2 p){',
'return sin(p.x)*sin(p.y);',
'}',
'vec2 warp(vec2 uv){',
'float t = time * speed * 0.01;',
'float n = noise(uv * frequency * 0.01 + t);',
'float n2 = noise((uv + n) * frequency * 0.02 - t);',
'uv += vec2(n, n2) * amount * 0.002;',
'return uv;',
'}',
'void main(void){',
'vec2 uv = vTexCoord;',
'uv = warp(uv);',
'gl_FragColor = texture2D(source, uv);',
'}'
].join('\n');
return shaderSource;
}
});

}));