/* global define, require */
(function (root, factory) {
    'use strict';
    if (typeof define === 'function' && define.amd) {
        define(['seriously'], factory);
    } else if (typeof exports === 'object') {
        factory(require('seriously'));
    } else {
        if (!root.Seriously) {
            root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
        }
        factory(root.Seriously);
    }
}(window, function (Seriously) {
    'use strict';
    Seriously.plugin('invert', {
        shader: function (inputs, shaderSource) {
            return {
                frag: [
                    'precision mediump float;',
                    'uniform sampler2D source;',
                    'uniform float amount;',
                    'varying vec2 vTexCoord;',
                    'void main(void) {',
                    '    vec4 color = texture2D(source, vTexCoord);',
                    '    gl_FragColor = mix(color, vec4(1.0 - color.rgb, color.a), amount);',
                    '}'
                ].join('\n')
            };
        },
        inputs: {
            source: { type: 'image', uniform: 'source' },
            amount: { type: 'number', uniform: 'amount', min: 0, max: 1, defaultValue: 1 }
        },
        title: 'Invert',
        description: 'Inverts the colors of the source image.'
    });
}));