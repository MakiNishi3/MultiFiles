/* global define, require */
(function (root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define(['seriously'], factory);
  } else if (typeof exports === 'object') {
    factory(require('seriously'));
  } else {
    if (!root.Seriously) {
      root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
    }
    factory(root.Seriously);
  }
}(window, function (Seriously) {
  'use strict';

  Seriously.plugin('tint', {
    shader: function (inputs, shaderSource) {
      shaderSource.vertex = [
        'precision mediump float;',
        'attribute vec2 position;',
        'attribute vec2 texCoord;',
        'varying vec2 vTexCoord;',
        'void main(void) {',
        '  vTexCoord = texCoord;',
        '  gl_Position = vec4(position, 0.0, 1.0);',
        '}'
      ].join('\n');

      shaderSource.fragment = [
        'precision mediump float;',
        'varying vec2 vTexCoord;',
        'uniform sampler2D source;',
        'uniform vec3 color1;',
        'uniform vec3 color2;',
        'void main(void) {',
        '  vec4 src = texture2D(source, vTexCoord);',
        '  float luminance = dot(src.rgb, vec3(0.299, 0.587, 0.114));',
        '  vec3 tinted = mix(color1, color2, luminance);',
        '  gl_FragColor = vec4(tinted * src.a, src.a);',
        '}'
      ].join('\n');

      return shaderSource;
    },

    inputs: {
      source: {
        type: 'image'
      },
      color1: {
        type: 'color',
        defaultValue: [0, 0, 0],
        min: [0, 0, 0],
        max: [1, 1, 1]
      },
      color2: {
        type: 'color',
        defaultValue: [0, 1, 0],
        min: [0, 0, 0],
        max: [1, 1, 1]
      }
    },

    title: 'Tint'
  });

}));