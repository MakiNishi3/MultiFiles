/* global define, require */
(function (root, factory) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define(['seriously'], factory);
  } else if (typeof exports === 'object') {
    factory(require('seriously'));
  } else {
    if (!root.Seriously) {
      root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
    }
    factory(root.Seriously);
  }
}(window, function (Seriously) {
  'use strict';

  Seriously.plugin('glitch', {
    commonShader: true,
    shader: function (inputs, shaderSource) {
      shaderSource.vertex = [
        'precision mediump float;',
        'attribute vec3 position;',
        'attribute vec2 texCoord;',
        'uniform mat4 transform;',
        'varying vec2 vTexCoord;',
        'void main(void) {',
        '  vTexCoord = texCoord;',
        '  gl_Position = transform * vec4(position, 1.0);',
        '}'
      ].join('\n');

      shaderSource.fragment = [
        'precision mediump float;',
        'varying vec2 vTexCoord;',
        'uniform sampler2D source;',
        'uniform float amount;',
        'uniform float frequency;',
        'uniform float speed;',
        'uniform float time;',

        'float rand(vec2 co) {',
        '  return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);',
        '}',

        'void main(void) {',
        '  vec2 uv = vTexCoord;',
        '  float t = time * speed * 0.01;',
        '  float freq = frequency * 0.01;',
        '  float amt = amount * 0.005;',

        '  float glitch = step(1.0 - freq, rand(vec2(t, uv.y)));',

        '  uv.x += glitch * (rand(vec2(uv.y, t)) - 0.5) * amt;',
        '  uv.y += glitch * (rand(vec2(uv.x, t)) - 0.5) * amt * 0.5;',

        '  vec4 color = texture2D(source, uv);',

        '  float r = texture2D(source, uv + vec2(amt * 0.5, 0.0)).r;',
        '  float g = color.g;',
        '  float b = texture2D(source, uv - vec2(amt * 0.5, 0.0)).b;',

        '  gl_FragColor = vec4(r, g, b, color.a);',
        '}'
      ].join('\n');
    },

    inputs: {
      source: {
        type: 'image',
        uniform: 'source'
      },
      amount: {
        type: 'number',
        uniform: 'amount',
        defaultValue: 0,
        min: 0,
        max: 200
      },
      frequency: {
        type: 'number',
        uniform: 'frequency',
        defaultValue: 0,
        min: 0,
        max: 200
      },
      speed: {
        type: 'number',
        uniform: 'speed',
        defaultValue: 0,
        min: 0,
        max: 200
      },
      time: {
        type: 'number',
        uniform: 'time',
        defaultValue: 0
      }
    },

    title: 'Glitch'
  });

}));