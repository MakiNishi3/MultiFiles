/* global define, require */ (function (root, factory) {  'use strict';
 if (typeof define === 'function' && define.amd) {
  define(['seriously'], factory);
 } else if (typeof exports === 'object') {
  factory(require('seriously'));
 } else {
  if (!root.Seriously) {
   root.Seriously = { plugin: function (name, opt) { this[name] = opt; } };
  }
  factory(root.Seriously);
 }
}(window, function (Seriously) {
 'use strict';

 Seriously.plugin('chromaticAberration', {
  shader: function (inputs, shaderSource) {
   shaderSource.vertex = [
    'precision mediump float;',
    'attribute vec2 position;',
    'attribute vec2 texCoord;',
    'varying vec2 vTexCoord;',
    'void main(void) {',
    'vTexCoord = texCoord;',
    'gl_Position = vec4(position, 0.0, 1.0);',
    '}'
   ].join('\n');

   shaderSource.fragment = [
    'precision mediump float;',
    'varying vec2 vTexCoord;',
    'uniform sampler2D source;',
    'uniform float amount;',
    'uniform float offsetX;',
    'uniform float offsetY;',
    'void main(void) {',
    'vec2 offset = vec2(offsetX, offsetY) * amount;',
    'float r = texture2D(source, vTexCoord + offset).r;',
    'float g = texture2D(source, vTexCoord).g;',
    'float b = texture2D(source, vTexCoord - offset).b;',
    'gl_FragColor = vec4(r, g, b, 1.0);',
    '}'
   ].join('\n');
  },

  inPlace: true,
  inputs: {
   source: {
    type: 'image',
    uniform: 'source'
   },
   amount: {
    type: 'number',
    uniform: 'amount',
    min: 0,
    max: 100,
    defaultValue: 0
   },
   x: {
    type: 'number',
    uniform: 'offsetX',
    min: 0,
    max: 100,
    defaultValue: 0
   },
   y: {
    type: 'number',
    uniform: 'offsetY',
    min: 0,
    max: 100,
    defaultValue: 0
   }
  }
 });

}));