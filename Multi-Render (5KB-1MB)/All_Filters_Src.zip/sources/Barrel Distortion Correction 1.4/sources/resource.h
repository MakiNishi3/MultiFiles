//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_BARREL_DISTORTION    101
#define IDC_BILINEAR                    1001
#define IDC_EBETA                       1002
#define IDC_EALPHA                      1003
#define IDC_VERT                        1004
#define IDC_HORIZ                       1005
#define IDC_AR                          1006
#define IDC_ALP                         1007
#define IDC_BET                         1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
