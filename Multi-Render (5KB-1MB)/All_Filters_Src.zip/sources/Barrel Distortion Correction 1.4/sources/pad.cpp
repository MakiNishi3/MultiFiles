/*  PAD Control - control for VirtualDub's filters
    Copyright (C) 2003 Emiliano Ferrari

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA

    Emiliano Ferrari
    e-mail: macinapepe@tiscali.it                                */

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>

#define VLCN_PADCHANGE 2

typedef struct
{
  NMHDR hdr;
  int dx,dy;
} NMVLPADCHANGE;

const char g_szPadControlName[]="bdPadControl";

typedef struct
{
  int sx,sy,ex,ey;
  bool capture;  
} PadControlData;


static LRESULT APIENTRY PadControlWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  PadControlData *pcd= (PadControlData *)GetWindowLong(hwnd, 0);

  switch(msg)
  {
    case WM_NCCREATE:
      if (!(pcd = new PadControlData)) return FALSE;
      memset(pcd,0,sizeof(PadControlData));
      pcd->capture= false;
      SetWindowLong(hwnd, 0, (LONG)pcd);
      return TRUE;

    case WM_CREATE:
    case WM_SIZE:
      break;

    case WM_DESTROY:
        delete pcd;
        SetWindowLong(hwnd, 0, 0);
        break;

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc;
        hdc= BeginPaint(hwnd, &ps);
        EndPaint(hwnd, &ps);
        break;
    }

    case WM_LBUTTONDOWN:
        {
          unsigned short px= LOWORD(lParam);
          unsigned short py= HIWORD(lParam);
          pcd->sx= *((short *)&px);
          pcd->sy= *((short *)&py);
          pcd->capture= true;
          SetCapture(hwnd);
        }
       break;

    case WM_LBUTTONUP:
        if (pcd->capture)
        {
          ReleaseCapture();
          pcd->capture= false;
        }
        break;

    case WM_MOUSEMOVE:
       if (pcd->capture)
       {
          unsigned short px= LOWORD(lParam);
          unsigned short py= HIWORD(lParam);
          pcd->ex= *((short *)&px);
          pcd->ey= *((short *)&py);
          NMVLPADCHANGE nmvltc;
          nmvltc.hdr.code    = VLCN_PADCHANGE;
          nmvltc.hdr.hwndFrom= hwnd;
          nmvltc.hdr.idFrom  = GetWindowLong(hwnd, GWL_ID);
          nmvltc.dx= pcd->ex-pcd->sx;
          nmvltc.dy= pcd->ey-pcd->sy;
          SendMessage(GetParent(hwnd), WM_NOTIFY, nmvltc.hdr.idFrom, (LPARAM)&nmvltc);
          pcd->sx= pcd->ex;
          pcd->sy= pcd->ey;
        }
        break;

    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return FALSE;
}

void RegisterPadControl(HINSTANCE hinst)
{

  WNDCLASS wc;
  wc.style= 0;
  wc.lpfnWndProc= PadControlWndProc;
  wc.cbClsExtra= 0;
  wc.cbWndExtra= sizeof(PadControlData *);
  wc.hInstance= hinst;
  wc.hIcon= NULL;
  wc.hCursor= LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground= (HBRUSH)(COLOR_3DFACE);
  wc.lpszMenuName= NULL;
  wc.lpszClassName= g_szPadControlName;
  RegisterClass(&wc);
}


/*
    case WM_NOTIFY:
      if (IDC_PAD==(int)wParam)
      {
        NMHDR *pnmh= (NMHDR *)lParam;
        NMVLPADCHANGE *pnmvltc= (NMVLPADCHANGE *)lParam;
        mfd->x+= pnmvltc->dx;
        mfd->y+= pnmvltc->dy;
        if (mfd->x<0) mfd->x=0;
        if (mfd->y<0) mfd->y=0;
        SetDlgItemInt(hdlg,IDC_X,mfd->x,false);
        SetDlgItemInt(hdlg,IDC_Y,mfd->y,false);
        mfd->ifp->RedoFrame();
      }
      break;



  RegisterPadControl(fa->filter->module->hInstModule);
*/
