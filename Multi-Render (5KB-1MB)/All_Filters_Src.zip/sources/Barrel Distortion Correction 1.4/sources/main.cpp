/*  Barrel Distortion Correction 1.1 - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari

    based on QuickWarp version 0.1 image warping module for QuickCam.
    Copyright (C) 1996 Michael Herf (herf@cmu.edu). under GPL license.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA

    Emiliano Ferrari
    e-mail: macinapepe@tiscali.it                                */

#include <math.h>
#include <stdio.h>
#include "resource.h"
#include "filter.h"
#include <windows.h>
#include <commctrl.h>
#include "ScriptValue.h"
#include "pad.cpp"

#define MASK 1023    // 2^10-1
#define M 1024.0     // 2^10
#define N 10         // fixpoint 12.10  max. picture size 4096x4096.

typedef struct
{
  IFilterPreview *ifp;
  float alpha,beta;
  int *px,*py,w,h;
  bool bilinear,vert,horiz,ar;
} MyFilterData;

void BuildTables (int w,int h,float alpha,float beta,int *px,int *py,bool vert,bool horiz,bool ar)
{ // no time critical code
  w= (w & ~1); // prevent bug on odd size
  h= (h & ~1);
  float cx= w/2.0f-0.5f;
  float cy= h/2.0f-0.5f;
  int hx= w/2;
  int hy= h/2;
  int x,y;

  if (!px) return;
  if (!py) return;

  for (y=0; y<=hy; y++)
    for (x=0; x<=hx; x++)
      {
        float dx= x-cx;
        float dy= y-cy;
        float xr,yr;
        float rcx= (float)(sqrt (dx*dx + dy*dy)/(cx+0.5f));
        float rcy;
        if (ar) rcy= (float)(sqrt (dx*dx + dy*dy)/(cy+0.5f));
          else  rcy= (float)(sqrt (dx*dx + dy*dy)/(cx+0.5f));

        float rpx= rcx;
        float rpy= rcy;

        if (horiz) rpx+= alpha*rcx*rcx*rcx+ beta*rcx*rcx*rcx*rcx*rcx;
        if (vert)  rpy+= alpha*rcy*rcy*rcy+ beta*rcy*rcy*rcy*rcy*rcy;

        if (rcx!=0.0f) xr= rpx*dx/rcx; else xr=0.0f;
        if (rcy!=0.0f) yr= rpy*dy/rcy; else yr=0.0f;
        if ((cx+xr)<2.0f) xr= 2.0f-cx;
        if ((cy+yr)<2.0f) yr= 2.0f-cy;
        px[x+y*hx]= (int) (M*xr);
        py[x+y*hx]= (int) (M*yr);
    }
}

// ========================== [ Main Code (time critical) ] =====================

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

Pixel32 bilinear (int x,int y,Pixel32 *src,int w,int h,int pitch)
{ // MMX optimizable
   int fx, fy;
   Pixel32 p0,p1,p2,p3;
   int b0,b1,b2,b3,g0,g1,g2,g3;
   int r0,r1,r2,r3;

   int ix= x>>N; fx= x & MASK;
   int iy= y>>N; fy= y & MASK;

   int nx= ix+1;
   int ny= iy+1;

   Clipping (nx,0,w);
   Clipping (ny,0,h);

   p0= src[ix+iy*pitch];
   p1= src[nx+iy*pitch];
   p2= src[ix+ny*pitch];
   p3= src[nx+ny*pitch];

   b0= p0 & 0x000000ff;
   b1= p1 & 0x000000ff;
   b2= p2 & 0x000000ff;
   b3= p3 & 0x000000ff;

   g0= (p0>>8) & 0x0000ff;
   g1= (p1>>8) & 0x0000ff;
   g2= (p2>>8) & 0x0000ff;
   g3= (p3>>8) & 0x0000ff;

   r0= (p0>>16) & 0x0000ff;
   r1= (p1>>16) & 0x0000ff;
   r2= (p2>>16) & 0x0000ff;
   r3= (p3>>16) & 0x0000ff;

   b0= (b0<<N) + fx * (b1-b0);
   b1= (b2<<N) + fx * (b3-b2);
   b0= (b0 + (fy*(b1-b0)>>N))>>N;

   g0= (g0<<N) + fx * (g1-g0);
   g1= (g2<<N) + fx * (g3-g2);
   g0= (g0 + (fy*(g1-g0)>>N))>>N;

   r0= (r0<<N) + fx * (r1-r0);
   r1= (r2<<N) + fx * (r3-r2);
   r0= (r0 + (fy*(r1-r0)>>N))>>N;

   return (Pixel32)((b0&0xff)|((g0&0xff)<<8)|((r0&0xff)<<16));
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  Pixel32 *src= fa->src.data;
  int w= fa->dst.w;
  int h= fa->dst.h;
  w= (w & ~1); // bug on odd size
  h= (h & ~1);
  const int pitch= fa->dst.pitch>>2;
  float cx= w/2.0f-0.5f;
  float cy= h/2.0f-0.5f;
  int hx= w/2;
  int hy= h/2;
  int x,y;

  if (!mfd->px) return 1;
  if (!mfd->py) return 1;

  int cx6= (int)(cx*M);
  int cy6= (int)(cy*M);

  if (!mfd->bilinear)

    for (y=0; y<hy; y++) // nearest neighbour
       for (x=0; x<hx; x++)
      {
         int fx= (cx6+mfd->px[x+y*hx])>>N;
         int fy= (cy6+mfd->py[x+y*hx])>>N;
         Clipping (fx,0,w);
         Clipping (fy,0,h);
         dst[x+y*pitch]=src[fx+fy*pitch];

         fx= (cx6-mfd->px[x+y*hx])>>N;
         fy= (cy6+mfd->py[x+y*hx])>>N;
         Clipping (fx,0,w);
         Clipping (fy,0,h);
         dst[(w-x-1)+y*pitch]=src[fx+fy*pitch];

         fx= (cx6+mfd->px[x+y*hx])>>N;
         fy= (cy6-mfd->py[x+y*hx])>>N;
         Clipping (fx,0,w);
         Clipping (fy,0,h);
         dst[x+(h-y-1)*pitch]= src[fx+fy*pitch];

         fx= (cx6-mfd->px[x+y*hx])>>N;
         fy= (cy6-mfd->py[x+y*hx])>>N;
         Clipping (fx,0,w);
         Clipping (fy,0,h);
         dst[(w-x-1)+(h-y-1)*pitch]= src[fx+fy*pitch];
      }
  else // bilinear
    for (y=0; y<hy; y++)
       for (x=0; x<hx; x++)
      {
         int fx= (cx6+mfd->px[x+y*hx]);
         int fy= (cy6+mfd->py[x+y*hx]);
         Clipping (fx,0,w<<N);
         Clipping (fy,0,h<<N);
         dst[x+y*pitch]= bilinear (fx,fy,src,w,h,pitch);

          fx= (cx6-mfd->px[x+y*hx]);
         fy= (cy6+mfd->py[x+y*hx]);
         Clipping (fx,0,w<<N);
         Clipping (fy,0,h<<N);
         dst[(w-x-1)+y*pitch]= bilinear (fx,fy,src,w,h,pitch);

         fx= (cx6+mfd->px[x+y*hx]);
         fy= (cy6-mfd->py[x+y*hx]);
         Clipping (fx,0,w<<N);
         Clipping (fy,0,h<<N);
         dst[x+(h-y-1)*pitch]= bilinear (fx,fy,src,w,h,pitch);

         fx= (cx6-mfd->px[x+y*hx]);
         fy= (cy6-mfd->py[x+y*hx]);
         Clipping (fx,0,w<<N);
         Clipping (fy,0,h<<N);
         dst[(w-x-1)+(h-y-1)*pitch]= bilinear (fx,fy,src,w,h,pitch);
      }
  return 0;
}

// ===================== [Startup/End Code] ==============================

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->alpha= 0.0f;
  mfd->beta=  0.0f;
  mfd->px= NULL;
  mfd->py= NULL;
  mfd->vert= true;
  mfd->horiz= true;
  mfd->bilinear= true;
  mfd->ar= true;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;

  if (mfd->px) { delete[]mfd->px; mfd->px= NULL; }
  if (mfd->py) { delete[]mfd->py; mfd->py= NULL; }

  int size= (fa->dst.w/2+1)*(fa->dst.h/2+1)+16;
  mfd->px= new int[size];
  if (!mfd->px) ff->ExceptOutOfMemory();
  mfd->py= new int[size];
  if (!mfd->py) { delete[]mfd->px; mfd->px=NULL; ff->ExceptOutOfMemory(); }
  mfd->w= fa->dst.w;
  mfd->h= fa->dst.h;
  BuildTables(fa->dst.w,fa->dst.h,mfd->alpha,mfd->beta,mfd->px,mfd->py,mfd->vert,mfd->horiz,mfd->ar);
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  if (mfd->px) { delete[]mfd->px; mfd->px= NULL; }
  if (mfd->py) { delete[]mfd->py; mfd->py= NULL; }
  return 0;
}

long ParamProc(FilterActivation *fa,const FilterFunctions *ff)
{
  return FILTERPARAM_SWAP_BUFFERS;
}

// =========================== [INTERFACE] ==============================================

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char tmp[128];
  static bool enabled= false;

  switch(msg)
  {
    case WM_INITDIALOG:
      enabled=false;
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      _snprintf (tmp,128,"%1.5f",mfd->alpha);
      SetDlgItemText(hdlg, IDC_EALPHA,tmp);
      _snprintf (tmp,128,"%1.5f",mfd->beta);
      SetDlgItemText(hdlg, IDC_EBETA,tmp);
      CheckDlgButton(hdlg, IDC_BILINEAR, mfd->bilinear ? BST_CHECKED : BST_UNCHECKED);
      CheckDlgButton(hdlg, IDC_VERT, mfd->vert ? BST_CHECKED : BST_UNCHECKED);
      CheckDlgButton(hdlg, IDC_HORIZ, mfd->horiz ? BST_CHECKED : BST_UNCHECKED);
      CheckDlgButton(hdlg, IDC_AR, mfd->ar ? BST_CHECKED : BST_UNCHECKED);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      enabled= true;
      return TRUE;

    case WM_NOTIFY:
        if (!enabled) break;

      if (IDC_ALP==(int)wParam)
      {
        NMHDR *pnmh= (NMHDR *)lParam;
        NMVLPADCHANGE *pnmvltc= (NMVLPADCHANGE *)lParam;
        mfd->alpha+= pnmvltc->dx/1000.0f;
        _snprintf (tmp,128,"%1.5f",mfd->alpha);
        SetDlgItemText(hdlg, IDC_EALPHA,tmp);
        BuildTables(mfd->w,mfd->h,mfd->alpha,mfd->beta,mfd->px,mfd->py,mfd->vert,mfd->horiz,mfd->ar);
        mfd->ifp->RedoFrame();
      }
      else
      if (IDC_BET==(int)wParam)
      {
        NMHDR *pnmh= (NMHDR *)lParam;
        NMVLPADCHANGE *pnmvltc= (NMVLPADCHANGE *)lParam;
        mfd->beta+= pnmvltc->dx/1000.0f;
        _snprintf (tmp,128,"%1.5f",mfd->beta);
        SetDlgItemText(hdlg, IDC_EBETA,tmp);
        BuildTables(mfd->w,mfd->h,mfd->alpha,mfd->beta,mfd->px,mfd->py,mfd->vert,mfd->horiz,mfd->ar);
        mfd->ifp->RedoFrame();
      }
      break;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;

        case IDC_VERT:
          mfd->vert= !!IsDlgButtonChecked(hdlg, IDC_VERT);
          BuildTables(mfd->w,mfd->h,mfd->alpha,mfd->beta,mfd->px,mfd->py,mfd->vert,mfd->horiz,mfd->ar);
          mfd->ifp->RedoFrame();
          break;
        case IDC_HORIZ:
          mfd->horiz= !!IsDlgButtonChecked(hdlg, IDC_HORIZ);
          BuildTables(mfd->w,mfd->h,mfd->alpha,mfd->beta,mfd->px,mfd->py,mfd->vert,mfd->horiz,mfd->ar);
          mfd->ifp->RedoFrame();
          break;

          case IDC_AR:
          mfd->ar= !!IsDlgButtonChecked(hdlg, IDC_AR);
          BuildTables(mfd->w,mfd->h,mfd->alpha,mfd->beta,mfd->px,mfd->py,mfd->vert,mfd->horiz,mfd->ar);
          mfd->ifp->RedoFrame();
          break;
        case IDC_BILINEAR:
          mfd->bilinear= !!IsDlgButtonChecked(hdlg, IDC_BILINEAR);
          mfd->ifp->RedoFrame();
          break;

        case IDC_EALPHA:
               if (HIWORD(wParam)==EN_CHANGE && mfd!=NULL)
            {
                char talpha[20];
                float alpha;
                GetDlgItemText (hdlg,IDC_EALPHA,talpha,sizeof(talpha));

                sscanf (talpha,"%f",&alpha);

                if (alpha!=mfd->alpha)
                {
                  mfd->alpha= alpha;
                  BuildTables(mfd->w,mfd->h,mfd->alpha,mfd->beta,mfd->px,mfd->py,mfd->vert,mfd->horiz,mfd->ar);
                  mfd->ifp->RedoFrame();
                }
            }
            break;
        case IDC_EBETA:
            if (HIWORD(wParam)==EN_CHANGE && mfd!=NULL)
            {
                char tbeta[20];
                float beta;

                GetDlgItemText (hdlg,IDC_EBETA ,tbeta ,sizeof(tbeta));

                sscanf (tbeta ,"%f",&beta);
                if (beta!=mfd->beta)
                {

                  mfd->beta= beta;
                  BuildTables(mfd->w,mfd->h,mfd->alpha,mfd->beta,mfd->px,mfd->py,mfd->vert,mfd->horiz,mfd->ar);
                  mfd->ifp->RedoFrame();
                }
            }
            break;
      }
      break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  RegisterPadControl(fa->filter->module->hInstModule);
  int Resoult= DialogBoxParam (fa->filter->module->hInstModule,
                               MAKEINTRESOURCE(IDD_FILTER_BARREL_DISTORTION),
                               hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (Resoult) *mfd= mfd_old;
  return !!Resoult;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(\"%1.5f\", \"%1.5f\", %d,%d,%d,%d )",mfd->alpha,mfd->beta,mfd->bilinear,mfd->vert,mfd->horiz,mfd->ar);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  sscanf(*argv[0].asString(),"%f",&mfd->alpha);
  sscanf(*argv[1].asString(),"%f",&mfd->beta);
  mfd->bilinear= !!argv[2].asInt();
  mfd->vert= !!argv[3].asInt();
  mfd->horiz= !!argv[4].asInt();
  mfd->ar= !!argv[5].asInt();
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0ssiiii"},{NULL},};
     CScriptObject script_obj= {NULL,func_defs};


void stringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(str,64, " (ALPHA:%1.5f  BETA:%1.5f [%s%s%s%s])",mfd->alpha,mfd->beta,mfd->horiz?"H":"-",mfd->vert?"V":"-",mfd->ar?".AR":".--",mfd->bilinear?".B":".-");
}

// =========================== [ Filter Registration ] ===============================

FilterDefinition filterDef_BarrelDistortion=
{  NULL, NULL, NULL,           // next, prev, module
  "Barrel Distortion",         // name
  "Remove or add barrel/pincushion distortion.\n"
  "Version 1.4 (14-10-2003)\n",// desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  stringProc,                  // stringProc
  StartProc,                   // startProc
  EndProc,                     // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd_BarrelDistortion;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_BarrelDistortion= ff->addFilter(fm, &filterDef_BarrelDistortion, sizeof(FilterDefinition));
  if (!fd_BarrelDistortion) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_BarrelDistortion);
}
