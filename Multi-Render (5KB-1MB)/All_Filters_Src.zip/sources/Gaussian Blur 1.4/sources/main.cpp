/*  Gaussian Blur - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari    <macinapepe@tiscali.it>

    based on GIMP code

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// Version 1.3 (30-09-2003)
// Version 1.4 (31-10-2004): rimossi piccoli bug (buffer overflow)

#include <math.h>
#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "ScriptValue.h"
#include "resource.h"

typedef struct
{
  IFilterPreview *ifp;
  int  horz,vert;
  double hbdp[5],hbdm[5],hnp[5],hnm[5],hdp[5],hdm[5];
  double vbdp[5],vbdm[5],vnp[5],vnm[5],vdp[5],vdm[5];
  int hcurve[2048],hlength;
  int vcurve[2048],vlength;

  bool link;
} MyFilterData;

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void find_constants(double np[],double nm[],double dp[],double dm[],double bdp[],double bdm[],double radius)
{
  int i;
  double sum_np,sum_nm,sum_d,a,b;

  const double R= fabs(radius*2.0+1.0)+1.0;
  const double sigma= sqrt(-(R*R)/(2*log(1.0/255.0)));
  const double div = sqrt(2 * 3.14156) * sigma;
  const double K0= -1.783 / sigma;
  const double K1= -1.723 / sigma;
  const double K2=  0.6318/ sigma;
  const double K3=  1.997 / sigma;
  const double K4=  1.6803/ div;
  const double K5=  3.735 / div;
  const double K6= -0.6803/ div;
  const double K7= -0.2598/ div;
  np[0]= K4+K6;
  np[1]= exp(K1)*(K7*sin(K3)-(K6+2*K4)*cos(K3))+exp(K0)*(K5*sin(K2)-(2*K6+K4)*cos(K2));
  np[2]= 2*exp(K0+K1)*((K4+K6)*cos(K3)*cos(K2)-K5*cos(K3)*sin(K2)-K7*cos(K2)*sin(K3))+K6*exp(2*K0)+K4*exp(2*K1);
  np[3]= exp(K1+2*K0)*(K7*sin(K3)-K6*cos(K3))+exp(K0+2*K1)*(K5*sin(K2)-K4*cos(K2));
  np[4]= 0.0;
  dp[0]= 0.0;
  dp[1]= -2*exp(K1)*cos(K3)-2*exp(K0)*cos(K2);
  dp[2]=  4*cos(K3)*cos(K2)*exp(K0+K1)+exp(2*K1)+exp(2*K0);
  dp[3]= -2*cos(K2)*exp(K0+2*K1)-2*cos(K3)*exp(K1+2*K0);
  dp[4]= exp(2*K0+2*K1);
  for (i=0; i<=4; i++) dm[i]= dp[i];
  nm[0] = 0.0;
  for (i=1; i<=4; i++) nm[i]= np[i]-dp[i]*np[0];
  sum_np= 0.0;
  sum_nm= 0.0;
  sum_d = 0.0;
  for (i=0; i<=4; i++)
  {
    sum_np+= np[i];
    sum_nm+= nm[i];
    sum_d += dp[i];
  }
  a= sum_np/(1.0+sum_d);
  b= sum_nm/(1.0+sum_d);
  for (i=0; i<=4; i++)
  {
    bdp[i]= dp[i]*a;
    bdm[i]= dm[i]*b;
  }
}

void MakeCurve(double radius,int &length,int *curve)
{
  double R= fabs(radius*2.0+1.0)+1.0;
  double sigma= sqrt(-(R*R)/(2.0*log(1.0/255.0)));
  double sigma2= 2.0*sigma*sigma;
  double l= sqrt(-sigma2*log(1.0/255.0));
  double dCurve[2048],total;
  int i, n= ((int)ceil(l)*2)|1;
  length= n/2;
  total= dCurve[length]= 1.0;
  for (i=1; i<=length; i++)
  {
    dCurve[length+i]= exp(-(i*i)/sigma2);
    total+= 2*dCurve[length+i];
  }
  for (i= 0; i<=length; i++)
     curve[length-i]=curve[length+i]= (int)(65536*(dCurve[length+i]/total));
}

void BuildTables (MyFilterData *mfd)
{
  find_constants (mfd->hnp,mfd->hnm,mfd->hdp,mfd->hdm,mfd->hbdp,mfd->hbdm,mfd->horz/100.0);
  find_constants (mfd->vnp,mfd->vnm,mfd->vdp,mfd->vdm,mfd->vbdp,mfd->vbdm,mfd->vert/100.0);
  MakeCurve(mfd->vert/100.0,mfd->vlength,mfd->vcurve);
  MakeCurve(mfd->horz/100.0,mfd->hlength,mfd->hcurve);

}

int STD_RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  Pixel32 *dst= fa->dst.data;
  const int w= fa->dst.w;
  const int h= fa->dst.h;
  const int pitch= fa->dst.pitch>>2;
  const int hlength= mfd->hlength;
  const int vlength= mfd->vlength;
  int x,y,i,l,r,g,b;
  Pixel32 p;

  if (w>=(4096-256)) return -1;
  static int rtemp[4096];
  static int gtemp[4096];
  static int btemp[4096];

  // HORIZONTAL GAUSSIAN BLUR

  if (mfd->horz>0)
  for (y=0; y<h; y++)
  {
      for (i=0; i<w+256; i++) rtemp[i]=gtemp[i]=btemp[i]=0;
      for (x=0; x<w; x++)
      {
          p= dst[x];
          r= (p>>16)&0xff;
          g= (p>>8)&0xff;
          b= p&0xff;

          int *rt= rtemp+(128+x-hlength);
          int *gt= gtemp+(128+x-hlength);
          int *bt= btemp+(128+x-hlength);
          int *vv= mfd->hcurve;

          for (l= -hlength; l<=hlength; l++)
          {
              *rt+= *vv * r;
              *gt+= *vv * g;
              *bt+= *vv * b;

              rt++; gt++; bt++; vv++;
          }
      }

      for (i=0; i<128; i++)
      {
          rtemp[i+128]+= rtemp[127-i];
          gtemp[i+128]+= gtemp[127-i];
          btemp[i+128]+= btemp[127-i];
          rtemp[(w-i)+127]+= rtemp[w+i+128];
          gtemp[(w-i)+127]+= gtemp[w+i+128];
          btemp[(w-i)+127]+= btemp[w+i+128];
      }

      for (i=0; i<w; i++)
      {
        r= rtemp[i+128]>>16;
        g= gtemp[i+128]>>16;
        b= btemp[i+128]>>16;

        if ((unsigned)r>255) r=(~r>>31)&255;
        if ((unsigned)g>255) g=(~g>>31)&255;
        if ((unsigned)b>255) b=(~b>>31)&255;

        dst[i]= (r<<16) | (g<<8) | b;
      }
    dst+= pitch;
  }

  if (mfd->vert==0) return 0;
  // VERTICAL GAUSSIAN BLUR
  dst= fa->dst.data;
  for (x=0; x<w; x++)
  {
      for (i=0; i<h+256; i++) rtemp[i]=gtemp[i]=btemp[i]=0;
      for (y=0; y<h; y++)
      {
          p= dst[x+y*pitch];
          r= (p>>16)&0xff;
          g= (p>>8)&0xff;
          b= p&0xff;

            int *rt= rtemp+(128+y-vlength);
          int *gt= gtemp+(128+y-vlength);
          int *bt= btemp+(128+y-vlength);
          int *vv= mfd->vcurve;

          for (l= -vlength; l<=vlength; l++)
          {
              *rt+= *vv * r;
              *gt+= *vv * g;
              *bt+= *vv * b;

              rt++; gt++; bt++; vv++;
          }
      }

      for (i=0; i<128; i++)
      {
          rtemp[i+128]+= rtemp[127-i];
          gtemp[i+128]+= gtemp[127-i];
          btemp[i+128]+= btemp[127-i];
          rtemp[(h-i)+127]+= rtemp[h+i+128];
          gtemp[(h-i)+127]+= gtemp[h+i+128];
          btemp[(h-i)+127]+= btemp[h+i+128];
      }

      for (i=0; i<h; i++)
      {
        r= rtemp[i+128]>>16;
        g= gtemp[i+128]>>16;
        b= btemp[i+128]>>16;

        if ((unsigned)r>255) r=(~r>>31)&255; // funziona solo con interi a 32 bit!!!
        if ((unsigned)g>255) g=(~g>>31)&255;
        if ((unsigned)b>255) b=(~b>>31)&255;

        dst[x+i*pitch]= (r<<16) | (g<<8) | b;
      }
  }
 return 0;
}


int IIR_RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const int pitch= fa->dst.pitch>>2;
  Pixel32 *dst= fa->dst.data;
  const int w= fa->dst.w;
  const int h= fa->dst.h;
  int rtemp[2048];
  int gtemp[2048];
  int btemp[2048];
  double rvpa[2048],rvma[2048];
  double gvpa[2048],gvma[2048];
  double bvpa[2048],bvma[2048];
  int rs,gs,bs;
  int x,i,y,j;
  double *vbdp= mfd->vbdp;
  double *vbdm= mfd->vbdm;
  double *vnp= mfd->vnp;
  double *vnm= mfd->vnm;
  double *vdp= mfd->vdp;
  double *vdm= mfd->vdm;
  double *hbdp= mfd->hbdp;
  double *hbdm= mfd->hbdm;
  double *hnp= mfd->hnp;
  double *hnm= mfd->hnm;
  double *hdp= mfd->hdp;
  double *hdm= mfd->hdm;

  if (mfd->vert>0)

  for (x=0; x<w; x++)
  {

    for (y=0; y<h; y++)
    {
      rtemp[y]= (dst[x+y*pitch]>>16)&0xff;
      gtemp[y]= (dst[x+y*pitch]>> 8)&0xff;
      btemp[y]= (dst[x+y*pitch]    )&0xff;
      rvpa[y]= rvma[y]= 0;
      gvpa[y]= gvma[y]= 0;
      bvpa[y]= bvma[y]= 0;
    }
    rs= rtemp[0];
    gs= gtemp[0];
    bs= btemp[0];
    int *rp= rtemp;
    int *gp= gtemp;
    int *bp= btemp;
    int *rm= rtemp+(h-1);
    int *gm= gtemp+(h-1);
    int *bm= btemp+(h-1);
    double *rvp= rvpa;
    double *gvp= gvpa;
    double *bvp= bvpa;
    double *rvm= rvma+(h-1);
    double *gvm= gvma+(h-1);
    double *bvm= bvma+(h-1);

     for (y=0; y<h; y++)
      {
        int t= (y<4)?y:4;

        for (i=0; i<=t; i++)
        {
          *rvp+= vnp[i]*rp[-i]-vdp[i]*rvp[-i];
          *rvm+= vnm[i]*rm[ i]-vdm[i]*rvm[ i];
          *gvp+= vnp[i]*gp[-i]-vdp[i]*gvp[-i];
          *gvm+= vnm[i]*gm[ i]-vdm[i]*gvm[ i];
          *bvp+= vnp[i]*bp[-i]-vdp[i]*bvp[-i];
          *bvm+= vnm[i]*bm[ i]-vdm[i]*bvm[ i];
        }

        for (j=i; j<=4; j++)
        {
          *rvp+= (vnp[j]-vbdp[j])*rs;
          *rvm+= (vnm[j]-vbdm[j])*rs;
          *gvp+= (vnp[j]-vbdp[j])*gs;
          *gvm+= (vnm[j]-vbdm[j])*gs;
          *bvp+= (vnp[j]-vbdp[j])*bs;
          *bvm+= (vnm[j]-vbdm[j])*bs;
        }

        rp++; gp++; bp++;
        rm--; gm--; bm--;
        rvp++; gvp++; bvp++;
        rvm--; gvm--; bvm--;
      }

    for (y=0; y<h; y++)
    {
      int r= (int)(rvpa[y]+rvma[y]);
      int g= (int)(gvpa[y]+gvma[y]);
      int b= (int)(bvpa[y]+bvma[y]);
      if ((unsigned)r>255) r= (~r>>31)&0xff;
      if ((unsigned)g>255) g= (~g>>31)&0xff;
      if ((unsigned)b>255) b= (~b>>31)&0xff;
      dst[x+y*pitch]= (r<<16) | (g<<8) | b;
    }
  }

  if (mfd->horz>0)
  for (y=0; y<h; y++)
  {
    for (x=0; x<w; x++)
    {
      rtemp[x]= (dst[x+y*pitch]>>16)&0xff;
      gtemp[x]= (dst[x+y*pitch]>> 8)&0xff;
      btemp[x]= (dst[x+y*pitch]    )&0xff;
      rvpa[x]= rvma[x]= 0;
      gvpa[x]= gvma[x]= 0;
      bvpa[x]= bvma[x]= 0;
    }
    rs= rtemp[0];
    gs= gtemp[0];
    bs= btemp[0];
    int *rp= rtemp;
    int *gp= gtemp;
    int *bp= btemp;
    int *rm= rtemp+(w-1);
    int *gm= gtemp+(w-1);
    int *bm= btemp+(w-1);
    double *rvp= rvpa;
    double *gvp= gvpa;
    double *bvp= bvpa;
    double *rvm= rvma+(w-1);
    double *gvm= gvma+(w-1);
    double *bvm= bvma+(w-1);

     for (x=0; x<w; x++)
      {
        int t= (x<4)?x:4;

        for (i=0; i<=t; i++)
        {
          *rvp+= hnp[i]*rp[-i]-hdp[i]*rvp[-i];
          *rvm+= hnm[i]*rm[ i]-hdm[i]*rvm[ i];
          *gvp+= hnp[i]*gp[-i]-hdp[i]*gvp[-i];
          *gvm+= hnm[i]*gm[ i]-hdm[i]*gvm[ i];
          *bvp+= hnp[i]*bp[-i]-hdp[i]*bvp[-i];
          *bvm+= hnm[i]*bm[ i]-hdm[i]*bvm[ i];
        }

        for (j=i; j<=4; j++)
        {
          *rvp+= (hnp[j]-hbdp[j])*rs;
          *rvm+= (hnm[j]-hbdm[j])*rs;
          *gvp+= (hnp[j]-hbdp[j])*gs;
          *gvm+= (hnm[j]-hbdm[j])*gs;
          *bvp+= (hnp[j]-hbdp[j])*bs;
          *bvm+= (hnm[j]-hbdm[j])*bs;
        }

        rp++; gp++; bp++;
        rm--; gm--; bm--;
        rvp++; gvp++; bvp++;
        rvm--; gvm--; bvm--;
      }

    for (x=0; x<w; x++)
    {
      int r= (int)(rvpa[x]+rvma[x]);
      int g= (int)(gvpa[x]+gvma[x]);
      int b= (int)(bvpa[x]+bvma[x]);
      if ((unsigned)r>255) r= (~r>>31)&0xff; // funziona solo con interi a 32 bit !!!
      if ((unsigned)g>255) g= (~g>>31)&0xff;
      if ((unsigned)b>255) b= (~b>>31)&0xff;
      dst[x+y*pitch]= (r<<16) | (g<<8) | b;
    }
  }

  return 0;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  if (mfd->horz>120 || mfd->vert>120)
    return IIR_RunProc(fa,ff);
  else
    return STD_RunProc(fa,ff);
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->horz= 100;
  mfd->vert= 100;
  BuildTables(mfd);
  mfd->link= true;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char tmp[128];

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg, IDC_HORZ),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,4000));
      SendMessage(GetDlgItem(hdlg, IDC_HORZ),TBM_SETPOS,(WPARAM)TRUE,mfd->horz);
      _snprintf(tmp,128,"%1.2f",mfd->horz/100.0f);
      SetDlgItemText(hdlg, IDC_VHORZ,tmp);

      SendMessage(GetDlgItem(hdlg, IDC_VERT),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,4000));
      SendMessage(GetDlgItem(hdlg, IDC_VERT),TBM_SETPOS,(WPARAM)TRUE,mfd->vert);
      _snprintf(tmp,128,"%1.2f",mfd->vert/100.0f);
      SetDlgItemText(hdlg, IDC_VVERT,tmp);
      CheckDlgButton(hdlg, IDC_LINK, mfd->link ? BST_CHECKED : BST_UNCHECKED);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;
        case IDC_LINK: mfd->link = !!IsDlgButtonChecked(hdlg, IDC_LINK);break;
      }
      break;

    case WM_HSCROLL:
    {
      int h= SendMessage(GetDlgItem(hdlg,IDC_HORZ),TBM_GETPOS,0,0);
      int v= SendMessage(GetDlgItem(hdlg,IDC_VERT),TBM_GETPOS,0,0);

        if (mfd->link)
        {
          int d= (h-mfd->horz)+(v-mfd->vert);
          h= mfd->horz+d;
          v= mfd->vert+d;
          Clipping (h,0,4000);
          Clipping (v,0,4000);
          SendMessage(GetDlgItem(hdlg,IDC_HORZ),TBM_SETPOS,(WPARAM)TRUE,h);
          SendMessage(GetDlgItem(hdlg,IDC_VERT),TBM_SETPOS,(WPARAM)TRUE,v);
        }

      mfd->vert= v;
      mfd->horz= h;
      _snprintf(tmp,128,"%1.2f",mfd->horz/100.0f);
      SetDlgItemText(hdlg, IDC_VHORZ,tmp);
      _snprintf(tmp,128,"%1.2f",mfd->vert/100.0f);
      SetDlgItemText(hdlg, IDC_VVERT,tmp);
      BuildTables(mfd);
      mfd->ifp->RedoFrame();
      break;
    }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int Resoult= DialogBoxParam ( fa->filter->module->hInstModule,
                                MAKEINTRESOURCE(IDD_FILTER_GAUSSIAN_BLUR),
                                hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (Resoult) *mfd= mfd_old;
  return !!Resoult;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  if (mfd->horz==0 && mfd->vert==0)
    _snprintf (str,64," (no filter)");
  else
    _snprintf (str,64,"(%1.2f %1.2f)",mfd->horz/100.0,mfd->vert/100.0);
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d)",mfd->horz,mfd->vert);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->horz= argv[0].asInt();
  mfd->vert= argv[1].asInt();
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0ii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

struct FilterDefinition filterDef_GB=
{
  NULL, NULL, NULL,            // next, prev, module
  "Gaussian Blur",             // name
  "Advanced Gaussian Blur Filter.\n"
  "Version 1.4 (31-10-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  NULL,                        // startProc
  NULL,                        // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd_GB;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_GB = ff->addFilter(fm, &filterDef_GB, sizeof(FilterDefinition));
  if (!fd_GB) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_GB);
}
