/*  Save/Restore Channels - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari        <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <math.h>
#include <stdio.h>
#include "resource.h"
#include "filter.h"
#include <windows.h>
#include <commctrl.h>
#include "ScriptValue.h"

typedef struct
{
  IFilterPreview *ifp;
  bool save;
  bool alpha,red,green,blue;
} MyFilterData;

static Pixel32 *tmp= NULL;
static int tsize=0;

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int psize= fa->dst.size>>2;
  const int Size= fa->dst.size;

  if ((psize==0) | (tsize!=psize)) return 0;
  if (mfd->save) { memcpy (tmp,dst,Size); return 0; }
  int mask= 0,imask;
  if (mfd->alpha) mask|= 0xff000000;
  if (mfd->red  ) mask|= 0x00ff0000;
  if (mfd->green) mask|= 0x0000ff00;
  if (mfd->blue ) mask|= 0x000000ff;
  imask= mask^0xffffffff;
  if (mask==0xffffffff) { memcpy (dst,tmp,Size); return 0; }
  if (mask==0) return 0;

  for (int p=0; p<psize; p++) dst[p]= (dst[p] & imask) | (tmp[p] & mask);
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->save = true;
  mfd->alpha= true;
  mfd->red  = true;
  mfd->green= true;
  mfd->blue = true;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  if (!tmp) { tsize= fa->src.size>>2; tmp= new Pixel32[tsize]; }
  if (!tmp) ff->ExceptOutOfMemory();
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  if (tmp) { delete[] tmp; tmp= NULL; tsize= 0; }
  return 0;
}

void EnableItems (HWND hdlg,MyFilterData *mfd)
{
  EnableWindow (GetDlgItem (hdlg,IDC_ALPHA),!mfd->save);
  EnableWindow (GetDlgItem (hdlg,IDC_RED)  ,!mfd->save);
  EnableWindow (GetDlgItem (hdlg,IDC_GREEN),!mfd->save);
  EnableWindow (GetDlgItem (hdlg,IDC_BLUE) ,!mfd->save);
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      CheckDlgButton(hdlg,IDC_SAVE   ,mfd->save ?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_RESTORE,!mfd->save?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_ALPHA  ,mfd->alpha?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_RED    ,mfd->red  ?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_GREEN  ,mfd->green?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_BLUE   ,mfd->blue ?BST_CHECKED:BST_UNCHECKED);
      EnableItems (hdlg,mfd);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW:   mfd->ifp->Toggle(hdlg);  break;
        case IDOK:        EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:    EndDialog(hdlg,1); return TRUE;
        case IDC_SAVE:    mfd->save= true;  EnableItems(hdlg,mfd); mfd->ifp->RedoFrame(); break;
        case IDC_RESTORE: mfd->save= false; EnableItems(hdlg,mfd); mfd->ifp->RedoFrame();  break;
        case IDC_ALPHA:   mfd->alpha= !!IsDlgButtonChecked(hdlg, IDC_ALPHA); mfd->ifp->RedoFrame(); break;
        case IDC_RED:     mfd->red=   !!IsDlgButtonChecked(hdlg, IDC_RED  ); mfd->ifp->RedoFrame(); break;
        case IDC_GREEN:   mfd->green= !!IsDlgButtonChecked(hdlg, IDC_GREEN); mfd->ifp->RedoFrame(); break;
        case IDC_BLUE:    mfd->blue=  !!IsDlgButtonChecked(hdlg, IDC_BLUE ); mfd->ifp->RedoFrame(); break;
      }
      break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int Resoult= DialogBoxParam(fa->filter->module->hInstModule,
                              MAKEINTRESOURCE(IDD_FILTER_SAVE_RESTORE),
                              hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (Resoult) *mfd= mfd_old;
  return !!Resoult;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->save) _snprintf(str,64, " (SAVE CHANNELS)");
  else _snprintf (str,64, " (RESTORE %s %s %s %s)",mfd->alpha?"Alpha":"-",mfd->red?"Red":"-",mfd->green?"Green":"-",mfd->blue?"Blue":"-");
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d, %d, %d, %d)",mfd->save,mfd->alpha,mfd->red,mfd->green,mfd->blue);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->save = !!argv[0].asInt();
  mfd->alpha= !!argv[1].asInt();
  mfd->red  = !!argv[2].asInt();
  mfd->green= !!argv[3].asInt();
  mfd->blue=  !!argv[4].asInt();
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

FilterDefinition filterDef_save=
{
  NULL, NULL, NULL,            // next, prev, module
  "Save/Restore Channels",     // name
  "Save and restore color channels.\n"
  "Version 1.3 (09-09-2003)\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  StartProc,                   // startProc
  EndProc,                     // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd_save;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_save = ff->addFilter(fm, &filterDef_save, sizeof(FilterDefinition));
  if (!fd_save) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_save);
}
