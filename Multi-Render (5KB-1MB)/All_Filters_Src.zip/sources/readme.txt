You need these softwares to recompile the sources:

Microsoft Visual C++ 6.0  (http://msdn.microsoft.com/vstudio/)
+ Service Pack 5.0        (http://msdn.microsoft.com/vstudio/downloads/updates/sp/vs6/sp5/default.aspx)
+ Processor Pack          (http://msdn.microsoft.com/vstudio/downloads/tools/ppack/default.aspx)
Nasm 0.98.36              (http://sourceforge.net/projects/nasm)
VirtualDub SDK 1.5        (http://www.virtualdub.org/downloads/filtsdk-1_05.zip)
memcpy_amd                (http://cdrom.amd.com/devconn/memcpy_amd.zip)
