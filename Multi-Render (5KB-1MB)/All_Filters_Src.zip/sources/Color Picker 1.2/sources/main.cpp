/*  Color Picker - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari   <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "ScriptValue.h"
#include "resource.h"

#define VLCN_PADCHANGE 2

typedef struct
{
  NMHDR hdr;
  int dx,dy;
} NMVLPADCHANGE;

const char g_szPadControlName[]="cpPadControl";

typedef struct
{
  int sx,sy,ex,ey;
  bool capture;
} PadControlData;


static LRESULT APIENTRY PadControlWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  PadControlData *pcd= (PadControlData *)GetWindowLong(hwnd, 0);

  switch(msg)
  {
    case WM_NCCREATE:
      if (!(pcd = new PadControlData)) return FALSE;
      memset(pcd,0,sizeof(PadControlData));
      pcd->capture= false;
      SetWindowLong(hwnd, 0, (LONG)pcd);
      return TRUE;

    case WM_CREATE:
    case WM_SIZE:
      break;

    case WM_DESTROY:
      delete pcd;
      SetWindowLong(hwnd, 0, 0);
      break;

    case WM_PAINT:
    {
      PAINTSTRUCT ps;
      HDC hdc;
      hdc= BeginPaint(hwnd, &ps);
      EndPaint(hwnd, &ps);
      break;
    }

    case WM_LBUTTONDOWN:
      {
        unsigned short px= LOWORD(lParam);
        unsigned short py= HIWORD(lParam);
        pcd->sx= *((short *)&px);
        pcd->sy= *((short *)&py);
        pcd->capture= true;
        SetCapture(hwnd);
        break;
      }

    case WM_LBUTTONUP:
      if (pcd->capture)
      {
        ReleaseCapture();
        pcd->capture= false;
      }
      break;

    case WM_MOUSEMOVE:
      if (pcd->capture)
      {
         unsigned short px= LOWORD(lParam);
         unsigned short py= HIWORD(lParam);
         pcd->ex= *((short *)&px);
         pcd->ey= *((short *)&py);

         NMVLPADCHANGE nmvltc;
         nmvltc.hdr.code    = VLCN_PADCHANGE;
         nmvltc.hdr.hwndFrom= hwnd;
         nmvltc.hdr.idFrom  = GetWindowLong(hwnd, GWL_ID);
         nmvltc.dx= pcd->ex-pcd->sx;
         nmvltc.dy= pcd->ey-pcd->sy;
         SendMessage(GetParent(hwnd), WM_NOTIFY, nmvltc.hdr.idFrom, (LPARAM)&nmvltc);

         pcd->sx= pcd->ex;
         pcd->sy= pcd->ey;
      }
      break;

    default:
      return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return FALSE;
}

ATOM RegisterPadControl(HINSTANCE hinst)
{
  WNDCLASS wc;
  wc.style= 0;
  wc.lpfnWndProc= PadControlWndProc;
  wc.cbClsExtra= 0;
  wc.cbWndExtra= sizeof(PadControlData *);
  wc.hInstance= hinst;
  wc.hIcon= NULL;
  wc.hCursor= LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground= (HBRUSH)(COLOR_3DFACE);
  wc.lpszMenuName= NULL;
  wc.lpszClassName= g_szPadControlName;
  return RegisterClass(&wc);
}


unsigned char Digit[160] = {
    0x00, 0x00, 0x3C, 0x66, 0xC3, 0xC3, 0xDB, 0xDB, 0xC3, 0xC3, 0x66, 0x3C, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x18, 0x38, 0x78, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0x03, 0x06, 0x0C, 0x18, 0x30, 0x60, 0xC0, 0xFF, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0x03, 0x03, 0x3E, 0x03, 0x03, 0x03, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x06, 0xC6, 0xC6, 0xC6, 0xC6, 0xFF, 0x06, 0x06, 0x06, 0x06, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFF, 0xC0, 0xC0, 0xC0, 0xFE, 0x03, 0x03, 0x03, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x3E, 0x60, 0xC0, 0xC0, 0xFE, 0xC3, 0xC3, 0xC3, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFF, 0x03, 0x03, 0x06, 0x0C, 0x18, 0x30, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0xC3, 0xC3, 0x7E, 0xC3, 0xC3, 0xC3, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0xC3, 0xC3, 0x7F, 0x03, 0x03, 0x03, 0x06, 0x7C, 0x00, 0x00, 0x00, 0x00};

int h,w,pitch;
Pixel32 *dst;

void PutPixel (int x,int y,Pixel32 colore)
{
  if ((x<0) || (x>w) || (y<0) || (y>h)) return;
  dst[x+(h-y)*pitch]= colore;
}

void GetPixel (int x,int y,int &r,int &g,int &b)
{
  r=g=b= 0;
  if ((x<0) || (x>w) || (y<0) || (y>h)) return;
  r= (dst[x+(h-y)*pitch]>>16)&0xff;
  g= (dst[x+(h-y)*pitch]>> 8)&0xff;
  b= (dst[x+(h-y)*pitch])&0xff;
}

#define dd 5

void DrawNum (int px,int py,char *s,Pixel32 color,Pixel32 bgcolor)
{
  int l= strlen(s);

  if (py+16+dd>h) py-= 16+dd;
  if (px+l*9+dd>w) px-= l*9+dd;

  for (unsigned c=0; c<strlen(s); c++)
  {
    for (int j=0; j<16; j++)
    {
      int b= Digit[j+((int)(s[c])-48)*16];
      for (int i=0; i<9; i++)
      {
        if (b&128)
          PutPixel (px+i,py+j,color);
        else
          PutPixel (px+i,py+j,bgcolor);
        b<<= 1;
      }
    }
    px+= 9;
  }
}

void DrawCross (int px,int py)
{
  for (int i=3; i<7; i++)
  {
    PutPixel (px-i,py,0xff00ff);
    PutPixel (px+i,py,0xff00ff);
    PutPixel (px,py-i,0xff00ff);
    PutPixel (px,py+i,0xff00ff);
  }
}

typedef struct
{
  IFilterPreview *ifp;
  int  x,y;
  bool justdo;
} MyFilterData;

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
   w= fa->dst.w;
  h= fa->dst.h;
   pitch= fa->dst.pitch>>2;
  dst= fa->dst.data;
  int r,g,b;
  char sr[20],sg[20],sb[20],s[80];

  GetPixel (mfd->x,mfd->y,r,g,b);
  itoa (r,sr,10);
  itoa (g,sg,10);
  itoa (b,sb,10);
  strcpy (s,sr);
  strcat (s," ");
  strcat (s,sg);
  strcat (s," ");
  strcat (s,sb);
  DrawCross (mfd->x,mfd->y);
  DrawNum (mfd->x+dd,mfd->y+dd,s,0xffff00,0);
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;

  mfd->x= 0;
  mfd->y= 0;
  mfd->justdo= false;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}


BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SetDlgItemInt(hdlg,IDC_X,mfd->x,false);
      SetDlgItemInt(hdlg,IDC_Y,mfd->y,false);
      SendMessage(GetDlgItem(hdlg,IDC_XSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(8192,0));
      SendMessage(GetDlgItem(hdlg,IDC_YSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(0,8192));
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW:
            mfd->ifp->Toggle(hdlg);
            break;

        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;
        case IDC_X:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int x= GetDlgItemInt(hdlg,IDC_X,NULL,false);
                if (x!=mfd->x)
                {
                  mfd->x= x;
                  mfd->ifp->RedoFrame();
                }
            }
            break;
        case IDC_Y:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int y= GetDlgItemInt(hdlg,IDC_Y,NULL,false);
                if (y!=mfd->y)
                {
                  mfd->y= y;
                  mfd->ifp->RedoFrame();
                }
            }
            break;
      }
      break;

    case WM_NOTIFY:
        if (IDC_PAD==(int)wParam)
        {
      NMHDR *pnmh= (NMHDR *)lParam;
      NMVLPADCHANGE *pnmvltc= (NMVLPADCHANGE *)lParam;
      mfd->x+= pnmvltc->dx;
      mfd->y+= pnmvltc->dy;
      if (mfd->x<0) mfd->x=0;
      if (mfd->y<0) mfd->y=0;
      SetDlgItemInt(hdlg,IDC_X,mfd->x,false);
      SetDlgItemInt(hdlg,IDC_Y,mfd->y,false);
      mfd->ifp->RedoFrame();

      break;
        }

    case WM_HSCROLL:
    case WM_VSCROLL:
    {
      int x= GetDlgItemInt(hdlg,IDC_X,NULL,false);
      int y= GetDlgItemInt(hdlg,IDC_Y,NULL,false);

      if (x!=mfd->x || y!=mfd->y)
      {
        mfd->x= x;
        mfd->y= y;
        mfd->ifp->RedoFrame();
      }
      break;
    }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;

      RegisterPadControl(fa->filter->module->hInstModule);

  mfd->ifp= fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_COLORPICKER),
                          hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return ret;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d)",mfd->x,mfd->y);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->y= argv[0].asInt();
  mfd->x= argv[1].asInt();
  if (mfd->x<0) mfd->x=0;
  if (mfd->y<0) mfd->y=0;
}

ScriptFunctionDef func_defs[]=
  {{(ScriptFunctionPtr)ScriptConfig,"Config","0ii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(str,64," (%d,%d)",mfd->x,mfd->y);
}

FilterDefinition filterDef_ColorPicker=
{
  NULL, NULL, NULL,        // next, prev, module
  "Color Picker",          // name
  "Experimental tools\n"
  "Version 1.2 (09-10-2003)\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it", // desc
  "Emiliano Ferrari",      // maker
  NULL,                    // private_data
  sizeof(MyFilterData),    // inst_data_size
  InitProc,                // initProc
  NULL,                    // deinitProc
  RunProc,                 // runProc
  ParamProc,               // paramProc
  ConfigProc,              // configProc
  StringProc,              // stringProc
  NULL,                    // startProc
  NULL,                    // endProc
  &script_obj,             // script_obj
  FssProc,                 // fssProc
};

static FilterDefinition *fd_ColorPicker;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_ColorPicker= ff->addFilter(fm, &filterDef_ColorPicker, sizeof(FilterDefinition));
  if (!fd_ColorPicker) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_ColorPicker);
}
