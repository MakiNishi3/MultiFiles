/*  Posterize - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// Version 1.0 (18-09-2003)
// Version 1.1 (31-10-2004): rimosso piccolo bug (buffer overflow)

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "resource.h"
#include "ScriptValue.h"

typedef struct
{
  int levels;
  int lut[256];
  IFilterPreview *ifp;
} MyFilterData;

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  const int psize= fa->dst.size>>2;
  Pixel32 *dst= fa->dst.data;

  for (int p=0; p<psize; p++)
  {
    int Alpha= (*dst) & 0xff000000;
    int Red=   (*dst>>16)&0xff;
    int Green= (*dst>> 8)&0xff;
    int Blue=  (*dst    )&0xff;
    *dst++= Alpha | (mfd->lut[Red]<<16) | (mfd->lut[Green]<<8) | mfd->lut[Blue];
  }
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;

  mfd->levels= 7;
  for (int i=0; i<256; i++)
  {
    mfd->lut[i]= (int)((255.0/(mfd->levels-1))*(int)(i*mfd->levels/255.0));
    Clipping (mfd->lut[i],0,255);
  }


  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

// ===============================================================

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(str,64," (%d)",mfd->levels);
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg, IDC_LEVELS), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(2,255));
      SendMessage(GetDlgItem(hdlg, IDC_LEVELS), TBM_SETPOS, (WPARAM)TRUE, mfd->levels);
      SetDlgItemInt(hdlg,IDC_VLEVELS,mfd->levels,false);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg, 0);  return TRUE;
        case IDCANCEL:  EndDialog(hdlg, 1);  return TRUE;
      }
      break;

    case WM_HSCROLL:
      {
        mfd->levels= SendMessage(GetDlgItem(hdlg,IDC_LEVELS),TBM_GETPOS,0,0);
        SetDlgItemInt(hdlg,IDC_VLEVELS,mfd->levels,false);
        for (int i=0; i<256; i++)
        {
          mfd->lut[i]= (int)((255.0/(mfd->levels-1))*(int)(i*mfd->levels/255.0));
          Clipping (mfd->lut[i],0,255);
        }
        mfd->ifp->RedoFrame();
        break;
      }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old = *mfd;
  mfd->ifp = fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_POSTERIZE),
                          hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd = mfd_old;
  return !!ret;
}

// ======================================================

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d)",mfd->levels);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->levels= argv[0].asInt();
  Clipping (mfd->levels,2,255);
}

ScriptFunctionDef func_defs[]=
  {{(ScriptFunctionPtr)ScriptConfig,"Config","0i"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

// ==========================================================

FilterDefinition filterDef_Posterize=
{
  NULL,NULL,NULL,            // next, prev, module
  "Posterize",               // name
  "Reduce the number of colors in a picture trought a fix stair steps values.\n"
  "Version 1.1 (31-10-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",   // desc
  "Emiliano Ferrari",        // maker
  NULL,                      // private_data
  sizeof(MyFilterData),      // inst_data_size
  InitProc,                  // initProc
  NULL,                      // deinitProc
  RunProc,                   // runProc
  ParamProc,                 // paramProc
  ConfigProc,                // configProc
  StringProc,                // stringProc
  NULL,                      // startProc
  NULL,                      // endProc
  &script_obj,               // script_obj
  FssProc,                   // fssProc
};

static FilterDefinition *fd_Posterize;

extern "C" int __declspec(dllexport) __cdecl
  VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_Posterize= ff->addFilter(fm, &filterDef_Posterize, sizeof(FilterDefinition));
  if (!fd_Posterize) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl
  VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_Posterize);
}
