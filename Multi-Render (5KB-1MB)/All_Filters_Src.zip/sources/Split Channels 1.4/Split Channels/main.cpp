/*  Split Channels - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari   <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

//  [ARGB] => [A][R]
//            [G][B]

#include "filter.h"

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  const int w= fa->src.w;
  const int h= fa->src.h;
  const int d= (fa->dst.pitch>>2)*fa->src.h;  
  Pixel32 *src= fa->src.data;
  Pixel32 *dst= fa->dst.data;
  for (int y=0; y<h; y++)
  {
    for (int x=0; x<w; x++)
      {
        int a= (src[x]>>24)&0xff;
        int r= (src[x]>>16)&0xff;
        int g= (src[x]>> 8)&0xff;
        int b= (src[x]    )&0xff;
        dst[x+d  ]= (a<<24)|(a<<16)|(a<<8)|a;
        dst[x+d+w]= (r<<24)|(r<<16)|(r<<8)|r;
        dst[x    ]= (g<<24)|(g<<16)|(g<<8)|g;
        dst[x+w  ]= (b<<24)|(b<<16)|(b<<8)|b;
      }
     dst+= fa->dst.pitch>>2;
     src+= fa->src.pitch>>2;
  }
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.w= fa->src.w*2;
  fa->dst.h= fa->src.h*2;
  fa->dst.AlignTo8();
  return FILTERPARAM_SWAP_BUFFERS;
}

FilterDefinition filterDef_SplitChannels=
{
  NULL, NULL, NULL,            // next, prev, module
  "Split Channels",            // name
  "Split channels in 4 pictures.\n"
  "Version 1.4 (14-03-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  0,                           // inst_data_size
  NULL,                        // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  NULL,                        // configProc
  NULL,                        // stringProc
  NULL,                        // startProc
  NULL,                        // endProc
  NULL,                        // script_obj
  NULL,                        // fssProc
};

static FilterDefinition *fd_SplitChannels;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_SplitChannels= ff->addFilter(fm, &filterDef_SplitChannels, sizeof(FilterDefinition));
  if (!fd_SplitChannels) return 1;    
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_SplitChannels);
}
