/*  Brightness & Contrast - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari   <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// ??-02-2002 v0.1: Inizio svliluppo.
// ...
// 25-09-2003 v1.4: modifica degli algoritmi e pulizia del codice.
// 14-02-2004 v1.5: rimosso bug nella RunProc scritta in C.
// 17-03-2004 v1.6: aggiunta funzionalit� per lavorare solo sul Luma.
// 30-10-2004 v1.7: rimossi alcuni possibili buffer overflow.

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "resource.h"
#include "ScriptValue.h"

typedef struct
{
  IFilterPreview *ifp;
  int brightness,contrast;
  bool luma;
} MyFilterData;

void BC_MMX_Optimized (Pixel32 *dst,int psize,__int64 br64,__int64 cn64);
void BC_Integer_SSE_Optimized (Pixel32 *dst,int psize,__int64 br64,__int64 cn64);

__int64 BuildQ (short A,short R,short G,short B)
{
  __int64 Quadword;
  *(((short *)&Quadword)+0)= B;
  *(((short *)&Quadword)+1)= G;
  *(((short *)&Quadword)+2)= R;
  *(((short *)&Quadword)+3)= A;
  return Quadword;
}

void Brightness_and_Contrast(Pixel32 *dst,const int Size,const int Brightness,const int Contrast)
{ // Brightness [-256..256], Contrast [0..1024]
  const int BR= (512-Contrast)*128+Brightness*512; // (1.0-CN)*0.5+BR
  for (int i=0; i<Size; i++)
  {
    // Estrai i canali alpha e colore
    int Alpha= *dst&0xff000000;
    int Red  = (*dst>>16)&0xff;
    int Green= (*dst>> 8)&0xff;
    int Blue = (*dst    )&0xff;
    // Aggiusta contrasto e luminosit�
    Red=  (Red   * Contrast+BR)>>9;
    Green=(Green * Contrast+BR)>>9;
    Blue= (Blue  * Contrast+BR)>>9;
    // Forza i risultati entro i limiti di rappresentabilit�
    if ((unsigned)Red>255)   Red=   (~Red>>31)&255;
    if ((unsigned)Green>255) Green= (~Green>>31)&255;
    if ((unsigned)Blue>255)  Blue=  (~Blue>>31)&255;
    // Scrive il nuovo pixel calcolato.
    *dst++= Alpha | (Red<<16) | (Green<<8) | Blue;
  }
}

void RGB2YUV(int r,int g,int b,int &Y,int &U,int &V)
{
 // input:  r,g,b [0..255]
 // output: Y,U,V [0..255]
 const int Yr= (int)( 0.257*65536.0*255.0/219.0);
 const int Yg= (int)( 0.504*65536.0*255.0/219.0);
 const int Yb= (int)( 0.098*65536.0*255.0/219.0);
 const int Ur= (int)( 0.439*65536.0*255.0/223.0);
 const int Ug= (int)(-0.368*65536.0*255.0/223.0);
 const int Ub= (int)(-0.071*65536.0*255.0/223.0);
 const int Vr= (int)(-0.148*65536.0*255.0/223.0);
 const int Vg= (int)(-0.291*65536.0*255.0/223.0);
 const int Vb= (int)( 0.439*65536.0*255.0/223.0);

 Y= ((int)(Yr * r + Yg * g + Yb * b+32767)>>16);
 U= ((int)(Ur * r + Ug * g + Ub * b+32767)>>16)+128;
 V= ((int)(Vr * r + Vg * g + Vb * b+32767)>>16)+128;
 if ((unsigned)U>255) U=(~U>>31)&0xff;
 if ((unsigned)V>255) V=(~V>>31)&0xff;
}

void YUV2RGB(int Y,int U,int V,int &r,int &g,int &b)
{
  // input:  Y,U,V [0..255]
  // output: r,g,b [0..255]

 const int YK= (int)(1.164*65536.0*219.0/255.0);
 const int k1= (int)(1.596*65536.0*223.0/255.0);
 const int k2= (int)(0.813*65536.0*223.0/255.0);
 const int k3= (int)(2.018*65536.0*223.0/255.0);
 const int k4= (int)(0.391*65536.0*223.0/255.0);

 Y*= YK;
 U-= 128;
 V-= 128;

 r= (Y+k1*U+32768)>>16;
 g= (Y-k2*U-k4*V+32768)>>16;
 b= (Y+k3*V+32768)>>16;

 if ((unsigned)r>255) r=(~r>>31)&0xff;
 if ((unsigned)g>255) g=(~g>>31)&0xff;
 if ((unsigned)b>255) b=(~b>>31)&0xff;
}

void BC_LumaOnly(Pixel32 *dst,const int Size,const int Brightness,const int Contrast)
{ // Brightness [-256..256], Contrast [0..1024]
  const int BR= (512-Contrast)*128+Brightness*512; // (1.0-CN)*0.5+BR
  for (int i=0; i<Size; i++)
  {
    // Estrai i canali alpha e colore
    int Alpha= *dst&0xff000000;
    int Red  = (*dst>>16)&0xff;
    int Green= (*dst>> 8)&0xff;
    int Blue = (*dst    )&0xff;
    int Y,U,V;

    RGB2YUV(Red,Green,Blue,Y,U,V);
    // Aggiusta contrasto e luminosit�
    Y=  (Y * Contrast+BR)>>9;
    // Forza i risultati entro i limiti di rappresentabilit�
    if ((unsigned)Y>255)   Y=   (~Y>>31)&255;
    YUV2RGB(Y,U,V,Red,Green,Blue);
    // Scrive il nuovo pixel calcolato.
    *dst++= Alpha | (Red<<16) | (Green<<8) | Blue;
  }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  if (mfd->luma)
  {
    BC_LumaOnly(fa->dst.data,fa->dst.size>>2,mfd->brightness,mfd->contrast);
    return 0;
  }

  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags())) // Integer SSE CPU ?
  {
    __int64 br64= BuildQ (0,mfd->brightness,mfd->brightness,mfd->brightness);
    __int64 cn64= BuildQ (512,mfd->contrast,mfd->contrast,mfd->contrast);
    BC_Integer_SSE_Optimized (fa->dst.data,fa->dst.size>>2,br64,cn64);
    return 0;
  }

  if ((CPUF_SUPPORTS_MMX & ff->getCPUFlags())) // MMX CPU ?
  {
    __int64 br64= BuildQ (0,mfd->brightness,mfd->brightness,mfd->brightness);
    __int64 cn64= BuildQ (512,mfd->contrast,mfd->contrast,mfd->contrast);
    BC_MMX_Optimized (fa->dst.data,fa->dst.size>>2,br64,cn64);
    return 0;
  }

  Brightness_and_Contrast (fa->dst.data,fa->dst.size>>2,mfd->brightness,mfd->contrast);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->brightness= 0;
  mfd->contrast  = 512;
  mfd->luma      = false;
  return 0;
}

// =================== SCRIPT SUPPORT ===============================

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d, %d, %d)", mfd->brightness,mfd->contrast,mfd->luma);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->brightness= argv[0].asInt();
  mfd->contrast  = argv[1].asInt();
  mfd->luma      = !!argv[2].asInt();
  Clipping (mfd->brightness,-256, 256);
  Clipping (mfd->contrast  ,   0,1024);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

// ============================ INTERFACE =================================
void UpDate (MyFilterData *mfd,HWND hdlg)
{
  char tmp[128];
  SendMessage(GetDlgItem(hdlg,IDC_BRIGHT),TBM_SETPOS,(WPARAM)TRUE,mfd->brightness);
  SendMessage(GetDlgItem(hdlg,IDC_CONT),  TBM_SETPOS,(WPARAM)TRUE,mfd->contrast);
  _snprintf (tmp,128,"Brightness (%3.1f%%)",(mfd->brightness*100.0f)/256.0f);
  SetDlgItemText(hdlg,IDC_BRIGHTVAL,tmp);
  _snprintf (tmp,128,"Contrast (%3.1f%%)",(mfd->contrast*100.0f)/512.0f);
  SetDlgItemText(hdlg,IDC_CONTVAL,tmp);
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg,IDC_BRIGHT),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG( -256, 256));
      SendMessage(GetDlgItem(hdlg,IDC_CONT),  TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(    0,1024));
      SendMessage(GetDlgItem(hdlg,IDC_BRIGHT),TBM_SETTICFREQ, 32, 0);
      SendMessage(GetDlgItem(hdlg,IDC_CONT  ),TBM_SETTICFREQ, 64, 0);
      CheckDlgButton(hdlg, IDC_LUMA, mfd->luma ? BST_CHECKED : BST_UNCHECKED);
      UpDate (mfd,hdlg);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW:mfd->ifp->Toggle(hdlg);  break;
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;
        case IDC_LUMA:
          mfd->luma= !!IsDlgButtonChecked(hdlg,IDC_LUMA);
          mfd->ifp->RedoFrame();
          break;
        case IDC_RESET:
          mfd->contrast  = 512;
          mfd->brightness=   0;
          UpDate (mfd,hdlg);
          mfd->ifp->RedoFrame();
          return TRUE;
      }
      break;

    case WM_HSCROLL:
      {
        mfd->brightness= SendMessage(GetDlgItem(hdlg,IDC_BRIGHT),TBM_GETPOS,0,0);
        mfd->contrast  = SendMessage(GetDlgItem(hdlg,IDC_CONT),  TBM_GETPOS,0,0);
        UpDate (mfd,hdlg);
        mfd->ifp->RedoFrame();
        break;
      }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_BRIGHTCONT),
                          hwnd,ConfigDlgProc,(LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return ret;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
   _snprintf(str,64, " (B:%1.1f%%  C:%1.1f%%)",
     (mfd->brightness*100.0f)/256.0f,(mfd->contrast*100.0f)/512.0f);
}

// ==================== FILTER REGISTRATION ================================

struct FilterDefinition filterDef_BrightCont=
{
  NULL,NULL,NULL,                 // next, prev, module
  "Brightness & Contrast",        // name
  "Adjust Brightness and Contrast.\n"
  "Version 1.7 (30-10-2004) [MMX/iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",      // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  sizeof(MyFilterData),           // inst_data_size
  InitProc,                       // initProc
  NULL,                           // deinitProc
  RunProc,                        // runProc
  ParamProc,                      // paramProc
  ConfigProc,                     // configProc
  StringProc,                     // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  &script_obj,                    // script_obj
  FssProc,                        // fssProc
};

static FilterDefinition *fd_BrightCont;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_BrightCont= ff->addFilter(fm, &filterDef_BrightCont, sizeof(FilterDefinition));
  if (!fd_BrightCont) return 1;
  vdfd_ver=    VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_BrightCont);
}

BOOL APIENTRY DllMain(HANDLE hModule,DWORD ul_reason_for_call, LPVOID lpReserved)
{
  return TRUE;
}

// ===================== SPECIAL OPTIMIZATIONS ==================================

void BC_MMX_Optimized (Pixel32 *dst,int psize,__int64 br64,__int64 cn64)
{
  __int64 mid = 0x0080008000800080;
  __asm {
        mov       edi,[dst]
        mov       ecx,[psize]
        movq      mm5,[br64]
        movq      mm4,[mid]
        paddw     mm5,mm4
        movq      mm6,[cn64]
        psllw     mm6,4
        pxor      mm7,mm7

        shr       ecx,2
        or        ecx,ecx
        jz        SkipLoop

        align     16
BCLoop: movq      mm0,[edi]
        movq      mm1,[edi+8]
        movq      mm2,mm0
        movq      mm3,mm1
        punpcklbw mm0,mm7
        punpcklbw mm1,mm7
        psubw     mm0,mm4
        psubw     mm1,mm4
        punpckhbw mm2,mm7
        punpckhbw mm3,mm7
        psllw     mm0,3
        psubw     mm2,mm4
        psllw     mm1,3
        psubw     mm3,mm4
        pmulhw    mm0,mm6
        psllw     mm2,3
        pmulhw    mm1,mm6
        psllw     mm3,3
        pmulhw    mm2,mm6
        paddw     mm0,mm5
        pmulhw    mm3,mm6
        paddw     mm2,mm5
        paddw     mm1,mm5
        packuswb  mm0,mm2
        paddw     mm3,mm5
        packuswb  mm1,mm3
        movq      [edi  ],mm0
        movq      [edi+8],mm1
        add       edi,16
        dec       ecx
        jnz       BCLoop
SkipLoop:

        and       edx,3
        jz        Quit
SLoop:  movq      mm0,[edi]
        punpcklbw mm0,mm7
        psubw     mm0,mm4
        psllw     mm0,3
        pmulhw    mm0,mm6
        paddw     mm0,mm5
        packuswb  mm0,mm0
        movq      [edi],mm0
        add       edi,4
        dec       edx
        jnz       SLoop
Quit:   emms
  }
}

void BC_Integer_SSE_Optimized (Pixel32 *dst,int psize,__int64 br64,__int64 cn64)
{
  __int64 mid = 0x0080008000800080;
  __asm {
        mov       edi,[dst]
        mov       ecx,[psize]
        movq      mm5,[br64]
        movq      mm4,[mid]
        paddw     mm5,mm4
        movq      mm6,[cn64]
        psllw     mm6,4
        pxor      mm7,mm7

        shr       ecx,2
        or        ecx,ecx
        jz        SkipLoop

        align     16
BCLoop: movd      mm0,[edi   ]
        movd      mm1,[edi+ 4]
        movd      mm2,[edi+ 8]
        movd      mm3,[edi+12]
        punpcklbw mm0,mm7
        punpcklbw mm1,mm7
        psubw     mm0,mm4
        psubw     mm1,mm4
        punpcklbw mm2,mm7
        prefetchnta [edi+192]
        punpcklbw mm3,mm7
        psllw     mm0,3
        psubw     mm2,mm4
        psllw     mm1,3
        psubw     mm3,mm4
        pmulhw    mm0,mm6
        psllw     mm2,3
        pmulhw    mm1,mm6
        psllw     mm3,3
        pmulhw    mm2,mm6
        paddw     mm0,mm5
        pmulhw    mm3,mm6
        paddw     mm2,mm5
        paddw     mm1,mm5
        packuswb  mm0,mm1
        paddw     mm3,mm5
        packuswb  mm2,mm3
        movq      [edi  ],mm0
        movq      [edi+8],mm2
        add       edi,16
        dec       ecx
        jnz       BCLoop
SkipLoop:

        and       edx,3
        jz        Quit
SLoop:  movq      mm0,[edi]
        punpcklbw mm0,mm7
        psubw     mm0,mm4
        psllw     mm0,3
        pmulhw    mm0,mm6
        paddw     mm0,mm5
        packuswb  mm0,mm0
        movq      [edi],mm0
        add       edi,4
        dec       edx
        jnz       SLoop
Quit:   emms
  }
}
