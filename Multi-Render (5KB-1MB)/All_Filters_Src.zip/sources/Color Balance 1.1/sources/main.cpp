/*  Color Balance - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari     <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <math.h>
#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "resource.h"
#include "filter.h"
#include "ScriptValue.h"

#define SHADOWS    0
#define MIDTONES   1
#define HIGHLIGHTS 2

typedef struct
{
  IFilterPreview *ifp;
  bool link,preserve_luma;
  int  mode;
  int  Cyan_Red[3];
  int  Magenta_Green[3];
  int  Yellow_Blue[3];
  int  Lut[256*3];
} MyFilterData;

void LUT_iSSE (Pixel32 *dst,int *LUT,int psize)
{
  __asm {
            mov     edi,[dst]
            mov     esi,[LUT]
            mov     ecx,[psize]

            align     16
GLoop:      mov     eax,[edi]
            xor     ebx,ebx
            mov     edx,eax
            mov     bl,ah
            and     edx,0xff0000
            and     eax,0xff
            shr     edx,16
            movd    mm0,[esi+eax*4+(512*4)]
            prefetchnta [edi+512]
            por     mm0,[esi+ebx*4+(256*4)]
            por     mm0,[esi+edx*4        ]
            movd    [edi],mm0
            add     edi,4
            dec     ecx
            jnz     GLoop
            emms
  }
}

inline double sqr (double a) { return a*a; }

void Create_Tables (MyFilterData *mfd)
{
  for (int i=0; i<256; i++)
  {
    double fr= i/255.0;
    double fg= i/255.0;
    double fb= i/255.0;

    double CRS= (mfd->Cyan_Red[SHADOWS]/4096.0);
    double CRM= (mfd->Cyan_Red[MIDTONES]/4096.0);
    double CRH= (mfd->Cyan_Red[HIGHLIGHTS]/4096.0);
    double MGS= (mfd->Magenta_Green[SHADOWS]/4096.0);
    double MGM= (mfd->Magenta_Green[MIDTONES]/4096.0);
    double MGH= (mfd->Magenta_Green[HIGHLIGHTS]/4096.0);
    double YBS= (mfd->Yellow_Blue[SHADOWS]/4096.0);
    double YBM= (mfd->Yellow_Blue[MIDTONES]/4096.0);
    double YBH= (mfd->Yellow_Blue[HIGHLIGHTS]/4096.0);

    if (CRS>0) fr+= CRS*0.667*(1-sqr(2*fr-1));
      else     fr+= CRS*(1.075-1/(17.0-16.0*fr));
    if (fr<0)  fr=0; if (fr>1.0) fr= 1.0;
               fr+= CRM*0.667*(1-sqr(2*fr-1));
    if (fr<0)  fr=0; if (fr>1.0) fr= 1.0;
    if (CRH>0) fr+= CRH*(1.075-1/(16.0*fr+1));
      else     fr+= CRH*0.667*(1-sqr(2*fr-1));
    if (fr<0)  fr=0; if (fr>1.0) fr= 1.0;

    if (MGS>0) fg+= MGS*0.667*(1-sqr(2*fg-1));
      else     fg+= MGS*(1.075-1/(17.0-16.0*fg));
    if (fg<0)  fg=0; if (fg>1.0) fg= 1.0;
               fg+= MGM*0.667*(1-sqr(2*fg-1));
    if (fg<0)  fg=0; if (fg>1.0) fg= 1.0;
    if (MGH>0) fg+= MGH*(1.075-1/(16.0*fg+1));
      else     fg+= MGH*0.667*(1-sqr(2*fg-1));
    if (fg<0)  fg=0; if (fg>1.0) fg= 1.0;

    if (YBS>0) fb+= YBS*0.667*(1-sqr(2*fb-1));
      else     fb+= YBS*(1.075-1/(17.0-16.0*fb));
    if (fb<0)  fb=0; if (fb>1.0) fb= 1.0;
               fb+= YBM*0.667*(1-sqr(2*fb-1));
    if (fb<0)  fb=0; if (fb>1.0) fb= 1.0;
    if (YBH>0) fb+= YBH*(1.075-1/(16.0*fb+1));
      else     fb+= YBH*0.667*(1-sqr(2*fb-1));
    if (fb<0)  fb=0; if (fb>1.0) fb= 1.0;

    mfd->Lut[i]= (int)(fr*255.0)<<16;
    mfd->Lut[i+256]= (int)(fg*255.0)<<8;
    mfd->Lut[i+512]= (int)(fb*255.0);
  }
}

inline void Clipping (int &dato,int min,int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void RGB2HSL(int r,int g,int b,int &H,int &S,int &L)
{ // RGB to HSL color space
  //   input  r,g,b [0..255]
  //   output H,S,L [0..255]
  int cmax= max(r,max(g,b));
  int cmin= min(r,min(g,b));
  S= cmax-cmin;
  L= cmax+cmin;  
  if (S==0) { H=0; L>>=1; if (L>255) L=255; return; }  
  if (L==0) L=1;
  if (r==cmax) H= (255*(g-b)+127)/S;
    else
     if (g==cmax) H= 510+(255*(b-r)+127)/S;
      else
        H= 1020+(255*(r-g)+127)/S;
  H/=6;
  if (H<0) H+= 255;
 
  if (L<255) S= (255*S+127)/L; else S= (255*S+127)/(510-L);
  L>>= 1;
  if ((unsigned)S>255) S= (~S>>31)&0xff;  
}

inline int HUE2RGB(const int M1,const int M2,int H)
{
  if (H<0)   H+= 255;
  if (H>255) H-= 255;
  if (6*H<255) return M1+((M2-M1)*H*6+127)/255;
  if (2*H<255) return M2;
  if (3*H<510) return M1+((M2-M1)*(170-H)*6+127)/255;
  return M1;
}

void HSL2RGB(int H,int S,int L,int &r,int &g,int &b)
{ // HSL to RGB color space
  //   input  H,S,L [0..255] 
  //   output r,g,b [0..255]
  int M1,M2;
  if (S==0) { r= g= b= L; return;}
  
  if (L<128) M2= (L*(255+S)+128)/255; else M2= L+S-(L*S+128)/255;
  M1= 2*L-M2;
  r= HUE2RGB(M1,M2,H+85);
  g= HUE2RGB(M1,M2,H);
  b= HUE2RGB(M1,M2,H-85);
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int psize= fa->dst.size>>2;

  if (mfd->preserve_luma)
  {
    for (int p=0; p<psize; p++)
    {
      int OH,OS,OL,NH,NS,NL;
      int Alpha= (*dst)&0xff000000;
      int Red=   (*dst>>16)&0xff;
      int Green= (*dst>> 8)&0xff;
      int Blue=  (*dst    )&0xff;
      RGB2HSL (Red,Green,Blue,OH,OS,OL);
      Red=   mfd->Lut[Red]>>16;
      Green= mfd->Lut[Green+256]>>8;
      Blue=  mfd->Lut[Blue+512];
      RGB2HSL (Red,Green,Blue,NH,NS,NL);
      HSL2RGB (NH,(NS+OS+1)>>1,OL,Red,Green,Blue);
    
      *dst++= Alpha | (Red<<16) | (Green<<8) | Blue;
    }
  }
  else
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
     LUT_iSSE (dst,mfd->Lut,psize);
  else
  for (int p=0; p<psize; p++)
  {
    int Alpha= (*dst)&0xff000000;
    int Red=   (*dst>>16)&0xff;
    int Green= (*dst>> 8)&0xff;
    int Blue=  (*dst    )&0xff;
    *dst++= Alpha | mfd->Lut[Red] | mfd->Lut[Green+256] | mfd->Lut[Blue+512];
  }
  return 0;
}

void DefaultParam (MyFilterData *mfd)
{
  for (int i=0; i<3; i++)
  {
    mfd->Cyan_Red[i]= 0;
    mfd->Magenta_Green[i]= 0;
    mfd->Yellow_Blue[i]= 0;
  }
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->link= false;
  mfd->preserve_luma= false;
  mfd->mode= MIDTONES;
  DefaultParam (mfd);
  Create_Tables(mfd);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

char *Scale (double input,double irange,double orange)
{
  static char s[128];
  _snprintf(s,128, "%1.2f%%",input*irange/orange);
  return s;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd= (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg,IDC_RED  ),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(-1024,1024));
      SendMessage(GetDlgItem(hdlg,IDC_GREEN),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(-1024,1024));
      SendMessage(GetDlgItem(hdlg,IDC_BLUE ),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(-1024,1024));
      SendMessage(GetDlgItem(hdlg, IDC_RED  ),TBM_SETPOS, (WPARAM)TRUE,mfd->Cyan_Red[mfd->mode]);
      SendMessage(GetDlgItem(hdlg, IDC_GREEN),TBM_SETPOS, (WPARAM)TRUE,mfd->Magenta_Green[mfd->mode]);
      SendMessage(GetDlgItem(hdlg, IDC_BLUE ),TBM_SETPOS, (WPARAM)TRUE,mfd->Yellow_Blue[mfd->mode]);
      SetDlgItemText(hdlg,IDC_VRED  ,Scale(mfd->Cyan_Red[mfd->mode],100,1024));
      SetDlgItemText(hdlg,IDC_VGREEN,Scale(mfd->Magenta_Green[mfd->mode],100,1024));
      SetDlgItemText(hdlg,IDC_VBLUE ,Scale(mfd->Yellow_Blue[mfd->mode],100,1024));
      CheckDlgButton(hdlg,IDC_SHADOWS,mfd->mode==SHADOWS?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_MIDTONES,mfd->mode==MIDTONES?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_HIGHLIGHTS,mfd->mode==HIGHLIGHTS?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_LINK,mfd->link?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_PRESERVE,mfd->preserve_luma?BST_CHECKED:BST_UNCHECKED);
      Create_Tables(mfd);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;
        case IDC_RESET:
          DefaultParam (mfd);
      SendMessage(GetDlgItem(hdlg, IDC_RED  ),TBM_SETPOS, (WPARAM)TRUE,mfd->Cyan_Red[mfd->mode]);
      SendMessage(GetDlgItem(hdlg, IDC_GREEN),TBM_SETPOS, (WPARAM)TRUE,mfd->Magenta_Green[mfd->mode]);
      SendMessage(GetDlgItem(hdlg, IDC_BLUE ),TBM_SETPOS, (WPARAM)TRUE,mfd->Yellow_Blue[mfd->mode]);
      SetDlgItemText(hdlg,IDC_VRED  ,Scale(mfd->Cyan_Red[mfd->mode],100,1024));
      SetDlgItemText(hdlg,IDC_VGREEN,Scale(mfd->Magenta_Green[mfd->mode],100,1024));
      SetDlgItemText(hdlg,IDC_VBLUE ,Scale(mfd->Yellow_Blue[mfd->mode],100,1024));
      CheckDlgButton(hdlg,IDC_SHADOWS,mfd->mode==SHADOWS?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_MIDTONES,mfd->mode==MIDTONES?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_HIGHLIGHTS,mfd->mode==HIGHLIGHTS?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_LINK,mfd->link?BST_CHECKED:BST_UNCHECKED);
      Create_Tables(mfd);
        mfd->ifp->RedoFrame();
          break;

        case IDC_LINK:
            mfd->link= !!IsDlgButtonChecked(hdlg, IDC_LINK);
            mfd->ifp->RedoFrame();
            break;

        case IDC_PRESERVE:
            mfd->preserve_luma= !!IsDlgButtonChecked(hdlg, IDC_PRESERVE);
            mfd->ifp->RedoFrame();
            break;

        case IDC_SHADOWS:
          mfd->mode= SHADOWS;
          SendMessage(GetDlgItem(hdlg, IDC_RED  ),TBM_SETPOS, (WPARAM)TRUE,mfd->Cyan_Red[mfd->mode]);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN),TBM_SETPOS, (WPARAM)TRUE,mfd->Magenta_Green[mfd->mode]);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE ),TBM_SETPOS, (WPARAM)TRUE,mfd->Yellow_Blue[mfd->mode]);
          SetDlgItemText(hdlg,IDC_VRED  ,Scale(mfd->Cyan_Red[mfd->mode],100,1024));
          SetDlgItemText(hdlg,IDC_VGREEN,Scale(mfd->Magenta_Green[mfd->mode],100,1024));
          SetDlgItemText(hdlg,IDC_VBLUE ,Scale(mfd->Yellow_Blue[mfd->mode],100,1024));
          mfd->ifp->RedoFrame();
          break;
        case IDC_MIDTONES:
          mfd->mode= MIDTONES;
          SendMessage(GetDlgItem(hdlg, IDC_RED  ),TBM_SETPOS, (WPARAM)TRUE,mfd->Cyan_Red[mfd->mode]);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN),TBM_SETPOS, (WPARAM)TRUE,mfd->Magenta_Green[mfd->mode]);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE ),TBM_SETPOS, (WPARAM)TRUE,mfd->Yellow_Blue[mfd->mode]);
          SetDlgItemText(hdlg,IDC_VRED  ,Scale(mfd->Cyan_Red[mfd->mode],100,1024));
          SetDlgItemText(hdlg,IDC_VGREEN,Scale(mfd->Magenta_Green[mfd->mode],100,1024));
          SetDlgItemText(hdlg,IDC_VBLUE ,Scale(mfd->Yellow_Blue[mfd->mode],100,1024));
          mfd->ifp->RedoFrame();
          break;
        case IDC_HIGHLIGHTS:
          mfd->mode= HIGHLIGHTS;
          SendMessage(GetDlgItem(hdlg, IDC_RED  ),TBM_SETPOS, (WPARAM)TRUE,mfd->Cyan_Red[mfd->mode]);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN),TBM_SETPOS, (WPARAM)TRUE,mfd->Magenta_Green[mfd->mode]);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE ),TBM_SETPOS, (WPARAM)TRUE,mfd->Yellow_Blue[mfd->mode]);
          SetDlgItemText(hdlg,IDC_VRED  ,Scale(mfd->Cyan_Red[mfd->mode],100,1024));
          SetDlgItemText(hdlg,IDC_VGREEN,Scale(mfd->Magenta_Green[mfd->mode],100,1024));
          SetDlgItemText(hdlg,IDC_VBLUE ,Scale(mfd->Yellow_Blue[mfd->mode],100,1024));
          mfd->ifp->RedoFrame();
          break;
      }
      break;

    case WM_HSCROLL:
      {
        int r= SendMessage(GetDlgItem(hdlg,IDC_RED),TBM_GETPOS,0,0);
        int g= SendMessage(GetDlgItem(hdlg,IDC_GREEN),TBM_GETPOS,0,0);
        int b= SendMessage(GetDlgItem(hdlg,IDC_BLUE),TBM_GETPOS,0,0);
        int rl= mfd->Cyan_Red[mfd->mode];
        int gl= mfd->Magenta_Green[mfd->mode];
        int bl= mfd->Yellow_Blue[mfd->mode];

        if (r!=rl || g!=gl || b!=bl)
        {
           if (mfd->link)
          {
            int d= (r - rl) + (g - gl) + (b - bl);
            r= rl + d;
            g= gl + d;
            b= bl + d;
            Clipping (r,-1024,1024);
            Clipping (g,-1024,1024);
            Clipping (b,-1024,1024);
            SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETPOS, (WPARAM)TRUE, r);
            SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETPOS, (WPARAM)TRUE, g);
            SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETPOS, (WPARAM)TRUE, b);
          }
          mfd->Cyan_Red[mfd->mode]= r;
          mfd->Magenta_Green[mfd->mode]= g;
          mfd->Yellow_Blue[mfd->mode]= b;
          SetDlgItemText(hdlg,IDC_VRED  ,Scale(mfd->Cyan_Red[mfd->mode],100,1024));
          SetDlgItemText(hdlg,IDC_VGREEN,Scale(mfd->Magenta_Green[mfd->mode],100,1024));
          SetDlgItemText(hdlg,IDC_VBLUE ,Scale(mfd->Yellow_Blue[mfd->mode],100,1024));
          Create_Tables(mfd);
          mfd->ifp->RedoFrame();
        }
        break;
      }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp = fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_COLOR_BALANCE),
                          hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return ret;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  _snprintf(buf,buflen,"Config(%d,%d,%d, %d,%d,%d, %d,%d,%d, %d)",
  mfd->Cyan_Red[SHADOWS],mfd->Magenta_Green[SHADOWS],mfd->Yellow_Blue[SHADOWS],
  mfd->Cyan_Red[MIDTONES],mfd->Magenta_Green[MIDTONES],mfd->Yellow_Blue[MIDTONES],
  mfd->Cyan_Red[HIGHLIGHTS],mfd->Magenta_Green[HIGHLIGHTS],mfd->Yellow_Blue[HIGHLIGHTS],
  mfd->link);
  return 0;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->Cyan_Red[SHADOWS]= argv[0].asInt();
  mfd->Magenta_Green[SHADOWS]= argv[1].asInt();
  mfd->Yellow_Blue[SHADOWS]= argv[2].asInt();
  mfd->Cyan_Red[MIDTONES]= argv[3].asInt();
  mfd->Magenta_Green[MIDTONES]= argv[4].asInt();
  mfd->Yellow_Blue[MIDTONES]= argv[5].asInt();
  mfd->Cyan_Red[HIGHLIGHTS]= argv[6].asInt();
  mfd->Magenta_Green[HIGHLIGHTS]= argv[7].asInt();
  mfd->Yellow_Blue[HIGHLIGHTS]= argv[8].asInt();
  mfd->link= !!argv[9].asInt();
  mfd->preserve_luma= !!argv[10].asInt();

  Clipping (mfd->Cyan_Red[SHADOWS],-1024,1024);
  Clipping (mfd->Magenta_Green[SHADOWS],-1024,1024);
  Clipping (mfd->Yellow_Blue[SHADOWS],-1024,1024);
  Clipping (mfd->Cyan_Red[MIDTONES],-1024,1024);
  Clipping (mfd->Magenta_Green[MIDTONES],-1024,1024);
  Clipping (mfd->Yellow_Blue[MIDTONES],-1024,1024);
  Clipping (mfd->Cyan_Red[HIGHLIGHTS],-1024,1024);
  Clipping (mfd->Magenta_Green[HIGHLIGHTS],-1024,1024);
  Clipping (mfd->Yellow_Blue[HIGHLIGHTS],-1024,1024);  
}

ScriptFunctionDef func_defs[]=
  {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiiiiiiiiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

FilterDefinition filterDef_ColorBalance=
{
  NULL, NULL, NULL,               // next, prev, module
  "Color Balance",                // name
  "adjust color balance\n"
  "Version 1.1 (30-09-2003) [iSSE]\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",        // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  sizeof(MyFilterData),           // inst_data_size
  InitProc,                       // initProc
  NULL,                           // deinitProc
  RunProc,                        // runProc
  ParamProc,                      // paramProc
  ConfigProc,                     // configProc
  NULL,                           // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  &script_obj,                    // script_obj
  FssProc,                        // fssProc
};

static FilterDefinition *fd_ColorBalance;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_ColorBalance= ff->addFilter(fm, &filterDef_ColorBalance, sizeof(FilterDefinition));
  if (!fd_ColorBalance) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_ColorBalance);
}
