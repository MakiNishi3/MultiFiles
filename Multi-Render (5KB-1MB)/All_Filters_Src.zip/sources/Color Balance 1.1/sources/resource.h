//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_COLOR_BALANCE        101
#define IDC_RESET                       1000
#define IDC_GREEN                       1001
#define IDC_BLUE                        1002
#define IDC_RED                         1003
#define IDC_VRED                        1004
#define IDC_VGREEN                      1005
#define IDC_VBLUE                       1006
#define IDC_PRESERVE                    1007
#define IDC_SHADOWS                     1008
#define IDC_MIDTONES                    1009
#define IDC_HIGHLIGHTS                  1010
#define IDC_LINK                        1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
