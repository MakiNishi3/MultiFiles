/*  Wide screen converter - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari   <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

//    version 1.4 (25-09-2003)
//    version 1.5 (17-03-2004): diviso in 2 file (resize e letterbox) per
//                              poter essere usato sotto AviSynth.

#include "filter.h"

void Run386_Alpha (Pixel32 *src,Pixel32 *dst,const int w,const int pitch)
{
  const int pitch2= pitch*2;
  const int pitch3= pitch*3;

  for (int x=0; x<w; x++)
      {
        Pixel32 RB0= (src[x       ]   )&0xff00ff;  // Read Line 0
        Pixel32 AG0= (src[x       ]>>8)&0xff00ff;
        Pixel32 RB1= (src[x+pitch ]   )&0xff00ff;  // Read Line 1
        Pixel32 AG1= (src[x+pitch ]>>8)&0xff00ff;
        Pixel32 RB2= (src[x+pitch2]   )&0xff00ff;  // Read Line 2
        Pixel32 AG2= (src[x+pitch2]>>8)&0xff00ff;
        Pixel32 RB3= (src[x+pitch3]   )&0xff00ff;  // Read Line 3
        Pixel32 AG3= (src[x+pitch3]>>8)&0xff00ff;
        RB0= (3*RB0+RB1+0x00020002)>>2;  // 75% Line 0 + 25% Line 1
        AG0= (3*AG0+AG1+0x00020002)>>2;
        RB1= (  RB1+RB2+0x00010001)>>1;  // 50% Line 1 + 50% Line 2
        AG1= (  AG1+AG2+0x00010001)>>1;
        RB2= (RB2+3*RB3+0x00020002)>>2;  // 25% Line 2 + 75% Line 3
        AG2= (AG2+3*AG3+0x00020002)>>2;
        dst[x       ]= (RB0&0xff00ff) | ((AG0&0xff00ff)<<8); // Write Line 0
        dst[x+pitch ]= (RB1&0xff00ff) | ((AG1&0xff00ff)<<8); // Write Line 1
        dst[x+pitch2]= (RB2&0xff00ff) | ((AG2&0xff00ff)<<8); // Write Line 2
      }
}

void Fill_386 (Pixel32 *dst,int psize)
{
  memset (dst,0,psize);
}

void Fill_MMX (Pixel32 *dst,int psize)
{
  __asm {
          mov       edi,[dst]
          mov       ecx,[psize]
          pxor      mm0,mm0
          shr       ecx,6
          align     16
FLoop:    movq      [edi   ],mm0
          movq      [edi+ 8],mm0
          movq      [edi+16],mm0
          movq      [edi+24],mm0
          movq      [edi+32],mm0
          movq      [edi+40],mm0
          movq      [edi+48],mm0
          movq      [edi+56],mm0
          add       edi,64
          dec       ecx
          jnz       FLoop
          mov       ecx,[psize]
          and       ecx,63
          jz        end
          cld
          xor       eax,eax
          rep       stosb
end:
  }
}

void Run_MMX (Pixel32 *src,Pixel32 *dst,const int w,const int pitch)
{
  static const __int64 m0001 = 0x0001000100010001;
  static const __int64 m0002 = 0x0002000200020002;
  __asm {   mov         esi,[src]
            mov         edi,[dst]
            mov         ecx,[w]
            mov         eax,[pitch]
            or          ecx,ecx
            jz          Quit
            shl         eax,2
            mov         ebx,eax
            add         ebx,eax
            add         ebx,eax
            pxor        mm7,mm7
            movq        mm6,[m0002]

            align       16
WSLoop:     movd        mm0,[esi      ]
            movd        mm1,[esi+eax  ]
            movd        mm2,[esi+eax*2]
            punpcklbw   mm0,mm7
            movd        mm3,[esi+ebx  ]
            punpcklbw   mm1,mm7
            punpcklbw   mm2,mm7
            movq        mm4,mm0
            punpcklbw   mm3,mm7
            paddw       mm0,mm1
            paddw       mm1,mm2
            psllw       mm4,1
            paddw       mm2,mm3     // r2+r3
            psllw       mm3,1
            paddw       mm0,mm4     // r0*3+r1
            paddw       mm2,mm3     // r2+r3*3
            paddw       mm1,[m0001]
            paddw       mm0,mm6
            paddw       mm2,mm6
            psrlw       mm1,1
            psrlw       mm0,2
            packuswb    mm1,mm1
            psrlw       mm2,2
            packuswb    mm0,mm0
            movd        [edi+eax],mm1
            packuswb    mm2,mm2
            movd        [edi],mm0
            add         esi,4
            movd        [edi+eax*2],mm2
            add         edi,4
            dec         ecx
            jnz         WSLoop
quit:
  }
}

void Run_iSSE (Pixel32 *src,Pixel32 *dst,const int w,const int pitch)
{
  static const __int64 m0002 = 0x0002000200020002;
  __asm {   mov         esi,[src]
            mov         edi,[dst]
            mov         ecx,[w]
            mov         eax,[pitch]
            or          ecx,ecx
            jz          Quit
            shl         eax,2
            mov         ebx,eax
            add         ebx,eax
            add         ebx,eax
            pxor        mm7,mm7
            movq        mm6,[m0002]
            align       16
WSLoop:     movd        mm0,[esi      ]
            movd        mm1,[esi+eax  ]
            movd        mm2,[esi+eax*2]
            movd        mm3,[esi+ebx  ]
            movq        mm5,mm1
            punpcklbw   mm0,mm7
            punpcklbw   mm1,mm7
            pavgb       mm5,mm2
            punpcklbw   mm2,mm7
            punpcklbw   mm3,mm7
            movd        [edi+eax],mm5
            prefetcht0  [esi+192      ]
            prefetcht0  [esi+192+eax  ]
            prefetcht0  [esi+192+eax*2]
            prefetcht0  [esi+192+ebx  ]
            prefetchnta [edi+192      ]
            prefetchnta [edi+192+eax  ]
            prefetchnta [edi+192+eax*2]
            paddw       mm1,mm0
            paddw       mm2,mm3
            psllw       mm0,1
            psllw       mm3,1
            paddw        mm1,mm6
            paddw        mm2,mm6
            paddw       mm1,mm0
            paddw       mm2,mm3
            psrlw       mm1,2
            psrlw       mm2,2
            packuswb    mm1,mm1
            packuswb    mm2,mm2
            movd        [edi],mm1
            add         esi,4
            movd        [edi+eax*2],mm2
            add         edi,4
            dec         ecx
            jnz         WSLoop
quit:
  }
}

void __Dummy() {}
void __EMMS() { __asm { EMMS } }

typedef void (RunFunc) (Pixel32 *src,Pixel32 *dst,const int w,const int pitch);
static RunFunc *RunLine= Run386_Alpha;
typedef void (FEMMS)();
static FEMMS *EMMS= __Dummy;
typedef void (FILLPROC) (Pixel32 *dst,int psize);
static FILLPROC *Fill= Fill_386;


int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
  {
     RunLine= Run_iSSE;
     Fill= Fill_MMX;
     EMMS= __EMMS;
  }
  else
  if ((CPUF_SUPPORTS_MMX & ff->getCPUFlags()))
  {
     RunLine= Run_MMX;
     Fill= Fill_MMX;
     EMMS= __EMMS;
  }
  else
  {
     RunLine= Run386_Alpha;
     Fill= Fill_386;
     EMMS= __Dummy;
  }
  return 0;
}

long RWS_ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  fa->dst.h= 6*(int)(fa->src.h/8);
  return 0;
}

int RWS_RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  const int h= fa->dst.h/3;
  const int pitch= fa->src.pitch>>2;
  const int pitch3= pitch*3;
  const int pitch4= pitch*4;
  Pixel32 *src= fa->src.data;
  Pixel32 *dst= fa->dst.data;

  for (int y=0; y<h; y++)
  {
    RunLine (src,dst,fa->src.w,pitch);
    src+= pitch4;
    dst+= pitch3;
  }
  EMMS();
  return 0;
}

FilterDefinition filterDef_WSR=
{
  NULL,NULL,NULL,         // next, prev, module
  "Wide screen converter (resize)", // name
  "adjust the aspect-ratio for 16:9 picture.\n"
  "version 1.5 (17-03-2004) [MMX/iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",// desc
  "Emiliano Ferrari",     // maker
  NULL,                   // private_data
  0,                      // inst_data_size
  NULL,                   // initProc
  NULL,                   // deinitProc
  RWS_RunProc,            // runProc
  RWS_ParamProc,          // paramProc
  NULL,                   // configProc
  NULL,                   // stringProc
  StartProc,              // startProc
  NULL,                   // endProc
  NULL,                   // script_obj
  NULL,                   // fssProc
};

static FilterDefinition *fd_WSR;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_WSR= ff->addFilter(fm, &filterDef_WSR, sizeof(FilterDefinition)); 
  if (!fd_WSR) return 1; 
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_WSR); 
}
