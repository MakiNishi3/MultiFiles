/*  Canvas Size (Cromp/Enlarge Tools) - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari  <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    version 0.1   ??-04-2003
    version 1.0   16-07-2003
    version 1.0.0 21-07-2003
    version 1.2   25-09-2003
    Version 1.3   30-10-2004: rimossi alcuni buffer overflow */

#include <math.h>
#include <stdio.h>
#include "resource.h"
#include "filter.h"
#include <windows.h>
#include <commctrl.h>
#include "ScriptValue.h"

#pragma warning(disable:4035)
#include "memcpy_amd.cpp"

#define POS_CENTER     0
#define POS_UPPERLEFT  1
#define POS_UPPER      2
#define POS_UPPERRIGHT 3
#define POS_LEFT       4
#define POS_RIGHT      5
#define POS_DOWNLEFT   6
#define POS_DOWN       7
#define POS_DOWNRIGHT  8

typedef void *(MEMCPY) (void *,const void *,size_t);
MEMCPY *_memcpy= memcpy;

typedef struct
{
  IFilterPreview *ifp;
  int position;
  int w,h,x,y;
  COLORREF color_ref;
  HBRUSH   color_brush;
} MyFilterData;

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const Pixel32 col= (GetRValue(mfd->color_ref)<<16) | (GetGValue(mfd->color_ref)<<8) | GetBValue(mfd->color_ref);
  const int sw= fa->src.w;
  const int sh= fa->src.h;
  const int dw= fa->dst.w;
  const int dh= fa->dst.h;
  Pixel32 *src= fa->src.data;
  Pixel32 *dst= fa->dst.data;
  const int spitch= fa->src.pitch>>2;
  const int dpitch= fa->dst.pitch>>2;
  int xo=  mfd->x;
  int yo= -mfd->y;
  int sx= 0;
  int sy= 0;
  int w = sw;
  int h = sh;
  int i,jx,jy;

  switch (mfd->position)
  {
    case POS_CENTER:    jx=1; jy=1; xo=0; yo= 0; break;
    case POS_UPPERLEFT: jx=0; jy=2; break;
    case POS_UPPER:     jx=1; jy=2; xo=0; break;
    case POS_UPPERRIGHT:jx=2; jy=2; xo= -xo; break;
    case POS_LEFT:      jx=0; jy=1; yo= 0; break;
    case POS_RIGHT:     jx=2; jy=1; xo= -xo; yo= 0; break;
    case POS_DOWNLEFT:  jx=0; jy=0; yo= -yo; break;
    case POS_DOWNRIGHT: jx=2; jy=0; xo= -xo; yo= -yo; break;
    case POS_DOWN:      jx=1; jy=0; xo=0; yo= -yo; break;
  }
  int x = xo + (((fa->dst.w - fa->src.w) * jx + 1)>>1);
  int y = yo + (((fa->dst.h - fa->src.h) * jy + 1)>>1);

  if ((x>dw) || (y>dh) || ((x+w)<0) || ((y+h)<0))
  {
      for (i=0; i<(dw*dh); i++) *dst++= col;
      return 0;
  }

  if (x<0) { sx= -x; x=0; w-= sx; }
  if (y<0) { sy= -y; y=0; h-= sy; }
  if ((x+w)>dw) { w= dw-x; }
  if ((y+h)>dh) { h= dh-y; }
  src+= sx + sy * spitch;

  for (i=0; i<(x+y*dpitch); i++) *dst++= col;
  for (int j=0; j<h-1; j++)
  {
      _memcpy (dst,src,w*sizeof(Pixel32));
      dst+= w;
      for (i=0; i<(dpitch-w); i++) *dst++= col;
      src+= spitch;
  }

  _memcpy (dst,src,w*sizeof(Pixel32));
  dst+= w;
  int last= (fa->dst.data+(fa->dst.size>>2))-dst;
  for (i=0; i<last; i++) *dst++= col;

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->w= 320;
  mfd->h= 240;
  mfd->x= 0;
  mfd->y= 0;
  mfd->color_ref= RGB (0,0,0);
  mfd->color_brush= CreateSolidBrush (mfd->color_ref);
  mfd->position= POS_CENTER;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->w!=-1)
  {
    fa->dst.w= mfd->w;
    fa->dst.h= mfd->h;
    fa->dst.pitch= mfd->w*4;
    fa->dst.modulo= 0;
  }
  return FILTERPARAM_SWAP_BUFFERS;
}

int StartProc (FilterActivation *fa, const FilterFunctions *ff)
{
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags())) _memcpy= memcpy_amd; else _memcpy= memcpy;
  return 0;
}

void MyChooseColor (COLORREF &Color,HWND hdlg)
{
  CHOOSECOLOR cc;
  static COLORREF Custom[16];

  cc.lStructSize= sizeof(CHOOSECOLOR);
  cc.hwndOwner= hdlg;
  cc.rgbResult= Color;
  cc.lpCustColors= Custom;
  cc.Flags= CC_RGBINIT | CC_FULLOPEN;
  cc.lCustData= 0L;
  cc.lpfnHook= NULL;
  cc.lpTemplateName= NULL;
  ChooseColor(&cc);
  Color= cc.rgbResult;
}

void BuildBrush (MyFilterData *mfd,HWND hdlg)
{
  DeleteObject (mfd->color_brush);
  mfd->color_brush= CreateSolidBrush (mfd->color_ref);
  RedrawWindow (GetDlgItem(hdlg,IDC_COLORBOX),NULL,NULL,RDW_ERASE|RDW_INVALIDATE|RDW_UPDATENOW);
}

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;

      SendMessage(GetDlgItem(hdlg, IDC_WSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(8192,16));
      SendMessage(GetDlgItem(hdlg, IDC_HSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(16,8192));
      SendMessage(GetDlgItem(hdlg, IDC_XSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(4096,-4096));
      SendMessage(GetDlgItem(hdlg, IDC_YSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(-4096,4096));

      SetDlgItemInt (hdlg,IDC_WIDTH,mfd->w,false);
      SetDlgItemInt (hdlg,IDC_HEIGHT,mfd->h,false);
      SetDlgItemInt (hdlg,IDC_XOFS,mfd->x,true);
      SetDlgItemInt (hdlg,IDC_YOFS,mfd->y,true);

      CheckDlgButton(hdlg,IDC_UL,(mfd->position==POS_UPPERLEFT )?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_UC,(mfd->position==POS_UPPER     )?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_UR,(mfd->position==POS_UPPERRIGHT)?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_DL,(mfd->position==POS_DOWNLEFT  )?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_DC,(mfd->position==POS_DOWN      )?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_DR,(mfd->position==POS_DOWNRIGHT )?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_CL,(mfd->position==POS_LEFT      )?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_CC,(mfd->position==POS_CENTER    )?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_CR,(mfd->position==POS_RIGHT     )?BST_CHECKED:BST_UNCHECKED);

      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;

        case IDC_UL: mfd->position= POS_UPPERLEFT;  mfd->ifp->RedoFrame(); break;
        case IDC_UC: mfd->position= POS_UPPER;      mfd->ifp->RedoFrame(); break;
        case IDC_UR: mfd->position= POS_UPPERRIGHT; mfd->ifp->RedoFrame(); break;
        case IDC_DL: mfd->position= POS_DOWNLEFT;   mfd->ifp->RedoFrame(); break;
        case IDC_DC: mfd->position= POS_DOWN  ;     mfd->ifp->RedoFrame(); break;
        case IDC_DR: mfd->position= POS_DOWNRIGHT;  mfd->ifp->RedoFrame(); break;
        case IDC_CL: mfd->position= POS_LEFT;       mfd->ifp->RedoFrame(); break;
        case IDC_CC: mfd->position= POS_CENTER;     mfd->ifp->RedoFrame(); break;
        case IDC_CR: mfd->position= POS_RIGHT;      mfd->ifp->RedoFrame(); break;

        case IDC_WIDTH:
             if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int w= GetDlgItemInt(hdlg,IDC_WIDTH,NULL,false);
                if (w!=mfd->w)
                {
                  mfd->w= w;
                  Clipping (mfd->w,16,8192);
                  mfd->ifp->RedoSystem();
                  mfd->ifp->RedoFrame();
                }
            }
            break;

        case IDC_HEIGHT:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int h= GetDlgItemInt(hdlg,IDC_HEIGHT,NULL,false);
                if (h!=mfd->h)
                {
                  mfd->h= h;
                  Clipping (mfd->h,16,8192);
                  mfd->ifp->RedoSystem();
                  mfd->ifp->RedoFrame();
                }
            }
            break;

        case IDC_XOFS:
              if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int x= GetDlgItemInt(hdlg,IDC_XOFS,NULL,true);
                if (x!=mfd->x)
                {
                  mfd->x= x;
                  Clipping (mfd->x,-4096,4096);
                  mfd->ifp->RedoFrame();
                }
            }
            break;

        case IDC_YOFS:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
               int y= GetDlgItemInt(hdlg,IDC_YOFS,NULL,true);
               if (y!=mfd->y)
               {
                 mfd->y= y;
                 Clipping (mfd->y,-4096,4096);
                 mfd->ifp->RedoFrame();
               }
            }
            break;

        case IDC_RESET:
            //mfd->ifp->UndoSystem();
            mfd->w= 320;
            mfd->h= 240;
            mfd->x= 0;
            mfd->y= 0;
            SetDlgItemInt(hdlg,IDC_WIDTH ,mfd->w,false);
            SetDlgItemInt(hdlg,IDC_HEIGHT,mfd->h,false);
            SetDlgItemInt(hdlg,IDC_XOFS  ,mfd->x,true);
            SetDlgItemInt(hdlg,IDC_YOFS  ,mfd->y,true);
            mfd->ifp->RedoSystem();
            mfd->ifp->RedoFrame();
            break;

        case IDC_COLORBOX:
            if (HIWORD(wParam)!=STN_DBLCLK) return TRUE;

        case IDC_PICCOLOR:
            MyChooseColor(mfd->color_ref,hdlg);
            BuildBrush (mfd,hdlg);
            mfd->ifp->RedoFrame();
            return TRUE;
      }
      break;

    case WM_CTLCOLORSTATIC:
          if (GetWindowLong((HWND)lParam,GWL_ID)== IDC_COLORBOX) return (BOOL)mfd->color_brush;


    case WM_VSCROLL:
    case WM_HSCROLL:
    {
        int w= GetDlgItemInt(hdlg,IDC_WIDTH ,NULL,false);
        int h= GetDlgItemInt(hdlg,IDC_HEIGHT,NULL,false);
        int x= GetDlgItemInt(hdlg,IDC_XOFS,NULL,true);
        int y= GetDlgItemInt(hdlg,IDC_YOFS,NULL,true);
        if (w!=mfd->w || h!=mfd->h)
        {
          //mfd->ifp->UndoSystem();
          mfd->w= w;
          mfd->h= w;
          mfd->ifp->RedoSystem();
        }
        if (x!=mfd->x || y!=mfd->y)
        {
          mfd->x= x;
          mfd->y= y;
          mfd->ifp->RedoFrame();
        }
    }
      break;

  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;

  int res=DialogBoxParam(fa->filter->module->hInstModule,
                        MAKEINTRESOURCE(IDD_FILTER_CANVAS),
                        hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (res) *mfd= mfd_old;
  return res;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d, %d, %d, %d, %d, %d,%d)",mfd->w,mfd->h,mfd->position,
      GetRValue(mfd->color_ref),GetGValue(mfd->color_ref),GetBValue(mfd->color_ref),
      mfd->x,mfd->y);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->w       = argv[0].asInt();
  mfd->h       = argv[1].asInt();
  mfd->position= argv[2].asInt();
  int R= argv[3].asInt();
  int G= argv[4].asInt();
  int B= argv[5].asInt();
  mfd->x       = argv[6].asInt();
  mfd->y       = argv[7].asInt();
  Clipping (mfd->w,16,8192);
  Clipping (mfd->h,16,8192);
  Clipping (mfd->x,-4096,4096);
  Clipping (mfd->y,-4096,4096);
  Clipping (mfd->position,0,8);
  Clipping (R,0,255);
  Clipping (G,0,255);
  Clipping (B,0,255);
  mfd->color_ref= RGB(R,G,B);
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  _snprintf(str,64," (W:%d H:%d [x:%d y:%d])",mfd->w,mfd->h,mfd->x,mfd->y);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiiiiiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

struct FilterDefinition filterDef_Canvas=
{
  NULL, NULL, NULL,            // next, prev, module
  "Canvas Size",               // name
  "Cromp/Enlarge picture.\n"
  "Version 1.3 (30-10-2004)[iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  StartProc,                   // startProc
  NULL,                        // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd_Canvas;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_Canvas = ff->addFilter(fm, &filterDef_Canvas, sizeof(FilterDefinition));
  if (!fd_Canvas) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_Canvas);
}
