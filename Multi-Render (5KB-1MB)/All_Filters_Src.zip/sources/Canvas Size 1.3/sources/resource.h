//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_CANVAS               101
#define IDC_WIDTH                       1001
#define IDC_HEIGHT                      1002
#define IDC_UL                          1003
#define IDC_UC                          1004
#define IDC_UR                          1005
#define IDC_CL                          1006
#define IDC_CC                          1007
#define IDC_CR                          1008
#define IDC_DL                          1009
#define IDC_DC                          1010
#define IDC_DR                          1011
#define IDC_XOFS                        1012
#define IDC_COLORBOX                    1013
#define IDC_PICCOLOR                    1014
#define IDC_YOFS                        1015
#define IDC_WSPIN                       1016
#define IDC_RESET                       1017
#define IDC_HSPIN                       1018
#define IDC_XSPIN                       1019
#define IDC_YSPIN                       1020

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
