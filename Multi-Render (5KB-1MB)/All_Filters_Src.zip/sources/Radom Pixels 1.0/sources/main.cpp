/* Random Pixels - filter for VirtualDub
   Copyright (C) 2003 Emiliano Ferrari     <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include "resource.h"
#include "filter.h"
#include "ScriptValue.h"

typedef struct
{
  IFilterPreview *ifp;
  int radius;
  bool fix;
} MyFilterData;

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  Pixel32 *src= fa->src.data;
  const int h= fa->src.h;
  const int w= fa->src.w;
  const int pitch= fa->src.pitch>>2;
  const int mod= pitch-w;
  const int radius= mfd->radius;

  if (mfd->fix) srand(0);
  for (int y=0; y<h; y++)
  {
    for (int x=0; x<w; x++)
    {
        int i= x+rand()%(radius*2)-radius;;
        int j= y+rand()%(radius*2)-radius;;
        if (i<0) i= -i; else if (i>=w) i= w-(i-w+1);
        if (j<0) j= -j; else if (j>=h) j= h-(j-h+1);
        *dst++= src[i+j*pitch];
    }
    dst+= mod;
  }
  return 0;
}

// =============================================================0

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d)", mfd->radius);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->radius= argv[0].asInt();
  Clipping (mfd->radius,1,100);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0i"},{NULL},};
     CScriptObject script_obj= {NULL,func_defs};

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(str,64, " (RADIUS:%d)",mfd->radius);
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->radius= 5;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  return FILTERPARAM_SWAP_BUFFERS;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;

      SendMessage(GetDlgItem(hdlg, IDC_RADIUS), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1,100));
      SendMessage(GetDlgItem(hdlg, IDC_RADIUS), TBM_SETPOS, (WPARAM)TRUE, mfd->radius);
      SetDlgItemInt(hdlg,IDC_RADIUSVAL,mfd->radius,false);
      CheckDlgButton(hdlg, IDC_FIXNOISE, mfd->fix ? BST_CHECKED : BST_UNCHECKED);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW:mfd->ifp->Toggle(hdlg);  break;
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;
        case IDC_FIXNOISE: mfd->fix= !!IsDlgButtonChecked(hdlg, IDC_FIXNOISE);break;
      }
      break;

    case WM_HSCROLL:
      {
        mfd->radius= SendMessage(GetDlgItem(hdlg, IDC_RADIUS), TBM_GETPOS, 0, 0);
        SetDlgItemInt(hdlg,IDC_RADIUSVAL,mfd->radius,false);
        mfd->ifp->RedoFrame();
        break;
      }
  }
  return FALSE;
}
int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int Resoult= DialogBoxParam (fa->filter->module->hInstModule,
                               MAKEINTRESOURCE(IDD_FILTER_RPIXELS),
                               hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (Resoult) *mfd= mfd_old;
  return !!Resoult;
}

// ========================================================

struct FilterDefinition filterDef_RGB=
{
  NULL,NULL,NULL,                 // next, prev, module
  "Random Pixels",                // name
  "Version 1.0\n"
  "Copyright (C) 2003 Emiliano Ferrari\n"
  "macinapepe@tiscali.it",        // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  sizeof(MyFilterData),           // inst_data_size
  InitProc,                       // initProc
  NULL,                           // deinitProc
  RunProc,                        // runProc
  ParamProc,                      // paramProc
  ConfigProc,                     // configProc
  StringProc,                     // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  &script_obj,                    // script_obj
  FssProc,                        // fssProc
};

static FilterDefinition *fd_RGB;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_RGB= ff->addFilter(fm, &filterDef_RGB, sizeof(FilterDefinition));
  if (!fd_RGB) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_RGB);
}
