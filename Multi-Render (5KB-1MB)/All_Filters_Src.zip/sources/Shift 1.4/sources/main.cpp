/*  Shift - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari   <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

//    Version 1.0 (23-09-2003): + aggiunto pad
//    Version 1.1 (17-03-2004): + aggiunto il codice del filtro Roller
//                              + modificata l'interfaccia
//                              + aggiunti tasti per l'azzeramento dei campi


#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "ScriptValue.h"
#include "resource.h"
#include "pad.cpp"

#pragma warning(disable:4035)
#include "memcpy_amd.cpp"

typedef void *(MEMCPY) (void *,const void *,size_t);
MEMCPY *_memcpy;

typedef struct
{
  int x,y;
  int red,green,blue;
  COLORREF color_ref;
  HBRUSH   color_brush;
  bool repeat;
  IFilterPreview *ifp;
} MyFilterData;

void memfill (Pixel32 *dst,Pixel32 color,int size)
{
  for (int i=0; i<size; i++) *dst++= color;
}

void VRoller(Pixel32 *dst,Pixel32 *src,const int pitch,const int h,const int y)
{
  const int A= y*pitch;
  const int B= (h-y)*pitch;
  _memcpy (dst+A,src,B*sizeof(Pixel32));
  _memcpy (dst,src+B,A*sizeof(Pixel32));
}

void HRoller(Pixel32 *dst,Pixel32 *src,const int pitch,const int w,const int h,const int x)
{
  const int A= x;
  const int B= w-x;
  for (int y=0; y<h; y++)
    {
      _memcpy (dst+A,src,B*sizeof(Pixel32));
      _memcpy (dst,src+B,A*sizeof(Pixel32));
      dst+= pitch;
      src+= pitch;
    }
}

void XYRoller(Pixel32 *dst,Pixel32 *src,const int pitch,const int w,const int h,const int x,const int y)
{
  Pixel32 *dest,*source;
  const int xdiff= (w-x);

  dest= dst+y*pitch;
  source= src;
  for (int j=0; j<(h-y); j++)
    {
      _memcpy (dest+x, source      , xdiff*sizeof(Pixel32));
      _memcpy (dest  , source+xdiff, x    *sizeof(Pixel32));
      dest+= pitch;
      source+= pitch;
    }

   dest= dst;
   source= src+(h-y)*pitch;
   for (j=0; j<y; j++)
    {
      _memcpy (dest+x,source, xdiff *sizeof(Pixel32));
      _memcpy (dest  ,source+xdiff,x *sizeof(Pixel32));
      dest+= pitch;
      source+= pitch;
    }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *src= fa->src.data;
  Pixel32 *dst= fa->dst.data;
  Pixel32 *end= fa->dst.data+(fa->dst.size>>2);
  Pixel32 color= (mfd->red<<16) | (mfd->green<<8) | mfd->blue;
  const int pitch= fa->dst.pitch>>2;
  const int w    = fa->dst.w;
  const int h    = fa->dst.h;

  if (mfd->repeat)
  {
    int x= mfd->x;
    int y= h-mfd->y;
    while (x<0) x+= w;
    while (x>w) x-= w;
    while (y<0) y+= h;
    while (y>h) y-= h;
    if (y==0) { HRoller (dst,src,pitch,w,h,x); return 0; }
    if (x==0) { VRoller (dst,src,pitch,h,y);   return 0; }
    XYRoller (dst,src,pitch,w,h,x,y);
  }
  else
  {
    const int x= mfd->x;
    const int y= -mfd->y;
    int s1,s3,dx,dy;
    if (fa->src.pitch!=fa->dst.pitch)
      ff->Except("ERROR: S100 - Please send me this bug. sorry.");
    int x1= x;
    int y1= y;
    int x2= x+w;
    int y2= y+h;
    if (x==0 && y==0)
    {
      _memcpy (dst,src,fa->dst.size);
      return 0;
    }

    if (x1>=w || x2<0 || y1>=h || y2<=0)
    {
      memfill (dst,color,fa->dst.size>>2);
        return 0;
    }

  int ox= 0;
  int oy= 0;
  if (x1<0) { ox= -x1; x1= 0; }
  if (y1<0) { oy= -y1; y1= 0; }
  src+= ox+oy*pitch;
  if (x2>w) x2= w;
  if (y2>h) y2= h;
  dx= x2-x1;
  dy= y2-y1;

  if (dx==0 || dy==0)
  {
    _memcpy (dst,src,fa->dst.size);
    return 0;
  }

  s1= x1+y1*pitch;
  if (s1!=0) memfill (dst,color,s1);
  dst+= s1;

 /* if (dx==pitch)
  {
      memcpy (dst,src,dy*pitch+4);
      dst+= dy*pitch;
  }
  else
  */
  for (int j=0; j<dy; j++)
  {
      _memcpy (dst,src,dx*4);
      dst+= dx;
      memfill (dst,color,pitch-dx);
      dst+= pitch-dx;
      src+= pitch;
  }

  s3= end-dst;
  if (s3!=0) memfill (dst,color,s3);

  }

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->x= 0;
  mfd->y= 0;
  mfd->color_ref= RGB (0,0,0);
  mfd->red= mfd->green= mfd->blue= 0;
  mfd->color_brush= CreateSolidBrush (mfd->color_ref);
  mfd->repeat= false;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  return FILTERPARAM_SWAP_BUFFERS;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags())) _memcpy= memcpy_amd; else _memcpy= memcpy;
  return 0;
}

void MyChooseColor(COLORREF &Color,HWND hdlg)
{
  CHOOSECOLOR cc;
  static COLORREF Custom[16];

  cc.lStructSize= sizeof(CHOOSECOLOR);
  cc.hwndOwner= hdlg;
  cc.rgbResult= Color;
  cc.lpCustColors= Custom;
  cc.Flags= CC_RGBINIT | CC_FULLOPEN;
  cc.lCustData= 0L;
  cc.lpfnHook= NULL;
  cc.lpTemplateName= NULL;
  ChooseColor(&cc);
  Color= cc.rgbResult;
}

void BuildBrush(MyFilterData *mfd,HWND hdlg)
{
  DeleteObject (mfd->color_brush);
  mfd->color_brush= CreateSolidBrush (mfd->color_ref);
  RedrawWindow (GetDlgItem(hdlg,IDC_COLORBOX),NULL,NULL,RDW_ERASE|RDW_INVALIDATE|RDW_UPDATENOW);
}

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {

    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SetDlgItemInt (hdlg,IDC_X,mfd->x,true);
      SetDlgItemInt (hdlg,IDC_Y,mfd->y,true);
      SendMessage(GetDlgItem(hdlg, IDC_XSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(8192,-8192));
      SendMessage(GetDlgItem(hdlg, IDC_YSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(-8192,8192));
      CheckDlgButton(hdlg, IDC_REPEAT, mfd->repeat ? BST_CHECKED : BST_UNCHECKED);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;

        case IDC_REPEAT:
          mfd->repeat= !!IsDlgButtonChecked(hdlg, IDC_REPEAT);
          mfd->ifp->RedoFrame();
          break;

        case IDC_X0:
        {
            mfd->x= 0;
            SetDlgItemInt (hdlg,IDC_X,mfd->x,true);
            mfd->ifp->RedoFrame();
            break;
        }
        case IDC_Y0:
        {
            mfd->y= 0;
            SetDlgItemInt (hdlg,IDC_Y,mfd->y,true);
            mfd->ifp->RedoFrame();
            break;
        }

        case IDC_X:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int x= GetDlgItemInt(hdlg,IDC_X,NULL,true);
            if (x!=mfd->x)
            {
              mfd->x= x;
              mfd->ifp->RedoFrame();
            }
          }
          break;
        case IDC_Y:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int y= GetDlgItemInt(hdlg,IDC_Y,NULL,true);
            if (y!=mfd->y)
            {
              mfd->y= y;
              mfd->ifp->RedoFrame();
            }
          }
          break;

        case IDC_COLORBOX:
            if (HIWORD(wParam)!=STN_DBLCLK) return TRUE;
        case IDC_PICCOLOR:
            MyChooseColor(mfd->color_ref,hdlg);
            BuildBrush (mfd,hdlg);
            mfd->red= GetRValue(mfd->color_ref);
            mfd->green= GetGValue(mfd->color_ref);
            mfd->blue= GetBValue(mfd->color_ref);
            mfd->ifp->RedoFrame();
            return TRUE;
      }
      break;

          case WM_NOTIFY:
      if (IDC_PAD==(int)wParam)
      {
        NMHDR *pnmh= (NMHDR *)lParam;
        NMVLPADCHANGE *pnmvltc= (NMVLPADCHANGE *)lParam;
        mfd->x+= pnmvltc->dx;
        mfd->y+= pnmvltc->dy;
        SetDlgItemInt(hdlg,IDC_X,mfd->x,true);
        SetDlgItemInt(hdlg,IDC_Y,mfd->y,true);
        mfd->ifp->RedoFrame();
      }
      break;


    case WM_VSCROLL:
    case WM_HSCROLL:
    {
      int x= GetDlgItemInt(hdlg,IDC_X,NULL,true);
      int y= GetDlgItemInt(hdlg,IDC_Y,NULL,true);
      if (x!=mfd->x || y!=mfd->y)
      {
        mfd->x= x;
        mfd->y= y;
        mfd->ifp->RedoFrame();
      }
      break;
    }

    case WM_CTLCOLORSTATIC:
          if (GetWindowLong((HWND)lParam,GWL_ID)== IDC_COLORBOX) return (BOOL)mfd->color_brush;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  RegisterPadControl(fa->filter->module->hInstModule);
  int res=DialogBoxParam(fa->filter->module->hInstModule,
                        MAKEINTRESOURCE(IDD_FILTER_SHIFT),
                        hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (res) *mfd= mfd_old;
  return res;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d, %d, %d)",
      mfd->x,mfd->y,(mfd->red<<16)|(mfd->green<<8)|mfd->blue,mfd->repeat);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->x    = argv[0].asInt();
  mfd->y    = argv[1].asInt();
  mfd->red  = (argv[2].asInt()>>16)&0xff;
  mfd->green= (argv[2].asInt()>> 8)&0xff;
  mfd->blue = (argv[2].asInt()    )&0xff;
  mfd->repeat= !!argv[3].asInt();
  mfd->color_ref= RGB(mfd->red,mfd->blue,mfd->green);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(str,64," (%d,%d,#%06X)%s", mfd->x,mfd->y,(mfd->red<<16)|(mfd->green<<8)|mfd->blue,mfd->repeat?" [repeated]":"");
}

FilterDefinition filterDef_fill=
{
  NULL, NULL, NULL,            // next, prev, module
  "Shift",                     // name
  "adjust frame position.\n"
  "Version 1.1 (17-03-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  StartProc,                   // startProc
  NULL,                        // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd_fill;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_fill = ff->addFilter(fm, &filterDef_fill, sizeof(FilterDefinition));
  if (!fd_fill) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_fill);
}
