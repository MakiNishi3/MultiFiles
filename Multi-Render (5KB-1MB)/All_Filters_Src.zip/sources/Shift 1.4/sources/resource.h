//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_SHIFT                101
#define IDC_X                           1001
#define IDC_Y                           1002
#define IDC_XSPIN                       1003
#define IDC_YSPIN                       1004
#define IDC_COLORBOX                    1005
#define IDC_PICCOLOR                    1006
#define IDC_PAD                         1007
#define IDC_REPEAT                      1008
#define IDC_X0                          1009
#define IDC_Y0                          1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
