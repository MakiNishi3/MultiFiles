/*  Fields Align - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// Version 1.3 (27-09-2003)
// Version 1.4 (31-10-2004): Piccola revisione al codice

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "ScriptValue.h"
#include "resource.h"

#pragma warning(disable:4035)
#include "memcpy_amd.cpp"

typedef struct
{
  IFilterPreview *ifp;
  int     shift;
  Pixel32 *tmp;
} MyFilterData;

typedef void *(MEMCPY) (void *,const void *,size_t);
MEMCPY *_memcpy;

void FAlign (Pixel32 *dst,Pixel32 *tmp,int w,int x)
{
  if (x>=0)
   {
     _memcpy (tmp  ,dst,(w-x)*sizeof(Pixel32));
     _memcpy (dst+x,tmp,(w-x)*sizeof(Pixel32));
     memset (dst,0,x*sizeof(Pixel32));
   }
  else
   {
     x= w+x;
     _memcpy (dst,dst+(w-x),x*sizeof(Pixel32));
     memset (dst+x,0,(w-x)*sizeof(Pixel32));
   }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const PixDim width= fa->src.w;
  const PixDim height= fa->src.h;

  int OddOffset= mfd->shift>>1;
  if (mfd->shift>=width)
  {
      memset (fa->dst.data,0,fa->dst.size);
      return 0;
  }

  const int EvenOffset= -(mfd->shift-(mfd->shift>>1));
  const int pitch= fa->dst.pitch>>2;
  Pixel32 *dst= fa->dst.data;

  for (int y=0; y<height; y+=2)
    {
      FAlign(dst,mfd->tmp,width,OddOffset);
      dst+= pitch;
      FAlign(dst,mfd->tmp,width,EvenOffset);
      dst+= pitch;
    }
  if (height&1) FAlign (dst,mfd->tmp,width,OddOffset);
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->shift= 0;
  mfd->tmp= NULL;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
      _memcpy= memcpy_amd; else _memcpy= memcpy;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->tmp) { delete[] mfd->tmp; mfd->tmp=NULL; }
  mfd->tmp= new Pixel32[fa->src.size>>2];
  if (!mfd->tmp) return 1;
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->tmp) { delete[] mfd->tmp; mfd->tmp=NULL; }
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd= (MyFilterData *)lParam;
      SetDlgItemInt (hdlg,IDC_SHIFT,mfd->shift,TRUE);
      SendMessage(GetDlgItem(hdlg, IDC_SPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(8192,-8192));
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg); break;
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;
        case IDC_SHIFT:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int shift= GetDlgItemInt(hdlg,IDC_SHIFT,NULL,TRUE);
            if (shift!=mfd->shift)
            {
              mfd->shift= shift;
              mfd->ifp->RedoFrame();
            }
          }
          break;

      }
      break;

    case WM_HSCROLL:
      int shift= GetDlgItemInt(hdlg,IDC_SHIFT,NULL,TRUE);
      if (shift!=mfd->shift)
      {
        mfd->shift= shift;
        mfd->ifp->RedoFrame();
      }
      break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_FALIGN),
                          hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return !!ret;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(str,64," (%d)", mfd->shift);
}

inline void Clipping(int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d)",mfd->shift);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->shift= argv[0].asInt();
  Clipping (mfd->shift,-8192,8192);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0i"},{NULL},};
CScriptObject script_obj={NULL,func_defs};

FilterDefinition filterDef_FieldsAlign=
{
  NULL, NULL, NULL,        // next, prev, module
  "Fields Align",          // name
  "adjust fields alignment.\n"
  "Version 1.4 (31-10-2004) [iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it", // desc
  "Emiliano Ferrari",      // maker
  NULL,                    // private_data
  sizeof(MyFilterData),    // inst_data_size
  InitProc,                // initProc
  NULL,                    // deinitProc
  RunProc,                 // runProc
  ParamProc,               // paramProc
  ConfigProc,              // configProc
  StringProc,              // stringProc
  StartProc,               // startProc
  EndProc,                 // endProc
  &script_obj,             // script_obj
  FssProc,                 // fssProc
};

static FilterDefinition *fd_FieldsAlign;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_FieldsAlign= ff->addFilter(fm, &filterDef_FieldsAlign, sizeof(FilterDefinition));
  if (!fd_FieldsAlign) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_FieldsAlign);
}
