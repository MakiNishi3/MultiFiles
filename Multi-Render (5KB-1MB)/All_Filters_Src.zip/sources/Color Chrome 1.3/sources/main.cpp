/*  Color Chrome - filter for VirtualDub.
    Copyright (C) 2003,2004 Emiliano Ferrari   <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// Version 1.2 (30-09-2003)
// Version 1.3 (31-10-2004): rimossi alcuni possibili buffer overflow

#include <math.h>
#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "ScriptValue.h"
#include "resource.h"

typedef struct
{
  IFilterPreview *ifp;
  int ofs;
  int freq;
  int palette[256];
  int HTab[256];
  int STab[512];
} MyFilterData;

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

void MakePal(MyFilterData *mfd)
{
  int x;

  mfd->HTab[0]= 0;
  for (x=1  ; x<256; x++) mfd->HTab[x]= (255*65536)/x;
  for (x=0  ; x<256; x++) mfd->STab[x]= mfd->HTab[x];
  for (x=256; x<510; x++) mfd->STab[x]= (255*65536)/(510-x);
  mfd->STab[510]=0;

  for (int l=0; l<256; l++)
    mfd->palette[l]= (int)(128+128*sin(((mfd->ofs+l)%256)*6.28/(256.0/mfd->freq)));
}

void RGB2HSL(int r,int g,int b,int &H,int &S,int &L)
{ // RGB to HSL color space
  //   input  r,g,b [0..255]
  //   output H,S,L [0..255]
  int cmax= max(r,max(g,b));
  int cmin= min(r,min(g,b));
  S= cmax-cmin;
  L= cmax+cmin;
  if (S==0) { H=0; L>>=1; if (L>255) L=255; return; }
  if (L==0) L=1;
  if (r==cmax) H= (255*(g-b)+127)/S;
    else
     if (g==cmax) H= 510+(255*(b-r)+127)/S;
      else
        H= 1020+(255*(r-g)+127)/S;
  H/=6;
  if (H<0) H+= 255;

  if (L<255) S= (255*S+127)/L; else S= (255*S+127)/(510-L);
  L>>= 1;
  if ((unsigned)S>255) S= (~S>>31)&0xff;
}

inline int HUE2RGB(const int M1,const int M2,int H)
{
  if (H<0)   H+= 255;
  if (H>255) H-= 255;
  if (6*H<255) return M1+((M2-M1)*H*6+127)/255;
  if (2*H<255) return M2;
  if (3*H<510) return M1+((M2-M1)*(170-H)*6+127)/255;
  return M1;
}

void HSL2RGB(int H,int S,int L,int &r,int &g,int &b)
{ // HSL to RGB color space
  //   input  H,S,L [0..255]
  //   output r,g,b [0..255]
  int M1,M2;
  if (S==0) { r= g= b= L; return;}

  if (L<128) M2= (L*(255+S)+128)/255; else M2= L+S-(L*S+128)/255;
  M1= 2*L-M2;
  r= HUE2RGB(M1,M2,H+85);
  g= HUE2RGB(M1,M2,H);
  b= HUE2RGB(M1,M2,H-85);
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const int w= fa->dst.w;
  const int h= fa->dst.h;
  Pixel32 *dst= fa->dst.data;

  for (int y=0; y<h; y++)
  {
    for (int x=0; x<w; x++)
    {
      int a,r,g,b,H,S,L;
      a= (*dst)&0xff000000;
      r= (*dst>>16) & 0xff;
      g= (*dst>> 8) & 0xff;
      b= (*dst    ) & 0xff;
      RGB2HSL (r,g,b,H,S,L);
      if ((L<24) || (L>231)) S=0;
      L= (L+mfd->palette[L])>>1;
      HSL2RGB (H,S,L,r,g,b);
      *dst++= a| (r<<16) | (g<<8) | b;
    }
    dst+= fa->dst.modulo;
  }
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->ofs = 0;
  mfd->freq= 4;
  MakePal (mfd);
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char temp[128];
  switch(msg)
    {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd= (MyFilterData *)lParam;
      HWND hWnd;
      hWnd= GetDlgItem(hdlg, IDC_OFS);
      SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(0,255));
      SendMessage(hWnd, TBM_SETTICFREQ, 10 , 0);
      SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, mfd->ofs);
      _snprintf(temp,128,"%d",mfd->ofs);
      SetDlgItemText (hdlg,IDC_EOFS,temp);
      hWnd= GetDlgItem(hdlg, IDC_INT);
      SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1,10));
      SendMessage(hWnd, TBM_SETTICFREQ, 10, 0);
      SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, mfd->freq);
      _snprintf(temp,128,"%d",mfd->freq);
      SetDlgItemText (hdlg,IDC_EINT,temp);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
        {
          case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
          case IDOK:      EndDialog(hdlg,0); return TRUE;
          case IDCANCEL:  EndDialog(hdlg,1); return TRUE;
        }
      break;

    case WM_HSCROLL:
      mfd->ofs= SendMessage(GetDlgItem(hdlg, IDC_OFS), TBM_GETPOS, 0, 0);
      _snprintf(temp,128,"%d",mfd->ofs);
      SetDlgItemText (hdlg,IDC_EOFS,temp);
      mfd->freq= SendMessage(GetDlgItem(hdlg, IDC_INT), TBM_GETPOS, 0, 0);
      _snprintf(temp,128,"%d",mfd->freq);
      SetDlgItemText (hdlg,IDC_EINT,temp);
      MakePal (mfd);
      mfd->ifp->RedoFrame();
      break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int ret= DialogBoxParam (fa->filter->module->hInstModule,
                           MAKEINTRESOURCE(IDD_FILTER_CCHROME),
                           hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return ret;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(str,64," (O:%d I:%d%%)", mfd->ofs, mfd->freq);
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d, %d)",mfd->ofs,mfd->freq);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->ofs = argv[0].asInt();
  mfd->freq= argv[1].asInt();
  Clipping (mfd->ofs,0,255);
  Clipping (mfd->freq,1,10);
}

ScriptFunctionDef func_defs[]=
  {{(ScriptFunctionPtr)ScriptConfig, "Config", "0ii"},{NULL},};
CScriptObject script_obj= {NULL, func_defs};

FilterDefinition filterDef_CCromo=
{
  NULL,NULL,NULL,        // next, prev, module
  "Color Chrome",        // name
  "Chrome Effects whith colors.\n"   // desc
  "Version 1.3 (31-10-2004)\n"
  "Copyright (C) 2003,2004 by Emiliano Ferrari\n"
  "macinapepe@tiscali.it",
  "Emiliano Ferrari",    // maker
  NULL,                  // private_data
  sizeof(MyFilterData),  // inst_data_size
  InitProc,              // initProc
  NULL,                  // deinitProc
  RunProc,               // runProc
  ParamProc,             // paramProc
  ConfigProc,            // configProc
  StringProc,            // stringProc
  NULL,                  // startProc
  NULL,                  // endProc
  &script_obj,           // script_obj
  FssProc,               // fssProc
};

static FilterDefinition *fd_CCromo;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_CCromo= ff->addFilter(fm, &filterDef_CCromo, sizeof(FilterDefinition));
  if (!fd_CCromo) return 1;
  vdfd_ver=    VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_CCromo);
}
