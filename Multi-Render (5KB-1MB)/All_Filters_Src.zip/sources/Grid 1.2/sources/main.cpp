/* Grid - filter for VirtualDub
   Copyright (C) 2004 Emiliano Ferrari <macinapepe@tiscali.it>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.          */

// Version 1.0 (22-04-2004): prima versione
// Version 1.1 (21-05-2004): rimossi alcuni bug
// Version 1.2 (31-10-2004): rimosso alcuni buffer overflow ed alcuni bug minori

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "resource.h"
#include "ScriptValue.h"

typedef struct
{
  IFilterPreview *ifp;
  int Alpha,Red,Green,Blue;
  int LineWidth,LineSpace;
  COLORREF color_ref;
  HBRUSH   color_brush;
} MyFilterData;

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->Alpha= 128;
  mfd->Red  = 255;
  mfd->Green= 255;
  mfd->Blue = 0;
  mfd->LineSpace= 40;
  mfd->LineWidth= 2;
  mfd->color_ref= RGB (mfd->Red,mfd->Green,mfd->Blue);
  mfd->color_brush= CreateSolidBrush (mfd->color_ref);
  return 0;
}

Pixel32 Blend (Pixel32 pix,Pixel32 ovl,int Alpha)
{
  int r= (pix>>16)&0xff;
  int g= (pix>> 8)&0xff;
  int b= (pix    )&0xff;
  int R= (ovl>>16)&0xff;
  int G= (ovl>> 8)&0xff;
  int B= (ovl    )&0xff;
  r+= ((R-r)*Alpha)>>8;
  g+= ((G-g)*Alpha)>>8;
  b+= ((B-b)*Alpha)>>8;
  return (r<<16)|(g<<8)|b;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const int w= fa->dst.w;
  const int h= fa->dst.h;
  Pixel32 *dst= fa->dst.data;
  Pixel32 pix= (mfd->Red<<16)|(mfd->Green<<8)|mfd->Blue;
  const int lw= mfd->LineWidth;
  const int ls= mfd->LineSpace;
  const int alpha= mfd->Alpha;
  const int pitch= fa->dst.pitch>>2;
  int x,y,s;

  if (lw>=ls) return 0;

  for (x=0; x<w; x+= ls)
   for (s=0; s<lw; s++)
    for (y=0; y<h; y++)
      if ((x+s) < w) dst[(x+s) + (y*pitch)]= Blend(dst[(x+s) + (y*pitch)],pix,alpha);

  for (y=0; y<h; y+= ls)
   for (s=0; s<lw; s++)
    for (x=0; x<w; x++)
     if ((x % ls) >= lw)   // Evita la sovrapposizione delle linee
       if ((y+s) < h) dst[x + ((y+s)*pitch)]= Blend(dst[x + ((y+s)*pitch)],pix,alpha);

  return 0;
}

void MyChooseColor(COLORREF &Color,HWND hdlg)
{
  CHOOSECOLOR cc;
  static COLORREF Custom[16];

  cc.lStructSize= sizeof(CHOOSECOLOR);
  cc.hwndOwner= hdlg;
  cc.rgbResult= Color;
  cc.lpCustColors= Custom;
  cc.Flags= CC_RGBINIT | CC_FULLOPEN;
  cc.lCustData= 0L;
  cc.lpfnHook= NULL;
  cc.lpTemplateName= NULL;
  ChooseColor(&cc);
  Color= cc.rgbResult;
}

void BuildBrush(MyFilterData *mfd,HWND hdlg)
{
  DeleteObject (mfd->color_brush);
  mfd->color_brush= CreateSolidBrush (mfd->color_ref);
  RedrawWindow (GetDlgItem(hdlg,IDC_COLORBOX),NULL,NULL,RDW_ERASE|RDW_INVALIDATE|RDW_UPDATENOW);
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd= (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg,IDC_ALPHA), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(0, 255));
      SendMessage(GetDlgItem(hdlg,IDC_ALPHA), TBM_SETPOS, (WPARAM)TRUE, mfd->Alpha);
      SendMessage(GetDlgItem(hdlg,IDC_LINEW), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1,10));
      SendMessage(GetDlgItem(hdlg,IDC_LINEW), TBM_SETPOS, (WPARAM)TRUE, mfd->LineWidth);
      SendMessage(GetDlgItem(hdlg,IDC_LINES), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(2,200));
      SendMessage(GetDlgItem(hdlg,IDC_LINES), TBM_SETPOS, (WPARAM)TRUE, mfd->LineSpace);
	  SetDlgItemInt(hdlg, IDC_ALPHAVAL,mfd->Alpha, FALSE);
      SetDlgItemInt(hdlg, IDC_LINEWVAL,mfd->LineWidth, FALSE);
      SetDlgItemInt(hdlg, IDC_LINESVAL,mfd->LineSpace, FALSE);
      BuildBrush (mfd,hdlg);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

      case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;
        case IDC_COLORBOX:
            if (HIWORD(wParam)!=STN_DBLCLK) return TRUE;
        case IDC_PICCOLOR:
            MyChooseColor(mfd->color_ref,hdlg);
            BuildBrush (mfd,hdlg);
            mfd->Red  = GetRValue(mfd->color_ref);
            mfd->Green= GetGValue(mfd->color_ref);
            mfd->Blue = GetBValue(mfd->color_ref);
            mfd->ifp->RedoFrame();
            return TRUE;
      }
      break;

      case WM_HSCROLL:
      {
      	mfd->Alpha= SendMessage(GetDlgItem(hdlg,IDC_ALPHA),TBM_GETPOS,0,0);
      	mfd->LineWidth= SendMessage(GetDlgItem(hdlg,IDC_LINEW),TBM_GETPOS,0,0);
      	mfd->LineSpace= SendMessage(GetDlgItem(hdlg,IDC_LINES),TBM_GETPOS,0,0);
      	if (mfd->LineWidth>=mfd->LineSpace)
      	{
      	  mfd->LineWidth= mfd->LineSpace-1;
      	  SendMessage(GetDlgItem(hdlg,IDC_LINEW), TBM_SETPOS, (WPARAM)TRUE, mfd->LineWidth);
      	}
        SetDlgItemInt(hdlg, IDC_ALPHAVAL,mfd->Alpha, FALSE);
        SetDlgItemInt(hdlg, IDC_LINEWVAL,mfd->LineWidth, FALSE);
        SetDlgItemInt(hdlg, IDC_LINESVAL,mfd->LineSpace, FALSE);
        mfd->ifp->RedoFrame();
        break;
      }
     case WM_CTLCOLORSTATIC:
       if (GetWindowLong((HWND)lParam,GWL_ID)== IDC_COLORBOX) return (BOOL)mfd->color_brush;
       break;
    }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
 MyFilterData *mfd= (MyFilterData *)fa->filter_data;
 MyFilterData mfd_old= *mfd;
 mfd->ifp= fa->ifp;
 int ret= DialogBoxParam(fa->filter->module->hInstModule,
                         MAKEINTRESOURCE(IDD_FILTER_GRID),
                         hwnd, ConfigDlgProc, (LPARAM) mfd);
 if (ret) *mfd= mfd_old;
 return ret;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  _snprintf(buf, buflen, "Config(%d, %d, %d, %d, %d, %d)",
    mfd->Alpha,mfd->Red,mfd->Green,mfd->Blue,mfd->LineWidth,mfd->LineSpace);
  return true;
}

inline void Clipping(int &value,const int min,const int max)
{
  if (value<min) value=min; else if (value>max) value=max;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->Alpha    = argv[0].asInt();
  mfd->Red      = argv[1].asInt();
  mfd->Green    = argv[2].asInt();
  mfd->Blue     = argv[3].asInt();
  mfd->LineWidth= argv[4].asInt();
  mfd->LineSpace= argv[5].asInt();
  Clipping (mfd->Alpha,0,255);
  Clipping (mfd->Red  ,0,255);
  Clipping (mfd->Green,0,255);
  Clipping (mfd->Blue ,0,255);
  mfd->color_ref= RGB(mfd->Red,mfd->Blue,mfd->Green);
  Clipping (mfd->LineWidth,1,10);
  Clipping (mfd->LineSpace,2,200);
  if (mfd->LineWidth>=mfd->LineSpace) mfd->LineWidth= mfd->LineSpace-1;
}

ScriptFunctionDef func_defs[]={{(ScriptFunctionPtr)ScriptConfig,"Config","0iiiiii"},{NULL},};
CScriptObject script_obj={NULL,func_defs};

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(str,64," (lw:%d ls:%d #%x)", mfd->LineWidth,mfd->LineSpace,
  (mfd->Alpha<<24)|(mfd->Red<<16)|(mfd->Green<<8)|mfd->Blue);
}

struct FilterDefinition filterDef=
{
  NULL, NULL, NULL,        // next, prev, module
  "Grid",                  // name
  "Display a grid on video.\n"
  "Version 1.2 (31-10-2004)\n"
  "Copyright (C) 2004 Emiliano Ferrari"
  "macinapepe@tiscali.it", //desc
  "Emiliano Ferrari",      // maker
   NULL,                   // private_data
  sizeof(MyFilterData),    // inst_data_size
  InitProc,                // initProc
  NULL,                    // deinitProc
  RunProc,                 // runProc
  ParamProc,               // paramProc
  ConfigProc,              // configProc
  StringProc,              // stringProc
  NULL,                    // startProc
  NULL,                    // endProc
  &script_obj,             // script_obj
  FssProc,                 // fssProc
};

static FilterDefinition *fd;

extern "C" int __declspec(dllexport) __cdecl
VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd= ff->addFilter(fm, &filterDef, sizeof(FilterDefinition));
  if (!fd) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl
VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd);
}
