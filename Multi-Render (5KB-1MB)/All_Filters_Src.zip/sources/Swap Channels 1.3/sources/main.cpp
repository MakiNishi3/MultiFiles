/*  Swap Channels - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// Version 1.2 (28-08-2003)
// Version 1.3 (31-10-2004): revisione dei sorgenti

#include <windows.h>
#include <stdio.h>
#include "resource.h"
#include "filter.h"
#include "ScriptValue.h"

#define MODE_RGB     0
#define MODE_RBG     1
#define MODE_GRB     2
#define MODE_GBR     3
#define MODE_BRG     4
#define MODE_BGR     5
#define MODE_LAST    5

typedef struct
{
  IFilterPreview *ifp;
  int mode;
} MyFilterData;

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int psize= fa->dst.size>>2;
  int RS,GS,BS;

  switch (mfd->mode)
  {
    case MODE_RGB: RS= 16; GS=  8; BS=  0; break;
    case MODE_RBG: RS= 16; GS=  0; BS=  8; break;
    case MODE_GRB: RS=  8; GS= 16; BS=  0; break;
    case MODE_GBR: RS=  0; GS= 16; BS=  8; break;
    case MODE_BRG: RS=  8; GS=  0; BS= 16; break;
    case MODE_BGR: RS=  0; GS=  8; BS= 16; break;
  }

  for (int p=0; p<psize; p++)
  {
    int r= (*dst>>16)&0xff;
    int g= (*dst>> 8)&0xff;
    int b= (*dst    )&0xff;
    *dst++= (r<<RS) | (g<<GS) | (b<<BS);
  }
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,0,(LPARAM)"Red-Green-Blue");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,1,(LPARAM)"Red-Blue-Green");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,2,(LPARAM)"Green-Red-Blue");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,3,(LPARAM)"Green-Blue-Red");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,4,(LPARAM)"Blue-Red-Green");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,5,(LPARAM)"Blue-Green-Red");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_SETCURSEL,(WPARAM)mfd->mode,0);

      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;
        case IDC_MODE:
            mfd->mode= SendMessage (GetDlgItem(hdlg,IDC_MODE),CB_GETCURSEL,0,0);
            mfd->ifp->RedoFrame();
            break;
      }
      break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int Resoult= DialogBoxParam ( fa->filter->module->hInstModule,
                                MAKEINTRESOURCE(IDD_FILTER_SWAPCHANNELS),
                                hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (Resoult) *mfd= mfd_old;
  return !!Resoult;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const static char *modename[]= {"RGB","RBG","GRB","GBR","BRG","BGR"};
  _snprintf(str,64, " (%s)", modename[mfd->mode]);
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->mode= MODE_RGB;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d)",mfd->mode);
  return true;
}

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->mode= argv[0].asInt();
  Clipping (mfd->mode,0,MODE_LAST);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0i"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

struct FilterDefinition filterDef_SwapChannels=
{
  NULL, NULL, NULL,            // next, prev, module
  "Swap Channels",             // name
  "Version 1.3 (31-10-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  NULL,                        // startProc
  NULL,                        // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd_SwapChannels;

extern "C" int __declspec(dllexport) __cdecl
  VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_SwapChannels= ff->addFilter(fm, &filterDef_SwapChannels, sizeof(FilterDefinition));
  if (!fd_SwapChannels) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;

  return 0;
}

extern "C" void __declspec(dllexport) __cdecl
  VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_SwapChannels);
}
