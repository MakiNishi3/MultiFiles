/*  Ghost Remover - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include "resource.h"
#include "filter.h"
#include "ScriptValue.h"

#pragma warning(disable:4035)
#include "memcpy_amd.cpp"

typedef struct
{
  IFilterPreview *ifp;
  int ofs,maxofs,ints;
  Pixel32 *lbuff;
} MyFilterData;

typedef void *(MEMCOPY) (void *,const void *,size_t);
MEMCOPY *_memcpy;
typedef void (BLENDFNC)(Pixel32 *dst,Pixel32 *lbuff,int width,int Alpha);
BLENDFNC *blend;
typedef void (EMMSFNC)(void);
EMMSFNC *EMMS;
void __Dummy(){}
void __EMMS(){__asm {emms}}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const PixDim width= fa->src.w;
  const PixDim height= fa->src.h;
  Pixel32 *dst= fa->dst.data;
  Pixel32 *lbuff= mfd->lbuff;    
  const pitch= fa->dst.pitch>>2;
  int Alpha= (4096*mfd->ints)/100;
  int ofs= mfd->ofs;
  while (ofs<0) ofs+= mfd->maxofs;
  while (ofs>mfd->maxofs) ofs-= mfd->maxofs;
  int A= ofs;
  int B= mfd->maxofs-ofs;

  for (int y=0; y<height; y++)
  {    
    _memcpy(lbuff+A,dst,B<<2);
    _memcpy(lbuff,dst+B,A<<2);
    blend (dst,lbuff,width,Alpha);
    dst+= pitch;    
  }
  EMMS();

  return 0;
}

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void blend_386 (Pixel32 *dst,Pixel32 *lbuff,int width,int Alpha)
{
  for (int x=0; x<width; x++)
  {
    int r=  (dst[x]>>16) & 0xff;
    int g=  (dst[x]>> 8) & 0xff;
    int b=  (dst[x]    ) & 0xff;
    int r2= (lbuff[x]>>16) & 0xff;
    int g2= (lbuff[x]>> 8) & 0xff;
    int b2= (lbuff[x]    ) & 0xff;
    r+= (r2*Alpha)>>12;
    g+= (g2*Alpha)>>12;
    b+= (b2*Alpha)>>12;
    if ((unsigned)r>255) r= (~r>>31)&0xff;
    if ((unsigned)g>255) g= (~g>>31)&0xff;
    if ((unsigned)b>255) b= (~b>>31)&0xff;
    dst[x]= (r<<16) | (g<<8) | b;
  }
}

void blend_MMX (Pixel32 *dst,Pixel32 *lbuff,int width,int Alpha)
{
  __asm {   mov     edi,[dst]
            mov     esi,[lbuff]
            mov     ecx,[width]
            movd    mm6,[Alpha]
            punpcklwd mm6,mm6
            punpckldq mm6,mm6
            pxor    mm7,mm7
            mov     edx,ecx
            shr     ecx,1
            or      ecx,ecx
            jz      quit
            lea     edi,[edi+ecx*8]
            lea     esi,[esi+ecx*8]
            neg     ecx

            align       16
MixLoop:    movq        mm0,[edi+ecx*8]
            movq        mm2,mm0
            movq        mm1,[esi+ecx*8]
            movq        mm3,mm1
            punpcklbw   mm0,mm7
            punpckhbw   mm2,mm7
            punpcklbw   mm1,mm7
            punpckhbw   mm3,mm7
            psllw       mm1,4
            psllw       mm3,4
            pmulhw      mm1,mm6
            pmulhw      mm3,mm6
            paddw       mm0,mm1
            paddw       mm2,mm3
            packuswb    mm0,mm2
            movq        [edi+ecx*8],mm0
            inc         ecx
            jnz         MixLoop

            and         edx,1
            jz          quit
            movd        mm0,[edi+ecx*8]
            movd        mm1,[esi+ecx*8]
            punpcklbw   mm0,mm7
            punpcklbw   mm1,mm7
            psllw       mm1,4
            pmulhw      mm1,mm6
            paddw       mm0,mm1
            packuswb    mm0,mm0
            movd        [edi+ecx*8],mm0
quit:
  }
}

void blend_iSSE (Pixel32 *dst,Pixel32 *lbuff,int width,int Alpha)
{
  __asm {   mov     edi,[dst]
            mov     esi,[lbuff]
            mov     ecx,[width]
            pshufw  mm6,[Alpha],0
            pxor    mm7,mm7
            mov     edx,ecx
            shr     ecx,1
            or      ecx,ecx
            jz      quit
            lea     edi,[edi+ecx*8]
            lea     esi,[esi+ecx*8]
            neg     ecx

            align       16
MixLoop:    movq        mm0,[edi+ecx*8]
            movq        mm2,mm0
            movq        mm1,[esi+ecx*8]
            movq        mm3,mm1
            prefetchnta [edi+ecx*8+192]
            prefetchnta [esi+ecx*8+192]
            punpcklbw   mm0,mm7
            punpckhbw   mm2,mm7
            punpcklbw   mm1,mm7
            punpckhbw   mm3,mm7
            psllw       mm1,4
            psllw       mm3,4
            pmulhw      mm1,mm6
            pmulhw      mm3,mm6
            paddw       mm0,mm1
            paddw       mm2,mm3
            packuswb    mm0,mm2
            movq        [edi+ecx*8],mm0
            inc         ecx
            jnz         MixLoop

            and         edx,1
            jz          quit
            movd        mm0,[edi+ecx*8]
            movd        mm1,[esi+ecx*8]
            punpcklbw   mm0,mm7
            punpcklbw   mm1,mm7
            psllw       mm1,4
            pmulhw      mm1,mm6
            paddw       mm0,mm1
            packuswb    mm0,mm0
            movd        [edi+ecx*8],mm0
quit:
  }
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->ofs  = 0;
  mfd->ints = 0;
  mfd->maxofs= fa->dst.w;
  mfd->lbuff= NULL;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
    {
      _memcpy= memcpy_amd;
      blend = blend_iSSE;
      EMMS= __EMMS;
    }
   else
    if ((CPUF_SUPPORTS_MMX & ff->getCPUFlags()))
      {
        _memcpy= (MEMCOPY *)memcpy;
        blend = blend_MMX;
        EMMS= __EMMS;
      }
     else
      {
        _memcpy= (MEMCOPY *)memcpy;
        blend = blend_386;
        EMMS= __Dummy;
      }

  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->maxofs= fa->dst.w;
  if (mfd->maxofs>4096) mfd->maxofs= 4096;
  while (mfd->ofs<0) mfd->ofs+= mfd->maxofs;
  while (mfd->ofs>mfd->maxofs) mfd->ofs-= mfd->maxofs;
  mfd->lbuff= new Pixel32[mfd->maxofs];
  if (!mfd->lbuff) return 1;
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->lbuff) { delete[] mfd->lbuff; mfd->lbuff= NULL; mfd->maxofs=0; }
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  fa->dst.offset=fa->src.offset;
  return 0;
}

// ============================= INTERFACE ===================================
BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char temp[128];

  switch(msg)
  {
     case WM_INITDIALOG:
       SetWindowLong(hdlg, DWL_USER, lParam);
       mfd= (MyFilterData *)lParam;
       HWND hWnd;

       hWnd= GetDlgItem(hdlg, IDC_OFS);
       SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(-200,200));
       SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, mfd->ofs);
       _snprintf(temp,128, "%d",mfd->ofs);
       SetDlgItemText (hdlg,IDC_EOFS,temp);
       hWnd= GetDlgItem(hdlg, IDC_INT);
       SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(-100,100));
       SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, mfd->ints);
       _snprintf(temp,128, "%d",mfd->ints);
       SetDlgItemText (hdlg,IDC_EINT,temp);
       mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
       return TRUE;

     case WM_COMMAND:
       switch(LOWORD(wParam))
       {
          case IDPREVIEW: mfd->ifp->Toggle(hdlg); break;
          case IDOK:      EndDialog(hdlg,0); return TRUE;
          case IDCANCEL:  EndDialog(hdlg,1); return TRUE;
       }
       break;
     case WM_HSCROLL:
       hWnd= GetDlgItem(hdlg, IDC_OFS);
       mfd->ofs= SendMessage(GetDlgItem(hdlg, IDC_OFS), TBM_GETPOS, 0, 0);
       _snprintf(temp,128, "%d",mfd->ofs);
       SetDlgItemText (hdlg,IDC_EOFS,temp);
       mfd->ints= SendMessage(GetDlgItem(hdlg, IDC_INT), TBM_GETPOS, 0, 0);
       _snprintf(temp,128, "%d",mfd->ints);
       SetDlgItemText (hdlg,IDC_EINT,temp);
       mfd->ifp->RedoFrame();
       break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
    MyFilterData *mfd= (MyFilterData *)fa->filter_data;
    MyFilterData mfd_old= *mfd;
    mfd->ifp= fa->ifp;
    int ret= DialogBoxParam(fa->filter->module->hInstModule,
                            MAKEINTRESOURCE(IDD_FILTER_GHOST_REMOVER),
                            hwnd, ConfigDlgProc, (LPARAM)mfd);
    if (ret) *mfd= mfd_old;
    return !!ret;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
    MyFilterData *mfd= (MyFilterData *)fa->filter_data;
    _snprintf(str,64, " (O:%d I:%d%%)", mfd->ofs, mfd->ints);
}

// =============================== SCRIPT SUPPORT ================================
bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d, %d)",mfd->ofs,mfd->ints);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->ofs=  argv[0].asInt();
  mfd->ints= argv[1].asInt();
  Clipping (mfd->ofs ,-200,200);
  Clipping (mfd->ints,-100,100);
}

ScriptFunctionDef func_defs[]=
  {{ (ScriptFunctionPtr)ScriptConfig, "Config", "0ii" },{ NULL },};
CScriptObject script_obj={NULL,func_defs};

// ================================== FILTER REGISTRATION ========================
struct FilterDefinition filterDef_Ghost_Remover=
{
  NULL, NULL, NULL,            // next, prev, module
  "Ghost Remover",                  // name
  "Remove ghost image.\n"
  "Version 1.2 (25-09-2003) [MMX/iSSE]\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",     // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  StartProc,                   // startProc
  EndProc,                     // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd_Ghost_Remover;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_Ghost_Remover= ff->addFilter(fm, &filterDef_Ghost_Remover, sizeof(FilterDefinition));
  if (!fd_Ghost_Remover) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_Ghost_Remover);
}
