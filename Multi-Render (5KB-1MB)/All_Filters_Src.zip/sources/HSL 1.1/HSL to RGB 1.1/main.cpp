/*  HSL 2 RGB Color Space - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include "filter.h"

inline int HUE2RGB(const int M1,const int M2,int H)
{
  if (H<0)   H+= 255;
  if (H>255) H-= 255;
  if (6*H<255) return M1+((M2-M1)*H*6+127)/255;
  if (2*H<255) return M2;
  if (3*H<510) return M1+((M2-M1)*(170-H)*6+127)/255;
  return M1;
}

void HSL2RGB(int H,int S,int L,int &r,int &g,int &b)
{ // HSL to RGB color space
  //   input  H,S,L [0..255] 
  //   output r,g,b [0..255]
  int M1,M2;
  if (S==0) { r= g= b= L; return;}
  
  if (L<128) M2= (L*(255+S)+128)/255; else M2= L+S-(L*S+128)/255;
  M1= 2*L-M2;
  r= HUE2RGB(M1,M2,H+85);
  g= HUE2RGB(M1,M2,H);
  b= HUE2RGB(M1,M2,H-85);
}

int HSL_to_RGB_RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  Pixel32 *dst=fa->dst.data;
  const int psize= fa->dst.size>>2; 
  for (int p=0; p<psize; p++)
  {
    int r,g,b;
    int Alpha= (*dst)&0xff000000;
    int H= (*dst>>16)&0xff;
    int S= (*dst>> 8)&0xff;
    int L= (*dst    )&0xff;
    HSL2RGB (H,S,L,r,g,b);
    *dst++= Alpha | (r<<16) | (g<<8) | b;
  }
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

struct FilterDefinition filterDef_HSL2RGB=
{
  NULL, NULL, NULL,               // next, prev, module
  "HSL to RGB",                   // name
  "inverse of RGB to HSL filter\n"
  "Version 1.2 (17-03-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",        // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  0,                              // inst_data_size
  NULL,                           // initProc
  NULL,                           // deinitProc
  HSL_to_RGB_RunProc,             // runProc
  ParamProc,                      // paramProc
  NULL,                           // configProc
  NULL,                           // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  NULL,                           // script_obj
  NULL,                           // fssProc
};

static FilterDefinition *fd_HSL2RGB;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_HSL2RGB= ff->addFilter(fm, &filterDef_HSL2RGB, sizeof(FilterDefinition));
  
  if (!fd_HSL2RGB) return 1;
  
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_HSL2RGB);

}
