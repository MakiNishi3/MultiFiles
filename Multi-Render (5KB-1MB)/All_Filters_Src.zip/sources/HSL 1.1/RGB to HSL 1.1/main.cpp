/*  RGB to HSL Color Space - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari  <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

//    Version 1.1 (30-09-2003)
//    v1.2 17-03-2004: suddiviso in due file per AviSynth

#include "filter.h"

void RGB2HSL(int r,int g,int b,int &H,int &S,int &L)
{ // RGB to HSL color space
  //   input  r,g,b [0..255]
  //   output H,S,L [0..255]
  int cmax= max(r,max(g,b));
  int cmin= min(r,min(g,b));
  S= cmax-cmin;
  L= cmax+cmin;  
  if (S==0) { H=0; L>>=1; if (L>255) L=255; return; }  
  if (L==0) L=1;
  if (r==cmax) H= (255*(g-b)+127)/S;
    else
     if (g==cmax) H= 510+(255*(b-r)+127)/S;
      else
        H= 1020+(255*(r-g)+127)/S;
  H/=6;
  if (H<0) H+= 255;
 
  if (L<255) S= (255*S+127)/L; else S= (255*S+127)/(510-L);
  L>>= 1;
  if ((unsigned)S>255) S= (~S>>31)&0xff;  
}

int RGB_to_HSL_RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  Pixel32 *dst=fa->dst.data;
  const int psize= fa->dst.size>>2; 
  for (int p=0; p<psize; p++)
  {
    int H,S,L;
    int Alpha= (*dst)&0xff000000;
    int Red=   (*dst>>16)&0xff;
    int Green= (*dst>> 8)&0xff;
    int Blue=  (*dst    )&0xff;
    RGB2HSL (Red,Green,Blue,H,S,L);
    *dst++= Alpha | (H<<16) | (S<<8) | L;
  }
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

struct FilterDefinition filterDef_RGB2HSL=
{
  NULL, NULL, NULL,               // next, prev, module
  "RGB to HSL",                   // name
  "Red= H, Green= S, Blue= L\n"
  "Version 1.2 (17-03-2004)\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",        // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  0,                              // inst_data_size
  NULL,                           // initProc
  NULL,                           // deinitProc
  RGB_to_HSL_RunProc,             // runProc
  ParamProc,                      // paramProc
  NULL,                           // configProc
  NULL,                           // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  NULL,                           // script_obj
  NULL,                           // fssProc
};



static FilterDefinition *fd_RGB2HSL;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  
  fd_RGB2HSL= ff->addFilter(fm, &filterDef_RGB2HSL, sizeof(FilterDefinition));
 
  if (!fd_RGB2HSL) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  
  ff->removeFilter(fd_RGB2HSL);
}
