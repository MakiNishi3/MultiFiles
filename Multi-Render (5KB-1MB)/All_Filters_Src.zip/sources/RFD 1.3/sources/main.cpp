/*  Reverse Field Dominance - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include "filter.h"

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  const int pitch= fa->dst.pitch>>2;
  Pixel32 *dst= fa->dst.data;

  memcpy (dst,dst+pitch,fa->dst.size-fa->dst.pitch);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

FilterDefinition filterDef_RFD=
{
  NULL, NULL, NULL,         // next, prev, module
  "Reverse Field Dominance",// name
  "reverse field dominance of a clip.\n"
  "Version 1.3 (25-09-2003)\n" // desc
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",
  "Emiliano Ferrari",       // maker
  NULL,                     // private_data
  0,                        // inst_data_size
  NULL,                     // initProc
  NULL,                     // deinitProc
  RunProc,                  // runProc
  ParamProc,                // paramProc
  NULL,                     // configProc
  NULL,                     // stringProc
  NULL,                     // startProc
  NULL,                     // endProc
  NULL,                     // script_obj
  NULL,                     // fssProc
};

static FilterDefinition *fd_RFD;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_RFD = ff->addFilter(fm, &filterDef_RFD, sizeof(FilterDefinition));
  if (!fd_RFD) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_RFD);
}
