/*  Count Colors - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari  <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <stdio.h>
#include "filter.h"

Pixel32 *Buffer=NULL;

unsigned char Digit[160] = {
    0x00, 0x00, 0x3C, 0x66, 0xC3, 0xC3, 0xDB, 0xDB, 0xC3, 0xC3, 0x66, 0x3C, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x18, 0x38, 0x78, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0x03, 0x06, 0x0C, 0x18, 0x30, 0x60, 0xC0, 0xFF, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0x03, 0x03, 0x3E, 0x03, 0x03, 0x03, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x06, 0xC6, 0xC6, 0xC6, 0xC6, 0xFF, 0x06, 0x06, 0x06, 0x06, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFF, 0xC0, 0xC0, 0xC0, 0xFE, 0x03, 0x03, 0x03, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x3E, 0x60, 0xC0, 0xC0, 0xFE, 0xC3, 0xC3, 0xC3, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFF, 0x03, 0x03, 0x06, 0x0C, 0x18, 0x30, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0xC3, 0xC3, 0x7E, 0xC3, 0xC3, 0xC3, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0xC3, 0xC3, 0x7F, 0x03, 0x03, 0x03, 0x06, 0x7C, 0x00, 0x00, 0x00, 0x00};

int h,w,pitch;
Pixel32 *dst;

void PutPixel (int x,int y,Pixel32 colore)
{
  if ((x<0) || (x>w) || (y<0) || (y>h)) return;
  dst[x+(h-y)*pitch]= colore;
}

void DrawNum (int px,int py,int num,Pixel32 color,Pixel32 bgcolor)
{
  char s[50];
  itoa (num,s,10);

  for (unsigned c=0; c<strlen(s); c++)
  {
    for (int j=0; j<16; j++)
    {
      int b= Digit[j+((int)(s[c])-48)*16];
      for (int i=0; i<9; i++)
      {
        if (b&128)
          PutPixel (px+i,py+j,color);
        else
          PutPixel (px+i,py+j,bgcolor);
        b<<= 1;
      }
    }
    px+= 9;
  }
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  if (Buffer) { delete[]Buffer; Buffer= NULL; }
  Buffer= new Pixel32[fa->dst.size>>2];
  if (!Buffer) ff->ExceptOutOfMemory();
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  if (Buffer) delete[]Buffer;
  Buffer= NULL;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int compare (const void *arg1,const void *arg2)
{
    int v1= *((int *)arg1);
    int v2= *((int *)arg2);

    return v1-v2;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  h= fa->dst.h;
  w= fa->dst.w;
  pitch= fa->dst.pitch>>2;
  dst= fa->dst.data;
  Pixel32 *buff= Buffer;
  int x,y;

  // Copy current frame to temp buffer. (Remove Alpha channel)
  for ( y=0; y<h; y++)
  {
     for( x=0; x<w; x++) buff[x]= dst[x]&0xffffff;
     buff+= w;
     dst+= pitch;
  }
  int buffsize= (int)((buff-Buffer));

  // Sort all pixels
  qsort(Buffer,buffsize,4,compare);

  // count colors
  int n= 1;
  for (int i=1; i<(buffsize); i++)
      if (Buffer[i]!=Buffer[i-1]) n++;

  // draw result
  dst= fa->dst.data;
  DrawNum(0,0,n,0xffffff,0);

  return 0;
}

struct FilterDefinition filterDef_CC=
{
  NULL,NULL,NULL,         // next, prev, module
  "Count colors used",    // name
  "report the number of unique colors in the frame.\n"
  "version 1.2 (01-09-2003)\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",// desc
  "Emiliano Ferrari",     // maker
  NULL,                   // private_data
  0,                      // inst_data_size
  NULL,                   // initProc
  NULL,                   // deinitProc
  RunProc,                // runProc
  ParamProc,              // paramProc
  NULL,                   // configProc
  NULL,                   // stringProc
  StartProc,              // startProc
  EndProc,                // endProc
  NULL,                   // script_obj
  NULL,                   // fssProc
};

static FilterDefinition *fd_CC;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_CC = ff->addFilter(fm, &filterDef_CC, sizeof(FilterDefinition));
  if (!fd_CC) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_CC);
}
