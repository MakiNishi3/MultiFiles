/*  Black Box - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari  <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "ScriptValue.h"
#include "resource.h"
#include "pad.cpp"

#define MAX_KEYFRAMES 10000

class KEYFRAME
{
  private:
  int NF[MAX_KEYFRAMES];
  int VX[MAX_KEYFRAMES];
  int VY[MAX_KEYFRAMES];
  int VW[MAX_KEYFRAMES];
  int VH[MAX_KEYFRAMES];
  int VP[MAX_KEYFRAMES];
  int n;
  public:

  KEYFRAME() {n=1; VX[0]= 0; VY[0]=0; VW[0]=100; VH[0]=100; VP[0]=10;}

  bool Add (int Frame,int X,int Y,int W,int H,int P)
  {
    int i,j;
    for (i=0; i<n; i++)
      if (Frame==NF[i])
        {
          VX[i]= X;
          VY[i]= Y;
          VW[i]= W;
          VH[i]= H;
          VP[i]= P;
          return true;
        }
    if (n>=MAX_KEYFRAMES) return false;

    for (i=0; i<n; i++)
      if (Frame<NF[i])
        {
          for (j= i+1; j<n; j++)
          {
            NF[j]= NF[j-1];
            VX[j]= VX[j-1];
            VY[j]= VY[j-1];
            VW[j]= VW[j-1];
            VH[j]= VH[j-1];
            VP[j]= VP[j-1];
          }
          break;
        }
     n++;
     NF[i]= Frame;
     VX[i]= X;
     VY[i]= Y;
     VW[i]= W;
     VH[i]= H;
     VP[i]= P;
     return true;
  }

  void Clear() {n=1; VX[0]= 0; VY[0]=0; VW[0]=100; VH[0]=100; VP[0]=10;}

  bool Get(int frame,int &X,int &Y,int &W,int &H,int &P)
  {
    int i;
    if (n==0) return false;

    if (frame<NF[0])
    {
      X= VX[0];
      Y= VY[0];
      W= VW[0];
      H= VH[0];
      P= VP[0];
      return true;
    }

    if (frame>NF[n-1])
    {
      X= VX[n-1];
      Y= VY[n-1];
      W= VW[n-1];
      H= VH[n-1];
      P= VP[n-1];
      return true;
    }

    for (i=1; i<n; i++)
      if (frame<NF[i])
      {
        double DELTA= (double)(frame-NF[i-1])/(NF[i]-NF[i-1]);

        X= VX[i-1]+(int)((VX[i]-VX[i-1])*DELTA);
        Y= VY[i-1]+(int)((VY[i]-VY[i-1])*DELTA);
        W= VW[i-1]+(int)((VW[i]-VW[i-1])*DELTA);
        H= VH[i-1]+(int)((VH[i]-VH[i-1])*DELTA);
        P= VP[i-1]+(int)((VP[i]-VP[i-1])*DELTA);
        return true;
      }

   return false;
   }
};



typedef struct
{
  IFilterPreview *ifp;
  int  x,y,w,h;
  KEYFRAME keys;
} MyFilterData;

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const int w= fa->dst.w;
  const int h= fa->dst.h;
  const int pitch= fa->dst.pitch>>2;
  Pixel32 *dst= fa->dst.data;

  int x1= (w/2+mfd->x) - mfd->w/2;
  int x2= x1+mfd->w;
  int y1= (h/2-mfd->y) - mfd->h/2;
  int y2= y1+mfd->h;

  if (x2<0 || x1>w || y2<0 || y1>h) return 0;
  if (x1<0) x1= 0;
  if (x2>=w) x2= w-1;
  if (y1<0) y1= 0;
  if (y2>=h) y2= h-1;

  for (int y=y1; y<=y2; y++)
    for (int x=x1; x<=x2; x++)
      dst[x+y*pitch]= 0;

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;

  mfd->x= 0;
  mfd->y= 0;
  mfd->w= 100;
  mfd->h= 100;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SetDlgItemInt(hdlg,IDC_X,mfd->x,true);
      SetDlgItemInt(hdlg,IDC_Y,mfd->y,true);
      SendMessage(GetDlgItem(hdlg,IDC_XSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(8192,-8192));
      SendMessage(GetDlgItem(hdlg,IDC_YSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(-8192,8192));
      SetDlgItemInt(hdlg,IDC_W,mfd->w,false);
      SetDlgItemInt(hdlg,IDC_H,mfd->h,false);
      SendMessage(GetDlgItem(hdlg,IDC_WSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(8192,0));
      SendMessage(GetDlgItem(hdlg,IDC_HSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(0,8192));
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg); break;
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;
        case IDC_X:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int x= GetDlgItemInt(hdlg,IDC_X,NULL,true);
                if (x!=mfd->x)
                {
                  mfd->x= x;
                  mfd->ifp->RedoFrame();
                }
            }
            break;
        case IDC_Y:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int y= GetDlgItemInt(hdlg,IDC_Y,NULL,true);
                if (y!=mfd->y)
                {
                  mfd->y= y;
                  mfd->ifp->RedoFrame();
                }
            }
            break;
        case IDC_W:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int w= GetDlgItemInt(hdlg,IDC_W,NULL,false);
                if (w!=mfd->w)
                {
                  mfd->w= w;
                  mfd->ifp->RedoFrame();
                }
            }
            break;
        case IDC_H:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int h= GetDlgItemInt(hdlg,IDC_H,NULL,false);
                if (h!=mfd->h)
                {
                  mfd->h= h;
                  mfd->ifp->RedoFrame();
                }
            }
            break;
      }
      break;

   case WM_NOTIFY:
      if (IDC_PAD==(int)wParam)
      {
        NMHDR *pnmh= (NMHDR *)lParam;
        NMVLPADCHANGE *pnmvltc= (NMVLPADCHANGE *)lParam;
        mfd->x+= pnmvltc->dx;
        mfd->y+= pnmvltc->dy;
        SetDlgItemInt(hdlg,IDC_X,mfd->x,true);
        SetDlgItemInt(hdlg,IDC_Y,mfd->y,true);
        mfd->ifp->RedoFrame();
      }
      else
    if (IDC_SIZEC==(int)wParam)
      {
        NMHDR *pnmh= (NMHDR *)lParam;
        NMVLPADCHANGE *pnmvltc= (NMVLPADCHANGE *)lParam;
        mfd->w+= pnmvltc->dx;
        mfd->h+= pnmvltc->dx;
         if (mfd->w<0) mfd->w=0;
        if (mfd->h<0) mfd->h=0;
        SetDlgItemInt(hdlg,IDC_W,mfd->w,false);
        SetDlgItemInt(hdlg,IDC_H,mfd->h,false);
        mfd->ifp->RedoFrame();
      }
      break;

    case WM_HSCROLL:
    case WM_VSCROLL:
    {
      int x= GetDlgItemInt(hdlg,IDC_X,NULL,true);
      int y= GetDlgItemInt(hdlg,IDC_Y,NULL,true);
      int w= GetDlgItemInt(hdlg,IDC_W,NULL,false);
      int h= GetDlgItemInt(hdlg,IDC_H,NULL,false);
      if (x!=mfd->x || y!=mfd->y || w!=mfd->w || h!=mfd->h)
      {
        mfd->x= x;
        mfd->y= y;
        mfd->w= w;
        mfd->h= h;
        mfd->ifp->RedoFrame();
      }
      break;
    }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  RegisterPadControl(fa->filter->module->hInstModule);
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_BLACKBOX),
                          hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return ret;
}

FilterDefinition filterDef_BlackBox=
{
  NULL, NULL, NULL,        // next, prev, module
  "Black Box",             // name
  "Experimental Filter.\n"
  "Version 0.1 (09-10-2003)\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it", // desc
  "Emiliano Ferrari",      // maker
  NULL,                    // private_data
  sizeof(MyFilterData),    // inst_data_size
  InitProc,                // initProc
  NULL,                    // deinitProc
  RunProc,                 // runProc
  ParamProc,               // paramProc
  ConfigProc,              // configProc
  NULL,                    // stringProc
  NULL,                    // startProc
  NULL,                    // endProc
  NULL,                    // script_obj
  NULL,                    // fssProc
};

static FilterDefinition *fd_BlackBox;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_BlackBox= ff->addFilter(fm, &filterDef_BlackBox, sizeof(FilterDefinition));
  if (!fd_BlackBox) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_BlackBox);
}
