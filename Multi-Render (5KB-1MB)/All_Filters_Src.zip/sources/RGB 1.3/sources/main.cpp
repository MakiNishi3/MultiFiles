/*  RGB - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// Version 1.2 (20-09-2003)
// Version 1.3 (30-10-2004): rimossi alcuni possibili buffer overflow

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "resource.h"
#include "filter.h"
#include "ScriptValue.h"

typedef struct
{
  IFilterPreview *ifp;
  int red,green,blue;
  int link;
} MyFilterData;

void RGB_MMX (Pixel32 *dst,__int64 K64,int psize);
void RGB_iSSE(Pixel32 *dst,__int64 K64,int psize);

inline void Clipping (int &dato,int min,int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

__int64 BuildQ (short A,short R,short G,short B)
{
  __int64 Quadword;
  *(((short *)&Quadword)+0)= B;
  *(((short *)&Quadword)+1)= G;
  *(((short *)&Quadword)+2)= R;
  *(((short *)&Quadword)+3)= A;
  return Quadword;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int kr= (mfd->red  <<10)/1000;
  const int kg= (mfd->green<<10)/1000;
  const int kb= (mfd->blue <<10)/1000;
  const int psize= fa->dst.size>>2;

  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
  {
    __int64 K64= BuildQ (1,kr,kg,kb);
    RGB_iSSE (dst,K64,psize);
    return 0;
  }

  if ((CPUF_SUPPORTS_MMX & ff->getCPUFlags()))
  {
    __int64 K64= BuildQ (1,kr,kg,kb);
    RGB_MMX (dst,K64,psize);
    return 0;
  }

  for (int p=0; p<psize; p++)
  {
    int r= (*dst>>16) & 0xff;
    int g= (*dst>> 8) & 0xff;
    int b= (*dst    ) & 0xff;

    r= (r*kr)>>10;
    g= (g*kg)>>10;
    b= (b*kb)>>10;

    if ((unsigned)r>255) r=(~r>>31)&255; // ATTENZIONE: questo tipo di clipping
    if ((unsigned)g>255) g=(~g>>31)&255; // funziona solo su interi a 32bit
    if ((unsigned)b>255) b=(~b>>31)&255; // altrimensi usare Clipping (valore,0,255);

    *dst++= (r<<16) | (g<<8) | b;
  }
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->red  = 1000;
  mfd->green= 1000;
  mfd->blue = 1000;
  mfd->link = false;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

// ============================================================

void setval (HWND hdlg,int OBJ,int val)
{
  char tmp[128];
  _snprintf (tmp,128,"%1.2f%%",val/10.0f);
  SetDlgItemText(hdlg,OBJ,tmp);
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(0,2000));
      SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETPOS, (WPARAM)TRUE, mfd->red);
      SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(0,2000));
      SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETPOS, (WPARAM)TRUE, mfd->green);
      SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(0,2000));
      SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETPOS, (WPARAM)TRUE, mfd->blue);
      setval (hdlg,IDC_REDVAL,mfd->red);
      setval (hdlg,IDC_GREENVAL,mfd->green);
      setval (hdlg,IDC_BLUEVAL,mfd->blue);
      CheckDlgButton(hdlg, IDC_LINK, mfd->link ? BST_CHECKED : BST_UNCHECKED);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW:mfd->ifp->Toggle(hdlg);  break;
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;
        case IDC_LINK: mfd->link = IsDlgButtonChecked(hdlg, IDC_LINK);break;
        case IDC_RESET:
          mfd->red  = 1000;
          mfd->green= 1000;
          mfd->blue = 1000;
          SendMessage(GetDlgItem(hdlg, IDC_RED),  TBM_SETPOS, (WPARAM)TRUE,mfd->red);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN),TBM_SETPOS, (WPARAM)TRUE,mfd->green);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETPOS, (WPARAM)TRUE,mfd->blue);
          setval (hdlg,IDC_REDVAL,mfd->red);
          setval (hdlg,IDC_GREENVAL,mfd->green);
          setval (hdlg,IDC_BLUEVAL,mfd->blue);
          mfd->ifp->RedoFrame();
          return TRUE;
      }
      break;

    case WM_HSCROLL:
      {
        int r,g,b;
        r= SendMessage(GetDlgItem(hdlg, IDC_RED),   TBM_GETPOS, 0, 0);
        g= SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_GETPOS, 0, 0);
        b= SendMessage(GetDlgItem(hdlg, IDC_BLUE),  TBM_GETPOS, 0, 0);

        if (mfd->link)
        {
          int d= (r - mfd->red) + (g - mfd->green) + (b - mfd->blue);
          r= mfd->red + d;
          g= mfd->green + d;
          b= mfd->blue + d;
          Clipping (r,0,2000);
          Clipping (g,0,2000);
          Clipping (b,0,2000);
          SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETPOS, (WPARAM)TRUE, r);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETPOS, (WPARAM)TRUE, g);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETPOS, (WPARAM)TRUE, b);
        }
        mfd->red= r;
        mfd->green= g;
        mfd->blue= b;
        setval (hdlg,IDC_REDVAL,mfd->red);
        setval (hdlg,IDC_GREENVAL,mfd->green);
        setval (hdlg,IDC_BLUEVAL,mfd->blue);
        mfd->ifp->RedoFrame();
        break;
      }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_RGB),
                          hwnd,ConfigDlgProc,(LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return !!ret;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(str,64, " (R:%3.1f%%  G:%3.1f%%  B:%3.1f%%)", mfd->red/10.0, mfd->green/10.0, mfd->blue/10.0);
}

// ======================================================

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d, %d, %d)", mfd->red, mfd->green, mfd->blue);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->red  = argv[0].asInt();
  mfd->green= argv[1].asInt();
  mfd->blue = argv[2].asInt();
  Clipping (mfd->red  ,0,2000);
  Clipping (mfd->green,0,2000);
  Clipping (mfd->blue ,0,2000);
}

ScriptFunctionDef func_defs[]=
    {{(ScriptFunctionPtr)ScriptConfig,"Config","0iii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

// ==================================================

FilterDefinition filterDef_RGB=
{
  NULL,NULL,NULL,                 // next, prev, module
  "Red/Green/Blue",               // name
  "Adjust red,green,blue channels.\n"
  "Version 1.3 (30-10-2004) [MMX/iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",      // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  sizeof(MyFilterData),           // inst_data_size
  InitProc,                       // initProc
  NULL,                           // deinitProc
  RunProc,                        // runProc
  ParamProc,                      // paramProc
  ConfigProc,                     // configProc
  StringProc,                     // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  &script_obj,                    // script_obj
  FssProc,                        // fssProc
};

static FilterDefinition *fd_RGB;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_RGB= ff->addFilter(fm, &filterDef_RGB, sizeof(FilterDefinition));
  if (!fd_RGB) { return 1; }
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_RGB);
}

// ===========================================================

void RGB_MMX (Pixel32 *dst,__int64 K64,int psize)
{
  __asm {   mov         edi,[dst]
            mov         ecx,[psize]
            movq        mm6,[K64]
            pxor        mm7,mm7
            psllw       mm6,3
            mov         edx,ecx
            shr         ecx,2
            or          ecx,ecx
            jz          nomainloop

            align 16
mainloop:   movq        mm0,[edi]
            movq        mm1,mm0
            movq        mm2,[edi+8]
            punpcklbw   mm0,mm7
            movq        mm3,mm2
            punpckhbw   mm1,mm7
            psllw       mm0,3
            punpcklbw   mm2,mm7
            psllw       mm1,3
            punpckhbw   mm3,mm7
            psllw       mm2,3
            pmulhw      mm0,mm6
            psllw       mm3,3
            pmulhw      mm1,mm6
            pmulhw      mm2,mm6
            packuswb    mm0,mm1
            pmulhw      mm3,mm6
            packuswb    mm2,mm3
            movq        [edi],mm0
            movq        [edi+8],mm2
            add         edi,16
            dec         ecx
            jnz         mainloop

nomainloop: and         edx,3
            jz          evenpixel
oddloop:    movd        mm0,[edi]
            punpcklbw   mm0,mm7
            psllw       mm0,3
            pmullw      mm0,mm6
            packuswb    mm0,mm0
            movd        [edi],mm0
            add         edi,4
            dec         edx
            jnz         oddloop
evenpixel:  emms
   }
}

void RGB_iSSE (Pixel32 *dst,__int64 K64,int psize)
{
  __int64 Zero=0;
  K64<<=3;
  __asm {   mov         edi,[dst]
            mov         ecx,[psize]
            mov         edx,ecx
            shr         ecx,3
            or          ecx,ecx
            jz          nomainloop

//-----------------------------------------
            align 16
mainloop:   movq        mm0,[edi   ]            // Optimized for AMD ATHLON Processor
            movq        mm1,[edi+ 8]            // Intel P3 and P4 Processor (no HT)
            movq        mm2,[edi+16]
            movq        mm3,[edi+24]
            prefetchnta [edi+512]               // iSSE prefetch istruction + Unrolled loop (8 pixels at loop) = Optimize memory bandwidth
            movq        mm4,mm0
            movq        mm5,mm1
            movq        mm6,mm2
            movq        mm7,mm3
            punpcklbw   mm0,[Zero]              // 1. Read Pixel
            punpckhbw   mm4,[Zero]              // 2. Expand to packed word
            punpcklbw   mm1,[Zero]              // 3. Fix Mul by 8 (left shift by 3)
            punpckhbw   mm5,[Zero]              // 4. Multiply by RGB const and divide by 65536 (Hi word = right shift by 16)
            punpcklbw   mm2,[Zero]              // 5. Pack to byte
            punpckhbw   mm6,[Zero]              // 6. write pixel and update idex
            punpcklbw   mm3,[Zero]
            punpckhbw   mm7,[Zero]
            psllw       mm0,3
            psllw       mm1,3
            psllw       mm2,3
            psllw       mm3,3
            psllw       mm4,3
            psllw       mm5,3
            psllw       mm6,3
            psllw       mm7,3
            pmulhw      mm0,[K64]
            pmulhw      mm1,[K64]
            pmulhw      mm2,[K64]
            pmulhw      mm3,[K64]
            pmulhw      mm4,[K64]
            pmulhw      mm5,[K64]
            pmulhw      mm6,[K64]
            pmulhw      mm7,[K64]
            packuswb    mm0,mm4
            packuswb    mm1,mm5
            packuswb    mm2,mm6
            packuswb    mm3,mm7
            movq        [edi   ],mm0
            movq        [edi+ 8],mm1
            movq        [edi+16],mm2
            movq        [edi+24],mm3
            add         edi,32
            dec         ecx
            jnz         mainloop
//-----------------------------------------

nomainloop: and         edx,7
            jz          evenpixel
            pxor        mm7,mm7
            movq        mm6,[K64]
oddloop:    movd        mm0,[edi]
            punpcklbw   mm0,mm7
            psllw       mm0,3
            pmullw      mm0,mm6
            packuswb    mm0,mm0
            movd        [edi],mm0
            add         edi,4
            dec         edx
            jnz         oddloop
evenpixel:  emms
   }
}
