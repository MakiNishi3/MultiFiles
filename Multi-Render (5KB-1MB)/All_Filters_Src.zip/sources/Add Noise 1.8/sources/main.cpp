/*  Add Noise - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA

    Emiliano Ferrari
    e-mail: macinapepe@tiscali.it                                */

// ??-09-2002 v0.1: Inizio sviluppo filtro
// ...
// 25-09-2003 v1.4: alcune piccole revisioni interne e nuova interfaccia
// 09-02-2004 v1.5: aggiunta selezione del seme per la generazione dei numeri casuali.
// 11-02-2004 v1.6: risolto bug nel file di script che invertiva pow con density.
// 17-03-2004 v1.7: rimosso bug su gaussian blur e cambiato nome a pow in intensity.
// 30-10-2004 v1.8: rimosso bug nell'interfaccia (buffer overflow della stringa tmp[20]).

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <math.h>
#include "resource.h"
#include "filter.h"
#include "ScriptValue.h"

typedef struct
{
  IFilterPreview *ifp;
  int      density,intensity,NoiseSize;
  int      RGB,gauss;
  int      RKey;
  __int64 *NoiseMap;
} MyFilterData;

inline void Clipping(int &value,const int min,const int max)
{
  if (value<min) value=min; else if (value>max) value=max;
}

inline void NoiseClipping(short &value,const int min,const int max)
{
  if (value<min) value=min; else if (value>max) value=max;
}

void BuildTables(short *NoiseMap,int NoiseSize,const int intensity,const int density,int gauss,int rgb,int RKey)
{
  srand(RKey); // Seleziona una specifica sequenza

  NoiseSize<<= 2;

  // Genera l'array dei valori casuali
  for(int i=0; i<NoiseSize; i++)
  {
    int t= rand()%2000-1000; // Genera valori casuali tra -1000 e 1000

    if (abs(t)>=density) // Scarta i risultati in base alla densit� di rumore richiesta
      NoiseMap[i]= 0;    // 0= nessun rumore su questo pixel
    else
    {
      t= (t*intensity)/density;
      NoiseMap[i]= (short)(0.511*t);        // Calcola la versione fixed point del rumore calcolato
      NoiseClipping (NoiseMap[i],-511,511); // forza i valori entro i limiti consentiti
    }
  }

  // cambia la distribuzione statistica del rumore da lineare a quadratica
  if (gauss)
  {
    short GM[1024];
    for(int x=0; x<1024; x++)
    {
      double t= (512-x)/511.0;   // ritorna in virgola mobile
      GM[x]= (short)(511.0*t*t); // cambia x in x*x
      if (x<512) GM[x]= -GM[x];
    }
    for(i=0; i<NoiseSize; i++) NoiseMap[i]= GM[512+NoiseMap[i]]; // reimposta i valori secondo la nuova scala
  }

  // forza il rumore come monocromatico.
  if (!rgb)
    for (int j=0; j<NoiseSize; j+=4)
      NoiseMap[j]= NoiseMap[j+1]= NoiseMap[j+2]= NoiseMap[j+3];
}

void Noise_386(Pixel32 *dst,__int64 *NMap,const int width,const int height,const int pitch,const int MaxRand)
{
  for(int y= 0; y<height; y++)
  {
    short *Noise= (short *) (NMap+rand()%MaxRand);
    for(int x= 0; x<width; x++)
    {
      int r= ((dst[x]>>16) & 0xff)+Noise[(x<<2)+2];
      int g= ((dst[x]>> 8) & 0xff)+Noise[(x<<2)+1];
      int b= ((dst[x]    ) & 0xff)+Noise[(x<<2)  ];
      if ((unsigned)r>255) r=(~r>>31)&255; // ATTENZIONE: questo tipo di clipping
      if ((unsigned)g>255) g=(~g>>31)&255; // funziona solo su interi a 32bit
      if ((unsigned)b>255) b=(~b>>31)&255; // altrimensi usare Clipping (valore,0,255);
      dst[x]= (r<<16)|(g<<8)|b;
    }
    dst+= pitch;
  }
}

void Noise_iSSE(Pixel32 *dst,__int64 *NMap,const int width,const int height,const int pitch,const int MaxRand)
{
  for(int y=0; y<height; y++)
  {
    __int64 *RN= NMap+rand()%MaxRand;
    __asm { mov         edi,[dst]
            mov         esi,[RN]
            mov         ecx,[width]
            shr         ecx,1
            or          ecx,ecx
            jz          End
            pxor        mm7,mm7
            align       16
NoiseLoop:  movq        mm0,[edi]
            movq        mm1,mm0
            prefetchnta [edi+192]
            punpcklbw   mm0,mm7
            punpckhbw   mm1,mm7
            prefetchnta [esi+192]
            paddw       mm0,[esi]
            paddw       mm1,[esi+8]
            add         esi,16
            packuswb    mm0,mm1
            movq        [edi],mm0
            add         edi,8
            dec         ecx
            jnz         NoiseLoop
            emms
End:      }
    dst+= pitch;
  }
}

void Noise_MMX(Pixel32 *dst,__int64 *NMap,const int width,const int height,const int pitch,const int MaxRand)
{
  for(int y=0; y<height; y++)
  {
    __int64 *RN= NMap+rand()%MaxRand;
    __asm { mov       edi,[dst]
            mov       esi,[RN]
            mov       ecx,[width]
            shr       ecx,1
            or        ecx,ecx
            jz        End
            pxor      mm7,mm7
            align     16
NoiseLoop:  movq      mm0,[edi]
            movq      mm1,mm0
            punpcklbw mm0,mm7
            punpckhbw mm1,mm7
            paddw     mm0,[esi]
            paddw     mm1,[esi+8]
            add       esi,16
            packuswb  mm0,mm1
            movq      [edi],mm0
            add       edi,8
            dec       ecx
            jnz       NoiseLoop
            emms
End:      }
    dst+= pitch;
  }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  int width = fa->dst.w;
  int height= fa->dst.h;
  const int pitch = fa->dst.pitch>>2;
  const int MaxRand= mfd->NoiseSize-width;
  Pixel32 *dst= fa->dst.data;

  if ((mfd->intensity==0) || (mfd->density==0)) return 0; // non fare nulla
  srand(fa->pfsi->lCurrentFrame+mfd->RKey);

  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
    Noise_iSSE(dst,mfd->NoiseMap,width,height,pitch,MaxRand);
   else
  if ((CPUF_SUPPORTS_MMX & ff->getCPUFlags()))
    Noise_MMX(dst,mfd->NoiseMap,width,height,pitch,MaxRand);
   else
    Noise_386(dst,mfd->NoiseMap,width,height,pitch,MaxRand);
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->NoiseMap = NULL;
  mfd->NoiseSize= 0;
  mfd->RGB      = FALSE;
  mfd->gauss    = TRUE;
  mfd->density  = 1000;
  mfd->intensity= 200;
  mfd->RKey     = 0;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->NoiseSize= fa->dst.w*8+4096; // questo valore pi� � grande pi� il rumore risulta vario
                                    // ma occupa parecchia memoria per filmati ad alta risoluzione.
  mfd->NoiseMap= new __int64[mfd->NoiseSize];
  if (!mfd->NoiseMap) return 1;
  BuildTables((short *)mfd->NoiseMap,mfd->NoiseSize,mfd->intensity,mfd->density,mfd->gauss,mfd->RGB,mfd->RKey);
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->NoiseSize= 0;
  delete[]mfd->NoiseMap;
  mfd->NoiseMap=NULL;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char tmp[128];

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg,IDC_HSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(8191,0));
      SendMessage(GetDlgItem(hdlg,IDC_NOISE),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,1000)); // max. 4000
      SendMessage(GetDlgItem(hdlg,IDC_NOISE),TBM_SETPOS,(WPARAM)TRUE,mfd->density);
      SendMessage(GetDlgItem(hdlg,IDC_NOISE),TBM_SETTICFREQ, 100, 0);
      _snprintf(tmp,128," Density (%3.1f%%) ",mfd->density/10.0);
      SetDlgItemText(hdlg, IDC_NOISEVAL,tmp);
      SendMessage(GetDlgItem(hdlg,IDC_INTENSITY),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,1000)); // max. 4000
      SendMessage(GetDlgItem(hdlg,IDC_INTENSITY),TBM_SETPOS,(WPARAM)TRUE,mfd->intensity);
      SendMessage(GetDlgItem(hdlg,IDC_INTENSITY),TBM_SETTICFREQ, 100, 0);
      _snprintf(tmp,128," Intensity (%3.1f%%) ",mfd->intensity/10.0);
      SetDlgItemText(hdlg, IDC_INTVAL,tmp);
      CheckDlgButton(hdlg, IDC_RGB, mfd->RGB ? BST_CHECKED : BST_UNCHECKED);
      CheckDlgButton(hdlg, IDC_GAUSS, mfd->gauss ? BST_CHECKED : BST_UNCHECKED);
      SetDlgItemInt(hdlg,IDC_RKEY,mfd->RKey,false);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW:mfd->ifp->Toggle(hdlg);  break;
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;
        case IDC_RGB:
          mfd->RGB= IsDlgButtonChecked(hdlg, IDC_RGB);
          BuildTables((short *)mfd->NoiseMap,mfd->NoiseSize,mfd->intensity,mfd->density,mfd->gauss,mfd->RGB,mfd->RKey);
          mfd->ifp->RedoFrame();
          break;
        case IDC_GAUSS:
          mfd->gauss= IsDlgButtonChecked(hdlg, IDC_GAUSS);
          BuildTables((short *)mfd->NoiseMap,mfd->NoiseSize,mfd->intensity,mfd->density,mfd->gauss,mfd->RGB,mfd->RKey);
          mfd->ifp->RedoFrame();
          break;
        case IDC_RKEY:
          if (HIWORD(wParam)==EN_CHANGE && mfd!=NULL)
          {
            int rk= (GetDlgItemInt(hdlg,IDC_RKEY,NULL,false))&8191;
            if (rk!=mfd->RKey)
            {
              mfd->RKey= rk;
              SetDlgItemInt(hdlg,IDC_RKEY,mfd->RKey,false);
              BuildTables((short *)mfd->NoiseMap,mfd->NoiseSize,mfd->intensity,mfd->density,mfd->gauss,mfd->RGB,mfd->RKey);
              mfd->ifp->RedoFrame();
            }
          }
          break;
        case IDC_RESET:
          mfd->RGB      = FALSE;
          mfd->gauss    = TRUE;
          mfd->density  = 1000;
          mfd->intensity= 200;
          SendMessage(GetDlgItem(hdlg,IDC_NOISE),TBM_SETPOS,(WPARAM)TRUE,mfd->density);
          _snprintf(tmp,128," Density (%3.1f%%) ",mfd->density/10.0);
          SetDlgItemText(hdlg, IDC_NOISEVAL,tmp);
          SendMessage(GetDlgItem(hdlg,IDC_INTENSITY),TBM_SETPOS,(WPARAM)TRUE,mfd->intensity);
          _snprintf(tmp,128," Intensity (%3.1f%%) ",mfd->intensity/10.0);
          SetDlgItemText(hdlg, IDC_INTVAL,tmp);
          CheckDlgButton(hdlg, IDC_RGB, mfd->RGB ? BST_CHECKED : BST_UNCHECKED);
          CheckDlgButton(hdlg, IDC_GAUSS, mfd->gauss ? BST_CHECKED : BST_UNCHECKED);
          BuildTables((short *)mfd->NoiseMap,mfd->NoiseSize,mfd->intensity,mfd->density,mfd->gauss,mfd->RGB,mfd->RKey);
          mfd->ifp->RedoFrame();
          break;
        }
        break;

    case WM_VSCROLL:
      mfd->RKey= (GetDlgItemInt(hdlg,IDC_RKEY,NULL,false))&8191;
      BuildTables((short *)mfd->NoiseMap,mfd->NoiseSize,mfd->intensity,mfd->density,mfd->gauss,mfd->RGB,mfd->RKey);
      mfd->ifp->RedoFrame();
      break;
    case WM_HSCROLL:
    {
      int d= SendMessage(GetDlgItem(hdlg,IDC_NOISE),TBM_GETPOS,0,0);
      if (d!=mfd->density)
      {
        mfd->density=  d;
        _snprintf(tmp,128," Density (%3.1f%%) ",mfd->density/10.0);
        SetDlgItemText(hdlg, IDC_NOISEVAL,tmp);
      }

      int p= SendMessage(GetDlgItem(hdlg,IDC_INTENSITY),TBM_GETPOS,0,0);
      if (p!=mfd->intensity)
      {
        mfd->intensity= p;
        _snprintf(tmp,128," Intensity (%3.1f%%) ",mfd->intensity/10.0);
        SetDlgItemText(hdlg, IDC_INTVAL,tmp);
      }

      BuildTables((short *)mfd->NoiseMap,mfd->NoiseSize,mfd->intensity,mfd->density,mfd->gauss,mfd->RGB,mfd->RKey);
      mfd->ifp->RedoFrame();
      break;
    }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp = fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_NOISE),
                          hwnd,ConfigDlgProc,(LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return ret;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d, %d, %d, %d)",mfd->intensity,mfd->density,mfd->RGB,mfd->gauss,mfd->RKey);
  return true;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  _snprintf(str,64," (I:%3.1f%% D:%3.1f%%%s%s [key: %d])",
      mfd->intensity/10.0,mfd->density/10.0,mfd->gauss?" Gauss":"",mfd->RGB?" RGB":"",mfd->RKey);
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->intensity=   argv[0].asInt();
  mfd->density  =   argv[1].asInt();
  mfd->RGB      = !!argv[2].asInt();
  mfd->gauss    = !!argv[3].asInt();
  mfd->RKey     =  (argv[4].asInt())&8191;
  Clipping(mfd->density,0,1000);
  Clipping(mfd->intensity,0,1000);
}

ScriptFunctionDef func_defs[]=
  {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

FilterDefinition filterDef_Noise=
{
  NULL,NULL,NULL,            // next, prev, module
  "Add Noise",               // name
  "Randomly changes pixel values throught the image.\n"
  "Version 1.8 (30-10-2004) [MMX/iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n", // desc
  "Emiliano Ferrari",        // maker
  NULL,                      // private_data
  sizeof(MyFilterData),      // inst_data_size
  InitProc,                  // initProc
  NULL,                      // deinitProc
  RunProc,                   // runProc
  ParamProc,                 // paramProc
  ConfigProc,                // configProc
  StringProc,                // stringProc
  StartProc,                 // startProc
  EndProc,                   // endProc
  &script_obj,               // script_obj
  FssProc,                   // fssProc
};

static FilterDefinition *fd_Noise;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm,const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_Noise= ff->addFilter(fm, &filterDef_Noise, sizeof(FilterDefinition));
  if (!fd_Noise) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_Noise);
}
