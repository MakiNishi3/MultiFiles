/*---------------------------------------------------------------------------*/
//  Modified for Avisynth VagueDenoiser plugin
/*---------------------------------------------------------------------------*/
// Baseline Wavelet Transform Coder Construction Kit
//
// Geoff Davis
// gdavis@cs.dartmouth.edu
// http://www.geoffdavis.net/
//
// Copyright 1996 Geoff Davis 9/11/96
//
// Permission is granted to use this software for research purposes as
// long as this notice stays attached to this software.
//
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include "wavelet.h"

Wavelet::Wavelet (FilterSet *filterset)
{
  analysisLow = filterset->analysisLow;
  analysisHigh = filterset->analysisHigh;
  synthesisLow = filterset->synthesisLow;
  synthesisHigh = filterset->synthesisHigh;
  symmetric = filterset->symmetric;

  // amount of space to leave for padding vectors for symmetric extensions
  npad = maxi(analysisLow->size, analysisHigh->size);
}

Wavelet::~Wavelet () {}

void Wavelet::transform2d (float *input, float *output, int hsize, int vsize,
			    int nsteps, int sym_ext)
{
   int j;
   int hLowSize = hsize, hHighSize;
   int vLowSize = vsize, vHighSize;

   // If form of extension unspecified, default to symmetric
   // extensions for symmetrical filters and periodic extensions for
   // asymmetrical filters
   if (sym_ext == -1)
     sym_ext = symmetric;

   float *temp_in = new float [2*npad+maxi(hsize,vsize)];
   float *temp_out = new float [2*npad+maxi(hsize,vsize)];

   copy (input, output, hsize*vsize);

   while (nsteps--)  {

      // Do a convolution on the low pass portion of each row
      for (j = 0; j < vLowSize; j++)  {
	 // Copy row j to data array
	 copy (output+(j*hsize), temp_in+npad, hLowSize);
	 
	 // Convolve with low and high pass filters
	 transform_step (temp_in, temp_out, hLowSize, sym_ext);

	 // Copy back to image
	 copy (temp_out+npad, output+(j*hsize), hLowSize);
      }

      // Now do a convolution on the low pass portion of  each column
      for (j = 0; j < hLowSize; j++)  {
	 // Copy column j to data array
	 copy (output+j, hsize, temp_in+npad, vLowSize);
	 
	 // Convolve with low and high pass filters
	 transform_step (temp_in, temp_out, vLowSize, sym_ext);

	 // Copy back to image
	 copy (temp_out+npad, output+j, hsize, vLowSize);
      }

      // Now convolve low-pass portion again
      hHighSize = hLowSize/2;
      hLowSize = (hLowSize+1)/2;
      vHighSize = vLowSize/2;
      vLowSize = (vLowSize+1)/2;
   }

   delete [] temp_out;
   delete [] temp_in;
}

void Wavelet::invert2d (float *input, float *output, int hsize, int vsize,
			 int nsteps, int sym_ext)
{
   int i, j;

   // If form of extension unspecified, default to symmetric
   // extensions for symmetrical filters and periodic extensions for
   // asymmetrical filters
   if (sym_ext == -1)
     sym_ext = symmetric;

   int *hLowSize = new int [nsteps],
       *hHighSize = new int [nsteps];
   int *vLowSize = new int [nsteps],
       *vHighSize = new int [nsteps];

   hLowSize[0] = (hsize+1)/2;
   hHighSize[0] = hsize/2;
   vLowSize[0] = (vsize+1)/2;
   vHighSize[0] = vsize/2;

   for (i = 1; i < nsteps; i++) {
     hLowSize[i] = (hLowSize[i-1]+1)/2;
     hHighSize[i] = hLowSize[i-1]/2;
     vLowSize[i] = (vLowSize[i-1]+1)/2;
     vHighSize[i] = vLowSize[i-1]/2;
   }

   float *temp_in = new float [2*npad+maxi(hsize,vsize)];
   float *temp_out = new float [2*npad+maxi(hsize,vsize)];

   copy (input, output, hsize*vsize);

   while (nsteps--)  {
      // Do a reconstruction for each of the columns
      for (j = 0; j < hLowSize[nsteps]+hHighSize[nsteps]; j++)  {
	 // Copy column j to data array
	 copy (output+j, hsize, temp_in+npad, 
	       vLowSize[nsteps]+vHighSize[nsteps]);
	 
	 // Combine low-pass data (first 1/2^n of signal) with high-pass
	 // data (next 1/2^n of signal) to get higher resolution low-pass data
	 invert_step (temp_in, temp_out,
		      vLowSize[nsteps]+vHighSize[nsteps], sym_ext);

	 // Copy back to image
	 copy (temp_out+npad, output+j, hsize,
	       vLowSize[nsteps]+vHighSize[nsteps]);
      }

      // Now do a reconstruction pass for each row
      for (j = 0; j < vLowSize[nsteps]+vHighSize[nsteps]; j++)  {
	 // Copy row j to data array
	 copy (output + (j*hsize), temp_in+npad, 
	       hLowSize[nsteps]+hHighSize[nsteps]);

	 // Combine low-pass data (first 1/2^n of signal) with high-pass
	 // data (next 1/2^n of signal) to get higher resolution low-pass data
	 invert_step (temp_in, temp_out,
		      hLowSize[nsteps]+hHighSize[nsteps], sym_ext);
	 
	 // Copy back to image
	 copy (temp_out+npad, output + (j*hsize), 
	       hLowSize[nsteps]+hHighSize[nsteps]);
      }
   }

   delete [] hLowSize;
   delete [] hHighSize;
   delete [] vLowSize;
   delete [] vHighSize;

   delete [] temp_in;
   delete [] temp_out;
}

// input and output are padded with npad values at the beginning and
// at the end
void Wavelet::transform_step (float *input, float *output, int size, 
			      int sym_ext)
{
  int i,j,idx;
  int lowSize = (size+1)/2;
  int left_ext, right_ext;

  if (analysisLow->size %2) {
    // odd filter length
    left_ext = right_ext = 1;
  } else {
    left_ext = right_ext = 2;
  }

  if (sym_ext)
    symmetric_extension (input, size, left_ext, right_ext, 1);
  else
    periodic_extension (input, size);
    
  idx=npad+analysisLow->firstIndex-2;
  for (i = 0; i < lowSize; i++)  {
    float tval=0.0;
    idx+=2;
    for (j=analysisLow->size;j-->0;)  {
      tval += (input[idx + j] * analysisLow->coeff[j]);

    }
    output [npad+i] = tval;
  }
  
  idx=npad+analysisHigh->firstIndex-2;
  for (i = lowSize; i < size; i++)  {
    float tval=0.0;
    idx+=2;
    for (j = analysisHigh->size; j-- >0;)  {
      tval+=input[ idx + j] * analysisHigh->coeff[j];
    }
    output[npad+i]=tval;
  }

}

void Wavelet::invert_step (float *input, float *output, int size, int sym_ext)
{
   int i, j, idx, firstIndex, lastIndex, lindex, findex;
   int left_ext, right_ext, symmetry;
   // amount of low and high pass -- if odd # of values, extra will be
   //   low pass
   int lowSize = (size+1)/2, highSize = size/2;

   symmetry = 1;
   if (analysisLow->size % 2 == 0) {
     // even length filter -- do (2, X) extension
     left_ext = 2;
   } else {
     // odd length filter -- do (1, X) extension
     left_ext = 1;
   }

   if (size % 2 == 0) {
     // even length signal -- do (X, 2) extension
     right_ext = 2;
   } else {
     // odd length signal -- do (X, 1) extension
     right_ext = 1;
   }

   float *temp = new float [2*npad+lowSize];
   for (i = 0; i < lowSize; i++) {
     temp[npad+i] = input[npad+i];
   }

   if (sym_ext)
     symmetric_extension (temp, lowSize, left_ext, right_ext, symmetry);
   else
     periodic_extension (temp, lowSize);

   // coarse  detail
   // HHHHHHHHGGGGGGGG --> xxxxxxxxxxxxxxxx
   idx=2*npad+size;
   for (i = 0; i < idx; i++)
     output[i] = 0.0;

   firstIndex = synthesisLow->firstIndex;
   lastIndex = synthesisLow->size - 1 + firstIndex;
   
   lindex= -lastIndex/2;
   findex= (size-1-firstIndex)/2;
   idx=npad+firstIndex+2*lindex-2;
   
   for (i = lindex; i <= findex; i++)  {
     idx+=2;
      for (j = synthesisLow->size; j-- >0;)  {
	output[idx + j] +=
	  temp[npad+i] * synthesisLow->coeff[j];
      }
   }

   left_ext = 2;

   if (analysisLow->size % 2 == 0) {
     // even length filters
     right_ext = (size % 2 == 0) ? 2 : 1;
     symmetry = -1;
   } else {
     // odd length filters
     right_ext = (size % 2 == 0) ? 1 : 2;
     symmetry = 1;
   }

   for (i = 0; i < highSize; i++) {
     temp[npad+i] = input[npad+lowSize+i];
   }
   if (sym_ext)
     symmetric_extension (temp, highSize, left_ext, right_ext,
			  symmetry);
   else
     periodic_extension (temp, highSize);


   firstIndex = synthesisHigh->firstIndex;
   lastIndex = synthesisHigh->size - 1 + firstIndex;

   lindex= -lastIndex/2;
   findex= (size-1-firstIndex)/2;
   idx=npad+firstIndex+2*lindex-2;
   for (i = lindex; i <= findex; i++)  {
     idx+=2;
      for (j = synthesisHigh->size; j-- >0;)  {
	output[idx + j] +=
	  temp[npad+i] * synthesisHigh->coeff[j];
      }
   }
   
   delete [] temp;
}

// Do symmetric extension of data using prescribed symmetries
//   Original values are in output[npad] through output[npad+size-1]
//   New values will be placed in output[0] through output[npad] and in
//      output[npad+size] through output[2*npad+size-1] (note: end values may
//      not be filled in)
//   left_ext = 1 -> extension at left bdry is   ... 3 2 1 | 0 1 2 3 ...
//   left_ext = 2 -> extension at left bdry is ... 3 2 1 0 | 0 1 2 3 ...
//   right_ext = 1 or 2 has similar effects at the right boundary
//
//   symmetry = 1  -> extend symmetrically
//   symmetry = -1 -> extend antisymmetrically
void Wavelet::symmetric_extension (float *output, int size, int left_ext, int
				   right_ext, int symmetry)
{
  int i;
  int first = npad, last = npad + size-1;

  if (symmetry == -1) {
    if (left_ext == 1)
      output[--first] = 0;
    if (right_ext == 1)
      output[++last] = 0;
  }
  int originalFirst = first;
  int originalLast = last;
  int originalSize = originalLast-originalFirst+1;

  int period = 2 * (last - first + 1) - (left_ext == 1) - (right_ext == 1);

  if (left_ext == 2)
    output[--first] = symmetry*output[originalFirst];
  if (right_ext == 2)
    output[++last] = symmetry*output[originalLast];

  // extend left end
  int nextend = mini (originalSize-2, first);
  for (i = 0; i < nextend; i++) {
    output[--first] = symmetry*output[originalFirst+1+i];
  }

  // should have full period now -- extend periodically
  while (first > 0) {
    first--;
    output[first] = output[first+period];
  }

  // extend right end
  nextend = mini (originalSize-2, 2*npad+size-1 - last);
  for (i = 0; i < nextend; i++) {
    output[++last] = symmetry*output[originalLast-1-i];
  }

  // should have full period now -- extend periodically
  while (last < 2*npad+size-1) {
    last++;
    output[last] = output[last-period];
  }
}

// Do periodic extension of data using prescribed symmetries
//   Original values are in output[npad] through output[npad+size-1]
//   New values will be placed in output[0] through output[npad] and in
//      output[npad+size] through output[2*npad+size-1] (note: end values may
//      not be filled in)
void Wavelet::periodic_extension (float *output, int size)
{
  int first = npad, last = npad + size-1;

  // extend left periodically
  while (first > 0) {
    first--;
    output[first] = output[first+size];
  }

  // extend right periodically
  while (last < 2*npad+size-1) {
    last++;
    output[last] = output[last-size];
  }
}
