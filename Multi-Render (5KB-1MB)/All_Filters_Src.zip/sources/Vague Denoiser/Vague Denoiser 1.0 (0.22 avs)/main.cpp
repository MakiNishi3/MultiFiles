/*  VagueDenoiser - filter for VirtualDub
    Copyright (C) 2004 Emiliano Ferrari   <macinapepe@tiscali.it>

    Based on: VagueDenoiser plugin for Avisynth v0.22

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <math.h>
#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "resource.h"
#include "Wavelet.h"
#include "ScriptValue.h"

const int WAVE_TYPES= 16;

enum WAVE_TYPE {HAAR=0,DAUBECHIES_4,DAUBECHIES_6,DAUBECHIES_8,ANTONINI_9_7,
                ADELSON_9_9,BRISLAWN_9_7,BRISLAWN_10_10,VILLA_2_6,VILLA_5_3,
                VILLA_6_10,VILLA_9_3,VILLA_9_7,VILLA_10_18,VILLA_13_11,ODEGARD_9_7};

char *ModeNames[]= {"Haar","Daubechies 4","Daubechies 6","Daubechies 8",
           "Antonini 9/7","Adelsons 9/9","Brislawn 9/7","Brislawn 10/10",
           "Villa 2/6","Villa 5/3","Villa 6/10","Villa 9/3","Villa 9/7",
           "Villa 10/18","Villa 13/11","Odergard 9/7"};

#define CMODE_Y    0
#define CMODE_YUV  1
#define CMODE_RGB  2

typedef struct
{
  WAVE_TYPE  wavetype;
  int        threshold;
  int        method;
  int        nsteps;
  int        colormode;
  float      *buffer;
  Wavelet    *wavelet;
  IFilterPreview *ifp;
} MyFilterData;

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void RGB2YUV(int r,int g,int b,int &Y,int &U,int &V)
{
 // input:  r,g,b [0..255]
 // output: Y,U,V [0..255]
 const int Yr= (int)( 0.257*65536.0*255.0/219.0);
 const int Yg= (int)( 0.504*65536.0*255.0/219.0);
 const int Yb= (int)( 0.098*65536.0*255.0/219.0);
 const int Ur= (int)( 0.439*65536.0*255.0/223.0);
 const int Ug= (int)(-0.368*65536.0*255.0/223.0);
 const int Ub= (int)(-0.071*65536.0*255.0/223.0);
 const int Vr= (int)(-0.148*65536.0*255.0/223.0);
 const int Vg= (int)(-0.291*65536.0*255.0/223.0);
 const int Vb= (int)( 0.439*65536.0*255.0/223.0);

 Y= ((int)(Yr * r + Yg * g + Yb * b+32767)>>16);
 U= ((int)(Ur * r + Ug * g + Ub * b+32767)>>16)+128;
 V= ((int)(Vr * r + Vg * g + Vb * b+32767)>>16)+128;
 if ((unsigned)U>255) U=(~U>>31)&0xff;
 if ((unsigned)V>255) V=(~V>>31)&0xff;
}

void YUV2RGB(int Y,int U,int V,int &r,int &g,int &b)
{
  // input:  Y,U,V [0..255]
  // output: r,g,b [0..255]

 const int YK= (int)(1.164*65536.0*219.0/255.0);
 const int k1= (int)(1.596*65536.0*223.0/255.0);
 const int k2= (int)(0.813*65536.0*223.0/255.0);
 const int k3= (int)(2.018*65536.0*223.0/255.0);
 const int k4= (int)(0.391*65536.0*223.0/255.0);

 Y*= YK;
 U-= 128;
 V-= 128;

 r= (Y+k1*U+32768)>>16;
 g= (Y-k2*U-k4*V+32768)>>16;
 b= (Y+k3*V+32768)>>16;

 if ((unsigned)r>255) r=(~r>>31)&0xff;
 if ((unsigned)g>255) g=(~g>>31)&0xff;
 if ((unsigned)b>255) b=(~b>>31)&0xff;
}

int realToChar (float x)
{
  int tmp;
  tmp= (int)(x);
  if ((unsigned)tmp>255) tmp=(~tmp>>31)&0xff;
  return tmp;
};

//Wavelet Transform
void DWTTransform(MyFilterData *mfd,float* block, int height, int width, bool inverse)
{
  if(!inverse)
    mfd->wavelet->transform2d(block,block,width,height,mfd->nsteps);
  else
    mfd->wavelet->invert2d(block,block,width,height,mfd->nsteps);
}

#define sgn(x) ((x<0)?-1:((x>0)?1:0))

//Apply a filtering on wavelet transformed coefficients
void filter(MyFilterData *mfd,float *block, int b)
 {
  int i;
  float thresh= mfd->threshold/100.0f;

  switch(mfd->method)
  {
  case 0://Hard thresholding
    for(i=0;i<b;i++)
      if (fabs(*(block+i)) <= thresh) *(block+i)=0.0f;
    break;

  case 1://Soft thresholding
    for(i=0;i<b;i++)
    {
      float temp= (float)fabs(*(block+i));
      if (temp <= thresh) *(block+i)=0.0f;
        else *(block+i)= sgn(*(block+i))*(temp-thresh);
    }
  }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst;
  const int psize= fa->dst.size>>2;
  const int w= fa->dst.w;
  const int h= fa->dst.h;
  const int pitch= fa->dst.pitch>>2;

  dst= fa->dst.data;
  if (mfd->colormode!=CMODE_RGB)
    for (int p=0; p<psize; p++)
    {
      int Y,U,V;
      int r= (*dst>>16) & 0xff;
      int g= (*dst>> 8) & 0xff;
      int b= (*dst    ) & 0xff;
      RGB2YUV (r,g,b,Y,U,V);
      *dst++= (U<<16) | (Y<<8) | V;
    }

  int x,y;
  float *bp;

  dst= fa->dst.data;

  if (mfd->colormode!=CMODE_Y)
  {
  // BLUE - V

  // Copy Source to Buffer
  bp= mfd->buffer;
  for(y=0; y<h; y++)
    for (x=0; x<w; x++)
      bp[x+y*w]= (float)(dst[x+y*pitch] & 0xff);

  // Apply filtering
  DWTTransform(mfd,bp,h,w,false);
  filter(mfd,bp,w*h);
  DWTTransform(mfd,bp,h,w,true);

  // Copy Buffer to Destination
  bp= mfd->buffer;
  for(y=0; y<h; y++)
    for (x=0; x<w; x++)
      dst[x+y*pitch]= (dst[x+y*pitch] & 0xffffff00)+realToChar(bp[x+y*w]);

  // GREEN - U

  // Copy Source to Buffer
  bp= mfd->buffer;
  for(y=0; y<h; y++)
    for (x=0; x<w; x++)
      bp[x+y*w]= (float)((dst[x+y*pitch]>>8) & 0xff);

  // Apply filtering
  DWTTransform(mfd,bp,h,w,false);
  filter(mfd,bp,w*h);
  DWTTransform(mfd,bp,h,w,true);

  // Copy Buffer to Destination
  bp= mfd->buffer;
  for(y=0; y<h; y++)
    for (x=0; x<w; x++)
      dst[x+y*pitch]= (dst[x+y*pitch] & 0xffff00ff)+(realToChar(bp[x+y*w])<<8);
  }

  // RED - Y

  // Copy Source to Buffer
  bp= mfd->buffer;
  for(y=0; y<h; y++)
    for (x=0; x<w; x++)
      bp[x+y*w]= (float)((dst[x+y*pitch]>>16) & 0xff);

  // Apply filtering
  DWTTransform(mfd,bp,h,w,false);
  filter(mfd,bp,w*h);
  DWTTransform(mfd,bp,h,w,true);

  // Copy Buffer to Destination
  bp= mfd->buffer;
  for(y=0; y<h; y++)
    for (x=0; x<w; x++)
      dst[x+y*pitch]= (dst[x+y*pitch] & 0xff00ffff)+(realToChar(bp[x+y*w])<<16);

  dst= fa->dst.data;
  if (mfd->colormode!=CMODE_RGB)
    for (int p=0; p<psize; p++)
    {
        int r,g,b;
      int U= (*dst>>16) & 0xff;
      int Y= (*dst>> 8) & 0xff;
      int V= (*dst    ) & 0xff;
      YUV2RGB (Y,U,V,r,g,b);
      *dst++= (r<<16) | (g<<8) | b;
    }

  return 0;
}

void WaveletInit(MyFilterData *mfd)
{
  if (mfd->wavelet) { delete[] mfd->wavelet; mfd->wavelet=NULL; }
  switch (mfd->wavetype)
  {
    case HAAR          : mfd->wavelet= new Wavelet(&Haar); break;
    case DAUBECHIES_4  : mfd->wavelet= new Wavelet(&Daub4); break;
    case DAUBECHIES_6  : mfd->wavelet= new Wavelet(&Daub6); break;
    case DAUBECHIES_8  : mfd->wavelet= new Wavelet(&Daub8); break;
    case ANTONINI_9_7  : mfd->wavelet= new Wavelet(&Antonini); break;
    case ADELSON_9_9   : mfd->wavelet= new Wavelet(&Adelson); break;
    case BRISLAWN_9_7  : mfd->wavelet= new Wavelet(&Brislawn); break;
    case BRISLAWN_10_10: mfd->wavelet= new Wavelet(&Brislawn2); break;
    case VILLA_2_6     : mfd->wavelet= new Wavelet(&Villa5); break;
    case VILLA_5_3     : mfd->wavelet= new Wavelet(&Villa4); break;
    case VILLA_6_10    : mfd->wavelet= new Wavelet(&Villa3); break;
    case VILLA_9_3     : mfd->wavelet= new Wavelet(&Villa6); break;
    case VILLA_9_7     : mfd->wavelet= new Wavelet(&Villa1); break;
    case VILLA_10_18   : mfd->wavelet= new Wavelet(&Villa); break;
    case VILLA_13_11   : mfd->wavelet= new Wavelet(&Villa2); break;
    case ODEGARD_9_7   : mfd->wavelet= new Wavelet(&Odegard); break;
  }
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->wavetype = BRISLAWN_10_10;
  mfd->threshold= (int)(0.8 * 100);
  mfd->method   = 1;
  mfd->nsteps   = 6;
  mfd->colormode= CMODE_YUV;
  mfd->buffer   = NULL;
  mfd->wavelet  = NULL;
  WaveletInit(mfd);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->buffer= new float[fa->dst.w*fa->dst.h];
  if (!mfd->buffer) ff->ExceptOutOfMemory();
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->buffer) { delete[] mfd->buffer; mfd->buffer= NULL; }
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char tmp[128];
  int i;

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;

       for (i=0; i<WAVE_TYPES; i++)
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,i,(LPARAM)ModeNames[i]);
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_SETCURSEL,(WPARAM)mfd->wavetype,0);

      CheckDlgButton(hdlg,IDC_YONLY,(mfd->colormode==CMODE_Y  )?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_YUV  ,(mfd->colormode==CMODE_YUV)?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_RGB  ,(mfd->colormode==CMODE_RGB)?BST_CHECKED:BST_UNCHECKED);

      SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,4000));
      SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD),TBM_SETTICFREQ,100,0);
      SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD),TBM_SETPOS  ,(WPARAM)TRUE,mfd->threshold);
      _snprintf(tmp,128," Treshold value (%1.2f): ", mfd->threshold/100.0);
      SetDlgItemText(hdlg,IDC_THRESHOLDVAL,tmp);

      SendMessage(GetDlgItem(hdlg,IDC_STEPS),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(1,8));
      SendMessage(GetDlgItem(hdlg,IDC_STEPS),TBM_SETPOS  ,(WPARAM)TRUE,mfd->nsteps);
      _snprintf(tmp,128," Steps (%d): ", mfd->nsteps);
      SetDlgItemText(hdlg,IDC_STEPSVAL,tmp);

      CheckDlgButton(hdlg,IDC_METHOD0,(mfd->method==0)?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_METHOD1,(mfd->method==1)?BST_CHECKED:BST_UNCHECKED);

      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;

        case IDC_MODE :
          mfd->wavetype= (WAVE_TYPE) SendMessage (GetDlgItem(hdlg,IDC_MODE),CB_GETCURSEL,0,0);
          WaveletInit(mfd);
          mfd->ifp->RedoFrame();
          break;

         case IDC_YONLY: mfd->colormode= CMODE_Y;   mfd->ifp->RedoFrame(); break;
        case IDC_YUV  : mfd->colormode= CMODE_YUV; mfd->ifp->RedoFrame(); break;
        case IDC_RGB  : mfd->colormode= CMODE_RGB; mfd->ifp->RedoFrame(); break;

        case IDC_METHOD0: mfd->method= 0; mfd->ifp->RedoFrame(); break;
        case IDC_METHOD1: mfd->method= 1; mfd->ifp->RedoFrame(); break;
      }
      break;

    case WM_HSCROLL:
      mfd->threshold= SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD),TBM_GETPOS,0,0);
      _snprintf(tmp,128," Treshold value (%1.2f): ", mfd->threshold/100.0);
      SetDlgItemText(hdlg, IDC_THRESHOLDVAL,tmp);
      mfd->nsteps= SendMessage(GetDlgItem(hdlg,IDC_STEPS),TBM_GETPOS,0,0);
      _snprintf(tmp,128," Steps (%d): ", mfd->nsteps);
      SetDlgItemText(hdlg,IDC_STEPSVAL,tmp);
      WaveletInit(mfd);
      mfd->ifp->RedoFrame();
      break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int Resoult= DialogBoxParam ( fa->filter->module->hInstModule,
                                MAKEINTRESOURCE(IDD_FILTER_VAGUEDENOISER),
                                hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (Resoult) *mfd= mfd_old;
  return !!Resoult;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(str,64, " (%s  %1.2f)",ModeNames[mfd->wavetype], mfd->threshold/100.0);
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d, %d, %d, %d, %d)",
      mfd->wavetype,mfd->threshold,mfd->method,mfd->nsteps,mfd->colormode);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->wavetype = (WAVE_TYPE) argv[0].asInt();
  mfd->threshold= argv[1].asInt();
  mfd->method   = argv[2].asInt();
  mfd->nsteps   = argv[3].asInt();
  mfd->colormode= argv[4].asInt();

  Clipping (mfd->threshold,0,40*100);
  Clipping (mfd->method,0,1);
  Clipping (mfd->nsteps,1,8);
  Clipping (mfd->colormode,CMODE_Y,CMODE_RGB);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

FilterDefinition filterDef=
{
  NULL, NULL, NULL,            // next, prev, module
  "Vague Denoiser",            // name
  "port of VagueDenoiser plugin for Avisynth v0.22\n"
  "Version 1.0 (13-02-2004)\n"
  "Copyright (C) 2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  StartProc,                   // startProc
  EndProc,                     // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd;

extern "C" int __declspec(dllexport) __cdecl
VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff,
                                        int& vdfd_ver, int& vdfd_compat)
{
  fd= ff->addFilter(fm, &filterDef, sizeof(FilterDefinition));
  if (!fd) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl
VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd);
}
