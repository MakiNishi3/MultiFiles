/*---------------------------------------------------------------------------*/
//  Modified for Avisynth VagueDenoiser plugin
/*---------------------------------------------------------------------------*/
// Baseline Wavelet Transform Coder Construction Kit
//
// Geoff Davis
// gdavis@cs.dartmouth.edu
// http://www.geoffdavis.net/
//
// Copyright 1996 Geoff Davis 9/11/96
//
// Permission is granted to use this software for research purposes as
// long as this notice stays attached to this software.
//
/*---------------------------------------------------------------------------*/
#define TRUE  1
#define FALSE 0

#define mini(x,y) (((x)<(y))?(x):(y))
#define maxi(x,y) (((x)>(y))?(x):(y))

class Filter {
public:
  int size, firstIndex, center;
  float *coeff;

  Filter () {coeff = NULL; size = 0; firstIndex = 0;};
  Filter (int size, int firstIndex = 0, float *coeff = NULL)
            { init (size, firstIndex, coeff); };
  Filter (const Filter &filter) {coeff=NULL; copy(filter);};
  ~Filter ();
  
  void init (int size, int firstIndex, float *coeff);
  Filter& operator= (const Filter &filter) {copy(filter); return *this;};
  float& operator[] (int index) {return coeff[index-firstIndex];};

protected:
  void copy (const Filter &filter);
};

class FilterSet {
public:
  FilterSet () {symmetric = FALSE; analysisLow = analysisHigh =
		synthesisLow = synthesisHigh = NULL;};
  FilterSet (int symmetric, 
	     float *anLow, int anLowSize, int anLowFirst,  
	     float *synLow = NULL, int synLowSize = 0, int
	     synLowFirst = 0);
  FilterSet (const FilterSet &filterset);
  ~FilterSet ();

  void init (int symmetric, 
	     float *anLow, int anLowSize, int anLowFirst, 
	     float *synLow, int synLowSize, int synLowFirst);
  FilterSet& operator= (const FilterSet filterset);

  int symmetric;
  Filter *analysisLow, *analysisHigh, *synthesisLow,
    *synthesisHigh;

protected:
  void copy (const FilterSet& filterset);
};

class Wavelet {
public:
  Wavelet (FilterSet *filterset);
  ~Wavelet ();

  void transform2d (float *input, float *output, int hsize, int vsize,
		     int nsteps, int sym_ext = -1);
  void invert2d (float *input, float *output, int hsize, int vsize, 
		  int nsteps, int sym_ext = -1);

  Filter *analysisLow, *analysisHigh;    // H and G
  Filter *synthesisLow, *synthesisHigh;  // H~ and G~
  int symmetric;  // TRUE if filter set is symmetric

  void symmetric_extension (float *output, int size, int left_ext, int
			    right_ext, int symmetry);
  void periodic_extension (float *output, int size);
  int npad;
  
 protected:
  void transform_step (float *input, float *output, int size, int sym_ext);
  void invert_step (float *input, float *output, int size, int sym_ext);

  // copy length elements from p1 to p2
  void copy (const float *p1, float *p2, const int length)
  {int temp = length; while(temp--) *p2++ = *p1++;}
  void copy (const float *p1, const int stride1, float *p2, 
	     const int length)
  {int temp = length; while(temp--) {*p2++ = *p1; p1 += stride1;}}
  void copy (const float *p1, float *p2, const int stride2,
	     const int length)
  {int temp = length; while(temp--) {*p2 = *p1++; p2 += stride2;}}
};

extern FilterSet Haar, Daub4, Daub6, Daub8, Antonini, Adelson,
  Brislawn, Brislawn2, Villa1, Villa2, Villa3, Villa4, Villa5, Villa6, 
  Odegard, Villa;

