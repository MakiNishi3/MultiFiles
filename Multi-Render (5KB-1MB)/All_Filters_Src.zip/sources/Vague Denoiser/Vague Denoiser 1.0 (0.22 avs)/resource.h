//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_VAGUE_DENOISER              101
#define IDD_FILTER_VAGUEDENOISER        101
#define IDC_MODE                        1000
#define IDC_YONLY                       1001
#define IDC_YUV                         1002
#define IDC_RGB                         1003
#define IDC_METHOD1                     1004
#define IDC_METHOD0                     1005
#define IDC_THRESHOLDVAL                1006
#define IDC_THRESHOLD                   1007
#define IDC_STEPSVAL                    1008
#define IDC_STEPS                       1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
