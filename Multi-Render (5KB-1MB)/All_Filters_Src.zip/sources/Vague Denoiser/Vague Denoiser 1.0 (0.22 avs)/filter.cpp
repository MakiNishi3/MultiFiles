/*---------------------------------------------------------------------------*/
//  Modified for Avisynth VagueDenoiser plugin
/*---------------------------------------------------------------------------*/
// Baseline Wavelet Transform Coder Construction Kit
//
// Geoff Davis
// gdavis@cs.dartmouth.edu
// http://www.geoffdavis.net/
//
// Copyright 1996 Geoff Davis 9/11/96
//
// Permission is granted to use this software for research purposes as
// long as this notice stays attached to this software.
//
/*---------------------------------------------------------------------------*/
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "wavelet.h"

float HaarCoeffs [] = { 1.0f/(float)sqrt(2.0), 1.0f/(float)sqrt(2.0) };

// A few Daubechies filters

float Daub4Coeffs [] = { 0.4829629131445341f,  0.8365163037378077f,
		          0.2241438680420134f, -0.1294095225512603f };

float Daub6Coeffs [] = { 0.3326705529500825f,  0.8068915093110924f,
		          0.4598775021184914f, -0.1350110200102546f,
		         -0.0854412738820267f,  0.0352262918857095f };

float Daub8Coeffs [] = { 0.2303778133088964f,  0.7148465705529154f,
			  0.6308807679398587f, -0.0279837694168599f,
			 -0.1870348117190931f,  0.0308413818355607f,
			  0.0328830116668852f, -0.0105974017850690f };

// Filter from Eero Simoncelli's PhD thesis -- used in Edward Adelson's EPIC wavelet coder
// These are probably the filter coefficients used in Shapiro's EZW paper
float AdelsonCoeffs[] = { 0.028220367f, -0.060394127f, -0.07388188f, 
			 0.41394752f,   0.7984298f,   0.41394752f, 
			 -0.07388188f, -0.060394127f, 0.028220367f };

// 7/9 Filter from M. Antonini, M. Barlaud, P. Mathieu, and
// I. Daubechies, "Image coding using wavelet transform", IEEE
// Transactions on Image Processing", Vol. pp. 205-220, 1992.

float AntoniniSynthesis [] = { -6.453888262893856e-02f,
			      -4.068941760955867e-02f,
			       4.180922732222124e-01f,
			       7.884856164056651e-01f,
			       4.180922732222124e-01f,
			      -4.068941760955867e-02f,
			      -6.453888262893856e-02f };
float AntoniniAnalysis[] =  {  3.782845550699535e-02f,
			     -2.384946501937986e-02f,
			     -1.106244044184226e-01f,
			      3.774028556126536e-01f,
			      8.526986790094022e-01f,
			      3.774028556126537e-01f,
			     -1.106244044184226e-01f,
			     -2.384946501937986e-02f,
			      3.782845550699535e-02f };

// Unpublished 18/10 filter from Villasenor's group

float Villa1810Synthesis [] = { 9.544158682436510e-04f,
			  -2.727196296995984e-06f,
			  -9.452462998353147e-03f,
			  -2.528037293949898e-03f,
			   3.083373438534281e-02f,
			  -1.376513483818621e-02f,
			  -8.566118833165798e-02f,
			   1.633685405569902e-01f,
			   6.233596410344172e-01f,
			   6.233596410344158e-01f,
			   1.633685405569888e-01f,
			  -8.566118833165885e-02f,
			  -1.376513483818652e-02f,
			   3.083373438534267e-02f,
			  -2.528037293949898e-03f,
			  -9.452462998353147e-03f,
			  -2.727196296995984e-06f,
			   9.544158682436510e-04f};
float Villa1810Analysis [] = {  2.885256501123136e-02f,
			   8.244478227504624e-05f,
			  -1.575264469076351e-01f,
			   7.679048884691438e-02f,
			   7.589077294537618e-01f,
			   7.589077294537619e-01f,
			   7.679048884691436e-02f,
			  -1.575264469076351e-01f,
			   8.244478227504624e-05f,
			   2.885256501123136e-02f};

// Filters from Chris Brislawn's tutorial code

float BrislawnAnalysis [] = {  0.037828455506995f,  -0.023849465019380f, 
			       -0.110624404418423f,   0.377402855612654f,
				0.852698679009403f, 
				0.377402855612654f,  -0.110624404418423f,
			       -0.023849465019380f,   0.037828455506995f };
float BrislawnSynthesis [] = { -0.064538882628938f, -0.040689417609558f,
				 0.418092273222212f, 
				 0.788485616405664f,
				 0.418092273222212f, 
				-0.040689417609558f, -0.064538882628938f};

float Brislawn2Analysis [] = {  0.026913419f, -0.032303352f,
			        -0.241109818f,  0.054100420f,
			         0.899506092f,  0.899506092f, 
			         0.054100420f, -0.241109818f, 
			        -0.032303352f,  0.026913419f};
float Brislawn2Synthesis [] = { 0.019843545f,  0.023817599f, 
				-0.023257840f,  0.145570740f,  
				 0.541132748f,  0.541132748f, 
				 0.145570740f, -0.023257840f, 
				 0.023817599f, 0.019843545f };

// Filters from J. Villasenor, B. Belzer, J. Liao, "Wavelet Filter
// Evaluation for Image Compression." IEEE Transactions on Image
// Processing, Vol. 2, pp. 1053-1060, August 1995.

float Villa1Analysis [] = {
  3.782845550699535e-02f,
  -2.384946501937986e-02f,
  -1.106244044184226e-01f,
  3.774028556126536e-01f,
  8.526986790094022e-01f,
  3.774028556126537e-01f,
  -1.106244044184226e-01f,
  -2.384946501937986e-02f,
  3.782845550699535e-02f
};

float Villa1Synthesis [] = {
  -6.453888262893856e-02f,
  -4.068941760955867e-02f,
  4.180922732222124e-01f,
  7.884856164056651e-01f,
  4.180922732222124e-01f,
  -4.068941760955867e-02f,
  -6.453888262893856e-02f
};

float Villa2Analysis [] = {
  -8.472827741318157e-03f,
  3.759210316686883e-03f,
  4.728175282882753e-02f,
  -3.347508104780150e-02f,
  -6.887811419061032e-02f,
  3.832692613243884e-01f,
  7.672451593927493e-01f,
  3.832692613243889e-01f,
  -6.887811419061045e-02f,
  -3.347508104780156e-02f,
  4.728175282882753e-02f,
  3.759210316686883e-03f,
  -8.472827741318157e-03f
};
float Villa2Synthesis [] = {
  1.418215589126359e-02f,
  6.292315666859828e-03f,
  -1.087373652243805e-01f,
  -6.916271012030040e-02f,
  4.481085999263908e-01f,
  8.328475700934288e-01f,
  4.481085999263908e-01f,
  -6.916271012030040e-02f,
  -1.087373652243805e-01f,
  6.292315666859828e-03f,
  1.418215589126359e-02f
};

float Villa3Analysis [] = {
  -1.290777652578771e-01f,
  4.769893003875977e-02f,
  7.884856164056651e-01f,
  7.884856164056651e-01f,
  4.769893003875977e-02f,
  -1.290777652578771e-01f
};
float Villa3Synthesis [] = {
  1.891422775349768e-02f,
  6.989495243807747e-03f,
  -6.723693471890128e-02f,
  1.333892255971154e-01f,
  6.150507673110278e-01f,
  6.150507673110278e-01f,
  1.333892255971154e-01f,
  -6.723693471890128e-02f,
  6.989495243807747e-03f,
  1.891422775349768e-02f
};

float Villa4Analysis [] = {
  -1.767766952966369e-01f,
  3.535533905932738e-01f,
  1.060660171779821e+00f,
  3.535533905932738e-01f,
  -1.767766952966369e-01f
};
float Villa4Synthesis [] = {
  3.535533905932738e-01f,
  7.071067811865476e-01f,
  3.535533905932738e-01f
};

float Villa5Analysis [] = {
  7.071067811865476e-01f,
  7.071067811865476e-01f
};
float Villa5Synthesis [] = {
  -8.838834764831845e-02f,
  8.838834764831845e-02f,
  7.071067811865476e-01f,
  7.071067811865476e-01f,
  8.838834764831845e-02f,
  -8.838834764831845e-02f
};

float Villa6Analysis [] = {
  3.314563036811943e-02f,
  -6.629126073623885e-02f,
  -1.767766952966369e-01f,
  4.198446513295127e-01f,
  9.943689110435828e-01f,
  4.198446513295127e-01f,
  -1.767766952966369e-01f,
  -6.629126073623885e-02f,
  3.314563036811943e-02f

};
float Villa6Synthesis [] = {
  3.535533905932738e-01f,
  7.071067811865476e-01f,
  3.535533905932738e-01f
};

// Filter

float OdegardAnalysis[] = {
   5.2865768532960523e-02f,
  -3.3418473279346828e-02f,
  -9.3069263703582719e-02f,
   3.8697186387262039e-01f,
   7.8751377152779212e-01f,
   3.8697186387262039e-01f,
  -9.3069263703582719e-02f,
  -3.3418473279346828e-02f,
   5.2865768532960523e-02f
};
float OdegardSynthesis[] = {
  -8.6748316131711606e-02f,
  -5.4836926902779436e-02f,
   4.4030170672498536e-01f,
   8.1678063499210640e-01f,
   4.4030170672498536e-01f,
  -5.4836926902779436e-02f,
  -8.6748316131711606e-02f
};

FilterSet Haar      (FALSE, HaarCoeffs,          2, 0);
FilterSet Daub4     (FALSE, Daub4Coeffs,         4, 0);
FilterSet Daub6     (FALSE, Daub6Coeffs,         6, 0);
FilterSet Daub8     (FALSE, Daub8Coeffs,         8, 0);
FilterSet Antonini  (TRUE,  AntoniniAnalysis,    9, -4, 
		            AntoniniSynthesis,   7, -3);
FilterSet Villa     (TRUE,  Villa1810Analysis,  10, -4,
		            Villa1810Synthesis, 18, -8);
FilterSet Adelson   (TRUE,  AdelsonCoeffs,       9, -4);
FilterSet Brislawn  (TRUE,  BrislawnAnalysis,    9, -4, 
		            BrislawnSynthesis,   7, -3);
FilterSet Brislawn2 (TRUE,  Brislawn2Analysis,  10, -4,
		            Brislawn2Synthesis, 10, -4);

FilterSet Villa1 (TRUE, Villa1Analysis,  9, -4, Villa1Synthesis,  7, -3);
FilterSet Villa2 (TRUE, Villa2Analysis, 13, -6, Villa2Synthesis, 11, -5);
FilterSet Villa3 (TRUE, Villa3Analysis,  6, -2, Villa3Synthesis, 10, -4);
FilterSet Villa4 (TRUE, Villa4Analysis,  5, -2, Villa4Synthesis,  3, -1);
FilterSet Villa5 (TRUE, Villa5Analysis,  2,  0, Villa5Synthesis,  6, -2);
FilterSet Villa6 (TRUE, Villa6Analysis,  9, -4, Villa6Synthesis,  3, -1);


FilterSet Odegard (TRUE, OdegardAnalysis, 9, -4, OdegardSynthesis, 7, -3);



// Destructor
Filter::~Filter () {
  if (coeff != NULL)
    delete [] coeff;
}

void Filter::init (int filterSize, int filterFirst, float *data) {
   size = filterSize;
   firstIndex = filterFirst;
   center = -firstIndex;

   coeff = new float [size];
   if (data != NULL) {
     for (int i = 0; i < size; i++)
       coeff[i] = data[i];
   } else {
     for (int i = 0; i < size; i++)
       coeff[i] = 0;
   }
}

void Filter::copy (const Filter& filter) {
  if (coeff != NULL)
    delete [] coeff;
  init (filter.size, filter.firstIndex, filter.coeff);
}

FilterSet::FilterSet (int symmetric, 
	     float *anLow, int anLowSize, int anLowFirst,  
	     float *synLow, int synLowSize, int synLowFirst) : 
             symmetric(symmetric) 
{
  int i, sign;

  analysisLow = new Filter (anLowSize, anLowFirst, anLow);

  // If no synthesis coeffs are given, assume wavelet is orthogonal
  if (synLow == NULL)  {
    synthesisLow = new Filter (*analysisLow);

    // For orthogonal wavelets, compute the high pass filter using
    // the relation g_n = (-1)^n h_{1-n}^*
    // (or equivalently g_{1-n} = (-1)^{1-n} h_n^*)

    analysisHigh = new Filter (analysisLow->size, 2 - analysisLow->size -
				analysisLow->firstIndex);
      
    // Compute (-1)^(1-n) for first n
    if (analysisLow->firstIndex % 2)
      sign = 1;
    else sign = -1;
    
    for (i = 0; i < analysisLow->size; i++)  {
      analysisHigh->coeff[1 - i - analysisLow->firstIndex - 
		           analysisHigh->firstIndex] = 
	sign * analysisLow->coeff[i];
      assert (1 - i - analysisLow->firstIndex - 
		           analysisHigh->firstIndex >= 0);
      assert (1 - i - analysisLow->firstIndex - 
		           analysisHigh->firstIndex < analysisHigh->size);
      sign *= -1;
    }

    // Copy the high pass analysis filter to the synthesis filter
    synthesisHigh = new Filter (*analysisHigh);    
    
  } else {
    // If separate synthesis coeffs given, assume biorthogonal
    
    synthesisLow = new Filter (synLowSize, synLowFirst, synLow);

    // For orthogonal wavelets, compute the high frequency filter using
    // the relation g_n = (-1)^n complement (h~_{1-n}) and
    //              g~_n = (-1)^n complement (h_{1-n})
    // (or equivalently g_{1-n} = (-1)^{1-n} complement (h~_n))
    
    analysisHigh = new Filter (synthesisLow->size, 2 - synthesisLow->size -
			 synthesisLow->firstIndex);
    
    // Compute (-1)^(1-n) for first n
    if (synthesisLow->firstIndex % 2)
      sign = 1;
    else sign = -1;
    
    for (i = 0; i < synthesisLow->size; i++)  {
      analysisHigh->coeff[1 - i - synthesisLow->firstIndex -
			  analysisHigh->firstIndex] = 
	sign * synthesisLow->coeff[i];
      assert (1 - i - synthesisLow->firstIndex - 
		           analysisHigh->firstIndex >= 0);
      assert (1 - i - synthesisLow->firstIndex - 
		           analysisHigh->firstIndex < analysisHigh->size);
      sign *= -1;
    }

    synthesisHigh = new Filter 
                           (analysisLow->size, 2 - analysisLow->size -
			    analysisLow->firstIndex); 
    
    // Compute (-1)^(1-n) for first n
    if (analysisLow->firstIndex % 2)
      sign = 1;
    else sign = -1;

    for (i = 0; i < analysisLow->size; i++)  {
      synthesisHigh->coeff[1 - i - analysisLow->firstIndex -
			   synthesisHigh->firstIndex] = 
	sign * analysisLow->coeff[i];
      assert (1 - i - analysisLow->firstIndex - 
		           synthesisHigh->firstIndex >= 0);
      assert (1 - i - analysisLow->firstIndex - 
		           synthesisHigh->firstIndex < synthesisHigh->size);
      sign *= -1;
    }
  }
}

FilterSet::FilterSet (const FilterSet& filterset) {
  copy (filterset);
}

FilterSet::~FilterSet () {
  delete analysisLow;
  delete analysisHigh;
  delete synthesisLow;
  delete synthesisHigh;
}

FilterSet& FilterSet::operator= (const FilterSet filterset) {
  delete analysisLow;
  delete analysisHigh;
  delete synthesisLow;
  delete synthesisHigh;
  copy (filterset);
  return *this;
}

void FilterSet::copy (const FilterSet& filterset) {
  symmetric = filterset.symmetric;
  analysisLow = new Filter (*(filterset.analysisLow));
  analysisHigh = new Filter (*(filterset.analysisHigh));
  synthesisLow = new Filter (*(filterset.synthesisLow));
  synthesisHigh = new Filter (*(filterset.synthesisHigh));
}
