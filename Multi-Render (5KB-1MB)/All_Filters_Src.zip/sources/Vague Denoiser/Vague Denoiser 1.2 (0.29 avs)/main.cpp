/*  VagueDenoiser - filter for VirtualDub
    Copyright (C) 2004 Emiliano Ferrari  <macinapepe@tiscali.it>

    Based on: VagueDenoiser plugin for Avisynth v0.29
    VagueDenoiser plugin for Avisynth (C) 2003, LeFunGus
    VagueDenoiser assembly parts, debug and adaptative thresholding (C) Kurosu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <math.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <windows.h>
#include "brislawn.h"
#include <commctrl.h>
#include "filter.h"
#include "resource.h"
#include "ScriptValue.h"

typedef struct
{
  int threshold;
  int method;
  int nsteps;
  __declspec(align(16)) Wavelet *wavelet;
  unsigned char *BR,*BG,*BB;
  float *block;
  IFilterPreview *ifp;
} MyFilterData;


//============================================================
_inline unsigned char realToChar (float x)
{
  return (x>255.0f?255:(x<0.0f?0:(unsigned char)(x+0.5f)));
}

_inline float sgn (float x)
{
    return (x<0)?-1.0f:((x>0)?1.0f:0.0f);
}

void ht_c(float* block, const unsigned int b, const float threshold,const unsigned int width, const unsigned int height)
{
  for (unsigned int i=0;i<b;i++)
   if (fabsf(block[i]) <= threshold) block[i] = 0.0f;
}

void st_c(float* block, const unsigned int b, const float threshold,const unsigned int width, const unsigned int height)
{
  for(unsigned int i=0;i<b;i++)
  {
    float temp=fabsf(block[i]);
    if (temp <= threshold) block[i]=0.0f;
      else block[i]= sgn(block[i])*(temp-threshold);
  }
}

void qt_c(float* block, const unsigned int b, const float threshold,const unsigned int width, const unsigned int height)
{
  float tr2 = threshold*threshold, tp2, temp;
  for(unsigned int i=0;i<b;i++)
  {
    temp=fabsf(block[i]);
    if(temp<=threshold) block[i]=0.0f;
    else
    {
      tp2 = temp*temp;
      block[i]*=(tp2-tr2)/tp2;
    }
  }
}

void b2f_c(const unsigned int h, const unsigned int w,const unsigned char* src, const unsigned int srcPitch,float *blockptr)
{
  //Copy Source to Buffer
  for (unsigned int i=0; i < h;i++)
  {
    for (unsigned int j = 0; j < w; j+=2)
    {
       blockptr[j] =  src[j];
       blockptr[j+1] = src[j+1];
    }
    src += srcPitch;
    blockptr += w;
  }
}

void f2b_c(const unsigned int h, const unsigned int w,unsigned char *dst, const unsigned int dstPitch,float *blockptr)
{
  //Copy Buffer to Destination
  for (unsigned int i=0; i < h;i++)
  {
    for (unsigned int j = 0; j < w; j+=2)
    {
      dst[j] = realToChar(blockptr[j]);
      dst[j+1] = realToChar(blockptr[j+1]);
    }
    dst += dstPitch;
    blockptr += w;
  }
}

void b2f1D_c(const unsigned int w, const unsigned char* src, float *blockptr)
{
  //Copy Source to Buffer
  for (unsigned int i=0; i < w;i+=2)
  {
    blockptr[i] =  src[i];
    blockptr[i+1] =  src[i+1];
  }
}

void f2b1D_c(const unsigned int w, unsigned char *dst, float *blockptr)
{
  //Copy Buffer to Destination
  for (unsigned int i=0; i < w;i+=2)
  {
    dst[i] = realToChar(blockptr[i]);
    dst[i+1] = realToChar(blockptr[i+1]);
  }
}

extern "C" {

/***** ByteToFloat ****/
typedef void(B2FFunc) (const unsigned int h,const unsigned int w,const unsigned char *src,const unsigned int srcPitch,float *blockptr);
typedef B2FFunc *B2FFuncPtr;
extern B2FFunc b2f_3dne, b2f_sse;

/***** ByteToFloat 1D ****/
typedef void(B2F1DFunc) (const unsigned int w,const unsigned char *src,float *blockptr);
typedef B2F1DFunc *B2F1DFuncPtr;
extern B2F1DFunc b2f1D_3dne, b2f1D_sse;

/***** FloatToByte ****/
typedef void(F2BFunc) (const unsigned int h,const unsigned int w,unsigned char *dst,const unsigned int srcPitch,float *blockptr);
typedef F2BFunc *F2BFuncPtr;
extern F2BFunc f2b_3dne, f2b_sse;

/***** ByteToFloat 1D ****/
typedef void(F2B1DFunc) (const unsigned int w,unsigned char *dst,float *blockptr);
typedef F2B1DFunc *F2B1DFuncPtr;
extern F2B1DFunc f2b1D_3dne, f2b1D_sse;

/***** Filter *****/
typedef void(FilterFunc)(float* block, const unsigned int b, const float threshold,const unsigned int width, const unsigned int height);
typedef FilterFunc *FilterFuncPtr;
extern FilterFunc ht_3dne, st_3dne, qt_3dne;
extern FilterFunc ht_sse, st_sse, qt_sse;
}

FilterFuncPtr filter;
B2FFuncPtr byte2float;
F2BFuncPtr float2byte;
B2F1DFuncPtr byte2float1D;
F2B1DFuncPtr float2byte1D;


int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const int w= fa->dst.w;
  const int h= fa->dst.h;
  const int nsteps= mfd->nsteps;

  mfd->BR= (unsigned char *) _mm_malloc(w*h*sizeof(unsigned char),128);
  if (!mfd->BR) ff->ExceptOutOfMemory();
  mfd->BG= (unsigned char *) _mm_malloc(w*h*sizeof(unsigned char),128);
  if (!mfd->BG) ff->ExceptOutOfMemory();
  mfd->BB= (unsigned char *) _mm_malloc(w*h*sizeof(unsigned char),128);
  if (!mfd->BB) ff->ExceptOutOfMemory();
  mfd->block= (float*) _mm_malloc((10+w*h)*sizeof(float),128);
  if (!mfd->block) ff->ExceptOutOfMemory();

  if (nsteps < 1 || pow(2,nsteps+1)>h || pow(2,nsteps)>w)
    ff->Except("clip dimensions too low to permit this value of nstep");

  if ((CPUF_SUPPORTS_MMX & ff->getCPUFlags()))
  {
  mfd->wavelet= new Brislawn_3DNow(w,h,nsteps);
  switch(mfd->method)
  {
    case 0: filter= ht_3dne; break;
    case 1: filter= st_3dne; break;
    case 3: filter= qt_3dne; break;
  }
  byte2float= b2f_3dne;
  float2byte= f2b_3dne;
  byte2float1D= b2f1D_3dne;
  float2byte1D= f2b1D_3dne;
  }
  else

  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
  {
  mfd->wavelet= new Brislawn_SSE(w,h,nsteps);
  switch(mfd->method)
  {
    case 0: filter= ht_sse; break;
    case 1: filter= st_sse; break;
    case 3: filter= qt_sse; break;
  }
  byte2float= b2f_sse;
  float2byte= f2b_sse;
  byte2float1D= b2f1D_sse;
  float2byte1D= f2b1D_sse;
  }

  else

  {
  mfd->wavelet= new Brislawn_C(w,h,nsteps);
  switch(mfd->method)
  {
    case 0: filter= ht_c; break;
    case 1: filter= st_c; break;
    case 3: filter= qt_c; break;
  }
  byte2float= b2f_c;
  float2byte= f2b_c;
  byte2float1D= b2f1D_c;
  float2byte1D= f2b1D_c;
  }

  return 0;
}


// ==========================================================

void filterBlockPlane(MyFilterData *mfd,int h, int w, const unsigned char* src,unsigned char* dst, int srcPitch, int dstPitch)
{
 // Most usual case, always this one for YUY2 and RGBx
 if (w != srcPitch) byte2float(h, w, src, srcPitch, mfd->block);
 else byte2float1D(w*h, src, mfd->block);

 //Apply filtering
 mfd->wavelet->transform2d(mfd->block,w,h,mfd->nsteps);
 if ((mfd->method != -1) && (mfd->threshold>0)) filter(mfd->block, w*h,mfd->threshold/100.0f, w, h);
 mfd->wavelet->invert2d(mfd->block,w,h,mfd->nsteps);
 /* Float to byte */
 if (w != dstPitch) float2byte(h, w, dst, dstPitch, mfd->block);
 else float2byte1D(h*w, dst, mfd->block);
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int w= fa->dst.w;
  const int h= fa->dst.h;
  const int pitch= fa->dst.pitch>>2;
  int x,y;
  unsigned char *BPR= mfd->BR;
  unsigned char *BPG= mfd->BG;
  unsigned char *BPB= mfd->BB;

  for (y=0; y<h; y++)
  {
    for (x=0; x<w; x++)
    {
      int px= dst[x];
      BPR[x]= (px>>16)&0xff;
      BPG[x]= (px>> 8)&0xff;
      BPB[x]= (px    )&0xff;
    }
    dst+= pitch;
    BPR+= w;
    BPG+= w;
    BPB+= w;
  }


  filterBlockPlane(mfd,h,w, mfd->BR,mfd->BR, w,w);
  filterBlockPlane(mfd,h,w, mfd->BG,mfd->BG, w,w);
  filterBlockPlane(mfd,h,w, mfd->BB,mfd->BB, w,w);


  BPR= mfd->BR;
  BPG= mfd->BG;
  BPB= mfd->BB;
  dst= fa->dst.data;
  for (y=0; y<h; y++)
  {
    for (x=0; x<w; x++)
      dst[x]= (BPR[x]<<16)|(BPG[x]<<8)|BPB[x];
    dst+= pitch;
    BPR+= w;
    BPG+= w;
    BPB+= w;
  }

  return 0;
}

// ===========================================================

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->threshold= (int)(0.8 * 100);
  mfd->method   = 1;
  mfd->nsteps   = 6;
  mfd->BR       = NULL;
  mfd->BG       = NULL;
  mfd->BB       = NULL;
  mfd->block    = NULL;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->BR) { _mm_free(mfd->BR); mfd->BR= NULL; }
  if (mfd->BG) { _mm_free(mfd->BG); mfd->BG= NULL; }
  if (mfd->BB) { _mm_free(mfd->BB); mfd->BB= NULL; }
  if (mfd->block) { _mm_free(mfd->block); mfd->block= NULL; }
  return 0;
}

// ==============================================================

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char tmp[128];

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;

      SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,4000));
      SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD),TBM_SETTICFREQ,100,0);
      SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD),TBM_SETPOS  ,(WPARAM)TRUE,mfd->threshold);
      _snprintf(tmp,128," treshold (%1.2f): ", mfd->threshold/100.0);
      SetDlgItemText(hdlg,IDC_THRESHOLDVAL,tmp);

      SendMessage(GetDlgItem(hdlg,IDC_STEPS),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(1,8));
      SendMessage(GetDlgItem(hdlg,IDC_STEPS),TBM_SETPOS  ,(WPARAM)TRUE,mfd->nsteps);
      _snprintf(tmp,128," nsteps (%d): ", mfd->nsteps);
      SetDlgItemText(hdlg,IDC_STEPSVAL,tmp);

      CheckDlgButton(hdlg,IDC_METHOD_1,(mfd->method==-1)?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_METHOD0,(mfd->method==0)?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_METHOD1,(mfd->method==1)?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_METHOD2,(mfd->method==2)?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_METHOD3,(mfd->method==3)?BST_CHECKED:BST_UNCHECKED);

      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;

         case IDC_METHOD_1: mfd->method= -1; mfd->ifp->RedoFrame(); break;
        case IDC_METHOD0: mfd->method= 0; mfd->ifp->RedoFrame(); break;
        case IDC_METHOD1: mfd->method= 1; mfd->ifp->RedoFrame(); break;
        case IDC_METHOD2: mfd->method= 2; mfd->ifp->RedoFrame(); break;
        case IDC_METHOD3: mfd->method= 3; mfd->ifp->RedoFrame(); break;
      }
      break;

    case WM_HSCROLL:
      mfd->threshold= SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD),TBM_GETPOS,0,0);
      _snprintf(tmp,128," treshold (%1.2f): ", mfd->threshold/100.0);
      SetDlgItemText(hdlg, IDC_THRESHOLDVAL,tmp);


      int ns= SendMessage(GetDlgItem(hdlg,IDC_STEPS),TBM_GETPOS,0,0);
      if (ns!=mfd->nsteps)
      {
          mfd->ifp->UndoSystem();
          mfd->nsteps= ns;
          _snprintf(tmp,128," nsteps (%d): ", mfd->nsteps);
          SetDlgItemText(hdlg,IDC_STEPSVAL,tmp);
          mfd->ifp->RedoSystem();
      }
      mfd->ifp->RedoFrame();
      break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int Resoult= DialogBoxParam ( fa->filter->module->hInstModule,
                                MAKEINTRESOURCE(IDD_FILTER_VAGUEDENOISER),
                                hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (Resoult) *mfd= mfd_old;
  return !!Resoult;
}

// =============================================================

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(str,64, " (T:%1.2f M:%d S:%d)", mfd->threshold/100.0,mfd->method,mfd->nsteps);
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d, %d, %d)",
      mfd->threshold,mfd->method,mfd->nsteps);
  return true;
}

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->threshold= argv[0].asInt();
  mfd->method   = argv[1].asInt();
  mfd->nsteps   = argv[2].asInt();
  Clipping (mfd->threshold,0,40*100);
  Clipping (mfd->method,-1,3);
  Clipping (mfd->nsteps,1,8);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

// ============================================================

FilterDefinition filterDef=
{
  NULL, NULL, NULL,            // next, prev, module
  "Vague Denoiser",            // name
  "port of \"VagueDenoiser plugin for Avisynth v0.29\"\n"
  "Version 1.2 (19-03-2004) [3DNow!,SSE]\n"
  "Copyright (C) 2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  StartProc,                   // startProc
  EndProc,                     // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd;

extern "C" int __declspec(dllexport) __cdecl
VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff,
                                        int& vdfd_ver, int& vdfd_compat)
{
  fd= ff->addFilter(fm, &filterDef, sizeof(FilterDefinition));
  if (!fd) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl
VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd);
}
