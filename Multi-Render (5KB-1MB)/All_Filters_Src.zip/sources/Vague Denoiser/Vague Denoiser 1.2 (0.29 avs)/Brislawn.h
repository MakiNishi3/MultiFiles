/*---------------------------------------------------------------------------*/
//  Modified for VirtualDub VagueDenoiser plugin
/*---------------------------------------------------------------------------*/
// Baseline Wavelet Transform Coder Construction Kit
//
// Geoff Davis
// gdavis@cs.dartmouth.edu
// http://www.geoffdavis.net/
//
// Copyright 1996 Geoff Davis 9/11/96
//
// Permission is granted to use this software for research purposes as
// long as this notice stays attached to this software.
//
/*---------------------------------------------------------------------------*/
#ifndef __WAVELET__
#define __WAVELET__

#include <windows.h>
#include <malloc.h>

#define		HAAR		1
#define		BRISLAWN	2

extern "C" {

/*********************************************/
/* transform function used in transform_step */
/*********************************************/
typedef void(transformFunc) (float* input,
							 float* output,
							 const unsigned int lowSize);
typedef transformFunc *transformFuncPtr;
extern transformFunc transform_3dne, transform_sse;

/*******************************************/
/* invert low function used in invert_step */
/*******************************************/
typedef void(invertlowFunc) (float* input,
							 float* output,
							 const unsigned int lowSize);
typedef invertlowFunc *invertlowFuncPtr;
extern invertlowFunc invertlow_3dne, invertlow_sse;

/*******************************************/
/* invert low function used in invert_step */
/*******************************************/
typedef void(inverthighFunc) (float* input,
							 float* output,
							 const unsigned int lowSize);
typedef inverthighFunc *inverthighFuncPtr;
extern inverthighFunc inverthigh_3dne, inverthigh_sse;
}

class Wavelet {
public:
	//Wavelet () { };
	Wavelet (int x, int y, int n)
	{
		hLowSize =  new int[n];
		hHighSize = new int[n]; 
		vLowSize =  new int[n];
		vHighSize = new int[n];
	};
	~Wavelet ()
	{
		_mm_free(temp_out);
		_mm_free(temp_in);
		_mm_free(temp2);
	};

	unsigned char wltnumber;
	float *temp_out, *temp_in, *temp2;
	int *hLowSize, *hHighSize, *vLowSize, *vHighSize;

	virtual void transform2d (float *input, int hsize, int vsize, int nsteps) = 0;
	virtual void invert2d (float *input, int hsize, int vsize, int nsteps) = 0;

	__declspec(align(16)) transformFuncPtr Transform;
	__declspec(align(16)) invertlowFuncPtr InvertLow;
	__declspec(align(16)) inverthighFuncPtr InvertHigh;

	//Copy functions
	_inline void Wavelet::copy(float register*p1, float register*p2, int length)
	{
	  memcpy((BYTE*)p2,(const BYTE*)p1,length*sizeof(float));
	};

	_inline void Wavelet::copy(float register*p1, int pitch, float register*p2, int length)
	{
#if 1
		for(int i=length;i!=0;i--)
		{
			*(p2++)=*p1;
			p1+=pitch;
		}
#else
		for(int i=0;i<length;i++)
		{
			p2[i]=*p1;
			p1+=pitch;
		}
#endif
	};

	_inline void Wavelet::copy(float register*p1, float register*p2, int pitch, int length)
	{
#if 1
		for(int i=length;i!=0;i--)
		{
			//*p2=p1[i];
			*p2=*(p1++);
			p2+=pitch;
		}
#else
		for(int i=0;i<length;i++)
		{
			*p2=p1[i];
			p2+=pitch;
		}
#endif
	};
    _inline void mem_set(void * dest, int set, size_t nBytes);
};

/*******************
 * Taken from http://www.john.findlay1.btinternet.co.uk/asm/memset.htm
 *******************/
#define USE_MOVNTQ2		0

#if USE_MOVNTQ2
#define MOVQ2  movntq
#else
#define MOVQ2  movq
#endif

__inline void Wavelet::mem_set(void * dest, int set, size_t nBytes)
{
	__asm
	{
		push		ebx
			
		mov			edi,[dest]		// dest
		mov			ebx,[set]		// get the set value
		mov			edx,nBytes
		mov			eax,edx
			
		// if num bytes is very small go straight to the last section
		// this will also handle zero num bytes
		cmp			eax,16
		jl			L8check
			
		movd		mm0,[set]		// all eight bytes from memory into mm0
		punpcklbw	mm0,mm0
		
		// align src on 8 boundary. If memory is non-aligned it will seriously
		// affect performance, one cannot align both src & dest
		mov			ecx,edi
		punpcklwd	mm0,mm0
		punpckldq	mm0,mm0
		and			ecx,7
		jecxz		L64check			// jump if no parity
		mov			eax,8
		sub			eax,ecx
		mov			ecx,eax
aligned:
		mov			di,bx
		inc			edi
		dec			ecx
		//cmp			ecx,0
		jnz			aligned
			
L64check:
		mov			ecx,edx
		shr			ecx,6
		mov			eax,ecx				// tmp
		jecxz		L32check
		shl			eax,6
		sub			edx,eax		// new value of num bytes (orig - 64's)

		//align		16	
L64:
		jecxz		L32check			// jump to next section if finished
		dec			ecx
		prefetcht0  [edi+64]
		MOVQ2		[edi+0],mm0
		MOVQ2		[edi+8],mm0
		MOVQ2		[edi+16],mm0
		MOVQ2		[edi+24],mm0
		MOVQ2		[edi+32],mm0
		MOVQ2		[edi+40],mm0
		MOVQ2		[edi+48],mm0
		MOVQ2		[edi+56],mm0
		add			edi,64					// add 64 each loop
#if USE_MOVNTQ2
		sfence
#endif
		jmp			L64
			
L32check:
		mov			ecx,edx
		shr			ecx,5
		mov			eax,ecx
		jecxz		L16check
		shl			eax,5
		sub			edx,eax
			
		//align		16	
//L32:									// can only be one 32's to copy, no loop
		dec			ecx
		movq		[edi+0],mm0
		movq		[edi+8],mm0
		movq		[edi+16],mm0
		movq		[edi+24],mm0
		add			edi,32
			
L16check:
		mov			ecx,edx
		shr			ecx,4
		mov			eax,ecx
		jecxz		L8check
		shl			eax,4
		sub			edx,eax
			
		//align		16	
//L16:									// can only be one 16's to copy
		MOVQ		[edi+0],mm0
		MOVQ		[edi+8],mm0
		add			edi,16
			
L8check:
		mov			ecx,edx
		shr			ecx,3
		mov			eax,ecx
		jecxz		L8
		shl			eax,3
		sub			edx,eax

		MOVQ		[edi+0],mm0			// can only be one 32's to copy, no loop
		add			edi,8
								

L8:
		mov			ecx,edx
Lcheck:									// copy the last remaining bytes
		jecxz		end1
		mov			di,bx
		inc			edi
		dec			ecx
		//cmp			ecx,0
		jnz			Lcheck
			
end1:
		pop			ebx
		emms
	}
}

invertlowFunc invertlow_c;
inverthighFunc inverthigh_c;
transformFunc transform_c;

class Brislawn : public Wavelet {
public:
	Brislawn(int x, int y, int n);
	_inline void transform2d (float *input, int hsize, int vsize, int nsteps);
	_inline void invert2d (float *input, int hsize, int vsize, int nsteps);
	_inline void invert_step(float register* input, float register* output,
							 int size);
	_inline void transform_step(float register* input, float register* output,
								int size, int lowSize);
	_inline void symmetric_extension(float *output, int size, int right_ext);
	_inline void antisymmetric_extension(float *output, int size, int right_ext);
};

class Brislawn_3DNowExt : public Brislawn
{
public:
	Brislawn_3DNowExt(int x, int y, int n) : Brislawn(x ,y, n)
	{
		Transform = transform_3dne;
		InvertLow = invertlow_3dne;
		InvertHigh = inverthigh_sse;
	};
};

class Brislawn_3DNow : public Brislawn
{
public:
	Brislawn_3DNow(int x, int y, int n) : Brislawn(x ,y, n)
	{
		Transform = transform_3dne;
		InvertLow = invertlow_3dne;
		InvertHigh = inverthigh_3dne;
	};
};

class Brislawn_SSE : public Brislawn
{
public:
	Brislawn_SSE(int x, int y, int n) : Brislawn(x ,y, n)
	{
		Transform = transform_sse;
		InvertLow = invertlow_sse;
		InvertHigh = inverthigh_sse;
	};
};

class Brislawn_C : public Brislawn
{
public:
	Brislawn_C(int x, int y, int n) : Brislawn(x ,y, n)
	{
		Transform = transform_c;
		InvertLow = invertlow_c;
		InvertHigh = inverthigh_c;
	};
};

#endif