BITS 32

%macro cglobal 1
  global _%1
  %define %1 _%1
%endmacro
%macro cextern 1
  extern _%1
  %define %1 _%1
%endmacro

%macro PUSHMOST 0
  push  esi
  push  edi
%endmacro

%macro POPMOST 0
  pop  edi
  pop  esi
%endmacro

%macro PUSHALL 0
  push  ebx
  PUSHMOST
%endmacro

%macro POPALL 0
  POPMOST
  pop  ebx
%endmacro

;=============================================================================
; Read only data
;=============================================================================

%ifdef FORMAT_COFF
SECTION .rodata data
%else
SECTION .rodata data align=16
%endif

ALIGN 64
rounder:
dd  0.5, 0.5

%undef PREFETCH3D
%ifdef PREFETCH3D
	%define MOVQ movq
%else
	%define MOVQ movntq
%endif

cglobal  b2f_3dne
cglobal  b2f1D_3dne
cglobal  f2b_3dne
cglobal  f2b1D_3dne

;=============================================================================
; Code
;=============================================================================

SECTION .text

;-----------------------------------------------------------------------------
; Helper macro CONVONE
;-----------------------------------------------------------------------------
%macro CONVONE 3 ; %1 = offset , %2 = offset' , %3 = use prefetchw
	movd      mm0,[esi+%1]
	movd      mm2,[esi+%1+4]
	punpcklbw mm0,mm7
	punpcklbw mm2,mm6
	movq      mm1,mm0
	movq      mm5,mm2
	punpcklwd mm0,mm7
	punpcklwd mm2,mm6
	punpckhwd mm1,mm7
	punpckhwd mm5,mm6
 
	%ifdef PREFETCH3D
	%if %3
		prefetchw [edi+%2+128]
	%endif
	%endif
	pi2fd     mm3,mm0
	pi2fd     mm2,mm2
	pi2fd     mm0,mm1
	pi2fd     mm4,mm5
 
	MOVQ      [edi+%2],mm3
	MOVQ      [edi+%2+8],mm0
	MOVQ      [edi+%2+16],mm2
	MOVQ      [edi+%2+24],mm4
%endmacro

;-----------------------------------------------------------------------------
;
; void b2f_3dne(const uint32_t  h,
; const uint32_t w,
; uint8_t *src,
; const uint32_t srcPitch
; float *blockptr);
;
;-----------------------------------------------------------------------------
ALIGN 16
b2f_3dne:
  PUSHALL
  push      ebp
  mov       ecx,[esp+16+ 4] ;h
  mov       edx,[esp+16+ 8] ;w
  mov       esi,[esp+16+12] ;src
  mov       ebp,[esp+16+16] ;pitch
  mov       edi,[esp+16+20] ;block
  mov       ebx,edx
  xor       eax,eax    ;char index
  and       ebx,-63
  pxor      mm7,mm7
  pxor      mm6,mm6

ALIGN 16
.loophere_aligned
  prefetch  [esi+eax+128]
%ifdef PREFETCH3D
  prefetchw [edi+64]
%endif
  CONVONE   eax+ 0,   0, 0
  CONVONE   eax+ 8,  32, 1
  CONVONE   eax+16,  64, 0
  CONVONE   eax+24,  96, 1
  CONVONE   eax+32, 128, 0
  CONVONE   eax+40, 160, 1
  CONVONE   eax+48, 192, 0
  CONVONE   eax+56, 224, 1

  add       eax,64
  add       edi,256
  
  cmp       eax,ebx
  jl        .loophere_aligned

  cmp       eax,edx
  jge       .loophere_end

ALIGN  16
.loophere_norm
  movd      mm0,[esi+eax]
  punpcklbw mm0,mm7
  punpcklwd mm0,mm6
  
  pi2fd     mm3,mm0
  
  movq      [edi],mm3
  
  add       eax,2
  add       edi,8
  
  cmp       eax,edx
  jl        .loophere_norm

ALIGN  16
.loophere_end
  sub		eax,edx
  shl		eax,2
  sub		edi,eax
  add       esi,ebp
  xor       eax,eax
  
  dec       ecx
  jnz       .loophere_aligned

  pop       ebp
  POPALL
  femms

  ret

;-----------------------------------------------------------------------------
;
; void b2f1D_3dne(const uint32_t int w,
;   const uint8_t* src,
;   float *blockptr);
;
;-----------------------------------------------------------------------------
ALIGN 16
b2f1D_3dne:
  PUSHALL
  mov   edx,[esp+12+ 4] ;w
  mov   esi,[esp+12+ 8] ;src
  mov   edi,[esp+12+12] ;block
  mov   ecx,edx
  and   ecx,-63
  sub   edx,ecx
  inc   edx
  pxor  mm7,mm7
  pxor  mm6,mm6

ALIGN  16
.loophere_aligned
  prefetch [esi+128]
%ifdef PREFETCH3D
  prefetchw [edi+256]
%endif

  CONVONE    0,   0, 0
  CONVONE    8,  32, 1
  CONVONE   16,  64, 0
  CONVONE   24,  96, 1
  CONVONE   32, 128, 0
  CONVONE   40, 160, 1
  CONVONE   48, 192, 0
  CONVONE   56, 224, 1

  add       esi,64
  add       edi,256
  
  sub       ecx,64
  jnz       .loophere_aligned

  dec       edx
  jz        .loophere_end
  ;padd to next multiple of 4
  add		edx,2
  and		edx,-3

ALIGN  16
.loophere_norm
  movd      mm0,[esi]
  punpcklbw mm0,mm7
  movq      mm1,mm0
  punpcklwd mm0,mm6
  punpckhwd mm1,mm7

  pi2fd     mm3,mm0
  pi2fd     mm4,mm1
  
  movq      [edi+0],mm3
  movq      [edi+8],mm4
  
  add       esi,4
  add       edi,16
  
  sub       edx,4
  jnz       .loophere_norm

.loophere_end
  femms
  POPALL
  ret

;-----------------------------------------------------------------------------
; Helper macro UNCONV
;-----------------------------------------------------------------------------
%macro UNCONV 2
  movq     mm0,[esi+%1+ 0]
  movq     mm1,[esi+%1+ 8]
  movq     mm2,[esi+%1+16]
  movq     mm3,[esi+%1+24]
    
  pfadd    mm0,mm7
  pfadd    mm1,mm6
  pfadd    mm2,mm7
  pfadd    mm3,mm6
    
  pf2id    mm4,mm0
  pf2id    mm5,mm1
  pf2id    mm0,mm2
  pf2id    mm1,mm3
    
  packssdw mm4,mm5
  packssdw mm0,mm1
  packuswb mm4,mm0

  movq     [edi+%2],mm4
%endmacro

;-----------------------------------------------------------------------------
;
; void f2b_3dne(const uint32_t h,
;   const uint32_t int w,
;   uint8_t* dst,
;   const uint32_t dstPitch,
;   float *blockptr);
;
;-----------------------------------------------------------------------------
ALIGN 16
f2b_3dne:
  PUSHALL
  push     ebp
  mov      ecx,[esp+16+ 4]
  mov      edx,[esp+16+ 8]
  mov      edi,[esp+16+12]
  mov      ebp,[esp+16+16]
  mov      esi,[esp+16+20] ;blockptr
  movq     mm7,[rounder]
  xor      ebx,ebx        ;char index
  mov      eax,edx
  and      eax,-63
  movq     mm6,mm7

ALIGN 16
.loopthere
  ;prefetch  [esi+128]
  UNCONV    0, ebx+0
  UNCONV   32, ebx+8

  add      esi,64
  add      ebx,16
  cmp      ebx,eax
  jl       .loopthere

  cmp      ebx,edx
  jge      .loopend

ALIGN 16
.loophere
  movq     mm0,[esi]
  
  pfadd    mm0,mm7
  pf2id    mm2,mm0
  packssdw mm2,mm3
  packuswb mm2,mm1

  movd     [edi+ebx],mm2
    
  add      ebx,2
  add      esi,8
  cmp      ebx,edx
  jl       .loophere
 
ALIGN 16   
.loopend
  sub	   ebx,edx
  shl	   ebx,2
  sub	   esi,ebx
  xor      ebx,ebx
  add      edi,ebp
  dec      ecx
  jnz      .loopthere

  pop      ebp
  POPALL
  femms
  ret

;-----------------------------------------------------------------------------
;
; void f2b1D_3dne(const uint32_t int w,
;   uint8_t* dst,
;   float *blockptr);
;
;-----------------------------------------------------------------------------
ALIGN 16
f2b1D_3dne:
  push  esi
  push  edi
  mov   edx,[esp+8+ 4]
  mov   edi,[esp+8+ 8]
  mov   esi,[esp+8+12]
  mov   ecx,edx
  and   ecx,-15
  sub   edx,ecx
  inc   edx
  movq  mm7,[rounder]
  movq  mm6,mm7

ALIGN 16
.loopthere
  ;prefetch  [esi+128]
  UNCONV   0,  0
  UNCONV   32, 8

  add      esi,64
  add      edi,16
  sub      ecx,16
  jnz      .loopthere

  dec       edx
  jz       .loopend
  ;padd to next multiple of 4
  add		edx,2
  and		edx,-2

ALIGN 16
.loophere
  movq     mm0,[esi]
  movq     mm1,[esi+8]
  
  pfadd    mm0,mm7
  pfadd    mm1,mm6
  pf2id    mm2,mm0
  pf2id    mm3,mm1
  packssdw mm2,mm3
  packuswb mm2,mm1
  movd     [edi],mm2
  
  add      edi,4
  add      esi,16
  sub      edx,4
  jnz      .loophere
  
.loopend
  femms
  pop     edi
  pop     esi
  ret