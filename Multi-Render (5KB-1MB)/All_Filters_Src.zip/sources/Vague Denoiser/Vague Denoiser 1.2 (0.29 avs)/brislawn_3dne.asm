BITS 32

%macro cglobal 1
	global _%1
	%define %1 _%1
%endmacro
%macro cextern 1
  extern _%1
  %define %1 _%1
%endmacro

%macro PUSHMOST 0
  push  esi
  push  edi
%endmacro

%macro POPMOST 0
  pop  edi
  pop  esi
%endmacro

%macro PUSHALL 0
  push  ebx
  PUSHMOST
%endmacro

%macro POPALL 0
  POPMOST
  pop  ebx
%endmacro

;=============================================================================
; Read only data
;=============================================================================

SECTION .rdata align=16

ALIGN 64
aL3D:
  dd  0.026913419, -0.032303352, -0.241109818,  0.054100420,  0.899506092,\
      0.899506092,  0.054100420, -0.241109818, -0.032303352,  0.026913419
aH3D:
  dd  0.019843545, -0.023817599, -0.023257840, -0.145570740,  0.541132748,\
     -0.541132748,  0.145570740,  0.023257840,  0.023817599, -0.019843545
sL3D:
  dd  0.019843545,  0.023817599, -0.023257840,  0.145570740,  0.541132748,\
      0.541132748,  0.145570740, -0.023257840,  0.023817599,  0.019843545
sH3D:
  dd  0.026913419,  0.032303352, -0.241109818, -0.054100420,  0.899506092,\
     -0.899506092,  0.054100420,  0.241109818, -0.032303352, -0.026913419

;=============================================================================
; Code
;=============================================================================

SECTION .text

cglobal  transform_3dne
cglobal  invertlow_3dne
cglobal  inverthigh_3dne

;-----------------------------------------------------------------------------
;
; void transform_3dne(float* input,
; float* output,
; const uint32_t size);
;
;-----------------------------------------------------------------------------

ALIGN 16
transform_3dne:
  PUSHALL
  mov   esi,[esp+12+ 4] ;input
  mov   edi,[esp+12+ 8] ;output
  mov   edx,[esp+12+12] ;lowSize
  lea   eax,[aL3D]
  add   esi,6*4        ;eax=output[10+i]=output[7+idx/2]
  shl   edx,2
  xor   ecx,ecx
  add   edi,10*4
  movq  mm3,[eax+0]    ;mm5=aH3D[0] | aH3D[1]
  movq  mm4,[eax+8]    ;mm5=aH3D[2] | aH3D[3]
  movq  mm5,[eax+16]   ;mm5=aH3D[4] | aH3D[5]
  movq  mm6,[eax+24]   ;mm5=aH3D[6] | aH3D[7]
  movq  mm7,[eax+32]   ;mm5=aL3D[8] | aL3D[9]

ALIGN 16
.looplow
  ;prefetch [esi+2*ecx+64]
  movq  mm1,[esi+2*ecx+ 0] ;mm0=input[idx] | input[idx+1]
  movq  mm0,[esi+2*ecx+ 8] ;mm0=input[idx+2] | input[idx+3]
  pfmul mm1,mm3            ;mm1=al0*i0 | al1*i1
  pfmul mm0,mm4

  movq  mm2,[esi+2*ecx+16] ;mm0=input[idx+4] | input[idx+5]
  pfadd mm1,mm0
  movq  mm0,[esi+2*ecx+24]
  pfmul mm2,mm5
  pfmul mm0,mm6
  pfadd mm1,mm2
  pfadd mm1,mm0

  movq  mm2,[esi+2*ecx+32]
  pfmul mm2,mm7
  pfadd mm1,mm2
  pfacc mm1,mm1
  movd  [edi+ecx],mm1

  add   ecx,4
  cmp   ecx,edx
  jl    .looplow

  lea   eax,[aH3D]
  xor   ecx,ecx
  add   edi,edx
  movq  mm3,[eax+0]  ;mm5=aH3D[6] | aH3D[7]
  movq  mm4,[eax+8]  ;mm5=aH3D[6] | aH3D[7]
  movq  mm5,[eax+16] ;mm5=aH3D[6] | aH3D[7]
  movq  mm6,[eax+24] ;mm5=aH3D[8] | aH3D[9]
  movq  mm7,[eax+32] ;mm5=aL3D[8] | aL3D[9]

ALIGN 16
.loophigh
  ;prefetch [esi+2*ecx+64]
  movq  mm1,[esi+2*ecx+0] ;mm0=input[idx] | input[idx+1]
  movq  mm0,[esi+2*ecx+8] ;mm0=input[idx+2] | input[idx+3]
  pfmul mm1,mm3           ;mm1=al0*i0 | al1*i1
  pfmul mm0,mm4

  movq  mm2,[esi+2*ecx+16] ;mm0=input[idx+4] | input[idx+5]
  pfadd mm1,mm0
  movq  mm0,[esi+2*ecx+24]
  pfmul mm2,mm5
  pfmul mm0,mm6
  pfadd mm1,mm2
  pfadd mm1,mm0

  movq  mm2,[esi+2*ecx+32]
  pfmul mm2,mm7
  pfadd mm1,mm2
  pfacc mm1,mm1
  movd  [edi+ecx],mm1

  add   ecx,4
  cmp   ecx,edx
  jl    .loophigh

  femms
  POPALL
  ret


;-----------------------------------------------------------------------------
;
; void invertlow_3dne(float* output,
; float* temp,
; const uint32_t findex)
;
;-----------------------------------------------------------------------------

ALIGN 16
invertlow_3dne:
  PUSHALL
  mov   edi,[esp+12+ 4] ;output
  mov   esi,[esp+12+ 8] ;temp
  mov   ecx,[esp+12+12] ;findex
  lea   edx,[sL3D]
  mov   eax,8*4        ;idx2=8 (*4)
  shl   ecx,2          ;findex (*4)
  mov   ebx,2*4        ;idx=2 (*4)
  add   ecx,11*4       ;findex+11 (*4)
                       ;i=findex => idx2=8+(findex+2) (*4)
  movq  mm1,[edx]      ;mm5=sL3D[0] | sL3D[1]
  movq  mm4,[edx+8]    ;mm5=sL3D[2] | sL3D[3]
  movq  mm5,[edx+16]   ;mm5=sL3D[4] | sL3D[5]
  movq  mm6,[edx+24]   ;mm6=sL3D[6] | sL3D[7]
  movq  mm7,[edx+32]   ;mm7=sL3D[8] | sL3D[9]

ALIGN 16
.loopback
  prefetchnta [esi+eax+192]
  movd  mm0,[esi+eax] ;mm0=? | temp[idx2]
  punpckldq mm0,mm0   ;mm0=temp[idx2] | temp[idx2]

  movq  mm2,mm1   ;mm2=sL3D[0] | sL3D[1]
  movq  mm3,mm4   ;mm3=sL3D[2] | sL3D[3]
  pfmul mm2,mm0   ;mm2=sl0*t0 | sl1*t0
  pfmul mm3,mm0   ;mm3=sl2*t0 | sl3*t0
  pfadd mm2,[edi+ebx+0] ;mm2=out[idx]+sl0*t0 | out[idx+1]+sl1*t0
  pfadd mm3,[edi+ebx+8] ;mm3=out[idx+2]+sl2*t0 | out[idx+3]+sl3*t0
  movq  [edi+ebx+0],mm2 ;o0 | o1 = o0+sl0*t0 | o1+sl1*t0
  movq  [edi+ebx+8],mm3 ;o2 | o3 = o2+sl2*t0 | o3+sl3*t0
  movq  mm2,mm5   ;mm1=sL3D[4] | sL3D[5]
  movq  mm3,mm6   ;mm1=sL3D[6] | sL3D[7]

  pfmul mm2,mm0   ;mm2=sl4*t0 | sl5*t0
  pfmul mm3,mm0   ;mm3=sl6*t0 | sl7*t0
  pfadd mm2,[edi+ebx+16] ;mm2=out[idx+4]+sl4*t0 | out[idx+5]+sl5*t0
  pfadd mm3,[edi+ebx+24] ;mm3=out[idx+6]+sl6*t0 | out[idx+7]+sl7*t0

  pfmul mm0,mm7   ;mm2=sl8*t0 | sl9*t0
  movq  [edi+ebx+16],mm2 ;o4 | o5 = o4+sl4*t0 | o5+sl5*t0
  movq  [edi+ebx+24],mm3 ;o6 | o7 = o6+sl6*t0 | o7+sl7*t0
  pfadd mm0,[edi+ebx+32] ;out[idx+8]+sl8*t0 | out[idx+9]+sl9*t0
  movq  [edi+ebx+32],mm0 ;o8 | o9 = o8+sl8*t0 | o9+sl9*t0

  add   eax,4   ;idx2++
  add   ebx,8   ;idx+=2
  cmp   eax,ecx ;(idx2 < findex+11)?
  jl    .loopback
  ;sfence
  femms
  POPALL
  ret

;-----------------------------------------------------------------------------
;
; void inverthigh_3dne(float* output,
; float* temp,
; const uint32_t findex,
;
;-----------------------------------------------------------------------------

ALIGN 16
inverthigh_3dne:
  PUSHALL
  mov   edi,[esp+12+ 4] ;output
  mov   esi,[esp+12+ 8] ;temp
  mov   ecx,[esp+12+12] ;findex
  lea   edx,[sH3D]
  mov   eax,8*4   ;idx2=8 (*4)
  shl   ecx,2     ;findex (*4)
  mov   ebx,2*4   ;idx=2 (*4)
  add   ecx,11*4  ;edx=findex+11 (*4)
                  ;i=findex => idx2=8+(findex+2)
  movq  mm1,[edx+0]  ;mm1=sH3D[0] | sH3D[1]
  movq  mm4,[edx+8]  ;mm1=sH3D[2] | sH3D[3]
  movq  mm5,[edx+16] ;mm1=sH3D[4] | sH3D[5]
  movq  mm6,[edx+24] ;mm1=sH3D[6] | sH3D[7]
  movq  mm7,[edx+32] ;mm1=sH3D[8] | sH3D[9]

.loopthere:
  movd  mm0,[esi+eax]   ;mm0=? temp[idx2]
  prefetchw [edi+ebx+160] ;slows down things in fact...
  punpckldq mm0,mm0     ;mm0=temp[idx2] | temp[idx2]

  movq  mm2,mm1          ;mm2=sH3D[0] | sH3D[1]
  movq  mm3,mm4          ;mm3=sH3D[2] | sH3D[3]
  pfmul mm2,mm0          ;mm2=sh0*t0 | sh1*t0
  pfmul mm3,mm0          ;mm3=sh2*t0 | sh3*t0
  pfadd mm2,[edi+ebx+ 0] ;mm2=out[idx]+sh0*t0 | out[idx+1]+sh1*t0
  pfadd mm3,[edi+ebx+ 8] ;mm3=out[idx+2]+sh2*t0 | out[idx+3]+sh3*t0
  movq  [edi+ebx+0],mm2  ;o0 | o1 = o0+sh0*t0 | o1+sh1*t0
  movq  [edi+ebx+8],mm3  ;o2 | o3 = o2+sh2*t0 | o3+sh3*t0
  
  movq  mm2,mm5          ;mm1=sH3D[4] | sH3D[5]
  movq  mm3,mm6          ;mm1=sH3D[6] | sH3D[7]
  pfmul mm2,mm0          ;mm2=sh4*t0 | sh5*t0
  pfmul mm3,mm0          ;mm3=sh6*t0 | sh7*t0
  pfadd mm2,[edi+ebx+16] ;mm2=out[idx+4]+sh4*t0 | out[idx+5]+sh5*t0
  pfadd mm3,[edi+ebx+24] ;mm3=out[idx+6]+sh6*t0 | out[idx+7]+sh7*t0
  movq  [edi+ebx+16],mm2 ;o4 | o5 = o4+sh4*t0 | o5+sh5*t0
  movq  [edi+ebx+24],mm3 ;o6 | o7 = o6+sh6*t0 | o7+sh7*t0
  
  pfmul mm0,mm7          ;mm2=sh8*t0 | sh9*t0
  pfadd mm0,[edi+ebx+32] ;out[idx+8]+sh8*t0 | out[idx+9]+sh9*t0
  movq  [edi+ebx+32],mm0 ;o8 | o9 = o8+sh8*t0 | o9+sh9*t0
  
  add   eax,4            ;idx2++
  add   ebx,8            ;idx+=2
  cmp   eax,ecx          ;(idx2 < findex+11)?
  jl    .loopthere

  femms
  POPALL
  ret