BITS 32

%macro cglobal 1
  global _%1
  %define %1 _%1
%endmacro
%macro cextern 1
  extern _%1
  %define %1 _%1
%endmacro

;=============================================================================
; Read only data
;=============================================================================

SECTION .rodata align=16

ALIGN 64
GetAbs:  dd 0x7FFFFFFF, 0x7FFFFFFF, 0x7FFFFFFF, 0x7FFFFFFF
ALIGN 64
GetSign: dd 0x80000000, 0x80000000, 0x80000000, 0x80000000

;=============================================================================
; Code
;=============================================================================

SECTION .text

cglobal  ht_sse
cglobal  st_sse
cglobal  qt_sse

;-----------------------------------------------------------------------------
;
; Hard Thresholding
; ht_sse(float* block, int b, float threshold);
;
;-----------------------------------------------------------------------------
ALIGN 16
ht_sse:
  push    ebx
  push    esi
  mov     esi,[esp+8+ 4]
  mov     ecx,[esp+8+ 8]
  movss   xmm7,[esp+8+12]
  movaps  xmm3,[GetAbs]
  shufps  xmm7,xmm7,0x0000
  ;mov     ebx,ecx
  ;xor     eax,eax
  ;and     ebx,-15
  ;shl     ecx,2
  ;shl     ebx,2
  shl   ecx,2
  mov   ebx,ecx
  xor   eax,eax
  and   ebx,-255

ALIGN 16
.loophard_aligned:
  prefetchnta [esi+eax+64]
  movaps  xmm0,[esi+eax]
  movaps  xmm2,xmm0
  
  movaps  xmm1,[esi+eax+16]
  andps   xmm0,xmm3
  cmpltps xmm0,xmm7
  movaps  xmm4,xmm1
  andnps  xmm0,xmm2
  andps   xmm1,xmm3
  movaps  [esi+eax],xmm0
  cmpltps xmm1,xmm7
    
  movaps  xmm0,[esi+eax+32]
  movaps  xmm2,xmm0
  andnps  xmm1,xmm4
  andps   xmm0,xmm3
  movaps  [esi+eax+16],xmm1
  cmpltps xmm0,xmm7
  
  movaps  xmm1,[esi+eax+48]
  movaps  xmm4,xmm1
  andnps  xmm0,xmm2
  andps   xmm1,xmm3
  movaps  [esi+eax+32],xmm0
  cmpltps xmm1,xmm7
  andnps  xmm1,xmm4
  movaps  [esi+eax+48],xmm1
   
  add     eax,64
  cmp     eax,ebx
  jl      .loophard_aligned
  cmp     eax,ecx
  jl      .loophard_norm
  jmp     loophard_end

ALIGN 16
.loophard_norm
  movaps  xmm0,[esi+eax]
  movaps  xmm2,xmm0
  andps   xmm0,xmm3
  cmpltps xmm0,xmm7
  andnps  xmm0,xmm2
  movaps  [esi+eax],xmm0
    
  add     eax,16
  cmp     eax,ecx
  jl      .loophard_norm

ALIGN 16
loophard_end:
  pop     esi
  pop     ebx
  ret

;-----------------------------------------------------------------------------
; Helper macro STONE
;-----------------------------------------------------------------------------
%macro STONE 1 ; %1 = offset
  movaps  xmm0,[esi+eax+%1]
  movaps  xmm2,xmm0
  movaps  xmm5,xmm0
  andps   xmm0,xmm3
  andps   xmm5,xmm4
  movaps  xmm6,xmm7
  movaps  xmm1,xmm7
  cmpltps xmm6,xmm0
  orps    xmm1,xmm5
  subps   xmm2,xmm1
  andps   xmm2,xmm6
  movaps  [esi+eax+%1],xmm2
%endmacro

;-----------------------------------------------------------------------------
;
; Soft Thresholding
; st_sse(float* block, int b, float threshold);
;
;-----------------------------------------------------------------------------
ALIGN 16
st_sse:
  push    ebx
  push    esi
  mov     esi,[esp+8+ 4]
  mov     ecx,[esp+8+ 8]
  movss   xmm7,[esp+8+12]
  movaps  xmm3,[GetAbs]
  movaps  xmm4,[GetSign]
  shufps  xmm7,xmm7,0x0000
  mov     ebx,ecx
  xor     eax,eax
  and     ebx,-15
  shl     ecx,2
  shl     ebx,2

ALIGN 16
.loopsoft_aligned
  prefetchnta [esi+eax+128]
  STONE    0
  STONE   16
  STONE   32
  STONE   48

  add     eax,64
  cmp     eax,ebx
  jl      .loopsoft_aligned
   
  cmp     eax,ecx
  jnl     .loopsoft_end

ALIGN 16
.loopsoft_norm
  STONE   0
  add     eax,16
  cmp     eax,ecx
  jl      .loopsoft_norm

ALIGN 16
.loopsoft_end
  pop     esi
  pop     ebx
  ret

;-----------------------------------------------------------------------------
; Helper macro QTONE
;-----------------------------------------------------------------------------
%macro QTONE 1 ; %1 = offset
  movaps  xmm0,[esi+eax+%1]
  movaps  xmm5,xmm0
  movaps  xmm2,xmm0
  mulps   xmm5,xmm5
  andps   xmm0,xmm3
  movaps  xmm1,xmm7
  rcpps   xmm4,xmm5
  subps   xmm5,xmm6
  mulps   xmm5,xmm2
  cmpltps xmm1,xmm0
  mulps   xmm5,xmm4
  andps   xmm5,xmm1
  movaps  [esi+eax+%1],xmm5
%endmacro

;-----------------------------------------------------------------------------
;
; Qian Thresholding
; qt_sse(float* block, int b, float threshold);
;
;-----------------------------------------------------------------------------
ALIGN 16
qt_sse:
  push    ebx
  push    esi
  mov     esi,[esp+8+ 4]
  mov     ecx,[esp+8+ 8]
  movss   xmm7,[esp+8+12]
  movaps  xmm3,[GetAbs]
  shufps  xmm7,xmm7,0x0
  mov     ebx,ecx
  xor     eax,eax
  movaps  xmm6,xmm7
  and     ebx,-15
  mulps	  xmm6,xmm7
  shl     ecx,2
  shl     ebx,2

ALIGN 16
.loopqian_aligned
  prefetchnta [esi+eax+64]
  QTONE    0
  QTONE   16
  QTONE   32
  QTONE   48

  add     eax,64
  cmp     eax,ebx
  jl      .loopqian_aligned
   
  cmp     eax,ecx
  jl      .loopqian_norm
  jmp     .loopqian_end

ALIGN 16
.loopqian_norm
  QTONE   0
  add     eax,16
  cmp     eax,ecx
  jl      .loopqian_norm

ALIGN 16
.loopqian_end
  pop     esi
  pop     ebx
  ret

