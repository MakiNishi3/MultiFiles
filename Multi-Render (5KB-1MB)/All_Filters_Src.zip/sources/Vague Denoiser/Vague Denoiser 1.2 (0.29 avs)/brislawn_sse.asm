BITS 32

%macro cglobal 1
	global _%1
	%define %1 _%1
%endmacro
%macro cextern 1
	extern _%1
	%define %1 _%1
%endmacro

%macro PUSHMOST 0
  push  esi
  push  edi
%endmacro

%macro POPMOST 0
  pop  edi
  pop  esi
%endmacro

%macro PUSHALL 0
  push  ebx
  PUSHMOST
%endmacro

%macro POPALL 0
  POPMOST
  pop  ebx
%endmacro


;=============================================================================
; Read only data
;=============================================================================

%ifdef FORMAT_COFF
SECTION .rodata data
%else
SECTION .rodata data align=16
%endif

ALIGN 64
aLSSE:
  dd  0.026913419, -0.032303352, -0.241109818,  0.054100420,  0.899506092,\
      0.899506092,  0.054100420, -0.241109818, -0.032303352,  0.026913419

ALIGN 64
aHSSE:
  dd  0.019843545, -0.023817599, -0.023257840, -0.145570740,  0.541132748,\
     -0.541132748,  0.145570740,  0.023257840,  0.023817599, -0.019843545

ALIGN 64
sLSSE:
  dd  0.019843545,  0.023817599, -0.023257840,  0.145570740,  0.541132748,\
      0.541132748,  0.145570740, -0.023257840,  0.023817599,  0.019843545

ALIGN 64
sHSSE:
  dd  0.026913419,  0.032303352, -0.241109818, -0.054100420,  0.899506092,\
     -0.899506092,  0.054100420,  0.241109818, -0.032303352, -0.026913419

;=============================================================================
; Code
;=============================================================================

SECTION .text

cglobal  transform_sse
cglobal  invertlow_sse
cglobal  inverthigh_sse

;-----------------------------------------------------------------------------
;
; void transform_sse(float* input,
; float* output,
; const uint32_t lowSize);
;
;-----------------------------------------------------------------------------

ALIGN 16
transform_sse:
  PUSHALL
  push   ebp
  mov    ecx,[esp+16+ 4] ;input
  mov    eax,[esp+16+ 8] ;output
  mov    ebp,[esp+16+12] ;lowSize
  add    ebp,3
  mov    ebx,eax
  shl    ebp,2
  lea    edx,[aLSSE]
  add    ebx,ebp        ;ebx=output[lowsize+3]
  add    eax,7*4        ;eax=output[10+i]=output[7+idx/2]
  add    ebx,4*4        ;ebx=output[4+(lowsize+3)+idx/2]=output[10+lowsize+i]
  lea    edi,[aHSSE]
  movaps xmm6,[edx+0]   ;We could use shufps but too much rewriting needed
  mov    esi,3*4        ;esi=idx/2=i+3
  movaps xmm7,[edx+16]

ALIGN 16
.loopthere
  movups xmm0,[ecx+2*esi+0]
  movaps xmm1,xmm6
  movaps xmm2,[edi+0]
  mulps  xmm1,xmm0
  mulps  xmm2,xmm0

  movups xmm3,[ecx+2*esi+16]
  movaps xmm4,xmm7
  movaps xmm5,[edi+16]
  mulps  xmm4,xmm3
  mulps  xmm5,xmm3
  addps  xmm1,xmm4
  addps  xmm2,xmm5

  movlps xmm3,[ecx+2*esi+32]
  movlps xmm4,[edx+32]
  movlps xmm5,[edi+32]
  mulps  xmm4,xmm3
  mulps  xmm5,xmm3

  movaps xmm3,xmm2
  shufps xmm3,xmm1,11101110b
  shufps xmm2,xmm1,01000100b
  shufps xmm5,xmm4,01000100b
  addps  xmm2,xmm3
  addps  xmm2,xmm5
  movaps xmm0,xmm2

  shufps xmm0,xmm2,10110001b
  addps  xmm0,xmm2

  movss  [ebx+esi],xmm0
  shufps xmm0,xmm0,10101010b
  movss  [eax+esi],xmm0

  add    esi,4
  cmp    esi,ebp
  jl     .loopthere
  pop    ebp
  POPALL
  ret


;-----------------------------------------------------------------------------
;
; void invertlow_sse(float* output,
; float* temp,
; const uint32_t findex,
;
;-----------------------------------------------------------------------------

ALIGN 16
invertlow_sse:
  PUSHALL
  mov   edi,[esp+12+ 4] ;output
  mov   esi,[esp+12+ 8] ;temp
  mov   ecx,[esp+12+12] ;findex
  lea   edx,[sLSSE]
  mov   eax,8*4   ;idx2=8 (*4)
  shl   ecx,2     ;ecx=findex (*4)
  movaps  xmm1,[edx+0]
  mov   ebx,2*4   ;idx=2 (*4)
  movaps  xmm6,[edx+16]
  add   ecx,11*4  ;edx=findex+11 (*4)
                  ;i=findex => idx2=8+(findex+2) (*4)
  movlps  xmm7,[edx+32]

ALIGN 16
.loopback
  movss  xmm0,[esi+eax]
  shufps xmm0,xmm0,00000000b

  movaps xmm2,xmm1
  movups xmm4,[edi+ebx+0]
  mulps  xmm2,xmm0
  movaps xmm3,xmm6
  movups xmm5,[edi+ebx+16]
  mulps  xmm3,xmm0
  addps  xmm2,xmm4
  addps  xmm3,xmm5
  mulps  xmm0,xmm7
  movups [edi+ebx+0],xmm2
  movups [edi+ebx+16],xmm3

  movlps xmm4,[edi+ebx+32]
  addps  xmm4,xmm0
  movlps [edi+ebx+32],xmm4

  add    eax,4   ;idx2++
  add    ebx,8   ;idx+=2
  cmp    eax,ecx   ;(idx2 < findex+11)?
  jl     .loopback

  POPALL
  ret

;-----------------------------------------------------------------------------
;
; void inverthigh_sse(float* output,
; float* temp,
; const uint32_t findex,
;
;-----------------------------------------------------------------------------

ALIGN 16
inverthigh_sse:
  PUSHALL
  mov     edi,[esp+12+ 4] ;output
  mov     esi,[esp+12+ 8] ;temp
  mov     ecx,[esp+12+12]  ;findex
  lea     edx,[sHSSE]
  mov     eax,8*4   ;idx2=8 (*4)
  shl     ecx,2     ;ecx=findex (*4)
  movaps  xmm1,[edx+0]
  mov     ebx,2*4   ;idx=2 (*4)
  movaps  xmm6,[edx+16]
  add     ecx,11*4  ;findex+11 (*4)
                    ;i=findex => idx2=8+(findex+2)
  movlps  xmm7,[edx+32]
ALIGN 16
.loophere
  movss   xmm0,[esi+eax]
  shufps  xmm0,xmm0,00000000b

  movaps  xmm2,xmm1
  movups  xmm4,[edi+ebx+0]
  mulps   xmm2,xmm0
  movaps  xmm3,xmm6
  movups  xmm5,[edi+ebx+16]
  mulps   xmm3,xmm0
  addps   xmm2,xmm4
  addps   xmm3,xmm5
  mulps   xmm0,xmm7
  movups  [edi+ebx+0],xmm2
  movups  [edi+ebx+16],xmm3

  movlps  xmm4,[edi+ebx+32]
  addps   xmm4,xmm0
  movlps  [edi+ebx+32],xmm4

  add     eax,4   ;idx2++
  add     ebx,8   ;idx+=2
  cmp     eax,ecx ;(idx2 < findex+11)?
  jl      .loophere

  POPALL
  ret