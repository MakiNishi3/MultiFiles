BITS 32

%macro cglobal 1
  global _%1
  %define %1 _%1
%endmacro
%macro cextern 1
  extern _%1
  %define %1 _%1
%endmacro

%macro PUSHMOST 0
  push  esi
  push  edi
%endmacro

%macro POPMOST 0
  pop  edi
  pop  esi
%endmacro

%macro PUSHALL 0
  push  ebx
  PUSHMOST
%endmacro

%macro POPALL 0
  POPMOST
  pop  ebx
%endmacro

%undef PREFETCHSSE
%ifdef PREFETCHSSE
  %define movaps movntps
%else
  %define movaps movaps
%endif

;=============================================================================
; Read only data
;=============================================================================

%ifdef FORMAT_COFF
SECTION .rodata data
%else
SECTION .rodata data align=16
%endif

ALIGN 64
rounder: dd  0.5, 0.5, 0.5, 0.5

;=============================================================================
; Code
;=============================================================================

SECTION .text

cglobal  b2f_sse
cglobal  b2f1D_sse
cglobal  f2b_sse
cglobal  f2b1D_sse

;-----------------------------------------------------------------------------
; Helper macro CONVONE
;-----------------------------------------------------------------------------
%macro CONVONE 4 ; %1 = offset1 , %2 = offset2 , %3 = use read prefetch , %4 =mova/u
  movd      mm0,[esi+%1+ 0]
  movd      mm2,[esi+%1+ 4]
  movd      mm4,[esi+%1+ 8]
  movd      mm6,[esi+%1+12]
  punpcklbw mm0,mm7
  punpcklbw mm2,mm7
  punpcklbw mm4,mm7
  punpcklbw mm6,mm7
  movq      mm1,mm0
  movq      mm3,mm2
  movq      mm5,mm4
  punpcklwd mm0,mm7
  punpcklwd mm2,mm7
  punpcklwd mm4,mm7
  punpckhwd mm1,mm7
  punpckhwd mm3,mm7
  punpckhwd mm5,mm7
%ifdef PREFETCHSSE
%if %3
  prefetchnta [edi+%1+64]
%endif
%endif
  
  cvtpi2ps  xmm3,mm0
  cvtpi2ps  xmm4,mm2
  cvtpi2ps  xmm7,mm4
  movq      mm0,mm6
  cvtpi2ps  xmm5,mm1
  cvtpi2ps  xmm6,mm3
  cvtpi2ps  xmm0,mm5
  punpcklwd mm6,mm7
  punpckhwd mm0,mm7
  
  shufps    xmm3,xmm5,01000100b
  cvtpi2ps  xmm1,mm6
  cvtpi2ps  xmm2,mm0
  shufps    xmm4,xmm6,01000100b
  shufps    xmm7,xmm0,01000100b
  shufps    xmm1,xmm2,01000100b
  %4        [edi+%2+ 0],xmm3
  %4        [edi+%2+16],xmm4
  %4        [edi+%2+32],xmm7
  %4        [edi+%2+48],xmm1
%endmacro
      
;-----------------------------------------------------------------------------
;
; void b2f_sse(const uint32_t  h,
; const uint32_t w,
; const uint8_t *src,
; float *blockptr);
;
;-----------------------------------------------------------------------------
ALIGN 16
b2f_sse:
  PUSHALL
  push      ebp
  mov       ecx,[esp+16+ 4]
  mov       edx,[esp+16+ 8]
  mov       esi,[esp+16+12]
  mov       ebp,[esp+16+16]
  mov       edi,[esp+16+20]
  xor       eax,eax  ;char index
  pxor      mm7,mm7
  mov       ebx,edx
  and       ebx,15
  jz        .la_start
  jmp       .lu_start

ALIGN 16
.la_start
  mov       ebx,edx
  
ALIGN 16
.la_here
%ifdef PREFETCHSSE
  prefetchnta [esi+eax+64]
%endif
  CONVONE   eax+ 0,   0, 0, movaps
  CONVONE   eax+16,  64, 1, movaps
  CONVONE   eax+32, 128, 0, movaps
  CONVONE   eax+48, 192, 1, movaps
  
  add       eax,64
  add       edi,256
  
  cmp       eax,ebx
  jl        .la_here

  cmp       eax,edx
  jnl       .la_end

ALIGN 16
.la_norm
  movq      mm0,[esi+eax]
  punpcklbw mm0,mm7
  movq      mm1,mm0
  punpcklwd mm0,mm7
  punpckhwd mm1,mm7
  
  cvtpi2ps  xmm3,mm0
  cvtpi2ps  xmm4,mm1
  
  shufps    xmm3,xmm4,01000100b
  movaps    [edi],xmm3
  
  add       eax,4
  add       edi,16
  
  cmp       eax,edx
  jl        .la_norm

ALIGN 16
.la_end
  add       esi,ebp
  xor       eax,eax
  
  dec       ecx
  jnz       .la_here
  jmp       .end

ALIGN 16
.lu_start
  mov       ebx,edx
  and       ebx,-63

ALIGN 16
.lu_here
%ifdef PREFETCHSSE
  prefetchnta  [esi+eax+64]
%endif
  CONVONE   eax+ 0,   0, 0, movups
  CONVONE   eax+16,  64, 1, movups
  CONVONE   eax+32, 128, 0, movups
  CONVONE   eax+48, 192, 1, movups
  
  add       eax,64
  add       edi,256
  
  cmp       eax,ebx
  jl        .lu_here

  cmp       eax,edx
  jl        .lu_norm
  jmp       .lu_end


ALIGN 16
.lu_norm
  movd      mm0,[esi+eax]
  punpcklbw mm0,mm7
  movq      mm1,mm0
  punpcklwd mm0,mm7
  punpckhwd mm1,mm7
    
  cvtpi2ps  xmm3,mm0
  cvtpi2ps  xmm4,mm1
    
  shufps    xmm3,xmm4,01000100b
  movups    [edi],xmm3
    
  add       eax,4
  add       edi,16
    
  cmp       eax,edx
  jl        .lu_norm

ALIGN 16
.lu_end
  ;undo the excess work
  sub       eax,edx
  shl       eax,2
  sub       edi,eax
  add       esi,ebp
  xor       eax,eax
    
  dec       ecx
  jnz       .lu_here

.end
  pop       ebp
  POPALL
  emms
  ret

;-----------------------------------------------------------------------------
;
; void b2f1D_sse(const uint32_t w,
; const uint8_t *src,
; float *blockptr);
;
;-----------------------------------------------------------------------------
ALIGN 16
b2f1D_sse:
  PUSHALL
  push      ebp
  mov       edx,[esp+16+ 4]
  mov       esi,[esp+16+ 8]
  mov       edi,[esp+16+12]
  mov       ecx,edx
  and       ecx,-63
  sub       edx,ecx
  inc       edx
  pxor      mm7,mm7

ALIGN 16
.la_here
%ifdef PREFETCHSSE
  prefetchnta [esi+eax+64]
%endif
  CONVONE    0,  0,  0, movaps
  CONVONE   16, 64,  1, movaps
  CONVONE   32, 128, 0, movaps
  CONVONE   48, 192, 1, movaps
  
  add       esi,64
  add       edi,256
  sub  ecx,64

  jnz       .la_here

  dec       edx
  jz        .la_end
  ;padd to next multiple of 2
  inc		edx
  and		edx,0xFFFFFFFE

ALIGN 16
.la_norm
  movd      mm0,[esi]
  punpcklbw mm0,mm7
  punpcklwd mm0,mm7
  
  cvtpi2ps  xmm3,mm0
  
  shufps    xmm3,xmm4,01000100b
  movlps    [edi],xmm3
  
  add       esi,2
  add       edi,8
  sub		edx,2
  
  jnz       .la_norm

ALIGN 16
.la_end
  pop       ebp
  POPALL
  emms
  ret

;-----------------------------------------------------------------------------
; Helper macro UNCONV
;-----------------------------------------------------------------------------
%macro UNCONV 1 ; %1 = movaps or movups
  %1        xmm0,[esi+ 0]
  %1        xmm1,[esi+16]
  %1        xmm2,[esi+32]
  %1        xmm3,[esi+48]
    
  addps     xmm0,xmm7
  addps     xmm1,xmm6
  addps     xmm2,xmm7
  addps     xmm3,xmm6
   
  cvttps2pi mm2,xmm0
  cvttps2pi mm3,xmm1
  cvttps2pi mm6,xmm2
  cvttps2pi mm7,xmm3
  shufps    xmm0,xmm0,01001110b
  shufps    xmm1,xmm1,01001110b
  shufps    xmm2,xmm2,01001110b
  shufps    xmm3,xmm3,01001110b
  cvttps2pi mm4,xmm0
  cvttps2pi mm5,xmm1
  cvttps2pi mm0,xmm2
  cvttps2pi mm1,xmm3
    
  packssdw  mm2,mm4
  packssdw  mm6,mm0
  packssdw  mm3,mm5
  packssdw  mm7,mm1
  packuswb  mm2,mm3
  packuswb  mm6,mm7
    
  movq      [edi+ebx+0],mm2
  movq      [edi+ebx+8],mm6
%endmacro

;-----------------------------------------------------------------------------
;
; void f2b_sse(const uint32_t  h,
; const uint32_t w,
; uint8_t *dst,
; const uint32_t dstPitch
; float *blockptr);
;
;-----------------------------------------------------------------------------
ALIGN 16
f2b_sse:
  PUSHALL
  push     ebp
  mov      ecx,[esp+16+ 4]
  mov      edx,[esp+16+ 8]
  mov      edi,[esp+16+12]
  mov      ebp,[esp+16+16]
  mov      esi,[esp+16+20]
  mov      ebx,edx
  movaps   xmm7,[rounder]
  movaps   xmm6,xmm7
  and      ebx,15
  jz	   .la_start
  jmp      .lu_start

.la_start
  mov      ebx,edx

ALIGN 16
.la_here
  UNCONV   movaps

  add      ebx,16
  add      esi,64
  cmp      ebx,edx
  jl       .la_here

  xor      ebx,ebx
  add      edi,ebp
  dec      ecx
  jnz      .la_here

  pop      ebp
  POPALL
  ret

ALIGN 16
.lu_start
  mov      eax,edx        ;float index
  and	   eax,-15
  xor	   ebx,ebx
ALIGN 16
.lu_here
  UNCONV   movups

  add      ebx,16  ;Yes, this means outbound memory access...
  add      esi,64
  cmp      ebx,eax
  jl       .lu_here

ALIGN 16
.lu_norm
  movups    xmm0,[esi]
  addps     xmm0,xmm7
  cvttps2pi mm2,xmm0
  shufps    xmm0,xmm0,01001110b
  cvttps2pi mm4,xmm0
  packssdw  mm2,mm4
  packuswb  mm2,mm3
    
  movd      [edi+ebx+0],mm2
  add		esi,16
  add		ebx,4
  cmp		ebx,edx
  jl		.lu_norm

  ;Undo conversion in excess
  sub      ebx,edx
  shl      ebx,2
  sub      esi,ebx

  xor      ebx,ebx
  add      edi,ebp
  dec      ecx
  jnz      .lu_here

  pop      ebp
  POPALL
  emms
  ret


;-----------------------------------------------------------------------------
;
; void f2b1D_sse(const uint32_t w,
; uint8_t *dst,
; float *blockptr);
;
;-----------------------------------------------------------------------------
ALIGN 16
f2b1D_sse:
  PUSHALL
  mov      edx,[esp+12+ 4]
  mov      edi,[esp+12+ 8]
  mov      esi,[esp+12+12]
  shl      edx,2
  mov      ecx,edx
  and      ecx,-63
  sub      edx,ecx
  inc      edx
  movaps   xmm7,[rounder]
  movaps   xmm6,xmm7

ALIGN 16
.loopthere_aligned
  movaps   xmm0,[esi]
  movaps   xmm1,[esi+16]
  movaps   xmm2,[esi+32]
  movaps   xmm3,[esi+48]
  cvtps2pi mm2,xmm0
  cvtps2pi mm3,xmm1
  cvtps2pi mm6,xmm2
  cvtps2pi mm7,xmm3
  shufps   xmm0,xmm0,01001110b
  shufps   xmm1,xmm1,01001110b
  shufps   xmm2,xmm2,01001110b
  shufps   xmm3,xmm3,01001110b
  cvtps2pi mm4,xmm0
  cvtps2pi mm5,xmm1
  cvtps2pi mm0,xmm2
  cvtps2pi mm1,xmm3
  packssdw mm2,mm4
  packssdw mm6,mm0
  packssdw mm3,mm5
  packssdw mm7,mm1
  packuswb mm2,mm3
  packuswb mm6,mm7
  
  movq     [edi],mm2
  movq     [edi+8],mm6
  
  add      edi,16
  add      esi,64
  sub      ecx,64
  jnz      .loopthere_aligned

  dec      edx
  jz       .loopthere_end
  ;padd to next multiple of 4
  add		edx,2
  and		edx,-3

ALIGN 16
.loopthere_norm
  movlps   xmm0,[esi]
  cvttss2si eax,xmm0
  mov      [edi],al
  
  inc      edi
  add      esi,4
  sub      edx,4
  jnz      .loopthere_norm

ALIGN 16
.loopthere_end
  POPALL
  ret
