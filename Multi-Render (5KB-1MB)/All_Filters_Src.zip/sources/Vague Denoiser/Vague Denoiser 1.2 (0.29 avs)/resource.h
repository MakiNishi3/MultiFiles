//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_VAGUEDENOISER        101
#define IDC_METHOD_1                    1001
#define IDC_METHOD1                     1005
#define IDC_METHOD0                     1006
#define IDC_THRESHOLDVAL                1007
#define IDC_THRESHOLD                   1008
#define IDC_STEPSVAL                    1009
#define IDC_STEPS                       1010
#define IDC_METHOD2                     1012
#define IDC_METHOD3                     1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
