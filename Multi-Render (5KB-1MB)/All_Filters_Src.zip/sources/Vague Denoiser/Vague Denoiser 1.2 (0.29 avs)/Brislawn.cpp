#include "brislawn.h"

/************************************************************************/
/*                                                                      */
/*                             Base class                               */
/*                                                                      */
/************************************************************************/
Brislawn::Brislawn(int x, int y, int n) : Wavelet(x ,y, n)
{
	wltnumber = BRISLAWN;
	temp_in = (float*) _mm_malloc((32+max(x,y))*sizeof(float),128);
	temp_out = (float*) _mm_malloc((32+max(x,y))*sizeof(float),128);
	temp2 = (float*) _mm_malloc((32+max(x,y))*sizeof(float),128);
}

#define OFFSET		6		//better alignment? 10+6=16 -> cacheline

void Brislawn::transform2d(float *input, int hsize, int vsize, int nsteps)
{
	int j;
	int hLowSize = hsize;
	int vLowSize = vsize;

	while (nsteps--)
	{
		int lowSize=(hLowSize+1)>>1;
		float *inputp = input;
		for (j = 0; j < vLowSize; j++) 
		{
			copy (inputp, temp_in+10+OFFSET, hLowSize);
			transform_step (temp_in+OFFSET, temp_out, hLowSize, lowSize);
			//symmetric_extension(temp_in+OFFSET, hLowSize, 2);
			//Transform(temp_in+OFFSET, temp_out, lowSize);
			copy (temp_out+10, inputp, hLowSize);
			inputp += hsize;
		}

		lowSize=(vLowSize+1)>>1;
		inputp = input;
		for (j = 0; j < hLowSize; j++)
		{
			copy (inputp, hsize, temp_in+10+OFFSET, vLowSize);
			transform_step(temp_in+OFFSET,temp_out,vLowSize,lowSize);
			//symmetric_extension(temp_in+OFFSET, vLowSize, 2);
			//Transform(temp_in+OFFSET, temp_out, lowSize);
			copy (temp_out+10,inputp,hsize,vLowSize);
			inputp++;
		}
		hLowSize = (hLowSize+1)>>1;
		vLowSize = (vLowSize+1)>>1;
	}
}

void Brislawn::transform_step (float* input, float* output,
									int size, int lowSize)
{
	symmetric_extension(input, size, 2);
	Transform(input, output, lowSize);
}

void Brislawn::invert2d(float *input, int hsize, int vsize, int nsteps)
{
	int i;

	hLowSize[0] = (hsize+1)>>1;
	hHighSize[0] = hsize>>1;
	vLowSize[0] = (vsize+1)>>1;
	vHighSize[0] = vsize>>1;
	
	for (i = 1; i < nsteps; i++)
	{
		hLowSize[i] = (hLowSize[i-1]+1)>>1;
		hHighSize[i] = hLowSize[i-1]>>1;
		vLowSize[i] = (vLowSize[i-1]+1)>>1;
		vHighSize[i] = vLowSize[i-1]>>1;
	}

	while (nsteps--)
	{
		int idx = vLowSize[nsteps]+vHighSize[nsteps];
		int idx2= hLowSize[nsteps]+hHighSize[nsteps];
		for (i=0;i<idx2;i++)
		{
			float* idx3=input+i; 
			copy (idx3,hsize,temp_in+10,idx);
			invert_step (temp_in,temp_out,idx);
			copy (temp_out+10,idx3,hsize,idx);
		}

		float* idx3=input;
		for (i=0;i<idx;i++)
		{
			copy(idx3,temp_in+10+OFFSET,idx2);
			invert_step(temp_in+OFFSET,temp_out,idx2);
			copy(temp_out+10,idx3,idx2);
			idx3 += hsize;
		}
	}
}

void Brislawn::invert_step(float* input, float* output, int size)
{
	int findex, right_ext;
	// amount of low and high pass -- if odd # of values, extra will be
	//   low pass
	int lowSize = (size+1)>>1, highSize = size>>1;
	float *temp = temp2;
	
	memcpy ((BYTE*)temp+10*sizeof(float),
			(const BYTE*)input+10*sizeof(float),
			lowSize*sizeof(float));

	right_ext = (size % 2 == 0) ? 2 : 1;
	symmetric_extension (temp, lowSize, right_ext);
	
	// coarse  detail
	// HHHHHHHHGGGGGGGG --> xxxxxxxxxxxxxxxx
	mem_set(output,0,(20+size)*sizeof(float));
	findex=(size+3)>>1;
	InvertLow(output, temp, findex);

	memcpy( (BYTE*)temp+10*sizeof(float),
					(const BYTE*)input+(10+lowSize)*sizeof(float),
					highSize*sizeof(float));

	antisymmetric_extension (temp, highSize, right_ext);
	InvertHigh(output, temp, findex);
}

// Do symmetric extension of data using prescribed symmetries
//   Original values are in output[npad] through output[npad+size-1]
//   New values will be placed in output[0] through output[npad] and in
//      output[npad+size] through output[2*npad+size-1] (note: end values may
//      not be filled in)
//    extension at left bdry is ... 3 2 1 0 | 0 1 2 3 ...
//    same for right boundary
//    if right_ext=1 then ... 3 2 1 0 | 1 2 3
//
//   symmetry = 1  -> extend symmetrically
//   symmetry = -1 -> extend antisymmetrically
void Brislawn::symmetric_extension (float *output, int size, int right_ext)
{
	int i,idx,first,last,originalLast,originalSize,period,nextend;
	first=9;last=9+size;
	
	originalLast=last;
	originalSize=originalLast-9;
	period=((last-9)<<1)-(right_ext==1);
	
	output[9] = output[10];
	if(right_ext==2)
		output[++last] = output[originalLast];
	
	// extend left end
	for (i = 0; i < 9; i++) 
		output[--first] = output[11+i];
	
	idx=19+size;
	
	// extend right end
	nextend=idx-last;
	for(i=0;i<nextend;i++) 
		output[++last]=output[originalLast-1-i];
}

void Brislawn::antisymmetric_extension (float *output, int size, int right_ext)
{
	int i,idx,first,last,originalLast,originalSize,period,nextend;
	first=9;last=9+size;
	
	if (right_ext==1) output[++last] = 0;
	
	originalLast=last;
	originalSize=originalLast-9;
	period=((last-9)<<1)-(right_ext==1);
	
	output[9] = -output[10];
	if(right_ext==2)
		output[++last] = -output[originalLast];
	
	// extend left end
	for (i = 0; i < 9; i++) 
		output[--first] = -output[11+i];
	
	idx=19+size;
	
	// extend right end
	nextend=idx-last;
	for(i=0;i<nextend;i++) 
		output[++last]=-output[originalLast-1-i];
}

__declspec(align(32)) float analysisLow[10] = {
		0.026913419f,-0.032303352f,-0.241109818f,0.054100420f,0.899506092f,
		0.899506092f,0.054100420f,-0.241109818f,-0.032303352f,0.026913419f};
__declspec(align(32)) float analysisHigh[10] = {
		0.019843545f,-0.023817599f,-0.023257840f,-0.145570740f,0.541132748f,
		-0.541132748f,0.145570740f,0.023257840f,0.023817599f,-0.019843545f};
__declspec(align(32)) float synthesisLow[10] = {
		0.019843545f,0.023817599f,-0.023257840f,0.145570740f,0.541132748f,
		0.541132748f,0.145570740f,-0.023257840f,0.023817599f,0.019843545f};
__declspec(align(32)) float synthesisHigh[10] = {
		0.026913419f,0.032303352f,-0.241109818f,-0.054100420f,0.899506092f,
		-0.899506092f,0.054100420f,0.241109818f,-0.032303352f,-0.026913419f};

void transform_c(float* input, float* output, const unsigned int lowSize)
{
	for (unsigned int i=10;i<10+lowSize;i++)
	{
		float a,b,c,d,e,f,g,h,k,l;
		a=input[2*i-14]*analysisLow[0];
		b=input[2*i-13]*analysisLow[1];
		c=input[2*i-12]*analysisLow[2];
		d=input[2*i-11]*analysisLow[3];
		e=input[2*i-10]*analysisLow[4];
		f=input[2*i-9]*analysisLow[4];
		g=input[2*i-8]*analysisLow[3];
		h=input[2*i-7]*analysisLow[2];
		k=input[2*i-6]*analysisLow[1];
		l=input[2*i-5]*analysisLow[0];
		output[i]=a+b+c+d+e+f+g+h+k+l;
	}
	for (i=10;i<10+lowSize;i++)
	{
		float a,b,c,d,e,f,g,h,k,l;
		a=input[2*i-14]*analysisHigh[0];
		b=input[2*i-13]*analysisHigh[1];
		c=input[2*i-12]*analysisHigh[2];
		d=input[2*i-11]*analysisHigh[3];
		e=input[2*i-10]*analysisHigh[4];
		f=input[2*i-9]*analysisHigh[4];
		g=input[2*i-8]*analysisHigh[3];
		h=input[2*i-7]*analysisHigh[2];
		k=input[2*i-6]*analysisHigh[1];
		l=input[2*i-5]*analysisHigh[0];
		output[i+lowSize]=a+b+c+d+e-f-g-h-k-l;
	}
};

void invertlow_c(float* output, float* temp, const unsigned int lowSize)
{
	float a,b,c,d,e;
	for(unsigned int i=8;i<lowSize+12;i++)
	{
		a=temp[i]*synthesisLow[0];
		b=temp[i]*synthesisLow[1];
		c=temp[i]*synthesisLow[2];
		d=temp[i]*synthesisLow[3];
		e=temp[i]*synthesisLow[4];
		
		output[2*i-14]+=a;
		output[2*i-13]+=b;
		output[2*i-12]+=c;
		output[2*i-11]+=d;
		output[2*i-10]+=e;
		output[2*i-9] +=e;
		output[2*i-8] +=d;
		output[2*i-7] +=c;
		output[2*i-6] +=b;
		output[2*i-5] +=a;
	}
};

void inverthigh_c(float* output, float* temp, const unsigned int lowSize)
{
	for (unsigned int i=8;i<lowSize+12;i++)
	{
		float a,b,c,d,e;
		
		a=temp[i]*synthesisHigh[0];
		b=temp[i]*synthesisHigh[1];
		c=temp[i]*synthesisHigh[2];
		d=temp[i]*synthesisHigh[3];
		e=temp[i]*synthesisHigh[4];
		
		output[2*i-14]+=a;
		output[2*i-13]+=b;
		output[2*i-12]+=c;
		output[2*i-11]+=d;
		output[2*i-10]+=e;
		output[2*i-9] -=e;
		output[2*i-8] -=d;
		output[2*i-7] -=c;
		output[2*i-6] -=b;
		output[2*i-5] -=a;
	}
};