BITS 32

%macro cglobal 1
  global _%1
  %define %1 _%1
%endmacro
%macro cextern 1
  extern _%1
  %define %1 _%1
%endmacro

;=============================================================================
; Read only data
;=============================================================================

SECTION .rdata rdata align=16

ALIGN 64
GetAbs: dd 0x7FFFFFFF, 0x7FFFFFFF
ALIGN 64
GetSign: dd 0x80000000, 0x80000000

;=============================================================================
; Code
;=============================================================================

SECTION .text

cglobal  ht_3dne
cglobal  st_3dne
cglobal  qt_3dne

;-----------------------------------------------------------------------------
; Helper macro HTONE
;-----------------------------------------------------------------------------
%macro HTONE 6
  movq    %2,[esi+eax+%1+8]
  movq    %3,mm7
  movq    %4,%2
  pandn   %5,%6
  pand    %2,mm3
  movq    [esi+eax+%1],%6
  pfcmpge %3,%2
%endmacro

%macro HTTWO 1
  HTONE   %1+0, mm1, mm5, mm4, mm6, mm2
  HTONE   %1+8, mm0, mm6, mm2, mm5, mm4
%endmacro
 
;-----------------------------------------------------------------------------
;
; Hard Thresholding
; ht_3dne(float* block, int b, float threshold);
;
;-----------------------------------------------------------------------------
ALIGN 16
ht_3dne:
  push  ebx
  push  esi
  mov   esi,[esp+8+ 4] ;block
  mov   ecx,[esp+8+ 8]
  movd  mm7,[esp+8+12]
  movq  mm3,[GetAbs]
  punpckldq mm7,mm7
  shl   ecx,2
  mov   ebx,ecx
  xor   eax,eax
  and   ebx,-255

ALIGN 16
.loophard_aligned
  prefetchw [esi+eax+64] ;Unrolled loop - should be faster...
  movq    mm6,mm7
  movq    mm0,[esi+eax]
  movq    mm2,mm0
  pand    mm0,mm3
  pfcmpge mm6,mm0
    
  HTTWO    0
  HTTWO   16
  HTTWO   32
  HTONE   48, mm1, mm5, mm4, mm6, mm2

  pfcmpge mm5,mm1
  pandn   mm5,mm4
  movq    [esi+eax+56],mm5

  add     eax,64
  cmp     eax,ebx
  jl      .loophard_aligned

  cmp     eax,ecx
  jnl     .loophard_end

ALIGN 16
.loophard_norm
  movq    mm0,[esi+eax]
  movq    mm2,mm0
  pand    mm0,mm3
  movq    mm6,mm7
  pfcmpge mm6,mm0
  pandn   mm6,mm2
  movq    [esi+eax],mm6
        
  add     eax,8
  cmp     eax,ecx
  jl      .loophard_norm

ALIGN 16
.loophard_end
  femms
  pop     esi
  pop     ebx
  ret

;-----------------------------------------------------------------------------
; Helper macro STONE
;-----------------------------------------------------------------------------
%macro STONE 1 ; %1 = offset
  movq    mm0,[esi+eax+%1]
  movq    mm2,mm0   ;mm2 = src
  movq    mm5,mm0   ;mm5 = src
  pand    mm0,mm3   ;mm0 = abs(src)
  pand    mm5,mm4   ;mm5 = sgn(src)
  movq    mm6,mm7   ;mm6 = thresh
  movq    mm1,mm7   ;mm1 = thresh
  pfcmpge mm0,mm6   ;mm0 = (abs(src)>=thresh)
  por     mm1,mm5   ;mm5 = sgn(src)*thresh
  pand    mm2,mm0   ;mm2 = (abs(src)>=thresh) ? src : 0
  pand    mm1,mm0   ;mm3 = (abs(src)>=thresh) ? sgn(src)*thresh : 0
  pfsub   mm2,mm1   ;mm3 = (abs(src)>=thresh) ? src + sgn(src)*thresh : 0
  movq    [esi+eax+%1],mm2
%endmacro

;-----------------------------------------------------------------------------
;
; Soft Thresholding
; st_3dne(float* block, int b, float threshold);
;
;-----------------------------------------------------------------------------
ALIGN 16
st_3dne:
  push  ebx
  push  esi
  mov   esi,[esp+8+ 4]
  mov   ecx,[esp+8+ 8]
  movq  mm7,[esp+8+12]
  punpckldq mm7,mm7
  shl   ecx,2
  mov   ebx,ecx
  movq  mm3,[GetAbs]
  xor   eax,eax
  movq  mm4,[GetSign]
  and   ebx,-255

ALIGN 16
.loopsoft_aligned 
  prefetchw [esi+eax+64] ;Unrolled loop - should be faster...
  STONE 0
  STONE 8
  STONE 16
  STONE 24
  STONE 32
  STONE 40
  STONE 48
  STONE 56

  add   eax,64
  cmp   eax,ecx
  jl    .loopsoft_aligned
 
  cmp   eax,ecx
  jnl   .loopsoft_end

ALIGN 16
.loopsoft_norm
  STONE 0

  add   eax,8
  cmp   eax,ecx
  jl    .loopsoft_norm

ALIGN 16
.loopsoft_end
  femms
  pop  esi
  pop  ebx
  ret

;-----------------------------------------------------------------------------
; Helper macro HTONE
;-----------------------------------------------------------------------------
%macro QTONE 1 ; %1 = offset
  movq      mm0,[esi+eax+%1]
  movq      mm5,mm0   ;mm5 = src1 | src2
  movq      mm2,mm0   ;mm2 = src | src2
  pfmul     mm5,mm5   ;mm5 = src1*src1 | src2*src2
  pand      mm0,mm3   ;mm0 = abs(src1)
  pfrcp     mm4,mm5   ;mm4 = 1/(src2*src2) 14bits precision
  pshufw    mm1,mm5,11101110b;mm1 = .... | src1*src1
  pcmpgtd   mm0,mm7   ;mm0 = (abs(src)>=thresh)
  pfrcp     mm1,mm1   ;mm1 = 1/(src1*src1) 14bits precision
  pfsub     mm5,mm6   ;mm5 = src*src - thresh*thresh
  pfmul     mm2,mm5   ;mm2 = src * (src*src - thresh*thresh)
  punpckldq mm4,mm1   ;mm1 = 1/src2*src2 | 1/src1*src1
  pfmul     mm2,mm4   ;mm2 = src * (src*src - thresh*thresh) * 1 / (src*src)
  pand      mm2,mm0   ;mm2 = (abs(src)>=thresh) ?
                      ;      src * (src*src - thresh*thresh) / (src*src) : 0
  movq  [esi+eax+%1],mm2
%endmacro

;-----------------------------------------------------------------------------
;
; Qian Thresholding
; qt_3dne(float* block, int b, float threshold);
;
;-----------------------------------------------------------------------------
ALIGN 16
qt_3dne:
  push  ebx
  push  esi
  mov   esi,[esp+8+ 4]
  mov   ecx,[esp+8+ 8]
  movq  mm7,[esp+8+12]
  punpckldq mm7,mm7
  shl   ecx,2
  mov   ebx,ecx
  movq  mm3,[GetAbs]
  xor   eax,eax
  movq  mm4,[GetSign]
  and   ebx,-255

ALIGN 16
.loopqian_aligned 
  prefetchw [esi+eax+64] ;Unrolled loop - should be faster...
  QTONE  0
  QTONE  8
  QTONE 16
  QTONE 24
  QTONE 32
  QTONE 40
  QTONE 48
  QTONE 56

  add   eax,64
  cmp   eax,ecx
  jl    .loopqian_aligned
 
  cmp   eax,ecx
  jnl   .loopqian_end

ALIGN 16
.loopqian_norm
  QTONE 0
  add   eax,8
  cmp   eax,ecx
  jl    .loopqian_norm

ALIGN 16
.loopqian_end
  femms
  pop   esi
  pop   ebx
  ret