/*  Threshold - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari   <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// Version 1.4 (13-10-2003)
// Version 1.5 (30-10-2004): aggiunto supporto per iSSE

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "resource.h"
#include "ScriptValue.h"

typedef struct
{
  IFilterPreview *ifp;
  int T1,T2;
} MyFilterData;

inline void Clipping(int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void Luma_Threshold (Pixel32 *dst,int TH,int TL,int psize)
{
  static int tmpl,tmph;
  __asm {
        mov       edi,[dst]                    //for (int p=0;p<psize;p++){
        mov       ecx,[psize]                  //  int r= (*dst>>16) & 0xff;
                                               //  int g= (*dst>> 8) & 0xff;
        mov       eax,[TH]    //  int b= (*dst    ) & 0xff;
        mov       ebx,0x80000000               //  int Y= (0x3672*r + 0xB714*g + 0x127A*b)>>15;
        shl       eax,8                        //  *dst++= (Y>=Threshold) ? 0xFFFFFF : 0;}
        sub       ebx,eax
        mov       [tmph],ebx

        mov       eax,[TL]    //  int b= (*dst    ) & 0xff;
        mov       ebx,0x80000000               //  int Y= (0x3672*r + 0xB714*g + 0x127A*b)>>15;
        shl       eax,8                        //  *dst++= (Y>=Threshold) ? 0xFFFFFF : 0;}
        sub       ebx,eax
        mov       [tmpl],ebx

        align 16
TLoop:  mov       eax,[edi]           // A.R.G.B
        xor       ebx,ebx             // 0

        mov       bl,ah               // 0.0.0.G
        and       eax,0xff00ff        // 0.R.0.B

        lea       esi,[eax+8*eax]     // [r*9][b*9]
        lea       edx,[ebx+2*ebx]     // [G*3]

        lea       eax,[eax+2*esi]     // [R*19][B*19]
        lea       ebx,[ebx+8*ebx]     // [G*9]

        lea       esi,[esi+2*esi]     // [R*27][B*27]
        shl       edx,6               // [G*192]

        shr       esi,15              // [R*54]
        sub       edx,ebx             // [G*183]

        add       edx,esi             // 183*G+19*B
        and       eax,0xffff

        mov       ebx,[tmpl]
        add       eax,edx             // 54*R+183*G+19*B

        add       ebx,eax
        add       eax,[tmph]

        sar       eax,31
        sar       ebx,31

        xor       eax,ebx
        add       edi,4

        mov       [edi-4],eax

        dec       ecx
        jne       TLoop
  }
}

void Luma_Threshold_iSSE (Pixel32 *dst,int TH,int TL,int psize)
{
  static int tmpl,tmph;
  __asm {
        mov       edi,[dst]                    //for (int p=0;p<psize;p++){
        mov       ecx,[psize]                  //  int r= (*dst>>16) & 0xff;
                                               //  int g= (*dst>> 8) & 0xff;
        mov       eax,[TH]    //  int b= (*dst    ) & 0xff;
        mov       ebx,0x80000000               //  int Y= (0x3672*r + 0xB714*g + 0x127A*b)>>15;
        shl       eax,8                        //  *dst++= (Y>=Threshold) ? 0xFFFFFF : 0;}
        sub       ebx,eax
        mov       [tmph],ebx

        mov       eax,[TL]    //  int b= (*dst    ) & 0xff;
        mov       ebx,0x80000000               //  int Y= (0x3672*r + 0xB714*g + 0x127A*b)>>15;
        shl       eax,8                        //  *dst++= (Y>=Threshold) ? 0xFFFFFF : 0;}
        sub       ebx,eax
        mov       [tmpl],ebx

        align 16
TLoop:  mov       eax,[edi]           // A.R.G.B
        xor       ebx,ebx             // 0

        mov       bl,ah               // 0.0.0.G
        and       eax,0xff00ff        // 0.R.0.B

        lea       esi,[eax+8*eax]     // [r*9][b*9]
        lea       edx,[ebx+2*ebx]     // [G*3]

        lea       eax,[eax+2*esi]     // [R*19][B*19]
        lea       ebx,[ebx+8*ebx]     // [G*9]

        lea       esi,[esi+2*esi]     // [R*27][B*27]
        shl       edx,6               // [G*192]

        shr       esi,15              // [R*54]
        sub       edx,ebx             // [G*183]

        add       edx,esi             // 183*G+19*B
        and       eax,0xffff

        mov       ebx,[tmpl]
        add       eax,edx             // 54*R+183*G+19*B

        add       ebx,eax
        add       eax,[tmph]

        sar       eax,31
        sar       ebx,31

        xor       eax,ebx
        add       edi,4

        mov       [edi-4],eax
		prefetchnta [edi+192]

        dec       ecx
        jne       TLoop
  }
}


int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int psize= fa->dst.size>>2;

  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
     Luma_Threshold_iSSE(dst,mfd->T1,mfd->T2,psize);
   else
     Luma_Threshold(dst,mfd->T1,mfd->T2,psize);

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->T1= 128;
  mfd->T2= 256;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg) {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd= (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,256));
      SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD),TBM_SETPOS,(WPARAM)TRUE,mfd->T1);
      SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD2),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,256));
      SendMessage(GetDlgItem(hdlg,IDC_THRESHOLD2),TBM_SETPOS,(WPARAM)TRUE,mfd->T2);
      SetDlgItemInt(hdlg, IDC_THRESHOLDVAL, mfd->T1, FALSE);
      SetDlgItemInt(hdlg, IDC_THRESHOLDVAL2, mfd->T2, FALSE);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;
      }
      break;
    case WM_HSCROLL:
      {
        mfd->T1= SendMessage(GetDlgItem(hdlg, IDC_THRESHOLD), TBM_GETPOS, 0, 0);
        SetDlgItemInt(hdlg, IDC_THRESHOLDVAL,mfd->T1, FALSE);
        mfd->T2= SendMessage(GetDlgItem(hdlg, IDC_THRESHOLD2), TBM_GETPOS, 0, 0);
        SetDlgItemInt(hdlg, IDC_THRESHOLDVAL2,mfd->T2, FALSE);
        mfd->ifp->RedoFrame();
        break;
      }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_THRESHOLD),
                          hwnd,ConfigDlgProc,(LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return !!ret;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf (str,64," (%d %d)",mfd->T1,mfd->T2);
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d,%d)",mfd->T1,mfd->T2);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->T1= argv[0].asInt();
  mfd->T2= argv[1].asInt();
  Clipping (mfd->T1,0,256);
  Clipping (mfd->T2,0,256);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0ii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

struct FilterDefinition filterDef_Threshold=
{
  NULL,NULL,NULL,                // next, prev, module
  "Threshold 1.4",               // name
  "Converts an image to black and white.\n"
  "Version 1.5 (30-10-2004) [ASM/iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",     // desc
  "Emiliano Ferrari",            // maker
  NULL,                          // private_data
  sizeof(MyFilterData),          // inst_data_size
  InitProc,                      // initProc
  NULL,                          // deinitProc
  RunProc,                       // runProc
  ParamProc,                     // paramProc
  ConfigProc,                    // configProc
  StringProc,                    // stringProc
  NULL,                          // startProc
  NULL,                          // endProc
  &script_obj,                   // script_obj
  FssProc,                       // fssProc
};
static FilterDefinition *fd_Threshold;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_Threshold= ff->addFilter(fm, &filterDef_Threshold, sizeof(FilterDefinition));
  if (!fd_Threshold) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_Threshold);
}
