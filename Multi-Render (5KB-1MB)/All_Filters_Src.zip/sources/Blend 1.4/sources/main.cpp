/*  filter Blender - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA  */

// Version 1.3 (26-09-2003)
// Version 1.4 (30-10-2004): rimossi alcuni possibili buffer overflow

#include <math.h>
#include <stdio.h>
#include "resource.h"
#include "filter.h"
#include <windows.h>
#include <commctrl.h>
#include "ScriptValue.h"

#pragma warning(disable:4035)
#include "memcpy_amd.cpp"

#define STORE 0
#define MSWAP 1
#define BLEND 2

#define MODE_NORMAL         0
#define MODE_MULTIPLY       1
#define MODE_SCREEN         2
#define MODE_DARKEN         3
#define MODE_LIGHTEN        4
#define MODE_DIFFERENCE     5
#define MODE_NEGATION       6
#define MODE_EXCLUSION      7
#define MODE_OVERLAY        8
#define MODE_HARDLIGHT      9
#define MODE_SOFTLIGHT     10
#define MODE_DODGE         11
#define MODE_BURN          12
#define MODE_INVDODGE      13
#define MODE_INVBURN       14
#define MODE_SOFTDODGE     15
#define MODE_SOFTBURN      16
#define MODE_REFLECT       17
#define MODE_GLOW          18
#define MODE_FREEZE        19
#define MODE_HEAT          20
#define MODE_ADDITIVE      21
#define MODE_SUBTRACTIVE   22
#define MODE_INTERPOLATION 23
#define MODE_STAMP         24
#define MODE_LAST          24

typedef struct
{
  IFilterPreview *ifp;
  int op,pow;
  int mode;
} MyFilterData;

static Pixel32 *tmp= NULL;
static int tsize=0;
static int BlendTable[256][256];

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void BuildTables (double Opacity,int mode)
{
  for (int S=0; S<256; S++)
    for (int O=0; O<256; O++)
    {
      double A= S/256.0;
      double B= O/256.0;
      double r;
      switch (mode)
      {
        case MODE_NORMAL       : r= B; break;
        case MODE_MULTIPLY     : r= A*B; break;
        case MODE_SCREEN       : r= 1.0-(1.0-A)*(1.0-B); break;
        case MODE_DARKEN       : if (A<B) r= A; else r= B; break;
        case MODE_LIGHTEN      : if (A>B) r= A; else r= B; break;
        case MODE_DIFFERENCE   : r= fabs (A-B); break;
        case MODE_NEGATION     : r= 1.0-(fabs(1.0-(A-B))); break;
        case MODE_EXCLUSION    : r= A+B - (2.0*A*B); break;
        case MODE_OVERLAY      : if (A<0.5) r= 2.0*A*B; else r= (1.0- 2.0*(1.0-A)*(1.0-B)); break;
        case MODE_HARDLIGHT    : if (B<0.5) r= 2.0*A*B; else r= (1.0- 2.0*(1.0-A)*(1.0-B)); break;
        case MODE_SOFTLIGHT    : r= (1.0-A)*A*B + A*(1.0-(1.0-A)*(1.0-B)); break;
        case MODE_DODGE        : r= A/(1.0-B); break;
        case MODE_BURN         : r= 1.0 - (1.0-A)/B; break;
        case MODE_INVDODGE     : r= B/(1.0-A); break;
        case MODE_INVBURN      : r= 1.0 - (1.0-B)/A; break;
        case MODE_SOFTDODGE    : if ((A+B)<1.0) r= 0.5*A/(1.0-B); else r= 1.0- 0.5*(1.0-B)/A; break;
        case MODE_SOFTBURN     : if ((A*B)<1.0) r= 0.5*B/(1.0-A); else r= 1.0- 0.5*(1.0-A)/B; break;
        case MODE_REFLECT      : r= A*A/(1.0-B); break;
        case MODE_GLOW         : r= B*B/(1.0-A); break;
        case MODE_FREEZE       : r= 1.0-((1.0-A)*(1.0-A))/B; break;
        case MODE_HEAT         : r= 1.0-((1.0-B)*(1.0-B))/A; break;
        case MODE_ADDITIVE     : r= A+B; break;
        case MODE_SUBTRACTIVE  : r= A-B; break;
        case MODE_INTERPOLATION: r= 0.5 -0.25*cos(3.14*A) -0.25*cos(4.14*B);
        case MODE_STAMP        : r= A+2.0*B -1.0;
      }
      int D= (int)(256.0*( r*Opacity + A* (1.0-Opacity) ));
      Clipping (D,0,255);
      BlendTable[S][O]= D;
    }
}

void BlendPicture (Pixel32 *Base,Pixel32 *Overlay,int pSize)
{
   for (int p=0; p<pSize; p++)
   {
     int Rb= (Base[p]>>16)&0xff;
     int Gb= (Base[p]>> 8)&0xff;
     int Bb= (Base[p]    )&0xff;
     int Ro= (Overlay[p]>>16)&0xff;
     int Go= (Overlay[p]>> 8)&0xff;
     int Bo= (Overlay[p]    )&0xff;
     Base[p]= (BlendTable[Rb][Ro]<<16) | (BlendTable[Gb][Go]<<8) | BlendTable[Bb][Bo];
   }
}

void memswp (void *dst,const void *src,size_t tsize)
{
  __asm {
            mov edi,[dst]
            mov esi,[src]
            mov ecx,[tsize]
            shr ecx,2
            jz  skip_loop
            lea  edi,[edi+ecx*4]
            lea  esi,[esi+ecx*4]
            neg  ecx
dw_loop:    mov  eax,[edi+ecx*4]
            xchg eax,[esi+ecx*4]
            mov  [edi+ecx*4],eax
            inc  ecx
            jnz  dw_loop
skip_loop:
   }
}

void Blend_MMX (Pixel32 *dst,Pixel32 *Overlay,__int64 AlphaOverlay,int psize)
{
  __asm {
            mov         edi,[dst]
            mov         esi,[Overlay]
            movq        mm6,[AlphaOverlay]
            punpcklwd   mm6,mm6
            punpcklwd   mm6,mm6
            psllw       mm6,4
            pxor        mm7,mm7
            mov         ecx,[psize]
            mov         edx,ecx
            shr         ecx,1
            or          ecx,ecx
            jz          SkipLoop
            lea         edi,[edi+ecx*8]
            lea         esi,[esi+ecx*8]
            neg         ecx

            align       16
BLoop:      movq        mm0,[edi+ecx*8]
            movq        mm4,mm0
            movq        mm1,[esi+ecx*8]
            movq        mm5,mm1
            punpcklbw   mm0,mm7
            punpckhbw   mm4,mm7
            punpcklbw   mm1,mm7
            punpckhbw   mm5,mm7

            psubw       mm1,mm0
            psubw       mm5,mm4
            psllw       mm1,4
            psllw       mm5,4
            pmulhw      mm1,mm6
            pmulhw      mm5,mm6
            paddw       mm0,mm1
            paddw       mm4,mm5
            packuswb    mm0,mm4
            movq        [edi+ecx*8],mm0
            inc         ecx
            jnz         BLoop

SkipLoop:   and         edx,1
            jz          quit
            movd        mm0,[edi+ecx*8]
            movd        mm1,[esi+ecx*8]
            punpcklbw   mm0,mm7
            punpcklbw   mm1,mm7
            psubw       mm1,mm0
            psllw       mm1,4
            pmulhw      mm1,mm6
            paddw       mm0,mm1
            packuswb    mm0,mm0
            movd        [edi+ecx*8],mm0
quit:       emms
    }
}

void Blend_iSSE (Pixel32 *dst,Pixel32 *Overlay,__int64 AlphaOverlay,int psize)
{
  __asm {
            mov         edi,[dst]
            mov         esi,[Overlay]
            pshufw      mm6,[AlphaOverlay],0
            psllw       mm6,4
            pxor        mm7,mm7
            mov         ecx,[psize]
            mov         edx,ecx
            shr         ecx,1
            or          ecx,ecx
            jz          SkipLoop
            lea         edi,[edi+ecx*8]
            lea         esi,[esi+ecx*8]
            neg         ecx

            align       16
BLoop:      movq        mm0,[edi+ecx*8]
            movq        mm1,[esi+ecx*8]
            movq        mm4,mm0
            movq        mm5,mm1
            punpcklbw   mm0,mm7
            punpckhbw   mm4,mm7
            punpcklbw   mm1,mm7
            punpckhbw   mm5,mm7
            prefetchnta [edi+ecx*8+192]
            prefetchnta [esi+ecx*8+192]
            psubw       mm1,mm0
            psubw       mm5,mm4
            psllw       mm1,4
            psllw       mm5,4
            pmulhw      mm1,mm6
            pmulhw      mm5,mm6
            paddw       mm0,mm1
            paddw       mm4,mm5
            packuswb    mm0,mm4
            movq        [edi+ecx*8],mm0
            inc         ecx
            jnz         BLoop

SkipLoop:   and         edx,1
            jz          quit
            movd        mm0,[edi+ecx*8]
            movd        mm1,[esi+ecx*8]
            punpcklbw   mm0,mm7
            punpcklbw   mm1,mm7
            psubw       mm1,mm0
            psllw       mm1,4
            pmulhw      mm1,mm6
            paddw       mm0,mm1
            packuswb    mm0,mm0
            movd        [edi+ecx*8],mm0
quit:       emms
    }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int pow= mfd->pow;
  const int psize= fa->dst.size>>2;
  const int Size= fa->dst.size;

  if ((psize==0) | (tsize!=psize)) return 0;

  switch (mfd->op)
  {
    case STORE:
       if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
          memcpy_amd (tmp,dst,Size);
        else
          memcpy (tmp,dst,Size);
       break;

    case MSWAP: memswp (tmp,dst,Size); break;

    case BLEND:
    if (mfd->mode==MODE_NORMAL)
    {
      if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
        Blend_iSSE (dst,tmp,pow,psize);
      else
      if (ff->isMMXEnabled())
        Blend_MMX (dst,tmp,pow,psize);
      else
        for (int p=0; p<psize; p++)
          {
             int r,g,b,rr,gg,bb;
             r=  (dst[p]>>16)&255;
             g=  (dst[p]>> 8)&255;
             b=  (dst[p]    )&255;
             rr= (tmp[p]>>16)&255;
             gg= (tmp[p]>> 8)&255;
             bb= (tmp[p]    )&255;
             r+= ((rr-r)*pow)>>8;
             g+= ((gg-g)*pow)>>8;
             b+= ((bb-b)*pow)>>8;
             dst[p]= (r<<16) | (g<<8) | b;
          }
      }
      else
        BlendPicture (dst,tmp,psize);
      break;
    }
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->pow= 128;
  mfd->op = STORE;
  mfd->mode= MODE_NORMAL;
  BuildTables (mfd->pow/256.0,mfd->mode);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  if (!tmp) { tsize= fa->src.size>>2; tmp= new Pixel32[tsize]; }
  if (!tmp) ff->ExceptOutOfMemory();
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  if (tmp) { delete[] tmp; tmp= NULL; tsize= 0; }
  return 0;
}

void EnableItems (HWND hdlg,MyFilterData *mfd)
{
  EnableWindow (GetDlgItem (hdlg,IDC_TRESHOLD)   ,mfd->op==BLEND);
  EnableWindow (GetDlgItem (hdlg,IDC_TRESHOLDVAL),mfd->op==BLEND);
  EnableWindow (GetDlgItem (hdlg,IDC_TEXT1)      ,mfd->op==BLEND);
  EnableWindow (GetDlgItem (hdlg,IDC_TEXT2)      ,mfd->op==BLEND);
  EnableWindow (GetDlgItem (hdlg,IDC_MODE)       ,mfd->op==BLEND);
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char tmp[128];

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg, IDC_TRESHOLD),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,256));
      SendMessage(GetDlgItem(hdlg, IDC_TRESHOLD),TBM_SETPOS,(WPARAM)TRUE,mfd->pow);

      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,0,(LPARAM)"NORMAL (fast)");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"MULTIPLY");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"SCREEN");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"DARKEN");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"LIGHTEN");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"DIFFERENCE");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"NEGATION");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"EXCLUSION");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"OVERLAY");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"HARDLIGHT");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"SOFTLGHT");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"DODGE");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"BURN");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"INVDODGE");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"INVBURN");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"SOFTDODGE");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"SOFTBURN");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"REFLECTION");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"GLOW");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"FREEZE");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"HEAT");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"ADDITIVE");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"SUBTRACTIVE");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"INTERPOLATION");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING,-1,(LPARAM)"STAMP");
      SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_SETCURSEL,(WPARAM)mfd->mode,0);

      _snprintf(tmp,128,"%d%%", (mfd->pow*100)/256);
      SetDlgItemText(hdlg, IDC_TRESHOLDVAL,tmp);
      CheckDlgButton(hdlg,IDC_STORE,(mfd->op==STORE)?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_MSWAP,(mfd->op==MSWAP)?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_BLEND,(mfd->op==BLEND)?BST_CHECKED:BST_UNCHECKED);
      EnableItems (hdlg,mfd);
      BuildTables (mfd->pow/256.0,mfd->mode);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;
        case IDC_STORE: mfd->op= STORE; EnableItems (hdlg,mfd); BuildTables (mfd->pow/256.0,mfd->mode); mfd->ifp->RedoFrame(); break;
        case IDC_MSWAP: mfd->op= MSWAP; EnableItems (hdlg,mfd); BuildTables (mfd->pow/256.0,mfd->mode); mfd->ifp->RedoFrame(); break;
        case IDC_BLEND: mfd->op= BLEND; EnableItems (hdlg,mfd); BuildTables (mfd->pow/256.0,mfd->mode); mfd->ifp->RedoFrame(); break;
        case IDC_MODE : mfd->mode = SendMessage (GetDlgItem(hdlg,IDC_MODE),CB_GETCURSEL,0,0); BuildTables (mfd->pow/256.0,mfd->mode); mfd->ifp->RedoFrame(); break;

      }
      break;

    case WM_HSCROLL:
      mfd->pow= SendMessage(GetDlgItem(hdlg, IDC_TRESHOLD), TBM_GETPOS, 0, 0);
      _snprintf(tmp,128,"%d%%", (mfd->pow*100)/256);
      SetDlgItemText(hdlg, IDC_TRESHOLDVAL,tmp);
      BuildTables (mfd->pow/256.0,mfd->mode);
      mfd->ifp->RedoFrame();
      break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int Resoult= DialogBoxParam ( fa->filter->module->hInstModule,
                                MAKEINTRESOURCE(IDD_FILTER_BLEND),
                                hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (Resoult) *mfd= mfd_old;
  return !!Resoult;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  const static char *modename[]= {"NORMAL","MULTIPLY","SCREEN","DARKEN","LIGHTEN","DIFFERENCE","NEGATION",
  "EXCLUSION","OVERLAY","HARDLIGHT","SOFTLIGHT","DODGE","BURN","INVDODGE","INVBURN","SOFTDODGE",
  "SOFTBURN","REFLECT","GLOW","FREEZE","HEAT","ADDITIVE","SUBTRACTIVE","INTERPOLATION","STAMP"};

  if (mfd->op==STORE) _snprintf(str,64, " [STORE]");
    else
      if (mfd->op==MSWAP) _snprintf(str,64, " [SWAP]");
    else
    {
      _snprintf(str,64, " (%s %d%%)", modename[mfd->mode],(mfd->pow*100)/256);
    }
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d, %d)",mfd->pow,mfd->op,mfd->mode);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->pow = argv[0].asInt();
  mfd->op  = argv[1].asInt();
  mfd->mode= argv[2].asInt();
  Clipping (mfd->pow,0,256);
  Clipping (mfd->op ,0,  2);
  Clipping (mfd->mode,0,MODE_LAST);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

FilterDefinition filterDef_Blend=
{
  NULL, NULL, NULL,            // next, prev, module
  "Blend",                     // name
  "Allows creation of two filter paths and blending the results.\n"
  "Version 1.4 (30-10-2004)[MMX/ISSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  StartProc,                   // startProc
  EndProc,                     // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd_Blend;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_Blend = ff->addFilter(fm, &filterDef_Blend, sizeof(FilterDefinition));
  if (!fd_Blend) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_Blend);
}
