//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_BLEND                101
#define IDC_STORE                       1002
#define IDC_MSWAP                       1003
#define IDC_BLEND                       1004
#define IDC_MODE                        1005
#define IDC_TEXT1                       1006
#define IDC_TEXT2                       1007
#define IDC_TRESHOLD                    1008
#define IDC_TRESHOLDVAL                 1009

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
