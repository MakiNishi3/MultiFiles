/*  fill borders - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// Version 1.2 (27-09-2003)
// Version 1.3 (30-10-2004)

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "ScriptValue.h"
#include "resource.h"

typedef struct
{
  int top,left,bottom,right;
  int red,green,blue;
  bool invert;
  COLORREF color_ref;
  HBRUSH   color_brush;
  IFilterPreview *ifp;
} MyFilterData;

void memfill (Pixel32 *dst,Pixel32 color,int size)
{
  for (int i=0; i<size; i++) *dst++= color;
}

void mem_invert (Pixel32 *dst,int size)
{
  for (int i=0; i<size; i++) *dst++ ^= 0xffffff;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int w     = fa->dst.w;
  const int h     = fa->dst.h;
  const int pitch = fa->dst.pitch>>2;
  const int top   = mfd->top;
  const int bottom= mfd->bottom;
  const int left  = mfd->left;
  const int right = mfd->right;

  const int s1= bottom*pitch+left;
  const int s2= left+right;
  const int lp= w-(left+right);
  const int hp= h-(top+bottom);
  const int s3= top*pitch+right;

  Pixel32 color= (mfd->red<<16) | (mfd->green<<8) | mfd->blue;

  if (mfd->top==0 && mfd->bottom==0 && mfd->left==0 && mfd->right==0)
    return 0;

  if (mfd->invert) // ------------------------------------------------------
  {
    if ((mfd->top+mfd->bottom)>=h || (mfd->left+mfd->right)>=w)
    {
      mem_invert (dst,h*pitch);
      return 0;
    }
    if (s1!=0) mem_invert (dst,s1);
    dst+= s1;
    if (s2==0)
      dst+= pitch*hp;
    else
    {
      dst+= lp;
      for (int y=1; y<hp; y++)
      {
         mem_invert (dst,s2);
         dst+= pitch;
      }
    }
    if (s3!=0) mem_invert (dst,s3);
  }
  else // ------------------------------------------------------
  {
    if ((mfd->top+mfd->bottom)>=h || (mfd->left+mfd->right)>=w)
    {
      memfill (dst,color,h*pitch);
      return 0;
    }
    if (s1!=0) memfill (dst,color,s1);
    dst+= s1;
    if (s2==0)
      dst+= pitch*hp;
    else
    {
      dst+= lp;
      for (int y=1; y<hp; y++)
      {
         memfill (dst,color,s2);
         dst+= pitch;
      }
    }
    if (s3!=0) memfill (dst,color,s3);
  }

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->top   = 0;
  mfd->left  = 0;
  mfd->bottom= 0;
  mfd->right = 0;
  mfd->invert= false;
  mfd->color_ref= RGB (0,0,0);
  mfd->red= mfd->green= mfd->blue= 0;
  mfd->color_brush= CreateSolidBrush (mfd->color_ref);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

void MyChooseColor(COLORREF &Color,HWND hdlg)
{
  CHOOSECOLOR cc;
  static COLORREF Custom[16];

  cc.lStructSize= sizeof(CHOOSECOLOR);
  cc.hwndOwner= hdlg;
  cc.rgbResult= Color;
  cc.lpCustColors= Custom;
  cc.Flags= CC_RGBINIT | CC_FULLOPEN;
  cc.lCustData= 0L;
  cc.lpfnHook= NULL;
  cc.lpTemplateName= NULL;
  ChooseColor(&cc);
  Color= cc.rgbResult;
}

void BuildBrush(MyFilterData *mfd,HWND hdlg)
{
  DeleteObject (mfd->color_brush);
  mfd->color_brush= CreateSolidBrush (mfd->color_ref);
  RedrawWindow (GetDlgItem(hdlg,IDC_COLORBOX),NULL,NULL,RDW_ERASE|RDW_INVALIDATE|RDW_UPDATENOW);
}

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {

    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;

      SendMessage(GetDlgItem(hdlg, IDC_TSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(0,8192));
      SendMessage(GetDlgItem(hdlg, IDC_LSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(8192,0));
      SendMessage(GetDlgItem(hdlg, IDC_BSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(8192,0));
      SendMessage(GetDlgItem(hdlg, IDC_RSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(0,8192));

      SetDlgItemInt (hdlg,IDC_LEFT  ,mfd->left  ,false);
      SetDlgItemInt (hdlg,IDC_TOP   ,mfd->top   ,false);
      SetDlgItemInt (hdlg,IDC_BOTTOM,mfd->bottom,false);
      SetDlgItemInt (hdlg,IDC_RIGHT ,mfd->right ,false);

      CheckDlgButton(hdlg, IDC_INVERT,mfd->invert ? BST_CHECKED : BST_UNCHECKED);
      EnableWindow (GetDlgItem (hdlg,IDC_COLORBOX),!mfd->invert);
      EnableWindow (GetDlgItem (hdlg,IDC_PICCOLOR),!mfd->invert);

      BuildBrush (mfd,hdlg);

      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;

        case IDC_INVERT:
            mfd->invert= !!IsDlgButtonChecked(hdlg, IDC_INVERT);
            EnableWindow (GetDlgItem (hdlg,IDC_COLORBOX),!mfd->invert);
            EnableWindow (GetDlgItem (hdlg,IDC_PICCOLOR),!mfd->invert);
            mfd->ifp->RedoFrame();
            break;

        case IDC_TOP:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int top= GetDlgItemInt(hdlg,IDC_TOP,NULL,false);
            if (top!=mfd->top)
            {
              mfd->top= top;
              mfd->ifp->RedoFrame();
            }
          }
          break;

        case IDC_LEFT:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int left= GetDlgItemInt(hdlg,IDC_LEFT,NULL,false);
            if (left!=mfd->left)
            {
              mfd->left= left;
              mfd->ifp->RedoFrame();
            }
          }
          break;

        case IDC_BOTTOM:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int bottom=    GetDlgItemInt(hdlg,IDC_BOTTOM,NULL,false);
            if (bottom!=mfd->bottom)
            {
              mfd->bottom= bottom;
              mfd->ifp->RedoFrame();
            }
          }
          break;

        case IDC_RIGHT:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int right= GetDlgItemInt(hdlg,IDC_RIGHT ,NULL,false);
            if (right!=mfd->right)
            {
              mfd->right= right;
              mfd->ifp->RedoFrame();
            }
          }
          break;

        case IDC_COLORBOX:
            if (HIWORD(wParam)!=STN_DBLCLK) return TRUE;
        case IDC_PICCOLOR:
            MyChooseColor(mfd->color_ref,hdlg);
            BuildBrush (mfd,hdlg);
            mfd->red  = GetRValue(mfd->color_ref);
            mfd->green= GetGValue(mfd->color_ref);
            mfd->blue = GetBValue(mfd->color_ref);
            mfd->ifp->RedoFrame();
            return TRUE;
      }
      break;

    case WM_VSCROLL:
    case WM_HSCROLL:
        {
          int top   = GetDlgItemInt(hdlg,IDC_TOP   ,NULL,false);
          int left  = GetDlgItemInt(hdlg,IDC_LEFT  ,NULL,false);
          int bottom= GetDlgItemInt(hdlg,IDC_BOTTOM,NULL,false);
          int right = GetDlgItemInt(hdlg,IDC_RIGHT ,NULL,false);
          if (top!=mfd->top || left!=mfd->left || bottom!=mfd->bottom || right!=mfd->right)
          {
            mfd->top= top;
            mfd->left= left;
            mfd->bottom= bottom;
            mfd->right= right;
            mfd->ifp->RedoFrame();
          }
        }
        break;

    case WM_CTLCOLORSTATIC:
          if (GetWindowLong((HWND)lParam,GWL_ID)== IDC_COLORBOX) return (BOOL)mfd->color_brush;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;

  int res=DialogBoxParam(fa->filter->module->hInstModule,
                        MAKEINTRESOURCE(IDD_FILTER_FILL),
                        hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (res) *mfd= mfd_old;
  return res;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d, %d, %d, %d)",
      mfd->top,mfd->left,mfd->bottom,mfd->right,mfd->invert?-1:(mfd->red<<16)|(mfd->green<<8)|mfd->blue);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->top   = argv[0].asInt();
  mfd->left  = argv[1].asInt();
  mfd->bottom= argv[2].asInt();
  mfd->right = argv[3].asInt();
  mfd->invert= (argv[4].asInt()<0);
  if (mfd->invert)
    mfd->red=mfd->green=mfd->blue=0;
  else
  {
    mfd->red   = (argv[4].asInt()>>16)&0xff;
    mfd->green= (argv[4].asInt()>> 8)&0xff;
    mfd->blue = (argv[4].asInt()    )&0xff;
  }
  mfd->color_ref= RGB(mfd->red,mfd->blue,mfd->green);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->invert)
      _snprintf(str,64," (%d,%d,%d,%d,invert)", mfd->top,mfd->left,mfd->bottom,mfd->right);
  else
      _snprintf(str,64," (%d,%d,%d,%d,#%06X)", mfd->top,mfd->left,mfd->bottom,mfd->right,(mfd->red<<16)|(mfd->green<<8)|mfd->blue);
}

FilterDefinition filterDef_fill=
{
  NULL, NULL, NULL,            // next, prev, module
  "Fill Borders",              // name
  "fills the borders of the image with a color\n"
  "Version 1.3 (30-10-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  NULL,                        // startProc
  NULL,                        // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd_fill;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_fill = ff->addFilter(fm, &filterDef_fill, sizeof(FilterDefinition));
  if (!fd_fill) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_fill);
}
