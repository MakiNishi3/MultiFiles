/*  Channel Mixer - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

//  v. 1.2  Emiliano Ferrari [18-09-2003]: ???
//  v. 1.3  Emiliano Ferrari [13-11-2003]: rimosso errore di battitura che rendeva impossibile l'uso degli script.
//  v. 1.4  Emiliano Ferrari [31-10-2004]: rimosso un possibile buffer overflow

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "resource.h"
#include "filter.h"
#include "ScriptValue.h"

#define TARGET_RED   0
#define TARGET_GREEN 1
#define TARGET_BLUE  2
#define NUM_CHANNELS 3

typedef struct
{
  IFilterPreview *ifp;
  int  rlut[NUM_CHANNELS];
  int  glut[NUM_CHANNELS];
  int  blut[NUM_CHANNELS];
  int  clut[NUM_CHANNELS];
  int  CurrentChannel;
  bool mono;
} MyFilterData;

inline void Clipping (int &dato,int min,int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void Run_Mono (Pixel32 *dst,const int psize,MyFilterData *mfd)
{
  const int r2M= mfd->rlut[mfd->CurrentChannel];
  const int g2M= mfd->glut[mfd->CurrentChannel];
  const int b2M= mfd->blut[mfd->CurrentChannel];
  const int KM=  mfd->clut[mfd->CurrentChannel]*255;

  for (int p=0; p<psize; p++)
  {
    int Alpha= (*dst) & 0xff000000;
    int Red=   (*dst>>16) & 0xff;
    int Green= (*dst>> 8) & 0xff;
    int Blue=  (*dst    ) & 0xff;
    int Mono= (Red*r2M + Green*g2M + Blue*b2M + KM)>>10;
    Clipping (Mono,0,255);
    *dst++= Alpha | (Mono<<16) | (Mono<<8) | Mono;
  }
}

void Run_Color (Pixel32 *dst,const int psize,MyFilterData *mfd)
{
  const int r2R= mfd->rlut[TARGET_RED  ];
  const int g2R= mfd->glut[TARGET_RED  ];
  const int b2R= mfd->blut[TARGET_RED  ];
  const int KR=  mfd->clut[TARGET_RED  ]*255;
  const int r2G= mfd->rlut[TARGET_GREEN];
  const int g2G= mfd->glut[TARGET_GREEN];
  const int b2G= mfd->blut[TARGET_GREEN];
  const int KG=  mfd->clut[TARGET_GREEN]*255;
  const int r2B= mfd->rlut[TARGET_BLUE ];
  const int g2B= mfd->glut[TARGET_BLUE ];
  const int b2B= mfd->blut[TARGET_BLUE ];
  const int KB=  mfd->clut[TARGET_BLUE ]*255;

  for (int p=0; p<psize; p++)
  {
    int Alpha= (*dst) & 0xff000000;
    int Red=   (*dst>>16) & 0xff;
    int Green= (*dst>> 8) & 0xff;
    int Blue=  (*dst    ) & 0xff;

    int NewRed=   (Red*r2R + Green*g2R + Blue*b2R + KR)>>10;
    int NewGreen= (Red*r2G + Green*g2G + Blue*b2G + KG)>>10;
    int NewBlue=  (Red*r2B + Green*g2B + Blue*b2B + KB)>>10;

    Clipping (NewRed  ,0,255);
    Clipping (NewGreen,0,255);
    Clipping (NewBlue ,0,255);

    *dst++= Alpha | (NewRed<<16) | (NewGreen<<8) | NewBlue;
  }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int psize= fa->dst.size>>2;

  if (mfd->mono)
    Run_Mono (dst,psize,mfd);
   else
    Run_Color (dst,psize,mfd);

  return 0;
}

void DefaultParam (MyFilterData *mfd)
{
  mfd->rlut[TARGET_RED  ]= 1024;
  mfd->glut[TARGET_RED  ]=    0;
  mfd->blut[TARGET_RED  ]=    0;
  mfd->clut[TARGET_RED  ]=    0;
  mfd->rlut[TARGET_GREEN]=    0;
  mfd->glut[TARGET_GREEN]= 1024;
  mfd->blut[TARGET_GREEN]=    0;
  mfd->clut[TARGET_GREEN]=    0;
  mfd->rlut[TARGET_BLUE ]=    0;
  mfd->glut[TARGET_BLUE ]=    0;
  mfd->blut[TARGET_BLUE ]= 1024;
  mfd->clut[TARGET_BLUE ]=    0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->CurrentChannel= TARGET_RED;
  mfd->mono= false;
  DefaultParam (mfd);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

char *Scale (double input,double irange,double orange)
{
  static char s[128];
  _snprintf(s,128,"%1.2f%%",input*irange/orange);
  return s;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd= (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg,IDC_RED  ),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(-2048,2048));
      SendMessage(GetDlgItem(hdlg,IDC_GREEN),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(-2048,2048));
      SendMessage(GetDlgItem(hdlg,IDC_BLUE ),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(-2048,2048));
      SendMessage(GetDlgItem(hdlg,IDC_CONST),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(-1024,1024));
      SendMessage(GetDlgItem(hdlg, IDC_RED  ),TBM_SETPOS, (WPARAM)TRUE, mfd->rlut[mfd->CurrentChannel]);
      SendMessage(GetDlgItem(hdlg, IDC_GREEN),TBM_SETPOS, (WPARAM)TRUE, mfd->glut[mfd->CurrentChannel]);
      SendMessage(GetDlgItem(hdlg, IDC_BLUE ),TBM_SETPOS, (WPARAM)TRUE, mfd->blut[mfd->CurrentChannel]);
      SendMessage(GetDlgItem(hdlg, IDC_CONST),TBM_SETPOS, (WPARAM)TRUE, mfd->clut[mfd->CurrentChannel]);
      SetDlgItemText(hdlg,IDC_VRED  ,Scale(mfd->rlut[mfd->CurrentChannel],100,1024));
      SetDlgItemText(hdlg,IDC_VGREEN,Scale(mfd->glut[mfd->CurrentChannel],100,1024));
      SetDlgItemText(hdlg,IDC_VBLUE ,Scale(mfd->blut[mfd->CurrentChannel],100,1024));
      SetDlgItemText(hdlg,IDC_VCONST,Scale(mfd->clut[mfd->CurrentChannel],100,1024));
      SendMessage(GetDlgItem(hdlg,IDC_TARGET),CB_INSERTSTRING,0,(LPARAM)"RED");
      SendMessage(GetDlgItem(hdlg,IDC_TARGET),CB_INSERTSTRING,1,(LPARAM)"GREEN");
      SendMessage(GetDlgItem(hdlg,IDC_TARGET),CB_INSERTSTRING,2,(LPARAM)"BLUE");
      SendMessage(GetDlgItem(hdlg,IDC_TARGET),CB_SETCURSEL,(WPARAM)mfd->CurrentChannel,0);
      CheckDlgButton(hdlg,IDC_MONO,mfd->mono?BST_CHECKED:BST_UNCHECKED);
      EnableWindow (GetDlgItem (hdlg,IDC_TARGET),!mfd->mono);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;
        case IDC_RESET:
          mfd->mono= false;
          CheckDlgButton(hdlg,IDC_MONO,mfd->mono?BST_CHECKED:BST_UNCHECKED);
          EnableWindow (GetDlgItem (hdlg,IDC_TARGET),!mfd->mono);
          DefaultParam (mfd);
          SendMessage(GetDlgItem(hdlg, IDC_RED  ),TBM_SETPOS, (WPARAM)TRUE, mfd->rlut[mfd->CurrentChannel]);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN),TBM_SETPOS, (WPARAM)TRUE, mfd->glut[mfd->CurrentChannel]);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE ),TBM_SETPOS, (WPARAM)TRUE, mfd->blut[mfd->CurrentChannel]);
          SendMessage(GetDlgItem(hdlg, IDC_CONST),TBM_SETPOS, (WPARAM)TRUE, mfd->clut[mfd->CurrentChannel]);
          SetDlgItemText(hdlg,IDC_VRED  ,Scale(mfd->rlut[mfd->CurrentChannel],100,1024));
          SetDlgItemText(hdlg,IDC_VGREEN,Scale(mfd->glut[mfd->CurrentChannel],100,1024));
          SetDlgItemText(hdlg,IDC_VBLUE ,Scale(mfd->blut[mfd->CurrentChannel],100,1024));
          SetDlgItemText(hdlg,IDC_VCONST,Scale(mfd->clut[mfd->CurrentChannel],100,1024));
          mfd->ifp->RedoFrame();
          break;
        case IDC_TARGET:
          mfd->CurrentChannel= SendMessage (GetDlgItem(hdlg,IDC_TARGET),CB_GETCURSEL,0,0);
          SendMessage(GetDlgItem(hdlg, IDC_RED  ),TBM_SETPOS, (WPARAM)TRUE, mfd->rlut[mfd->CurrentChannel]);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN),TBM_SETPOS, (WPARAM)TRUE, mfd->glut[mfd->CurrentChannel]);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE ),TBM_SETPOS, (WPARAM)TRUE, mfd->blut[mfd->CurrentChannel]);
          SendMessage(GetDlgItem(hdlg, IDC_CONST),TBM_SETPOS, (WPARAM)TRUE, mfd->clut[mfd->CurrentChannel]);
          SetDlgItemText(hdlg,IDC_VRED  ,Scale(mfd->rlut[mfd->CurrentChannel],100,1024));
          SetDlgItemText(hdlg,IDC_VGREEN,Scale(mfd->glut[mfd->CurrentChannel],100,1024));
          SetDlgItemText(hdlg,IDC_VBLUE ,Scale(mfd->blut[mfd->CurrentChannel],100,1024));
          SetDlgItemText(hdlg,IDC_VCONST,Scale(mfd->clut[mfd->CurrentChannel],100,1024));
          break;
        case IDC_MONO:
          mfd->mono= !!IsDlgButtonChecked(hdlg,IDC_MONO);
          EnableWindow (GetDlgItem (hdlg,IDC_TARGET),!mfd->mono);
          if (!mfd->mono)
          {
             for (int ch=0; ch<NUM_CHANNELS; ch++)
            {
              mfd->rlut[ch]= mfd->rlut[mfd->CurrentChannel];
              mfd->glut[ch]= mfd->glut[mfd->CurrentChannel];
              mfd->blut[ch]= mfd->blut[mfd->CurrentChannel];
              mfd->clut[ch]= mfd->clut[mfd->CurrentChannel];
            }
          }
          mfd->ifp->RedoFrame();
          break;

      }
      break;

    case WM_HSCROLL:
      {
        mfd->rlut[mfd->CurrentChannel]= SendMessage(GetDlgItem(hdlg,IDC_RED  ),TBM_GETPOS,0,0);
        mfd->glut[mfd->CurrentChannel]= SendMessage(GetDlgItem(hdlg,IDC_GREEN),TBM_GETPOS,0,0);
        mfd->blut[mfd->CurrentChannel]= SendMessage(GetDlgItem(hdlg,IDC_BLUE ),TBM_GETPOS,0,0);
        mfd->clut[mfd->CurrentChannel]= SendMessage(GetDlgItem(hdlg,IDC_CONST),TBM_GETPOS,0,0);
        SetDlgItemText(hdlg,IDC_VRED  ,Scale(mfd->rlut[mfd->CurrentChannel],100,1024));
        SetDlgItemText(hdlg,IDC_VGREEN,Scale(mfd->glut[mfd->CurrentChannel],100,1024));
        SetDlgItemText(hdlg,IDC_VBLUE ,Scale(mfd->blut[mfd->CurrentChannel],100,1024));
        SetDlgItemText(hdlg,IDC_VCONST,Scale(mfd->clut[mfd->CurrentChannel],100,1024));
        mfd->ifp->RedoFrame();
        break;
      }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp = fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_CHANNELMIXER),
                          hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return ret;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  _snprintf(buf,buflen,"Config(%d,%d,%d,%d, %d,%d,%d,%d, %d,%d,%d,%d)",
    mfd->rlut[TARGET_RED  ],mfd->glut[TARGET_RED  ],mfd->blut[TARGET_RED  ],mfd->clut[TARGET_RED  ],
    mfd->rlut[TARGET_GREEN],mfd->glut[TARGET_GREEN],mfd->blut[TARGET_GREEN],mfd->clut[TARGET_GREEN],
    mfd->rlut[TARGET_BLUE ],mfd->glut[TARGET_BLUE ],mfd->blut[TARGET_BLUE ],mfd->clut[TARGET_BLUE ]);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->rlut[TARGET_RED  ]= argv[ 0].asInt();
  mfd->glut[TARGET_RED  ]= argv[ 1].asInt();
  mfd->blut[TARGET_RED  ]= argv[ 2].asInt();
  mfd->clut[TARGET_RED  ]= argv[ 3].asInt();
  mfd->rlut[TARGET_GREEN]= argv[ 4].asInt();
  mfd->glut[TARGET_GREEN]= argv[ 5].asInt();
  mfd->blut[TARGET_GREEN]= argv[ 6].asInt();
  mfd->clut[TARGET_GREEN]= argv[ 7].asInt();
  mfd->rlut[TARGET_BLUE ]= argv[ 8].asInt();
  mfd->glut[TARGET_BLUE ]= argv[ 9].asInt();
  mfd->blut[TARGET_BLUE ]= argv[10].asInt();
  mfd->clut[TARGET_BLUE ]= argv[11].asInt();

  Clipping (mfd->rlut[TARGET_RED  ],-2048,2048);
  Clipping (mfd->glut[TARGET_RED  ],-2048,2048);
  Clipping (mfd->blut[TARGET_RED  ],-2048,2048);
  Clipping (mfd->clut[TARGET_RED  ],-1024,1024);
  Clipping (mfd->rlut[TARGET_GREEN],-2048,2048);
  Clipping (mfd->glut[TARGET_GREEN],-2048,2048);
  Clipping (mfd->blut[TARGET_GREEN],-2048,2048);
  Clipping (mfd->clut[TARGET_GREEN],-1024,1024);
  Clipping (mfd->rlut[TARGET_BLUE ],-2048,2048);
  Clipping (mfd->glut[TARGET_BLUE ],-2048,2048);
  Clipping (mfd->blut[TARGET_BLUE ],-2048,2048);
  Clipping (mfd->clut[TARGET_BLUE ],-1024,1024);
}

ScriptFunctionDef func_defs[]=
  {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiiiiiiiiiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

FilterDefinition filterDef_ChannelMixer=
{
  NULL, NULL, NULL,               // next, prev, module
  "Channel Mixer",                // name
  "Mix RGB Channels\n"
  "Version 1.4 (31-10-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",        // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  sizeof(MyFilterData),           // inst_data_size
  InitProc,                       // initProc
  NULL,                           // deinitProc
  RunProc,                        // runProc
  ParamProc,                      // paramProc
  ConfigProc,                     // configProc
  NULL,                           // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  &script_obj,                    // script_obj
  FssProc,                        // fssProc
};

static FilterDefinition *fd_ChannelMixer;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_ChannelMixer= ff->addFilter(fm, &filterDef_ChannelMixer, sizeof(FilterDefinition));
  if (!fd_ChannelMixer) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_ChannelMixer);
}
