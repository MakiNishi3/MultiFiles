/*  Flip/Mirror/Rot180 - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari  <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.  */

#include "filter.h"
#pragma warning(disable:4035)
#include "memcpy_amd.cpp"

typedef void *(MEMCPY) (void *,const void *,size_t);
MEMCPY *_memcpy;

typedef struct MyFilterData
{
  Pixel32 *lbuff;
} MyFilterData;

void VerticalFlip (Pixel32 *dst,Pixel32 *tmp,const int pitch,const int h, const FilterFunctions *ff)
{  
  Pixel32 *a= dst;
  Pixel32 *b= dst + (h*pitch);

  for (int j=0; j<(h>>1); j++)
  {
    _memcpy (tmp,a,pitch*sizeof(Pixel32));
    _memcpy (a  ,b,pitch*sizeof(Pixel32));
    _memcpy (b,tmp,pitch*sizeof(Pixel32));
    a+= pitch;
    b-= pitch;
  }
}

void HorizontalFlip (Pixel32 *dst,Pixel32 *tmp,const int pitch,const int w,const int h, const FilterFunctions *ff)
{
  for (int j=0; j<h; j++)
  {
    _memcpy (tmp,dst,w*sizeof(Pixel32));
    tmp+= w;
    for (int i=0; i<w; i++) dst[i]= *tmp--;
    dst+= pitch;
  }
}

void Rotate180 (Pixel32 *dst,Pixel32 *tmp,const int pitch,const int w,const int h, const FilterFunctions *ff)
{ 
  Pixel32 *a,*b;
  int i;
  
  a= dst;
  b= dst + (h*pitch);
  int alf = h/2;
  if (h&1) alf++;

  for (int j=0; j<alf; j++)
  {
    _memcpy (tmp,a,w*sizeof(Pixel32)); // tmp= a;
    a+= w;      
    for (i=0; i<w; i++) *a--= *b++;   // a=b 
    for (i=0; i<w; i++) *b--= *tmp++; // b=tmp
    tmp-= w;      
    a+= pitch;
    b-= pitch;
  }    
  if (!(h&1)) // even lines
  {
    _memcpy (tmp,a,w*sizeof(Pixel32));
    a+= w;      
    for (i=0; i<w; i++) *a--= *tmp++;         
  }
}

int Rot180RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Rotate180 (fa->dst.data,mfd->lbuff,fa->dst.pitch>>2,fa->dst.w,fa->dst.h,ff);
  return 0;
}

int vFlipRunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  VerticalFlip (fa->dst.data,mfd->lbuff,fa->dst.pitch>>2,fa->dst.h,ff);
  return 0;
}

int hFlipRunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;

  HorizontalFlip (fa->dst.data,mfd->lbuff,fa->dst.pitch>>2,fa->dst.w,fa->dst.h,ff);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->lbuff=NULL;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags())) _memcpy= memcpy_amd; else _memcpy= memcpy;

  mfd->lbuff= new Pixel32[fa->src.size>>2];
  if (!mfd->lbuff) return 1;
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  delete[]mfd->lbuff;
  mfd->lbuff=NULL;
  return 0;
}

struct FilterDefinition filterDef_Rot180=
{
  NULL, NULL, NULL,         // next, prev, module
  "Rotate 180",             // name
  "Rotates an image by 180 degress.\n"
  "Version 1.1 (21-05-2004) [iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",  // desc
  "Emiliano Ferrari",       // maker
  NULL,                     // private_data
  sizeof(MyFilterData),     // inst_data_size
  InitProc,                 // initProc
  NULL,                     // deinitProc
  Rot180RunProc,            // runProc
  ParamProc,                // paramProc
  NULL,                     // configProc
  NULL,                     // stringProc
  StartProc,                // startProc
  EndProc,                  // endProc
  NULL,                     // script_obj
  NULL,                     // fssProc
};

struct FilterDefinition filterDef_hFlip=
{
  NULL, NULL, NULL,           // next, prev, module
  "Mirror", // name
  "Horizontally flips an image.\n"
  "Version 1.1 (21-05-2004) [iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",    // desc
  "Emiliano Ferrari",         // maker
  NULL,                       // private_data
  sizeof(MyFilterData),       // inst_data_size
  InitProc,                   // initProc
  NULL,                       // deinitProc
  hFlipRunProc,               // runProc
  ParamProc,                  // paramProc
  NULL,                       // configProc
  NULL,                       // stringProc
  StartProc,                  // startProc
  EndProc,                    // endProc
  NULL,                       // script_obj
  NULL,                       // fssProc
};

struct FilterDefinition filterDef_vFlip=
{
  NULL, NULL, NULL,         // next, prev, module
  "Flip",                   // name
  "Vertically flips an image.\n"
  "Version 1.0.1 (21-05-2004) [iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",  // desc
  "Emiliano Ferrari",       // maker
  NULL,                     // private_data
  sizeof(MyFilterData),     // inst_data_size
  InitProc,                 // initProc
  NULL,                     // deinitProc
  vFlipRunProc,             // runProc
  ParamProc,                // paramProc
  NULL,                     // configProc
  NULL,                     // stringProc
  StartProc,                // startProc
  EndProc,                  // endProc
  NULL,                     // script_obj
  NULL,                     // fssProc
};

static FilterDefinition *fd_hFlip,*fd_vFlip,*fd_Rot180;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_hFlip = ff->addFilter(fm, &filterDef_hFlip, sizeof(FilterDefinition));
  fd_vFlip = ff->addFilter(fm, &filterDef_vFlip, sizeof(FilterDefinition));
  fd_Rot180= ff->addFilter(fm, &filterDef_Rot180,sizeof(FilterDefinition));
  if (!fd_hFlip) return 1;
  if (!fd_vFlip) return 1;
  if (!fd_Rot180) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_Rot180);
  ff->removeFilter(fd_vFlip);
  ff->removeFilter(fd_hFlip);
}
