/*  Grayscale RGB - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari    <macinapepe@tiscali.it

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include "resource.h"
#include "filter.h"
#include "ScriptValue.h"

typedef struct
{
  IFilterPreview *ifp;
  int red,green,blue,link;
} MyFilterData;

__int64 BuildQ (short A,short R,short G,short B)
{
  __int64 Quadword;
  *(((short *)&Quadword)+0)= B;
  *(((short *)&Quadword)+1)= G;
  *(((short *)&Quadword)+2)= R;
  *(((short *)&Quadword)+3)= A;
  return Quadword;
}

void Grayscale2_MMX (Pixel32 *dst,__int64 KGray,int psize)
{
  KGray>>= 1;
  __asm {
        mov       edi,[dst]
        mov       ecx,[psize]
        or        ecx,ecx
        jz        End

        pxor      mm7,mm7
        movq      mm6,[KGray]

        align     16
ColLoop:movd      mm0,[edi]
        punpcklbw mm0,mm7

        // GrayScale
        psllw     mm0,2
        pmulhw    mm0,mm6
        movq      mm1,mm0
        movq      mm2,mm0
        psrlq     mm1,16
        psrlq     mm2,32
        paddw     mm1,mm2
        paddw     mm0,mm1
        psrlw     mm0,1
        punpcklwd mm0,mm0
        punpcklwd mm0,mm0
        packuswb  mm0,mm0

        movd      [edi],mm0
        add       edi,4
        dec       ecx
        jnz       ColLoop
        emms
End:
   }
}

void Grayscale2_iSSE (Pixel32 *dst,__int64 KGray,int psize)
{
  __asm {
        mov       ecx,[psize]
        mov       edi,[dst]
        movq      mm6,[KGray]
        pxor      mm7,mm7
        shr       ecx,1
        jz        last_pixel
        align     16
tloop:  movq      mm0,[edi]
        movq      mm3,mm0
        prefetchnta  [edi+64]
        punpcklbw mm0,mm7
        punpckhbw mm3,mm7
        pmulhuw   mm0,mm6
        pmulhuw   mm3,mm6
        pshufw    mm1,mm0,0
        pshufw    mm5,mm3,0
        pshufw    mm2,mm0,0x55
        pshufw    mm4,mm3,0x55
        pshufw    mm0,mm0,0xaa
        pshufw    mm3,mm3,0xaa
        paddw     mm1,mm2
        paddw     mm5,mm4
        paddw     mm0,mm1
        paddw     mm3,mm5
        packuswb  mm0,mm3
        movq      [edi],mm0
        add       edi,8
        dec       ecx
        jnz       tloop
last_pixel:
        mov       ecx,[psize]
        and       ecx,1
        jz        quit
        movd      mm0,[edi]
        punpcklbw mm0,mm7
        pmulhuw   mm0,mm6
        pshufw    mm1,mm0,0
        pshufw    mm2,mm0,0x55
        pshufw    mm0,mm0,0xaa
        paddw     mm1,mm2
        paddw     mm0,mm1
        packuswb  mm0,mm0
        movd      [edi],mm0
quit:   emms
  }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst;
  const int psize= fa->dst.size>>2;
  dst= fa->dst.data;
  const int KR= mfd->red;
  const int KG= mfd->green;
  const int KB= mfd->blue;
  __int64 KGray = BuildQ (0,mfd->red<<4,mfd->green<<4,mfd->blue<<4);

  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
    Grayscale2_iSSE (dst,KGray,psize);
  else

  if ((CPUF_SUPPORTS_MMX & ff->getCPUFlags()))
    Grayscale2_MMX (dst,KGray,psize);
  else

    for (int p=0;p<psize;p++)
      {
        int r,g,b,Y;
        r= (*dst>>16) & 0xff;
        g= (*dst>> 8) & 0xff;
        b= (*dst    ) & 0xff;
        // Grayscale
        Y= (KR*r + KG*g + KB*b)>>12;
        if (Y>255) Y=255; // clipping
        *dst++= (Y<<16)|(Y<<8)|Y;
      }
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
 /*
  ITU Rec. Luma 601:  Y= 0.298912*R + 0.586611*G + 0.114478*B
  ITU Rec. Luma 709:  Y= 0.212671*R + 0.715160*G + 0.072169*B
  ITU gray:           Y= 0.222015*R + 0.706655*G + 0.071330*B
  Linear RGB Correct: Y= 0.3086  *R + 0.6094  *G + 0.0820  *B */

  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->red  = (int)(4096.0*0.212671);
  mfd->green= (int)(4096.0*0.715160);
  mfd->blue = 4096-(mfd->red+mfd->green);
  mfd->link = false;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(str,64, " (R:%1.3f  G:%1.3f  B:%1.3f)",
          mfd->red/4096.0,mfd->green/4096.0,mfd->blue/4096.0);
}

void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d, %d, %d)", mfd->red, mfd->green, mfd->blue);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa = (FilterActivation *)lpVoid;
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->red  = argv[0].asInt();
  mfd->green= argv[1].asInt();
  mfd->blue = argv[2].asInt();
  Clipping (mfd->red  ,0,4096);
  Clipping (mfd->green,0,4096);
  Clipping (mfd->blue ,0,4096);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};


BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd = (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char t[128];
  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(0,4095));
      SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETPOS, (WPARAM)TRUE, mfd->red);
      SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(0,4095));
      SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETPOS, (WPARAM)TRUE, mfd->green);
      SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(0,4095));
      SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETPOS, (WPARAM)TRUE, mfd->blue);
      _snprintf (t,128," %1.3f",mfd->red/4096.0);
      SetDlgItemText(hdlg, IDC_REDVAL, t);
      _snprintf (t,128," %1.3f",mfd->green/4096.0);
      SetDlgItemText(hdlg, IDC_GREENVAL,t);
      _snprintf (t,128," %1.3f",mfd->blue/4096.0);
      SetDlgItemText(hdlg, IDC_BLUEVAL,t);
      _snprintf (t,128," %1.3f",(mfd->red+mfd->green+mfd->blue+0.5)/4096.0);
      SetDlgItemText(hdlg, IDC_TOTAL,t);
      CheckDlgButton(hdlg, IDC_LINK, mfd->link ? BST_CHECKED : BST_UNCHECKED);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW:mfd->ifp->Toggle(hdlg);  break;
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;
        case IDC_LINK: mfd->link = IsDlgButtonChecked(hdlg, IDC_LINK);break;

        case ITU_L601:
        case ITU_L709:
        case ITU_GRAY:
        case ITU_LINEAR:

          if (LOWORD(wParam)==ITU_L601)
            {
             mfd->red  = (int)(4096.0*0.298912);
             mfd->green= (int)(4096.0*0.586611);
            }
           else
            if (LOWORD(wParam)==ITU_L709)
            {
             mfd->red  = (int)(4096.0*0.212671);
             mfd->green= (int)(4096.0*0.715160);
            }
           else
            if (LOWORD(wParam)==ITU_GRAY)
            {
             mfd->red  = (int)(4096.0*0.222015);
             mfd->green= (int)(4096.0*0.706655);
            }
           else
            {
             mfd->red  = (int)(4096.0*0.3086);
             mfd->green= (int)(4096.0*0.6094);
            }
          mfd->blue = 4096-(mfd->red+mfd->green);
          SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETPOS, (WPARAM)TRUE,mfd->red);
          _snprintf (t,128," %1.3f",mfd->red/4096.0);
          SetDlgItemText(hdlg, IDC_REDVAL, t);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETPOS, (WPARAM)TRUE,mfd->green);
          _snprintf (t,128," %1.3f",mfd->green/4096.0);
          SetDlgItemText(hdlg, IDC_GREENVAL,t);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETPOS, (WPARAM)TRUE,mfd->blue);
          _snprintf (t,128," %1.3f",mfd->blue/4096.0);
          SetDlgItemText(hdlg, IDC_BLUEVAL,t);
          _snprintf (t,128," %1.3f",(mfd->red+mfd->green+mfd->blue+0.5)/4096.0);
          SetDlgItemText(hdlg, IDC_TOTAL,t);
          mfd->ifp->RedoFrame();
        return TRUE;
      }
      break;
    case WM_HSCROLL:
      {
        int r,g,b;
        r= SendMessage(GetDlgItem(hdlg, IDC_RED),   TBM_GETPOS, 0, 0);
        g= SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_GETPOS, 0, 0);
        b= SendMessage(GetDlgItem(hdlg, IDC_BLUE),  TBM_GETPOS, 0, 0);

        if (mfd->link)
        {
          int d= (r - mfd->red) + (g - mfd->green) + (b - mfd->blue);
          r= mfd->red + d;
          g= mfd->green + d;
          b= mfd->blue + d;
          Clipping (r,0,4096);
          Clipping (g,0,4096);
          Clipping (b,0,4096);
          SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETPOS, (WPARAM)TRUE, r);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETPOS, (WPARAM)TRUE, g);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETPOS, (WPARAM)TRUE, b);
        }
      mfd->red= r;
      mfd->green= g;
      mfd->blue= b;
      _snprintf (t,128," %1.3f",mfd->red/4096.0);
      SetDlgItemText(hdlg, IDC_REDVAL, t);
      _snprintf (t,128," %1.3f",mfd->green/4096.0);
      SetDlgItemText(hdlg, IDC_GREENVAL,t);
      _snprintf (t,128," %1.3f",mfd->blue/4096.0);
      SetDlgItemText(hdlg, IDC_BLUEVAL,t);
      _snprintf (t,128," %1.3f",(mfd->red+mfd->green+mfd->blue+0.5)/4096.0);
      SetDlgItemText(hdlg, IDC_TOTAL,t);
      mfd->ifp->RedoFrame();
      break;
     }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old = *mfd;
  mfd->ifp = fa->ifp;
  int ret=DialogBoxParam(fa->filter->module->hInstModule,
                         MAKEINTRESOURCE(IDD_FILTER_GRAYSCALE),
                         hwnd,ConfigDlgProc,(LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return ret;
}

FilterDefinition filterDef_Grayscale=
{
  NULL,NULL,NULL,                     // next, prev, module
  "Grayscale RGB",                    // name
  "Adjustable grayscale filter\n"     // desc
  "Version 1.2 (27-09-2003) [MMX/iSSE]\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",
  "Emiliano Ferrari",                 // maker
  NULL,                               // private_data
  sizeof(MyFilterData),               // inst_data_size
  InitProc,                           // initProc
  NULL,                               // deinitProc
  RunProc,                            // runProc
  ParamProc,                          // paramProc
  ConfigProc,                         // configProc
  StringProc,                         // stringProc
  NULL,                               // startProc
  NULL,                               // endProc
  &script_obj,                        // script_obj
  FssProc,                            // fssProc
};

static FilterDefinition *fd_Grayscale;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_Grayscale= ff->addFilter(fm, &filterDef_Grayscale, sizeof(FilterDefinition));
  if (!fd_Grayscale) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_Grayscale);
}
