/*  Video Shiver (Old Cinema) - filter for VirtualDub
    Copyright (C) 2004 Emiliano Ferrari

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA

    Emiliano Ferrari
    e-mail: macinapepe@tiscali.it

   01-03-2004 v0.1: inizio progetto
   15-04-2004 v0.2: uso della funzione seno per rendere piu' realistico
                    il movimento.                            */

#include <math.h>
#include "filter.h"

#pragma warning(disable:4035)
#include "memcpy_amd.cpp"

typedef void *(MEMCPY) (void *,const void *,size_t);
MEMCPY *_memcpy;


typedef struct
{
  IFilterPreview *ifp;
  int sequence [4096];
} MyFilterData;

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const int w= fa->dst.w;
  const int h= fa->dst.h;
  const int psize= fa->dst.size>>2;
  const int pitch= fa->dst.pitch>>2;
  Pixel32 *dst= fa->dst.data;
  Pixel32 *src= fa->src.data;
  int cf= fa->pfsi->lCurrentFrame;
  int diff= mfd->sequence[cf%4096];

  if (diff==0) _memcpy (dst,src,4*psize);

  int y1,y2,oy,dy;

  y1= diff;
  y2= diff+h;
  oy= 0;
  if (y1<0) { oy= -y1; y1= 0; }
  if (y2>h) y2= h;
  dy= y2-y1;

  src+= oy*pitch;
  dst+= y1*pitch;

  for (int j=0; j<dy; j++)
  {
    _memcpy (dst,src,pitch*4);
    dst+= pitch;
    src+= pitch;
  }
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  int last= 0, yoffset=0;
  
  srand(0);
  for (int i=0; i<4096; i++)
  {
    double r1= 80+rand()%20;
    double r2= 50+rand()%50;
    double r3= 20+rand()%80;
    double r4= rand()%100;
    double s1= sin((i*2.0*3.14)/r1);
    double s2= sin((i*2.0*3.14)/r2);
    double s3= sin((i*2.0*3.14)/r3);
    double s4= sin((i*2.0*3.14)/r4);
    yoffset= (int)(5*s1*s2*s3*s4);
    if (abs(yoffset-last)>2)
      if (yoffset>last)
        yoffset= last+2;
      else
        yoffset= last-2;
    mfd->sequence[i]= yoffset;
    last= yoffset;
  }
  return 0;
}


int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags())) _memcpy= memcpy_amd; else _memcpy= memcpy;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  return FILTERPARAM_SWAP_BUFFERS;
}

FilterDefinition filterDef=
{
  NULL, NULL, NULL,         // next, prev, module
  "shiver",                    // name
  "random shake up and down video.\n"
  "Version 0.2 (15-04-2004)\n" // desc
  "Copyright (C) 2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",
  "Emiliano Ferrari",       // maker
  NULL,                     // private_data
  sizeof(MyFilterData),     // inst_data_size
  InitProc,                 // initProc
  NULL,                     // deinitProc
  RunProc,                  // runProc
  ParamProc,                // paramProc
  NULL,                     // configProc
  NULL,                     // stringProc
  StartProc,                     // startProc
  NULL,                     // endProc
  NULL,                     // script_obj
  NULL,                     // fssProc
};

static FilterDefinition *fd;

extern "C" int __declspec(dllexport) __cdecl
VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd= ff->addFilter(fm, &filterDef, sizeof(FilterDefinition));
  if (!fd) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl
VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd);
}
