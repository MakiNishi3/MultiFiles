/*  FPS (Old Cinema) - filter for VirtualDub
    Copyright (C) 2004 Emiliano Ferrari

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA

    Emiliano Ferrari
    e-mail: macinapepe@tiscali.it                                */

#include <math.h>
#include <stdio.h>
#include "save.h"
#include "filter.h"
#include <windows.h>
#include <commctrl.h>
#include "ScriptValue.h"

#pragma warning(disable:4035)
#include "memcpy_amd.cpp"

typedef void *(MEMCPY) (void *,const void *,size_t);
MEMCPY *_memcpy;

typedef struct
{
  IFilterPreview *ifp;  
  Pixel32 *tmp;
  int tsize;
  int mframe;
} MyFilterData;

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int psize= fa->dst.size>>2;
  const int Size= fa->dst.size;
  
  const int cf= fa->pfsi->lCurrentFrame;
  


  if ((mfd->mframe<0) || (cf%3 == 0))
  {
      mfd->mframe= cf;
      _memcpy (mfd->tmp,dst,Size);
  }
  else 
  {
      _memcpy (dst,mfd->tmp,Size);
  }

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->mframe= -1;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags())) _memcpy= memcpy_amd; else _memcpy= memcpy;
  if (!mfd->tmp) { mfd->tsize= fa->src.size>>2; mfd->tmp= new Pixel32[mfd->tsize]; }
  if (!mfd->tmp) ff->ExceptOutOfMemory();
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  if (mfd->tmp) { delete[] mfd->tmp; mfd->tmp= NULL; mfd->tsize= 0; }
  return 0;
}
FilterDefinition filterDef_save=
{
  NULL, NULL, NULL,            // next, prev, module
  "Old Cinema: FPS",     // name  
  "Version 1.0 (21-04-2004) [iSSE]\n"
  "Copyright (C) 2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  NULL,                  // configProc
  NULL,                  // stringProc
  StartProc,                   // startProc
  EndProc,                     // endProc
  NULL,                 // script_obj
  NULL,                     // fssProc
};

static FilterDefinition *fd_save;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_save = ff->addFilter(fm, &filterDef_save, sizeof(FilterDefinition));
  if (!fd_save) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_save);
}
