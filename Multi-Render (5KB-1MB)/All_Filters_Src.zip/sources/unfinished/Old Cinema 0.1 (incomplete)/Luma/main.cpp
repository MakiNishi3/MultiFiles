/*  Random Luma (Old Cinema) - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA

    Emiliano Ferrari
    e-mail: macinapepe@tiscali.it                                */

#include <stdio.h>
#include <math.h>
#include <windows.h>
#include <commctrl.h>
#include "resource.h"
#include "filter.h"
#include "ScriptValue.h"

typedef struct
{
  IFilterPreview *ifp;
  int sequence [4096];
} MyFilterData;

void RGB_MMX (Pixel32 *dst,__int64 K64,int psize);
void RGB_iSSE(Pixel32 *dst,__int64 K64,int psize);


__int64 BuildQ (short A,short R,short G,short B)
{
  __int64 Quadword;
  *(((short *)&Quadword)+0)= B;
  *(((short *)&Quadword)+1)= G;
  *(((short *)&Quadword)+2)= R;
  *(((short *)&Quadword)+3)= A;
  return Quadword;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;  
  const int psize= fa->dst.size>>2;

  int cf= fa->pfsi->lCurrentFrame;
  const int K= mfd->sequence[cf%4096];

  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
  {
    __int64 K64= BuildQ (1,K,K,K);
    RGB_iSSE (dst,K64,psize);
    return 0;
  }

  if ((CPUF_SUPPORTS_MMX & ff->getCPUFlags()))
  {
    __int64 K64= BuildQ (1,K,K,K);
    RGB_MMX (dst,K64,psize);
    return 0;
  }

  for (int p=0; p<psize; p++)
  {
    int r= (*dst>>16) & 0xff;
    int g= (*dst>> 8) & 0xff;
    int b= (*dst    ) & 0xff;

    r= (r*K)>>10;
    g= (g*K)>>10;
    b= (b*K)>>10;

    if ((unsigned)r>255) r=(~r>>31)&0xff;
    if ((unsigned)g>255) g=(~g>>31)&0xff;
    if ((unsigned)b>255) b=(~b>>31)&0xff;
    
    *dst++= (r<<16) | (g<<8) | b;
  }
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  
  int last= 0, yoffset=0;
 
  srand(0);
  for (int i=0; i<4096; i++)
  {
    double r1= 80+rand()%20;
    double r2= 50+rand()%50;
    double r3= 20+rand()%80;
    double r4= rand()%100;
    double s1= 512*sin((i*2.0*3.14)/r1);
    double s2= 256*sin((i*2.0*3.14)/r2);
    double s3= 128*sin((i*2.0*3.14)/r3);
    double s4=  64*sin((i*2.0*3.14)/r4);
    yoffset= (int)(s1*s2*s3*s4);
    if (abs(yoffset-last)>8)
      if (yoffset>last)
        yoffset= last+8;
      else
        yoffset= last-8;
    mfd->sequence[i]= 1024+yoffset;
    last= yoffset;
  }

  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

FilterDefinition filterDef_RGB=
{
  NULL,NULL,NULL,                 // next, prev, module
  "Old Cinema: random Luma",               // name  
  "Version 1.0 (21-04-2004) [MMX/iSSE]\n"
  "Copyright (C) 2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",      // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  sizeof(MyFilterData),           // inst_data_size
  InitProc,                       // initProc
  NULL,                           // deinitProc
  RunProc,                        // runProc
  ParamProc,                      // paramProc
  NULL,                     // configProc
  NULL,                     // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  NULL,                    // script_obj
  NULL,                        // fssProc
};

static FilterDefinition *fd_RGB;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_RGB= ff->addFilter(fm, &filterDef_RGB, sizeof(FilterDefinition));
  if (!fd_RGB) { return 1; }
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_RGB);
}

// ===========================================================

void RGB_MMX (Pixel32 *dst,__int64 K64,int psize)
{
  __asm {   mov         edi,[dst]
            mov         ecx,[psize]
            movq        mm6,[K64]
            pxor        mm7,mm7
            psllw       mm6,3
            mov         edx,ecx
            shr         ecx,2
            or          ecx,ecx
            jz          nomainloop

            align 16
mainloop:   movq        mm0,[edi]
            movq        mm1,mm0
            movq        mm2,[edi+8]
            punpcklbw   mm0,mm7
            movq        mm3,mm2
            punpckhbw   mm1,mm7
            psllw       mm0,3
            punpcklbw   mm2,mm7
            psllw       mm1,3
            punpckhbw   mm3,mm7
            psllw       mm2,3
            pmulhw      mm0,mm6
            psllw       mm3,3
            pmulhw      mm1,mm6
            pmulhw      mm2,mm6
            packuswb    mm0,mm1
            pmulhw      mm3,mm6
            packuswb    mm2,mm3
            movq        [edi],mm0
            movq        [edi+8],mm2
            add         edi,16
            dec         ecx
            jnz         mainloop

nomainloop: and         edx,3
            jz          evenpixel
oddloop:    movd        mm0,[edi]
            punpcklbw   mm0,mm7
            psllw       mm0,3
            pmullw      mm0,mm6
            packuswb    mm0,mm0
            movd        [edi],mm0
            add         edi,4
            dec         edx
            jnz         oddloop
evenpixel:  emms
   }
}

void RGB_iSSE (Pixel32 *dst,__int64 K64,int psize)
{
  __int64 Zero=0;
  K64<<=3;
  __asm {   mov         edi,[dst]
            mov         ecx,[psize]
            mov         edx,ecx
            shr         ecx,3
            or          ecx,ecx
            jz          nomainloop

//-----------------------------------------
            align 16
mainloop:   movq        mm0,[edi   ]            // Optimized for AMD ATHLON Processor
            movq        mm1,[edi+ 8]            // Intel P3 and P4 Processor (no HT)
            movq        mm2,[edi+16]
            movq        mm3,[edi+24]
            prefetchnta [edi+512]               // iSSE prefetch istruction + Unrolled loop (8 pixels at loop) = Optimize memory bandwidth
            movq        mm4,mm0
            movq        mm5,mm1
            movq        mm6,mm2
            movq        mm7,mm3
            punpcklbw   mm0,[Zero]              // 1. Read Pixel
            punpckhbw   mm4,[Zero]              // 2. Expand to packed word
            punpcklbw   mm1,[Zero]              // 3. Fix Mul by 8 (left shift by 3)
            punpckhbw   mm5,[Zero]              // 4. Multiply by RGB const and divide by 65536 (Hi word = right shift by 16)
            punpcklbw   mm2,[Zero]              // 5. Pack to byte
            punpckhbw   mm6,[Zero]              // 6. write pixel and update idex
            punpcklbw   mm3,[Zero]
            punpckhbw   mm7,[Zero]
            psllw       mm0,3
            psllw       mm1,3
            psllw       mm2,3
            psllw       mm3,3
            psllw       mm4,3
            psllw       mm5,3
            psllw       mm6,3
            psllw       mm7,3
            pmulhw      mm0,[K64]
            pmulhw      mm1,[K64]
            pmulhw      mm2,[K64]
            pmulhw      mm3,[K64]
            pmulhw      mm4,[K64]
            pmulhw      mm5,[K64]
            pmulhw      mm6,[K64]
            pmulhw      mm7,[K64]
            packuswb    mm0,mm4
            packuswb    mm1,mm5
            packuswb    mm2,mm6
            packuswb    mm3,mm7
            movq        [edi   ],mm0
            movq        [edi+ 8],mm1
            movq        [edi+16],mm2
            movq        [edi+24],mm3
            add         edi,32
            dec         ecx
            jnz         mainloop
//-----------------------------------------

nomainloop: and         edx,7
            jz          evenpixel
            pxor        mm7,mm7
            movq        mm6,[K64]
oddloop:    movd        mm0,[edi]
            punpcklbw   mm0,mm7
            psllw       mm0,3
            pmullw      mm0,mm6
            packuswb    mm0,mm0
            movd        [edi],mm0
            add         edi,4
            dec         edx
            jnz         oddloop
evenpixel:  emms
   }
}
