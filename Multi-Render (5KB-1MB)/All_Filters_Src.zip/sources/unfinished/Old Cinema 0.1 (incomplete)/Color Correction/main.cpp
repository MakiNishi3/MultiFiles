/*  Color Correction (Old Cinema) - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari  <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. */

#include "filter.h"

typedef struct
{
  IFilterPreview *ifp;
  int Red,Green,Blue;
  Pixel32 palette[256];
} MyFilterData;

void BuildTables(MyFilterData *mfd)
{
  for (int l=0; l<256; l++)
    {
      int r= (l*mfd->Red+128)>>8;
      int g= (l*mfd->Green+128)>>8;
      int b= (l*mfd->Blue+128)>>8;
      mfd->palette[l]= (r<<16) | (g<<8) | b;      
    }
}

#pragma warning(disable: 4731)

void PseudoColor (Pixel32 *dst,Pixel32 *Pal32,int psize)
{
  __asm { mov       edi,[dst]
          mov       esi,[Pal32]
          mov       ecx,[psize]
          or        ecx,ecx
          jz        End
          push      ebp

          align     16
ColLoop:  mov       eax,[edi]           // A.R.G.B
          xor       ebx,ebx             // 0
          mov       bl,ah               // 0.0.0.G
          and       eax,0xff00ff        // 0.R.0.B
          lea       ebp,[eax+8*eax]     // [r*9][b*9]  // IGNORE warning C4731
          lea       edx,[ebx+2*ebx]     // [G*3]
          lea       eax,[eax+2*ebp]     // [R*19][B*19]
          lea       ebx,[ebx+8*ebx]     // [G*9]
          lea       ebp,[ebp+2*ebp]     // [R*27][B*27]
          shl       edx,6               // [G*192]
          shr       ebp,15              // [R*54]
          sub       edx,ebx             // [G*183]
          add       edx,ebp             // 183*G+19*B
          and       eax,0xffff
          add       eax,edx             // 54*R+183*G+19*B
          add       edi,4
          shr       eax,8               // PseudoColor
          mov       ebx,[esi+eax*4]
          mov       [edi-4],ebx
          dec       ecx
          jnz       ColLoop
          pop       ebp
End:    }
}

void PseudoColor_iSSE (Pixel32 *dst,Pixel32 *Pal32,int psize)
{
  __asm { mov         edi,[dst]     // for (int p=0; p<psize; p++) {
          mov         esi,[Pal32]   //   int r= (*dst>>16) & 0xff;
          mov         ecx,[psize]   //   int g= (*dst>> 8) & 0xff;
          or          ecx,ecx       //   int b= (*dst    ) & 0xff;
          jz          End           //   int Y=(0x3672*r + 0xB714*g + 0x127A*b)>>16;
          push        ebp           //   *dst++= mfd->palette[Y]; }

          align       16
ColLoop:  mov         eax,[edi]           // A.R.G.B
          xor         ebx,ebx             // 0
          mov         bl,ah               // 0.0.0.G
          and         eax,0xff00ff        // 0.R.0.B
          lea         ebp,[eax+8*eax]     // [r*9][b*9]  // IGNORE warning C4731
          lea         edx,[ebx+2*ebx]     // [G*3]
          lea         eax,[eax+2*ebp]     // [R*19][B*19]
          lea         ebx,[ebx+8*ebx]     // [G*9]
          lea         ebp,[ebp+2*ebp]     // [R*27][B*27]
          shl         edx,6               // [G*192]
          shr         ebp,15              // [R*54]
          sub         edx,ebx             // [G*183]
          add         edx,ebp             // 183*G+19*B
          and         eax,0xffff
          add         eax,edx             // 54*R+183*G+19*B
          add         edi,4
          shr         eax,8               // PseudoColor
          prefetchnta [edi+192]
          mov         ebx,[esi+eax*4]
          mov         [edi-4],ebx
          dec         ecx
          jnz         ColLoop
          pop         ebp
End:    }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int psize= fa->dst.size>>2;

  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
    PseudoColor_iSSE (dst,mfd->palette,psize);
   else
     PseudoColor (dst,mfd->palette,psize);

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->Red= 247;
  mfd->Green= 223;
  mfd->Blue= 181;
  BuildTables (mfd);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

struct FilterDefinition filterDef=
{
  NULL,NULL,NULL,              // next, prev, module
  "Old Cinema: Color Correction",      // name
  "Version 1.0 (21-04-2004) [ASM/iSSE]\n"
  "Copyright (C) 2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",     // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  NULL,                        // configProc
  NULL,                        // stringProc
  NULL,                        // startProc
  NULL,                        // endProc
  NULL,                        // script_obj
  NULL,                        // fssProc
};

static FilterDefinition *fd;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff,int& vdfd_ver, int& vdfd_compat)
{
  fd= ff->addFilter(fm, &filterDef, sizeof(FilterDefinition));
  if (!fd) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd);
}
