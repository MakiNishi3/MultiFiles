/*  Timer - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari   <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <windows.h>
#include "filter.h"
#include "resource.h"

#define START_TIMER 0
#define SHOW_TIMER  1

typedef struct { int op; } MyFilterData;
static __int64 tt=0;

__int64 ReadTSC() { __asm {RDTSC} }

unsigned char Digit[160] = {
    0x00, 0x00, 0x3C, 0x66, 0xC3, 0xC3, 0xDB, 0xDB, 0xC3, 0xC3, 0x66, 0x3C, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x18, 0x38, 0x78, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0x03, 0x06, 0x0C, 0x18, 0x30, 0x60, 0xC0, 0xFF, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0x03, 0x03, 0x3E, 0x03, 0x03, 0x03, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x06, 0xC6, 0xC6, 0xC6, 0xC6, 0xFF, 0x06, 0x06, 0x06, 0x06, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFF, 0xC0, 0xC0, 0xC0, 0xFE, 0x03, 0x03, 0x03, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x3E, 0x60, 0xC0, 0xC0, 0xFE, 0xC3, 0xC3, 0xC3, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFF, 0x03, 0x03, 0x06, 0x0C, 0x18, 0x30, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0xC3, 0xC3, 0x7E, 0xC3, 0xC3, 0xC3, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0xC3, 0xC3, 0x7F, 0x03, 0x03, 0x03, 0x06, 0x7C, 0x00, 0x00, 0x00, 0x00};

int h,w,pitch;
Pixel32 *dst;

void PutPixel (int x,int y,Pixel32 colore)
{
  if ((x<0) || (x>w) || (y<0) || (y>h)) return;
  dst[x+(h-y)*pitch]= colore;
}

void DrawNum (int px,int py,int num,Pixel32 color,Pixel32 bgcolor)
{
  char s[50];
  itoa (num,s,10);

  for (unsigned c=0; c<strlen(s); c++)
  {
    for (int j=0; j<16; j++)
    {
      int b= Digit[j+((int)(s[c])-48)*16];
      for (int i=0; i<9; i++)
      {
        if (b&128)
          PutPixel (px+i,py+j,color);
        else
          PutPixel (px+i,py+j,bgcolor);
        b<<= 1;
      }
    }
    px+= 9;
  }
}


int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  dst= fa->dst.data;
  h= fa->dst.h;
  w= fa->dst.w;
  pitch= fa->dst.pitch>>2;

  switch (mfd->op)
  {
    case START_TIMER: tt= ReadTSC();  break;
    case SHOW_TIMER:  tt= ReadTSC()-tt;
                      DrawNum (0,0,tt,0xffffff,0);
                      DrawNum (0,20,(int)(tt/(w*h)),0x00ff00,0);
                      break;
  }
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->op = START_TIMER;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      CheckDlgButton(hdlg,IDC_STORE,(mfd->op==START_TIMER)?BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_BLEND,(mfd->op==SHOW_TIMER)?BST_CHECKED:BST_UNCHECKED);
      return TRUE;
    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDOK: EndDialog(hdlg,0); return TRUE;
        case IDC_STORE: mfd->op= START_TIMER; break;
        case IDC_BLEND: mfd->op= SHOW_TIMER; break;
      }
      break;

  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  int Resoult= DialogBoxParam ( fa->filter->module->hInstModule,
                                MAKEINTRESOURCE(IDD_FILTER_TIMER),
                                hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (Resoult) *mfd= mfd_old;
  return !!Resoult;
}

FilterDefinition filterDef=
{
  NULL, NULL, NULL,            // next, prev, module
  " TIMER",                       // name
  "visualizza il numero di clock utilizzati da una applicazione\n"
  "Version 1.0 (13-04-2004) [Pentium Only]\n"
  "Copyright (C) 2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  NULL,                           // stringProc
  NULL,                           // startProc
  NULL,                        // endProc
  NULL,                           // script_obj
  NULL,                        // fssProc
};

static FilterDefinition *fd;

extern "C" int __declspec(dllexport) __cdecl
VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd= ff->addFilter(fm, &filterDef, sizeof(FilterDefinition));
  if (!fd) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl
VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd);
}
