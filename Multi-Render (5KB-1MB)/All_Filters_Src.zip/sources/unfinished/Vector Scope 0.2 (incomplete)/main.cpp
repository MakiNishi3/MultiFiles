/*  Vectorscope - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.                  */

#include <stdio.h>
#include <math.h>
#include "filter.h"

int h,w,pitch;
Pixel32 *dst;

Pixel32 vectorscope [256*256];
Pixel32 Col[256];

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  Col[0]= 0;
  for (int i=1; i<256; i++)
  {
     int r,g,c= 16+i*8;
     if (c>255) {r= c>>3; g= 255; } else { r= 0; g= c; }      
     if (r>255) r=255;
     Col[i]= (r<<16) | (g<<8) | r;
  }
  fa->dst.data= fa->src.data;
  return 0;
  
}

inline void Clipping (int &dato,int min,int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  h= fa->dst.h;
  w= fa->dst.w;
  pitch= fa->dst.pitch>>2;
  dst= fa->dst.data;  
  Pixel32 *src=fa->src.data;
  const int psize= fa->dst.size>>2;
  int i,j;

  memset (vectorscope,0,sizeof(vectorscope));  

/*
  for (int i=0; i<256; i++)
  {
      putpixel (i,128,0xCD9219);
      putpixel (128,i,0xCD9219);
  }

  for (int a=0; a<3600; a++)
  {
      int x= (int)(128+100*cos(a*3.14/180));
      int y= (int)(128+100*sin(a*3.14/180));
      putpixel (x,y,0xCD9219);
  }
*/

  const int Rr= (int)(65536* 0.439f);
  const int Rg= (int)(65536*-0.368f);
  const int Rb= (int)(65536*-0.071f);  
  const int Br= (int)(65536*-0.148f*0.75f);
  const int Bg= (int)(65536*-0.291f*0.75f);
  const int Bb= (int)(65536* 0.439f*0.75f);

  int U,V;
  double med=0;
  for (int p=0; p<psize; p++)
  {
    int r= (src[p]>>16) & 0xff;
    int g= (src[p]>> 8) & 0xff;
    int b= (src[p]    ) & 0xff;
    U= ((Rr*r +Rg*g +Rb*b)>>16)+128;
    V= ((Br*r +Bg*g +Bb*b)>>16)+128;

    med+= (double)U/(double)V;
    if(vectorscope[V+(U<<8)]<255) vectorscope[V+(U<<8)]++;    
  }

  med/= psize;
  
  if (med<1.0)
  {
    V= 256;
    U= (int)(V*med);
  }
  else
  {
    U= 256;
    V= (int)(U/med);
  }

  for (j=0; j<256; j++)
    for (i=0; i<256; i++)  
      dst[i+j*pitch]= Col[vectorscope[i+(j<<8)]];   

    dst[V+(256-U)*pitch]= 0xffffff;
  return 0;
}

struct FilterDefinition filterDef_vectorscope=
{
  NULL,NULL,NULL,         // next, prev, module
  "Vector Scope",         // name
  "Version 0.2 (28-07-2003)\n"
  "Copyright (C) 2003 Emliano Ferrari\n"
  "macinapepe@tiscali.it",// desc
  "Emiliano Ferrari",     // maker
  NULL,                   // private_data
  0,                      // inst_data_size
  NULL,                   // initProc
  NULL,                   // deinitProc
  RunProc,                // runProc
  ParamProc,              // paramProc
  NULL,                   // configProc
  NULL,                   // stringProc
  NULL,                   // startProc
  NULL,                   // endProc
  NULL,                   // script_obj
  NULL,                   // fssProc
};

static FilterDefinition *fd_vectorscope;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_vectorscope = ff->addFilter(fm, &filterDef_vectorscope, sizeof(FilterDefinition));
  if (!fd_vectorscope) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{  
  ff->removeFilter(fd_vectorscope);
}
