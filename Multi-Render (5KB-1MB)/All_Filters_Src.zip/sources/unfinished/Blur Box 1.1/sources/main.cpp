/*  Blur Box - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari   <macinapepe@tiscali.it>

    Box Blur code is part of VirtualDub
    Copyright (C) 1998,2001 Avery Lee

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// Version 0.1 (10-10-2003) EF
// Version 1.1 (21-05-2004) EF

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "ScriptValue.h"
#include "resource.h"

#define VLCN_PADCHANGE 2

typedef struct
{
  NMHDR hdr;
  int dx,dy;
} NMVLPADCHANGE;

const char g_szPadControlName[]="bbPadControl";

typedef struct
{
  int sx,sy,ex,ey;
  bool capture;
} PadControlData;


static LRESULT APIENTRY PadControlWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  PadControlData *pcd= (PadControlData *)GetWindowLong(hwnd, 0);

  switch(msg)
  {
    case WM_NCCREATE:
      if (!(pcd = new PadControlData)) return FALSE;
      memset(pcd,0,sizeof(PadControlData));
      pcd->capture= false;
      SetWindowLong(hwnd, 0, (LONG)pcd);
      return TRUE;

    case WM_CREATE:
    case WM_SIZE:
      break;

    case WM_DESTROY:
        delete pcd;
        SetWindowLong(hwnd, 0, 0);
        break;

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc;
        hdc= BeginPaint(hwnd, &ps);
        EndPaint(hwnd, &ps);
        break;
    }

    case WM_LBUTTONDOWN:
        {
          unsigned short px= LOWORD(lParam);
          unsigned short py= HIWORD(lParam);
          pcd->sx= *((short *)&px);
          pcd->sy= *((short *)&py);
          pcd->capture= true;
          SetCapture(hwnd);
        }
       break;

    case WM_LBUTTONUP:
        if (pcd->capture)
        {
          ReleaseCapture();
          pcd->capture= false;
        }
        break;

    case WM_MOUSEMOVE:
       if (pcd->capture)
       {
          unsigned short px= LOWORD(lParam);
          unsigned short py= HIWORD(lParam);
          pcd->ex= *((short *)&px);
          pcd->ey= *((short *)&py);
          NMVLPADCHANGE nmvltc;
          nmvltc.hdr.code    = VLCN_PADCHANGE;
          nmvltc.hdr.hwndFrom= hwnd;
          nmvltc.hdr.idFrom  = GetWindowLong(hwnd, GWL_ID);
          nmvltc.dx= pcd->ex-pcd->sx;
          nmvltc.dy= pcd->ey-pcd->sy;
          SendMessage(GetParent(hwnd), WM_NOTIFY, nmvltc.hdr.idFrom, (LPARAM)&nmvltc);
          pcd->sx= pcd->ex;
          pcd->sy= pcd->ey;
        }
        break;

    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return FALSE;
}

void RegisterPadControl(HINSTANCE hinst)
{

  WNDCLASS wc;
  wc.style= 0;
  wc.lpfnWndProc= PadControlWndProc;
  wc.cbClsExtra= 0;
  wc.cbWndExtra= sizeof(PadControlData *);
  wc.hInstance= hinst;
  wc.hIcon= NULL;
  wc.hCursor= LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground= (HBRUSH)(COLOR_3DFACE);
  wc.lpszMenuName= NULL;
  wc.lpszClassName= g_szPadControlName;
  RegisterClass(&wc);
}

#define MAX_KEYFRAMES 10000

class KEYFRAME
{
  private:
  int NF[MAX_KEYFRAMES];
  int VX[MAX_KEYFRAMES];
  int VY[MAX_KEYFRAMES];
  int VW[MAX_KEYFRAMES];
  int VH[MAX_KEYFRAMES];
  int VP[MAX_KEYFRAMES];
  int n;
  public:

  KEYFRAME() {n=1; VX[0]= 0; VY[0]=0; VW[0]=100; VH[0]=100; VP[0]=10;}

  bool Add (int Frame,int X,int Y,int W,int H,int P)
  {
    int i,j;
    for (i=0; i<n; i++)
      if (Frame==NF[i])
        {
          VX[i]= X;
          VY[i]= Y;
          VW[i]= W;
          VH[i]= H;
          VP[i]= P;
          return true;
        }
    if (n>=MAX_KEYFRAMES) return false;

    for (i=0; i<n; i++)
      if (Frame<NF[i])
        {
          for (j= i+1; j<n; j++)
          {
            NF[j]= NF[j-1];
            VX[j]= VX[j-1];
            VY[j]= VY[j-1];
            VW[j]= VW[j-1];
            VH[j]= VH[j-1];
            VP[j]= VP[j-1];
          }
          break;
        }
     n++;
     NF[i]= Frame;
     VX[i]= X;
     VY[i]= Y;
     VW[i]= W;
     VH[i]= H;
     VP[i]= P;
     return true;
  }

  void Clear() {n=1; VX[0]= 0; VY[0]=0; VW[0]=100; VH[0]=100; VP[0]=10;}

  bool Get(int frame,int &X,int &Y,int &W,int &H,int &P)
  {
    int i;
    if (n==0) return false;

    if (frame<NF[0])
    {
      X= VX[0];
      Y= VY[0];
      W= VW[0];
      H= VH[0];
      P= VP[0];
      return true;
    }

    if (frame>NF[n-1])
    {
      X= VX[n-1];
      Y= VY[n-1];
      W= VW[n-1];
      H= VH[n-1];
      P= VP[n-1];
      return true;
    }

    for (i=1; i<n; i++)
      if (frame<NF[i])
      {
        double DELTA= (double)(frame-NF[i-1])/(NF[i]-NF[i-1]);

        X= VX[i-1]+(int)((VX[i]-VX[i-1])*DELTA);
        Y= VY[i-1]+(int)((VY[i]-VY[i-1])*DELTA);
        W= VW[i-1]+(int)((VW[i]-VW[i-1])*DELTA);
        H= VH[i-1]+(int)((VH[i]-VH[i-1])*DELTA);
        P= VP[i-1]+(int)((VP[i]-VP[i-1])*DELTA);
        return true;
      }

   return false;
   }
};


typedef unsigned short Pixel16;

typedef struct
{
  IFilterPreview *ifp;
  Pixel32 *rows;
  Pixel16 *trow;
  int filter_width;
  int  x,y,w,h;
//  KEYFRAME keys;
} MyFilterData;

void box_filter_mult_row(Pixel16 *dst, Pixel32 *src, int cnt, int mult)
{
        __asm {
            mov         eax,src
            movd        mm6,mult
            mov         edx,dst
            punpcklwd   mm6,mm6
            mov         ecx,cnt
            punpckldq   mm6,mm6
            pxor        mm7,mm7
            lea         eax,[eax+ecx*4]
            lea         edx,[edx+ecx*8]
            neg         ecx
xloop:      movd        mm0,[eax+ecx*4]
            punpcklbw   mm0,mm7
            pmullw      mm0,mm6
            movq        [edx+ecx*8],mm0
            inc         ecx
            jne         xloop
            emms
        }
}

void box_filter_add_row(Pixel16 *dst, Pixel32 *src, int cnt)
{
  __asm {   mov       eax,src
            mov       edx,dst
            mov       ecx,cnt
            pxor      mm7,mm7
            lea       eax,[eax+ecx*4]
            lea       edx,[edx+ecx*8]
            neg       ecx
            align     16
xloop:      movd      mm0,[eax+ecx*4]
            punpcklbw mm0,mm7
            paddw     mm0,[edx+ecx*8]
            movq      [edx+ecx*8],mm0
            inc       ecx
            jne       xloop
            emms
        }
}

static void box_filter_produce_row(Pixel32 *dst, Pixel16 *tmp, Pixel32 *src_add, Pixel32 *src_sub, int cnt, int filter_width)
{
  int mult = 0x10000 / (2*filter_width+1);

   __asm {
      movd      mm6,mult
      punpcklwd mm6,mm6
      punpckldq mm6,mm6
      mov       eax,src_add
      mov       edx,tmp
      mov       ecx,cnt
      mov       ebx,src_sub
      mov       edi,dst
      pxor      mm7,mm7
      lea       edx,[edx+ecx*8]
      lea       eax,[eax+ecx*4]
      lea       ebx,[ebx+ecx*4]
      lea       edi,[edi+ecx*4]
      neg       ecx
      align     16
xloop:movq      mm0,[edx+ecx*8]
      movq      mm1,mm0
      pmulhw    mm0,mm6
      packuswb  mm0,mm0
      movd      [edi+ecx*4],mm0
      movd      mm2,[eax+ecx*4]
      punpcklbw mm2,mm7
      movd      mm3,[ebx+ecx*4]
      punpcklbw mm3,mm7
      paddw     mm2,mm1
      psubw     mm2,mm3
      movq      [edx+ecx*8],mm2
      inc       ecx
      jne       xloop
      emms
        }

}

static void box_filter_produce_row2(Pixel32 *dst, Pixel16 *tmp, int cnt, int filter_width)
{
  int mult = 0x10000 / (2*filter_width+1);

  __asm {

      mov        esi,[tmp]    // sorgente valori temporanei
      mov        edi,[dst]    // destinazione
      mov        ecx,[cnt]    // contatore

      lea        esi,[esi+ecx*8]
      lea        edi,[edi+ecx*4]
      neg        ecx

      movd       mm6,[mult]  // 16 bit  0000 0000 : 0000 mmmm
      punpcklwd  mm6,mm6
      punpckldq  mm6,mm6

      align      16
xloop:movq       mm0,[esi+ecx*8]    // legge 1 pixel  xxxx bbbb gggg rrrr
      pmulhw     mm0,mm6            // moltiplica per valore a 16 bit
      packuswb   mm0,mm0            // xxbbggrr:xxbbggrr
      movd       [edi+ecx*4],mm0 // write Pixel
      inc        ecx
      jnz        xloop
      emms
  }
}

void box_do_vertical_pass(Pixel32 *dst, PixOffset dstpitch, Pixel32 *src, PixOffset srcpitch, Pixel16 *trow, int w, int h, int filtwidth)
{
  Pixel32 *srch = src;
  int j;

  box_filter_mult_row(trow, src, w, filtwidth + 1);
  src = (Pixel32 *)((char *)src + srcpitch);
  for(j=0; j<filtwidth; j++)
  {
    box_filter_add_row(trow, src, w);
    src = (Pixel32 *)((char *)src + srcpitch);
  }

  for(j=0; j<filtwidth; j++)
  {
    box_filter_produce_row(dst, trow, src, srch, w, filtwidth);
    src = (Pixel32 *)((char *)src + srcpitch);
    dst = (Pixel32 *)((char *)dst + dstpitch);
  }

  for(j=0; j<h - (2*filtwidth+1); j++)
  {
    box_filter_produce_row(dst, trow, src, (Pixel32 *)((char *)src - srcpitch*(2*filtwidth+1)), w, filtwidth);
    src = (Pixel32 *)((char *)src + srcpitch);
    dst = (Pixel32 *)((char *)dst + dstpitch);
  }

  srch = (Pixel32 *)((char *)src - srcpitch);

  for(j=0; j<filtwidth; j++)
  {
    box_filter_produce_row(dst, trow, srch, (Pixel32 *)((char *)src - srcpitch*(2*filtwidth+1)), w, filtwidth);
    src = (Pixel32 *)((char *)src + srcpitch);
    dst = (Pixel32 *)((char *)dst + dstpitch);
   }

  box_filter_produce_row2(dst, trow, w, filtwidth);
}

static void __declspec(naked) box_filter_row_MMX(Pixel32 *dst, Pixel32 *src, int filtwidth, int cnt, int divisor)
{
    __asm {
        push        ebx

        mov         ecx,[esp+12+4]            ;ecx = filtwidth
        mov         eax,[esp+8+4]            ;eax = src
        movd        mm6,ecx
        pxor        mm7,mm7
        movd        mm5,[eax]                ;A = source pixel
        punpcklwd   mm6,mm6
        pcmpeqw     mm4,mm4                    ;mm4 = all -1's
        punpckldq   mm6,mm6
        psubw       mm6,mm4                    ;mm6 = filtwidth+1
        punpcklbw   mm5,mm7                    ;mm5 = src[0] (word)
        movq        mm0,mm5                    ;mm0 = A
        pmullw      mm5,mm6                    ;mm5 = src[0]*(filtwidth+1)
        add         eax,4                    ;next source pixel
xloop1:
        movd        mm1,[eax]                ;B = next source pixel
        pxor        mm7,mm7
        punpcklbw   mm1,mm7
        add         eax,4
        paddw       mm5,mm1
        dec         ecx
        jne         xloop1

        mov         ecx,[esp+12+4]            ;ecx = filtwidth
        movd        mm6,[esp+20+4]
        punpcklwd   mm6,mm6
        mov         edx,[esp+4+4]            ;edx = dst
        punpckldq   mm6,mm6
xloop2:
        movd        mm1,[eax]                ;B = next source pixel
        movq        mm2,mm5                    ;mm1 = accum

        pmulhw      mm2,mm6
        punpcklbw   mm1,mm7

        psubw       mm5,mm0                    ;accum -= A
        add         eax,4

        paddw       mm5,mm1                    ;accum += B
        add         edx,4

        packuswb    mm2,mm2
        dec         ecx

        movd        [edx-4],mm2
        jne         xloop2

        ;main loop.

        mov         ebx,[esp+12+4]            ;ebx = filtwidth
        mov         ecx,[esp+16+4]            ;ecx = cnt
        lea         ebx,[ebx+ebx+1]            ;ebx = 2*filtwidth+1
        sub         ecx,ebx                    ;ecx = cnt - (2*filtwidth+1)
        shl         ebx,2
        neg         ebx                        ;ebx = -4*(2*filtwidth+1)
xloop3:
        movd        mm0,[eax+ebx]            ;mm0 = A = src[-(2*filtwidth+1)]
        movq        mm2,mm5

        movd        mm1,[eax]                ;mm0 = B = src[0]
        pmulhw      mm2,mm6

        punpcklbw   mm0,mm7
        add         edx,4

        punpcklbw   mm1,mm7
        add         eax,4

        psubw       mm5,mm0                    ;accum -= A
        packuswb    mm2,mm2                    ;pack finished pixel

        paddw       mm5,mm1                    ;accum += B
        dec         ecx

        movd        [edx-4],mm2
        jne         xloop3

        ;finish up remaining pixels

        mov         ecx,[esp+12+4]            ;ecx = filtwidth
xloop4:
        movd        mm0,[eax+ebx]            ;mm0 = A = src[-(2*filtwidth+1)]
        movq        mm2,mm5

        pmulhw      mm2,mm6
        add         edx,4

        punpcklbw   mm0,mm7
        add         eax,4

        psubw       mm5,mm0                    ;accum -= A
        packuswb    mm2,mm2                    ;pack finished pixel

        paddw       mm5,mm1                    ;accum += B
        dec         ecx

        movd        [edx-4],mm2
        jne         xloop4

        pmulhw      mm5,mm6
        packuswb    mm5,mm5
        movd        [edx],mm5

        emms
        pop         ebx
        ret
    }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const int w= fa->dst.w;
  const int h= fa->dst.h;
  Pixel32 *dst= fa->dst.data;
  Pixel32 *src= fa->src.data;
  const int spitch= fa->src.pitch>>2;
  const int dpitch= fa->dst.pitch>>2;
  int fw= mfd->filter_width;
  const int mult= 0x10000/(2*fw+1);
  const int srcpitch= ((w+1)&-2)*4;
  const int dstpitch= fa->dst.pitch;
  Pixel32 *tmp= mfd->rows;

  if (!ff->isMMXEnabled) ff->Except ("MMX CPU Required");


  memcpy (dst,src,fa->dst.size);

  int x1= (w/2+mfd->x) - mfd->w/2;
  int x2= x1+mfd->w;
  int y1= (h/2-mfd->y) - mfd->h/2;
  int y2= y1+mfd->h;

  if (x1>x2) { int t=x1; x1=x2; x2=t; }
  if (y1>y2) { int t=y1; y1=y2; y2=t; }

  if (x2<0 || x1>w || y2<0 || y1>h) return 0;
  if (x1<0) x1= 0;
  if (x2>=w) x2= w-1;
  if (y1<0) y1= 0;
  if (y2>=h) y2= h-1;


  if (x2-x1<(fw*2+4)) return 0;
  if (y2-y1<(fw*2+4)) return 0;


  src+= x1+y1*spitch;
  dst+= x1+y1*dpitch;
  tmp+= x1+y1*((w+1)&-2);
  for (int y=y1; y<y2; y++)
  {
    box_filter_row_MMX(tmp,src,fw,x2-x1,mult);
    box_filter_row_MMX(dst,tmp,fw,x2-x1,mult);
    box_filter_row_MMX(tmp,dst,fw,x2-x1,mult);
    src+= spitch;
    dst+= dpitch;
    tmp+= (w+1)&-2;
  }
  src= mfd->rows+ (x1+y1*((w+1)&-2));
  dst= fa->dst.data + (x1+y1*dpitch);

  box_do_vertical_pass(dst,dstpitch, src,srcpitch, mfd->trow, x2-x1,y2-y1, fw);
  box_do_vertical_pass(src,srcpitch, dst,dstpitch, mfd->trow, x2-x1,y2-y1, fw);
  box_do_vertical_pass(dst,dstpitch, src,srcpitch, mfd->trow, x2-x1,y2-y1, fw);

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;

  mfd->x= 0;
  mfd->y= 0;
  mfd->w= 100;
  mfd->h= 100;
  mfd->filter_width= 10;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->filter_width<1) mfd->filter_width= 1;
  mfd->rows= NULL;
  mfd->trow= NULL;
  mfd->rows= new Pixel32[((fa->dst.w+1)&-2)*fa->dst.h+100];
  if (!mfd->rows) ff->ExceptOutOfMemory();
  mfd->trow= new Pixel16[fa->dst.w*4+100];
  if (!mfd->trow) ff->ExceptOutOfMemory();
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  delete[]mfd->rows; mfd->rows= NULL;
  delete[]mfd->trow; mfd->trow= NULL;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  return FILTERPARAM_SWAP_BUFFERS;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SetDlgItemInt(hdlg,IDC_X,mfd->x,true);
      SetDlgItemInt(hdlg,IDC_Y,mfd->y,true);
      SendMessage(GetDlgItem(hdlg,IDC_XSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(8192,-8192));
      SendMessage(GetDlgItem(hdlg,IDC_YSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(-8192,8192));
      SetDlgItemInt(hdlg,IDC_W,mfd->w,false);
      SetDlgItemInt(hdlg,IDC_H,mfd->h,false);
      SendMessage(GetDlgItem(hdlg,IDC_WSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(8192,0));
      SendMessage(GetDlgItem(hdlg,IDC_HSPIN),UDM_SETRANGE,0,(LPARAM)MAKELONG(0,8192));
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg); break;
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;
        case IDC_X:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int x= GetDlgItemInt(hdlg,IDC_X,NULL,true);
                if (x!=mfd->x)
                {
                  mfd->x= x;
                  mfd->ifp->RedoFrame();
                }
            }
            break;
        case IDC_Y:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int y= GetDlgItemInt(hdlg,IDC_Y,NULL,true);
                if (y!=mfd->y)
                {
                  mfd->y= y;
                  mfd->ifp->RedoFrame();
                }
            }
            break;
        case IDC_W:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int w= GetDlgItemInt(hdlg,IDC_W,NULL,false);
                if (w!=mfd->w)
                {
                  mfd->w= w;
                  mfd->ifp->RedoFrame();
                }
            }
            break;
        case IDC_H:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
            {
                int h= GetDlgItemInt(hdlg,IDC_H,NULL,false);
                if (h!=mfd->h)
                {
                  mfd->h= h;
                  mfd->ifp->RedoFrame();
                }
            }
            break;
      }
      break;

   case WM_NOTIFY:
      if (IDC_PAD==(int)wParam)
      {
        NMHDR *pnmh= (NMHDR *)lParam;
        NMVLPADCHANGE *pnmvltc= (NMVLPADCHANGE *)lParam;
        mfd->x+= pnmvltc->dx;
        mfd->y+= pnmvltc->dy;
        SetDlgItemInt(hdlg,IDC_X,mfd->x,true);
        SetDlgItemInt(hdlg,IDC_Y,mfd->y,true);
        mfd->ifp->RedoFrame();
      }
      else
    if (IDC_SIZEC==(int)wParam)
      {
        NMHDR *pnmh= (NMHDR *)lParam;
        NMVLPADCHANGE *pnmvltc= (NMVLPADCHANGE *)lParam;
        mfd->w+= pnmvltc->dx;
        mfd->h+= pnmvltc->dx;
         if (mfd->w<0) mfd->w=0;
        if (mfd->h<0) mfd->h=0;
        SetDlgItemInt(hdlg,IDC_W,mfd->w,false);
        SetDlgItemInt(hdlg,IDC_H,mfd->h,false);
        mfd->ifp->RedoFrame();
      }
      break;

    case WM_HSCROLL:
    case WM_VSCROLL:
    {
      int x= GetDlgItemInt(hdlg,IDC_X,NULL,true);
      int y= GetDlgItemInt(hdlg,IDC_Y,NULL,true);
      int w= GetDlgItemInt(hdlg,IDC_W,NULL,false);
      int h= GetDlgItemInt(hdlg,IDC_H,NULL,false);
      if (x!=mfd->x || y!=mfd->y || w!=mfd->w || h!=mfd->h)
      {
        mfd->x= x;
        mfd->y= y;
        mfd->w= w;
        mfd->h= h;
        mfd->ifp->RedoFrame();
      }
      break;
    }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  RegisterPadControl(fa->filter->module->hInstModule);
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_BLACKBOX),
                          hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return ret;
}

FilterDefinition filterDef_BlackBox=
{
  NULL, NULL, NULL,        // next, prev, module
  "Blur Box",             // name
  "Experimental Filter.\n"
  "Version 1.1 (21-05-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it", // desc
  "Emiliano Ferrari",      // maker
  NULL,                    // private_data
  sizeof(MyFilterData),    // inst_data_size
  InitProc,                // initProc
  NULL,                    // deinitProc
  RunProc,                 // runProc
  ParamProc,               // paramProc
  ConfigProc,              // configProc
  NULL,                    // stringProc
  StartProc,               // startProc
  EndProc,                 // endProc
  NULL,                    // script_obj
  NULL,                    // fssProc
};

static FilterDefinition *fd_BlackBox;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_BlackBox= ff->addFilter(fm, &filterDef_BlackBox, sizeof(FilterDefinition));
  if (!fd_BlackBox) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_BlackBox);
}
