/*  Waveform Monitor - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari  <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// version 1.0 (20-08-2003) EF
// version 1.1 (15-03-2004) EF: Versione sperimentale, NON FUNZIONA!! :)

#include "filter.h"

const int nl= 1;
const bool colors= false;
const bool pic= true;

Pixel32 Col[256+1];

unsigned char Digit[160] = {
    0x00, 0x00, 0x3C, 0x66, 0xC3, 0xC3, 0xDB, 0xDB, 0xC3, 0xC3, 0x66, 0x3C, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x18, 0x38, 0x78, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0x03, 0x06, 0x0C, 0x18, 0x30, 0x60, 0xC0, 0xFF, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0x03, 0x03, 0x3E, 0x03, 0x03, 0x03, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x06, 0xC6, 0xC6, 0xC6, 0xC6, 0xFF, 0x06, 0x06, 0x06, 0x06, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFF, 0xC0, 0xC0, 0xC0, 0xFE, 0x03, 0x03, 0x03, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x3E, 0x60, 0xC0, 0xC0, 0xFE, 0xC3, 0xC3, 0xC3, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFF, 0x03, 0x03, 0x06, 0x0C, 0x18, 0x30, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0xC3, 0xC3, 0x7E, 0xC3, 0xC3, 0xC3, 0xC3, 0x7E, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x7E, 0xC3, 0xC3, 0xC3, 0x7F, 0x03, 0x03, 0x03, 0x06, 0x7C, 0x00, 0x00, 0x00, 0x00};

int dh,dw,dpitch;
Pixel32 *dst;

void PutPixel (int x,int y,Pixel32 colore)
{
  if ((x<0) || (x>dw) || (y<0) || (y>dh)) return;
  dst[x+(dh-y)*dpitch]= colore;
}

void DrawNum (int px,int py,int num,Pixel32 color,Pixel32 bgcolor)
{
  char s[50];
  itoa (num,s,10);

  for (unsigned c=0; c<strlen(s); c++)
  {
    for (int j=0; j<16; j++)
    {
      int b= Digit[j+((int)(s[c])-48)*16];
      for (int i=0; i<9; i++)
      {
        if (b&128)
          PutPixel (px+i,py+j,color);
        else
          PutPixel (px+i,py+j,bgcolor);
        b<<= 1;
      }
    }
    px+= 9;
  }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  int w= fa->src.w;
  dw= w+64;
  int h= fa->src.h;
  dh= h+32;
  const int spitch= fa->src.pitch>>2;
  dpitch= fa->dst.pitch>>2;
  const int R2Y= 19611;
  const int G2Y= 38460;
  const int B2Y=  7465;
  Pixel32 *src= fa->src.data;
  Pixel32 *wfm= fa->dst.data;
  dst= fa->dst.data;

  int miny=256,maxy=0,minx=0,maxx=0;
  int x,y,r,g,b,Y,px,i;
  int l1=0;

  Col[0]= 0;
  Col[256]= 0xff00ff;

  for (i=1; i<256; i++)
  {
    int g= 64+i*16;
    int r= g-255;
    if (r<0) r=0;
    if (r>255) r= 255;
    if (g>255) g= 255;
    Col[i]= (r<<16) | (g<<8) | r;
  }

  memset(wfm,0,fa->dst.size);

  for (y=0; y<h; y+=nl)
  {
    for (x=0; x<w; x++)
    {
      px= src[x];

      r= (px>>16) & 0xff;
      g= (px>> 8) & 0xff;
      b= (px    ) & 0xff;
      Y= (R2Y*r +G2Y*g +B2Y*b+32768)>>16;

      if (Y<miny) {miny= Y; minx= x; }
      if (Y>maxy) {maxy= Y; maxx= x; }

      if (colors)
        wfm[8+x+(Y+16)*dpitch]= px;
      else
        if (wfm[8+x+(Y+16)*dpitch]<255) wfm[8+x+(Y+16)*dpitch]++;
    }
   src+= spitch;
  }

  if (!colors)
  {

  for (y=0; y<256; y++)
      for (x=0; x<w; x++)
      wfm[8+x+(y+16)*dpitch]= Col[wfm[8+x+(y+16)*dpitch]];
  }

  for (x=0; x<w+8; x++)
  {
    wfm[8+x+(0+16)*dpitch]= 0x606060;
    wfm[8+x+(-1+16)*dpitch]= 0x606060;
    wfm[8+x+(16+16)*dpitch]= 0x606060;
    wfm[8+x+(235+16)*dpitch]= 0x606060;
    wfm[8+x+(255+16)*dpitch]= 0x606060;
    wfm[8+x+(32+16)*dpitch]= 0x606060;
    wfm[8+x+(64+16)*dpitch]= 0x606060;
    wfm[8+x+(192+16)*dpitch]= 0x606060;
    wfm[8+x+(128+16)*dpitch]= 0x606060;
  }

  for (y=0; y<256; y++)
  {
      wfm[8+w+1+(y+16)*dpitch]= 0x606060;
      wfm[8+w+2+(y+16)*dpitch]= 0x606060;
  }


  for (x=1; x<8; x++)
  {
      wfm[w+x+8+(miny+16)*dpitch]= 0xff00ff;
      wfm[w+x+8+(maxy+16)*dpitch]= 0xff0000;
  }

  DrawNum (w+20,0,maxy,0xff0000,0);
//DrawNum (w+20,dh-16,miny,0xff00ff,0);


/*
  dst= fa->dst.data;
  for (j=0; j<256; j++)
    for (i=0; i<256; i++)
      dst[i+j*pitch]= Col[waveform[i+(j<<8)]];
  for (i=0; i<256; i++)
  {
      dst [i+(192*pitch)]^= 0x70510E;
      dst [i+(128*pitch)]^= 0x70510E;
      dst [i+( 64*pitch)]^= 0x70510E;
      dst [i+(med*pitch)]^= 0xffffff;
  }
  */
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.w= fa->src.w+64;
  fa->dst.pitch = (fa->dst.w*4 + 7) & -8;
  fa->dst.h= 256+32;
  return FILTERPARAM_SWAP_BUFFERS;
}

FilterDefinition filterDef_WFM=
{
  NULL,NULL,NULL,                 // next, prev, module
  "Waveform Monitor",             // name
  "...\n"
  "Version 1.1 (15-03-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",      // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  0,                              // inst_data_size
  NULL,                           // initProc
  NULL,                           // deinitProc
  RunProc,                        // runProc
  ParamProc,                      // paramProc
  NULL,                           // configProc
  NULL,                           // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  NULL,                           // script_obj
  NULL,                           // fssProc
};

static FilterDefinition *fd_WFM;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_WFM= ff->addFilter(fm, &filterDef_WFM, sizeof(FilterDefinition));
  if (!fd_WFM) return 1;
  vdfd_ver=    VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_WFM);
}
