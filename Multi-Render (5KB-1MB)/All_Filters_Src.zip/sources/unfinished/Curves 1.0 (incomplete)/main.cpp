/*  Curves - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "resource.h"
#include "ScriptValue.h"

#define CHANNEL_RGB       0
#define CHANNEL_RED       1
#define CHANNEL_GREEN     2
#define CHANNEL_BLUE      3
#define NUM_CHANNELS      4

#define MAX_POINTS       32

#define CT_FREE           0
#define CT_LINEAR         1
#define CT_SMOOTH         2

typedef char NAME[20];
NAME CHANNEL_NAME[]={"RGB","RED","GREEN","BLUE"};
NAME CURVE_NAME[]  ={"FREE","LINEAR","SMOOTH"};

typedef struct
{
  int CurrentChannel;
  int CurveType[NUM_CHANNELS];
  int iPoints[NUM_CHANNELS][MAX_POINTS];
  int oPoints[NUM_CHANNELS][MAX_POINTS];
  int Curve[NUM_CHANNELS][256];
  int lut[3*256];
  IFilterPreview *ifp;
} MyFilterData;

inline void Clipping (int &dato,int min,int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void BuildLut (MyFilterData *mfd)
{
  for (int i=0; i<256; i++)
  {
    mfd->lut[i    ]= mfd->Curve[CHANNEL_RGB][mfd->Curve[CHANNEL_RED  ][i]]<<16;
    mfd->lut[i+256]= mfd->Curve[CHANNEL_RGB][mfd->Curve[CHANNEL_GREEN][i]]<<8;
    mfd->lut[i+512]= mfd->Curve[CHANNEL_RGB][mfd->Curve[CHANNEL_BLUE ][i]];
  }
}

void ChannelReset (MyFilterData *mfd,int channel)
{
  mfd->CurveType[channel]= CT_FREE;
  mfd->iPoints[channel][0]= 0;
  mfd->oPoints[channel][0]= 0;
  for (int i=1; i<(MAX_POINTS-1); i++)
  {
    mfd->iPoints[channel][i]= -1;
    mfd->oPoints[channel][i]= -1;
  }
  mfd->iPoints[channel][MAX_POINTS-1]= 255;
  mfd->oPoints[channel][MAX_POINTS-1]= 255;

  for (int v=0; v<256; v++)
    mfd->Curve[channel][v]= v;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  const psize= fa->dst.size>>2;
  Pixel32 *dst= fa->dst.data;

  for (int p=0; p<psize; p++)
  {
    int R= (*dst>>16)&0xff;
    int G= (*dst>> 8)&0xff;
    int B= (*dst    )&0xff;
    *dst++= mfd->lut[R] | mfd->lut[G+256] | mfd->lut[B+512];
  }

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->CurrentChannel= CHANNEL_RGB;
  for (int ch=0; ch<NUM_CHANNELS; ch++)
    ChannelReset (mfd,ch);
  BuildLut(mfd);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

// ========= [GIMP] ====================
typedef double Matrix[4][4];

Matrix CR_basis=
{
  { -0.5,  1.5, -1.5,  0.5 },
  {  1.0, -2.5,  2.0, -0.5 },
  { -0.5,  0.0,  0.5,  0.0 },
  {  0.0,  1.0,  0.0,  0.0 },
};

void MulMat (Matrix a,Matrix b,Matrix ab)
{
  for (int i=0; i<4; i++)
    for (int j=0; j<4; j++)
      ab[i][j]= (a[i][0]*b[0][j] + a[i][1]*b[1][j]
               + a[i][2]*b[2][j] + a[i][3]*b[3][j]);
}

void PlotCurve (MyFilterData *mfd,int channel,int p1,int p2,int p3,int p4)
{
  Matrix geometry;
  Matrix tmp1, tmp2;
  Matrix deltas;
  double  x, dx, dx2, dx3;
  double  y, dy, dy2, dy3;
  double  d, d2, d3;
  int     lastx, lasty;
  int     newx, newy;
  int     i;

  /* construct the geometry matrix from the segment */
  for (i=0; i<4; i++)
  {
    geometry[i][2]= 0;
    geometry[i][3]= 0;
  }
  geometry[0][0]= mfd->iPoints[channel][p1];
  geometry[1][0]= mfd->iPoints[channel][p2];
  geometry[2][0]= mfd->iPoints[channel][p3];
  geometry[3][0]= mfd->iPoints[channel][p4];
  geometry[0][1]= mfd->oPoints[channel][p1];
  geometry[1][1]= mfd->oPoints[channel][p2];
  geometry[2][1]= mfd->oPoints[channel][p3];
  geometry[3][1]= mfd->oPoints[channel][p4];

  /* subdivide the curve 1000 times */
  /* n can be adjusted to give a finer or coarser curve */
  d = 1.0/1000;
  d2= d*d;
  d3= d*d*d;

  /* construct a temporary matrix for determining
     the forward differencing deltas */
  tmp2[0][0]= 0;     tmp2[0][1]= 0;     tmp2[0][2]= 0;    tmp2[0][3]= 1;
  tmp2[1][0]= d3;    tmp2[1][1]= d2;    tmp2[1][2]= d;    tmp2[1][3]= 0;
  tmp2[2][0]= 6*d3;  tmp2[2][1]= 2*d2;  tmp2[2][2]= 0;    tmp2[2][3]= 0;
  tmp2[3][0]= 6*d3;  tmp2[3][1]= 0;     tmp2[3][2]= 0;    tmp2[3][3]= 0;

  /* compose the basis and geometry matrices */
  MulMat (CR_basis, geometry, tmp1);

  /* compose the above results to get the deltas matrix */
  MulMat (tmp2, tmp1, deltas);

  /* extract the x deltas */
  x  = deltas[0][0];
  dx = deltas[1][0];
  dx2= deltas[2][0];
  dx3= deltas[3][0];

  /* extract the y deltas */
  y  = deltas[0][1];
  dy = deltas[1][1];
  dy2= deltas[2][1];
  dy3= deltas[3][1];

  lastx= (int)x;
  lasty= (int)y;
  Clipping (lastx,0,255);
  Clipping (lasty,0,255);

  mfd->Curve[channel][lastx]= lasty;

  /* loop over the curve */
  for (i = 0; i < 1000; i++)
  {
    /* increment the x values */
    x  += dx;
    dx += dx2;
    dx2+= dx3;

    /* increment the y values */
    y  += dy;
    dy += dy2;
    dy2+= dy3;

    newx= (int)x;
    newy= (int)y;

    Clipping(newx,0,255);
    Clipping(newy,0,255);

    /* if this point is different than the last one...then draw it */
    if ((lastx != newx) || (lasty != newy)) mfd->Curve[channel][newx]= newy;
    lastx = newx;
    lasty = newy;
  }
}
// ============ end [GIMP] ========================

void Calculate_Curve (MyFilterData *mfd,int channel)
{
  int i,points[MAX_POINTS],up=0;

  for (int p=0; p<MAX_POINTS; p++)
    if (mfd->iPoints[channel][p]!= -1)
      points[up++]= p;

  switch (mfd->CurveType[channel])
  {
    case CT_FREE:
    break;

    case CT_LINEAR:
      for (i=0; i<mfd->iPoints[channel][points[0]]; i++)
        mfd->Curve[channel][i]= mfd->oPoints[channel][points[0]];
      for (i=mfd->iPoints[channel][points[up-1]]; i<256; i++)
        mfd->Curve[channel][i]= mfd->oPoints[channel][points[up-1]];
      for (i=1; i<up; i++)
      {
          int x1= mfd->iPoints[channel][points[i-1]];
          int y1= mfd->oPoints[channel][points[i-1]];
          int x2= mfd->iPoints[channel][points[i]];
          int y2= mfd->oPoints[channel][points[i]];
          for (int x=x1; x<=x2; x++)
             mfd->Curve[channel][x]= (int)(y1+(double)(x-x1)
                                       /(double)(x2-x1)*(double)(y2-y1));
      }
    break;

    case CT_SMOOTH:
      for (i=0; i<mfd->iPoints[channel][points[0]]; i++)
        mfd->Curve[channel][i]= mfd->oPoints[channel][points[0]];
      for (i=mfd->iPoints[channel][points[up-1]]; i<256; i++)
        mfd->Curve[channel][i]= mfd->oPoints[channel][points[up-1]];
      for (i=0; i<up-1; i++)
      {
          int p1= (i==0)?points[i]:points[(i-1)];
          int p2= points[i];
          int p3= points[(i+1)];
          int p4= (i==(up-2))?points[(up-1)]:points[(i+2)];
        PlotCurve (mfd, channel, p1, p2, p3, p4);
       }
    break;
  }
}

void Import_AMP_File(MyFilterData *mfd,HWND hwnd)
{
  MyFilterData new_mfd= *mfd;
  char filename[1024]= "\0";
  OPENFILENAME ofn;
  ofn.lStructSize      = sizeof(OPENFILENAME);
  ofn.hwndOwner        = hwnd;
  ofn.lpTemplateName   = NULL;
  ofn.lpstrFilter      =
          "PhotoShop Arbitrary Map Settings (*.amp)\0*.amp\0All files\0*.*\0";
  ofn.lpstrCustomFilter= NULL;
  ofn.nFilterIndex     = NULL;
  ofn.lpstrFile        = filename;
  ofn.nMaxFile         = 1024;
  ofn.lpstrFileTitle   = NULL;
  ofn.lpstrInitialDir  = NULL;
  ofn.lpstrTitle       = NULL;
  ofn.Flags            = OFN_FILEMUSTEXIST | OFN_EXPLORER | OFN_PATHMUSTEXIST;
  ofn.nFileOffset      = 0;
  ofn.nFileExtension   = 0;
  ofn.lpstrDefExt      = "amp";
  ofn.lCustData        = 0;
  ofn.lpfnHook         = NULL;
  if (!((GetOpenFileName(&ofn)) && (filename[0]!=0))) return;

  FILE *f;
  if (!(f= fopen (filename,"rb"))) return;

  fseek (f,0,SEEK_END);
  int fsize= ftell(f);
  rewind(f);

  if (fsize==(256*5))
  {
    for (int ch=0; ch<NUM_CHANNELS; ch++)
    {
      new_mfd.CurveType[ch]= CT_FREE;
      for (int i= 0; i<256; i++)
        new_mfd.Curve[ch][i]= fgetc(f);
    }
  }
  fclose(f);
  *mfd= new_mfd;
}

void Export_AMP_File(MyFilterData *mfd,HWND hdlg)
{
  static char filename[1024]= "\0";
  OPENFILENAME ofn;
  ofn.lStructSize      = sizeof(OPENFILENAME);
  ofn.hwndOwner        = hdlg;
  ofn.lpTemplateName   = NULL;
  ofn.lpstrFilter      =
          "PhotoShop Arbitrary Map Settings (*.amp)\0*.amp\0All files\0*.*\0";
  ofn.lpstrCustomFilter= NULL;
  ofn.nFilterIndex     = NULL;
  ofn.lpstrFile        = filename;
  ofn.nMaxFile         = 1024;
  ofn.lpstrFileTitle   = NULL;
  ofn.lpstrInitialDir  = NULL;
  ofn.lpstrTitle       = NULL;
  ofn.Flags            = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_PATHMUSTEXIST;
  ofn.nFileOffset      = 0;
  ofn.nFileExtension   = 0;
  ofn.lpstrDefExt      = "amp";
  ofn.lCustData        = 0;
  ofn.lpfnHook         = NULL;

  if (!GetSaveFileName(&ofn)) return;
  FILE *f;
  int ch,i;
  if (!(f= fopen (filename,"wb"))) return;

  for (ch=0; ch<NUM_CHANNELS; ch++)
    for (i= 0; i<256; i++)
      fprintf(f,"%c",char(mfd->Curve[ch][i]));

  for (i= 0; i<256; i++) fprintf(f,"%c",char(i)); // dummy channel

  fclose (f);
}

void SAVE_FILE(MyFilterData *mfd,HWND hdlg)
{
  static char filename[1024];
  OPENFILENAME ofn;
  filename[0]= NULL;
  ofn.lStructSize      = sizeof(OPENFILENAME);
  ofn.hwndOwner        = hdlg;
  ofn.lpTemplateName   = NULL;
  ofn.lpstrFilter      = "Curves file (*.cvf)\0*.cvf\0All files\0*.*\0";
  ofn.lpstrCustomFilter= NULL;
  ofn.nFilterIndex     = NULL;
  ofn.lpstrFile        = filename;
  ofn.nMaxFile         = 1024;
  ofn.lpstrFileTitle   = NULL;
  ofn.lpstrInitialDir  = NULL;
  ofn.lpstrTitle       = NULL;
  ofn.Flags            = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_PATHMUSTEXIST;
  ofn.nFileOffset      = 0;
  ofn.nFileExtension   = 0;
  ofn.lpstrDefExt      = "cvf";
  ofn.lCustData        = 0;
  ofn.lpfnHook         = NULL;
  if (GetSaveFileName(&ofn))
    {
       FILE *f;
       if (f= fopen (filename,"w"))
         {
           fprintf (f,"%d %d\n",NUM_CHANNELS,MAX_POINTS);
           for (int channel=0; channel<NUM_CHANNELS; channel++)
           {
             fprintf (f,"%d %d\n",channel,mfd->CurveType[channel]);
             if (mfd->CurveType[channel]!=CT_FREE)
               for (int i=0; i<MAX_POINTS; i++)
                 fprintf (f,"%d %d\n",mfd->iPoints[channel][i],mfd->oPoints[channel][i]);
               else
                 for (int y=0; y<16; y++)
                 {
                 for (int x=0; x<16; x++)
                   fprintf (f,"%3d ",mfd->Curve[channel][x+y*16]);
                 fprintf (f,"\n");
                 }
           }
           fclose (f);
         }
    }
}

void LOAD_FILE(MyFilterData *mfd,HWND hdlg)
{
  MyFilterData new_mfd= *mfd;
  char filename[1024];
  OPENFILENAME ofn;
  FILE *f;
  int fields,nc,mp,ch,ct,i,in,out;
  filename[0]= NULL;
  ofn.lStructSize      = sizeof(OPENFILENAME);
  ofn.hwndOwner        = hdlg;
  ofn.lpTemplateName   = NULL;
  ofn.lpstrFilter      = "Curves file (*.cvf)\0*.cvf\0All files\0*.*\0";
  ofn.lpstrCustomFilter= NULL;
  ofn.nFilterIndex     = NULL;
  ofn.lpstrFile        = filename;
  ofn.nMaxFile         = 1024;
  ofn.lpstrFileTitle   = NULL;
  ofn.lpstrInitialDir  = NULL;
  ofn.lpstrTitle       = NULL;
  ofn.Flags            = OFN_FILEMUSTEXIST | OFN_EXPLORER | OFN_PATHMUSTEXIST;
  ofn.nFileOffset      = 0;
  ofn.nFileExtension   = 0;
  ofn.lpstrDefExt      = "cvf";
  ofn.lCustData        = 0;
  ofn.lpfnHook         = NULL;
  if (!((GetOpenFileName(&ofn)) && (filename[0]!=0))) return;
  if (!(f= fopen (filename,"r"))) return;
  fields= fscanf (f,"%d %d",&nc,&mp);
  if (fields!=2) { fclose(f); return; }
  if (nc!=NUM_CHANNELS) { fclose(f); return; }
  if (mp!=MAX_POINTS) { fclose(f); return; }
  for (int channel=0; channel<NUM_CHANNELS; channel++)
  {
    fields= fscanf (f,"%d %d",&ch,&ct);
    if (fields!=2) { fclose(f); return; }
    if (ch!=channel) { fclose(f); return; }
    if (ct<0 || ct>3) { fclose(f); return; }
    new_mfd.CurveType[channel]= ct;
    if (ct==CT_FREE)
      for (i=0; i<256; i++)
      {
        fields= fscanf (f,"%d",&new_mfd.Curve[channel][i]);
        if (fields!=1) { fclose(f); return; }
      }
    else
      for (i=0; i<MAX_POINTS; i++)
      {
        fields= fscanf (f,"%d %d",&in,&out);
        if (fields!=2) { fclose(f); return; }
        if (in<0 || in>255 || out<0 || out>255) { fclose(f); return; }
        new_mfd.iPoints[channel][i]= in;
        new_mfd.oPoints[channel][i]= out;
      }
  }
  fclose(f);
  *mfd= new_mfd;
}

void DrawControl(HDC hdc,int x,int y)
{
  HPEN  hPen,oldPen;
  hPen  = CreatePen(PS_SOLID,1,RGB(0,0,0));
  oldPen= (HPEN)SelectObject(hdc,hPen);
  Rectangle(hdc,x-3,y-3,x+4,y+4);
  SelectObject(hdc,oldPen);
  DeleteObject(hPen);
}

void DrawCurve(HWND hwnd)
{
  int i;
  RECT rect;
 
 // InvalidateRect(hwnd,NULL,TRUE);
 // UpdateWindow(hwnd);  
  GetClientRect(hwnd, &rect);
  HDC hdc= GetDC(hwnd);

  
  int cx= (rect.left+rect.right)/2;
  int cy= (rect.top+rect.bottom)/2;

  rect.top= cy-128;
  rect.left= cx-128;
  rect.bottom= rect.top+256;
  rect.right= rect.left+256;

  HBRUSH hbr= CreateSolidBrush(RGB(255,255,255));
  FillRect(hdc,&rect,hbr);
  DeleteObject(hbr);
        
  // Traccia Griglia    
  double StepX= (rect.right-rect.left)/8.0;
  double StepY= (rect.bottom-rect.top)/8.0;
  HPEN hpen= CreatePen(PS_DOT,1,RGB(232,232,232));
  SelectObject (hdc,hpen);
  

  for (i=1; i<8; i++)
  {
    MoveToEx(hdc,rect.left+(int)(StepX*i),rect.top,NULL);
    LineTo(hdc, rect.left + (int)(StepX * i), rect.bottom - 1);
    MoveToEx(hdc, rect.left, rect.bottom - (int)(StepY * i) - 1, NULL);
    LineTo(hdc, rect.right, rect.bottom - (int)(StepY * i) - 1);
  }
  DeleteObject(hpen);

  StepX= (rect.right-rect.left)/4.0;
  StepY= (rect.bottom-rect.top)/4.0;
  hpen= CreatePen(PS_SOLID,1,RGB(192,192,192));
  SelectObject (hdc,hpen);
  for (i=1; i<4; i++)
  {
    MoveToEx(hdc,rect.left+(int)(StepX*i),rect.top,NULL);
    LineTo(hdc, rect.left + (int)(StepX * i), rect.bottom - 1);
    MoveToEx(hdc, rect.left, rect.bottom - (int)(StepY * i) - 1, NULL);
    LineTo(hdc, rect.right, rect.bottom - (int)(StepY * i) - 1);
  }
  DeleteObject(hpen);


  /*
  // Curve
  HPEN hPen= CreatePen(PS_SOLID,1,RGB(0,0,0));
  SelectObject (hdc,hPen);
  double scaleX= (rect.right - rect.left) / 256.0;
  double scaleY= (rect.bottom - rect.top) / 256.0;

  MoveToEx(hdc, rect.left, rect.bottom - (int)(scaleY * (mfd->Curve[mfd->CurrentChannel][0])+1), NULL);
  for(i= 0; i < 256; i++)
    LineTo(hdc, rect.left + (int)((scaleX * (i))), rect.bottom - (int)(scaleY * (mfd->Curve[mfd->CurrentChannel][i])+1));
  LineTo(hdc, rect.left + (int)((scaleX * (255))), rect.bottom - (int)(scaleY * (mfd->Curve[mfd->CurrentChannel][255])));

  DeleteObject(hPen);

  if (mfd->CurveType[mfd->CurrentChannel]!=CT_FREE)
  {
    for (i=0; i<MAX_POINTS; i++)
      if (mfd->iPoints[mfd->CurrentChannel][i]>0)
        if (mfd->oPoints[mfd->CurrentChannel][i]>0)
           DrawControl(hdc,rect.left+(int)(scaleX*mfd->iPoints[mfd->CurrentChannel][i]),rect.bottom-(int)(scaleY*(mfd->oPoints[mfd->CurrentChannel][i])));
  }
  */
  
ReleaseDC(hwnd, hdc);
}

void DrawHBar(HWND hwnd, MyFilterData *mfd,bool inv)
{
  RECT rect;
  HDC  hdc;

  int r,g,b;
  int ir,ig,ib;

  if (inv)
  {
  InvalidateRect(hwnd,NULL,TRUE);
  UpdateWindow(hwnd);
  }
  GetClientRect(hwnd,&rect);
  hdc= GetDC(hwnd);

  r=g=b= 0;

  switch(mfd->CurrentChannel)
  {
    case CHANNEL_RGB  : ir= 255; ig= 255; ib= 255; break;
    case CHANNEL_RED  : ir= 255; ig=   0; ib=   0; break;
    case CHANNEL_GREEN: ir=   0; ig= 255; ib=   0; break;
    case CHANNEL_BLUE : ir=   0; ig=   0; ib= 255; break;
  }

  ir= (ir<<16)/rect.right;
  ig= (ig<<16)/rect.right;
  ib= (ib<<16)/rect.right;

  for (int i= 0; i<rect.right; i++)
  {
    RECT temp;
    HBRUSH color;

    temp.left=   i;
    temp.right=  i+1;
    temp.top=    0;
    temp.bottom= rect.bottom;
    color= CreateSolidBrush(RGB(r>>16,g>>16,b>>16));
    r+= ir;
    g+= ig;
    b+= ib;
    FillRect(hdc,&temp,color);
    DeleteObject(color);
  }

  ReleaseDC(hwnd, hdc);
}

void DrawVBar(HWND hwnd, MyFilterData *mfd,bool inv)
{
  RECT rect;
  HDC  hdc;

  int r,g,b;
  int ir,ig,ib;

  if (inv)
  {
  InvalidateRect(hwnd,NULL,TRUE);
  UpdateWindow(hwnd);
  }
  GetClientRect(hwnd,&rect);
  hdc= GetDC(hwnd);

  r=g=b= 0;

  switch(mfd->CurrentChannel)
  {
    case CHANNEL_RGB  : ir= 255; ig= 255; ib= 255; break;
    case CHANNEL_RED  : ir= 255; ig=   0; ib=   0; break;
    case CHANNEL_GREEN: ir=   0; ig= 255; ib=   0; break;
    case CHANNEL_BLUE : ir=   0; ig=   0; ib= 255; break;
  }

  ir= (ir<<16)/rect.bottom;
  ig= (ig<<16)/rect.bottom;
  ib= (ib<<16)/rect.bottom;

  for (int i= rect.bottom-1; i>=0; i--)
  {
    RECT temp;
    HBRUSH color;

    temp.left=   0;
    temp.right=  rect.right;
    temp.top=    i;
    temp.bottom= i+1;
    color= CreateSolidBrush(RGB(r>>16,g>>16,b>>16));
    r+= ir;
    g+= ig;
    b+= ib;
    FillRect(hdc,&temp,color);
    DeleteObject(color);
  }

  ReleaseDC(hwnd, hdc);
}

void UPDATE (HWND hdlg,MyFilterData *mfd)
{
  CheckDlgButton(hdlg,IDC_FREE,(CT_FREE==mfd->CurveType[mfd->CurrentChannel]) ? BST_CHECKED : BST_UNCHECKED);
  CheckDlgButton(hdlg,IDC_LINEAR,(CT_LINEAR==mfd->CurveType[mfd->CurrentChannel]) ? BST_CHECKED : BST_UNCHECKED);
  CheckDlgButton(hdlg,IDC_SMOOTH,(CT_SMOOTH==mfd->CurveType[mfd->CurrentChannel]) ? BST_CHECKED : BST_UNCHECKED);

  
//  DrawCurve(GetDlgItem(hdlg,IDC_GRAPH),mfd,false);
  DrawHBar (GetDlgItem(hdlg,IDC_HBAR ),mfd,false);
  DrawVBar (GetDlgItem(hdlg,IDC_VBAR ),mfd,false);
  
}


#define CCCN_CHANGE 2

typedef struct
{
  NMHDR hdr;
  int dx,dy;
} NMCC_CHANGE;

const char g_szControlName[]="bbCurveControl";

typedef struct
{
  MyFilterData tmfd;
  int sx,sy,ex,ey;
  bool capture;  
} ControlData;

static LRESULT APIENTRY ControlWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  ControlData *cd= (ControlData *)GetWindowLong(hwnd, 0);

  switch(msg)
  {
    case WM_NCCREATE:
      if (!(cd = new ControlData)) return FALSE;
      memset(cd,0,sizeof(ControlData));
      cd->capture= false;
      SetWindowLong(hwnd,0,(LONG)cd);
      return TRUE;

    case WM_CREATE:
    case WM_SIZE:
      break;

    case WM_DESTROY:
        delete cd;
        SetWindowLong(hwnd,0,0);
        break;

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc;
        hdc= BeginPaint(hwnd, &ps);
        DrawCurve(hwnd);        
        EndPaint(hwnd, &ps);
        break;
    }

    case WM_LBUTTONDOWN:
        {
          unsigned short px= LOWORD(lParam);
          unsigned short py= HIWORD(lParam);
          cd->sx= *((short *)&px);
          cd->sy= *((short *)&py);
          cd->capture= true;
          SetCapture(hwnd);
        }
       break;

    case WM_LBUTTONUP:
        if (cd->capture)
        {
          ReleaseCapture();
          cd->capture= false;
        }
        break;

    case WM_MOUSEMOVE:
       if (cd->capture)
       {
          unsigned short px= LOWORD(lParam);
          unsigned short py= HIWORD(lParam);
          cd->ex= *((short *)&px);
          cd->ey= *((short *)&py);
          NMCC_CHANGE nmccc;
          nmccc.hdr.code    = CCCN_CHANGE;
          nmccc.hdr.hwndFrom= hwnd;
          nmccc.hdr.idFrom  = GetWindowLong(hwnd, GWL_ID);
          nmccc.dx= cd->ex-cd->sx;
          nmccc.dy= cd->ey-cd->sy;
          SendMessage(GetParent(hwnd), WM_NOTIFY, nmccc.hdr.idFrom, (LPARAM)&nmccc);
          cd->sx= cd->ex;
          cd->sy= cd->ey;
        }
        break;

    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return FALSE;
}

void RegisterControl(HINSTANCE hinst)
{
 
  WNDCLASS wc;
  wc.style= 0;
  wc.lpfnWndProc= ControlWndProc;
  wc.cbClsExtra= 0;
  wc.cbWndExtra= sizeof(ControlData *);
  wc.hInstance= hinst;
  wc.hIcon= NULL;
  wc.hCursor= LoadCursor(NULL, IDC_CROSS);
  wc.hbrBackground= (HBRUSH)(COLOR_3DFACE);
  wc.lpszMenuName= NULL;
  wc.lpszClassName= g_szControlName;
  RegisterClass(&wc);
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  int ch;

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
     
      for (ch=0; ch<NUM_CHANNELS; ch++)
        SendMessage(GetDlgItem(hdlg,IDC_CHANNEL),CB_INSERTSTRING,ch,(long)CHANNEL_NAME[ch]);
      SendMessage(GetDlgItem(hdlg,IDC_CHANNEL),CB_SETCURSEL,mfd->CurrentChannel,0);

      CheckDlgButton(hdlg,IDC_FREE,(CT_FREE==mfd->CurveType[mfd->CurrentChannel]) ? BST_CHECKED : BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_LINEAR,(CT_LINEAR==mfd->CurveType[mfd->CurrentChannel]) ? BST_CHECKED : BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_SMOOTH,(CT_SMOOTH==mfd->CurveType[mfd->CurrentChannel]) ? BST_CHECKED : BST_UNCHECKED);

      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

     case WM_PAINT:
    {
      PAINTSTRUCT ps;
    DrawHBar (GetDlgItem(hdlg,IDC_HBAR ),mfd,true);
      DrawVBar (GetDlgItem(hdlg,IDC_VBAR ),mfd,true);
      
     BeginPaint(hdlg, &ps);
     EndPaint(hdlg, &ps);          
    }
    return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDPREVIEW:mfd->ifp->Toggle(hdlg);  break;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;

        case IDC_CHANNEL:
          if (HIWORD(wParam)== CBN_SELCHANGE)
          {
            mfd->CurrentChannel= SendDlgItemMessage(hdlg,IDC_CHANNEL,CB_GETCURSEL,0,0);
            UPDATE (hdlg,mfd);
          }
          return TRUE;

        case IDHELP:
        {
          char prog[256];
          char path[256];
          LPTSTR ptr;
          GetModuleFileName(NULL, prog, 255);
          GetFullPathName(prog, 255, path, &ptr);
          *ptr = 0;
          strcat(path, "plugins\\curves.html");
          ShellExecute(hdlg, "open", path, NULL, NULL, SW_SHOWNORMAL);
          return TRUE;
        }

        case IDC_LOAD:
          LOAD_FILE(mfd,hdlg);

          for (ch=0; ch<NUM_CHANNELS; ch++) Calculate_Curve(mfd,ch);

          mfd->CurrentChannel= CHANNEL_RGB;
          SendMessage(GetDlgItem(hdlg,IDC_CHANNEL),CB_SETCURSEL,mfd->CurrentChannel,0);
          BuildLut(mfd);
          UPDATE (hdlg,mfd);
          mfd->ifp->RedoFrame();
          break;

        case IDC_SAVE:
          SAVE_FILE(mfd,hdlg);
          break;

        case IDC_IMPORT_AMP:
          Import_AMP_File(mfd,hdlg);
          mfd->CurrentChannel= CHANNEL_RGB;
          SendMessage(GetDlgItem(hdlg,IDC_CHANNEL),CB_SETCURSEL,mfd->CurrentChannel,0);
          BuildLut(mfd);
          UPDATE (hdlg,mfd);
          mfd->ifp->RedoFrame();
          break;

        case IDC_EXPORT_AMP:
          Export_AMP_File(mfd,hdlg);
          break;

        case IDC_RESET_ALL:
          mfd->CurrentChannel= CHANNEL_RGB;
          SendMessage(GetDlgItem(hdlg,IDC_CHANNEL),CB_SETCURSEL,mfd->CurrentChannel,0);
          for (ch=0; ch<NUM_CHANNELS; ch++) ChannelReset (mfd,ch);
          BuildLut(mfd);
          UPDATE (hdlg,mfd);
          mfd->ifp->RedoFrame();
          break;

        case IDC_RESET:
          ChannelReset (mfd,mfd->CurrentChannel);
          BuildLut (mfd);
          UPDATE (hdlg,mfd);
          mfd->ifp->RedoFrame();
          break;

           case IDC_FREE:
            if (IsDlgButtonChecked(hdlg, IDC_FREE))
              mfd->CurveType[mfd->CurrentChannel]= CT_FREE;
              InvalidateRgn(hdlg,NULL,FALSE);
              mfd->ifp->RedoFrame();
            break;
        case IDC_LINEAR:
            // TODO: Ricreare la curva se CT_FREE
            if (IsDlgButtonChecked(hdlg, IDC_LINEAR))
              mfd->CurveType[mfd->CurrentChannel]= CT_LINEAR;
            Calculate_Curve(mfd,mfd->CurrentChannel);
          BuildLut(mfd);
          InvalidateRgn(hdlg,NULL,FALSE);
            mfd->ifp->RedoFrame();
            break;
         case IDC_SMOOTH:
            // TODO: Ricreare la curva se CT_FREE
            if (IsDlgButtonChecked(hdlg, IDC_SMOOTH))
              mfd->CurveType[mfd->CurrentChannel]= CT_SMOOTH;
            Calculate_Curve(mfd,mfd->CurrentChannel);
               BuildLut(mfd);
          InvalidateRgn(hdlg,NULL,FALSE);
            mfd->ifp->RedoFrame();
            break;
      }
      break;

     
    case WM_NOTIFY:
      if (IDC_GRAPH==(int)wParam)
      {
        NMHDR *pnmh= (NMHDR *)lParam;
        NMCC_CHANGE *pnmccc= (NMCC_CHANGE *)lParam;
        /*
        mfd->Curve[mfd->CurrentChannel]= pnmccc->Curve;
        Calculate_Curve(mfd,mfd->CurrentChannel);
        BuildLut(mfd);
        
        mfd->x+= pnmccc->dx;
        mfd->y+= pnmccc->dy;
        if (mfd->x<0) mfd->x=0;
        if (mfd->y<0) mfd->y=0;
        SetDlgItemInt(hdlg,IDC_X,mfd->x,false);
        SetDlgItemInt(hdlg,IDC_Y,mfd->y,false);
        */
        mfd->ifp->RedoFrame();
      }
      break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  RegisterControl(fa->filter->module->hInstModule);
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_CURVES),
                          hwnd,ConfigDlgProc,(LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return !!ret;
}

FilterDefinition filterDef_Curves=
{
  NULL,NULL,NULL,                 // next, prev, module
  "Curves",                       // name
  "Adjust RGB channels by curves.\n"
  "Version 1.0 (20-01-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",      // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  sizeof(MyFilterData),           // inst_data_size
  InitProc,                       // initProc
  NULL,                           // deinitProc
  RunProc,                        // runProc
  ParamProc,                      // paramProc
  ConfigProc,                     // configProc
  NULL,                           // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  NULL,                           // script_obj
  NULL,                           // fssProc
};

static FilterDefinition *fd_Curves;

extern "C" int __declspec(dllexport) __cdecl
VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff,
                                            int& vdfd_ver, int& vdfd_compat)
{
  fd_Curves= ff->addFilter(fm, &filterDef_Curves, sizeof(FilterDefinition));
  if (!fd_Curves) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl
VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_Curves);
}
