//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_CURVES               103
#define IDR_MENU_CURVES                 105
#define IDC_CHANNEL                     1014
#define IDC_VBAR                        1015
#define IDC_HBAR                        1016
#define IDC_GRAPH                       1017
#define IDC_FREE                        1020
#define IDC_IN                          1021
#define IDC_LINEAR                      1022
#define IDC_SMOOTH                      1023
#define IDC_OUT                         1024
#define IDC_LOAD                        40001
#define IDC_SAVE                        40002
#define IDC_IMPORT_AMP                  40003
#define IDC_EXPORT_AMP                  40004
#define IDC_RESET_ALL                   40005
#define IDC_RESET                       40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40012
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
