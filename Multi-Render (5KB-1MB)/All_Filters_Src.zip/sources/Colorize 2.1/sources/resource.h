//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_COLORIZE             101
#define IDR_COLORIZE_MENU               109
#define IDC_SAT2                        1001
#define IDC_SHUE                        1002
#define IDC_SAT                         1003
#define IDC_LUMA                        1004
#define IDC_ALPHA                       1005
#define IDC_VSAT2                       1006
#define IDC_VSHUE                       1007
#define IDC_VSAT                        1008
#define IDC_VLUMA                       1009
#define IDC_VALPHA                      1010
#define IDC_EHUE                        1011
#define IDC_VEHUE                       1012
#define IDC_SAVE                        1013
#define IDC_SEPPIA                      1014
#define IDC_MAILME                      1024
#define IDC_HOMEPAGE                    1025
#define IDC_SAT2RESET                   1027
#define IDC_SATRESET                    1028
#define IDC_LUMARESET                   1029
#define IDC_HUELINK                     1031
#define IDC_MODE                        1032
#define IDC_LOAD                        1037
#define IDC_ONOFF                       1042
#define IDC_SAVE_GRADIENT               40008
#define IDM_ITU601                      40014
#define IDM_ITU709                      40015
#define IDM_ITUGRAY                     40016
#define IDM_LINEAR                      40017
#define IDM_AVERAGE                     40018
#define IDM_BUG                         40024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40025
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
