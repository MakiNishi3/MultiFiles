/*  Colorize - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari  <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

// Version 2.0 (12-09-2003)
// Version 2.1 (31-10-2004): Revisione del codice e rimozione piccoli bug

#define LUMASIZE 1024
#define SB         2

#define VERSION   "2.1"
#define VER_DATE  "(31-10-2004)"
#define VER_OPT   "[MMX/ISSE]"
#define VER_COPY  "Copyright (C) 2003,2004 Emiliano Ferrari"
#define E_MAIL    "macinapepe@tiscali.it"

#include "filter.h"
#include "resource.h"
#include <stdio.h>
#include <commctrl.h>
#include "ScriptValue.h"

bool Detect_VirtualDub= false;

typedef struct
{
  int SHue,EHue;   // tinta colore sovrapposto
  int Sat;         // saturazione colore sovrapposto
  int Luma;        // luminosit� colore sovrapposto
  int Alpha;       // trasparenza colore sovrapposto
  int Sat2;        // saturazione dell' originale
  int mode;
  bool huelink,filteroff;
  Pixel32 Color[LUMASIZE]; // tabella del colore differenti per luminosit�
  int graymode;
  IFilterPreview *ifp;
} MyFilterData;

#define ITU601  0
#define ITU709  1
#define ITUGRAY 2
#define LINEAR  3
#define AVERAGE 4

inline void Clipping (int &dato,int min,int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void BuildTables (MyFilterData *mfd) // Precalcola "Color[]"
{
  int R,G,B;
  int sr,sg,sb;
  int er,eg,eb;
  int r,g,b;
  // Bug-free (tm)
  int SH= mfd->SHue;          // Controlla i parametri di ingresso
  int EH= mfd->EHue;

  int S= mfd->Sat;
  int L= mfd->Luma;
  Clipping (SH, 0, 1791);
  Clipping (EH, 0, 1791);
  Clipping (S, 0,  512);
  Clipping (L, 0,  512);

  // Build color by Hue    // Calcola il colore RGB in base alla tinta indicata
  if (SH<(256*1)) {sr=255;        sg=SH&255;    sb=0;    } else
  if (SH<(256*2)) {sr=255-SH&255; sg=255;       sb=0;    } else
  if (SH<(256*3)) {sr=0;          sg=255;       sb=SH&255;} else
  if (SH<(256*4)) {sr=0;          sg=255-SH&255;sb=255;  } else
  if (SH<(256*5)) {sr=0;          sg=0;         sb=255;  } else
  if (SH<(256*6)) {sr=SH&255;     sg=0;         sb=255;  } else
  {sr=255;       sg=0;        sb=255-SH&255;}

  // Build color by Hue    // Calcola il colore RGB in base alla tinta indicata
  if (EH<(256*1)) {er=255;        eg=EH&255;    eb=0;    } else
  if (EH<(256*2)) {er=255-EH&255; eg=255;       eb=0;    } else
  if (EH<(256*3)) {er=0;          eg=255;       eb=EH&255;} else
  if (EH<(256*4)) {er=0;          eg=255-EH&255;eb=255;  } else
  if (EH<(256*5)) {er=0;          eg=0;         eb=255;  } else
  if (EH<(256*6)) {er=EH&255;     eg=0;         eb=255;  } else
  {er=255;       eg=0;        eb=255-EH&255;}



  // Compute Saturation and MaxLuma output
  for (int i=0; i<LUMASIZE; i++)    // calcola i colori in base alla luminosit� di ingresso
  {
    r= sr+((er-sr)*i)/(LUMASIZE-1);
    g= sg+((eg-sg)*i)/(LUMASIZE-1);
    b= sb+((eb-sb)*i)/(LUMASIZE-1);

    if (i<(LUMASIZE/2)) // Luma
    {
      R= (r*i)/(LUMASIZE/2);
      G= (g*i)/(LUMASIZE/2);
      B= (b*i)/(LUMASIZE/2);
    }
    else
    {
      R= r+(((255-r)*(i-(LUMASIZE/2)))/(LUMASIZE/2));
      G= g+(((255-g)*(i-(LUMASIZE/2)))/(LUMASIZE/2));
      B= b+(((255-b)*(i-(LUMASIZE/2)))/(LUMASIZE/2));
    }

   // Adjust saturation
   int Sat= (((LUMASIZE-1)-i)*S)/(LUMASIZE-1); // corregge saturazione in base alla luminosit� di ingresso
   R= (((((R<<SB)-i)*Sat)>>8)+i)>>SB; // Applica saturazione selezionata
   G= (((((G<<SB)-i)*Sat)>>8)+i)>>SB;
   B= (((((B<<SB)-i)*Sat)>>8)+i)>>SB;

   // Adjust Max Luma
   R= (R*L)>>8; // Riduce la luminosit� totale dell'immagine
   G= (G*L)>>8;
   B= (B*L)>>8;

   Clipping (R,0,255);
   Clipping (G,0,255);
   Clipping (B,0,255);

   mfd->Color[i]= (R<<16)|(G<<8)|B; // Crea la tabella dei colori
 }
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->SHue  = 0;
  mfd->EHue  = 0;
  mfd->Luma  = 256;
  mfd->Sat   = 256;
  BuildTables (mfd);
  mfd->Sat2  = 256;
  mfd->Alpha = 0;
  mfd->mode  = 0;
  mfd->huelink= true;
  mfd->filteroff= false;
  mfd->graymode= ITU709;
  return 0;
}

void Colorize_386 (Pixel32 *dst,const int datasize,Pixel32 *Color,const int Alpha,const int Sat2,const int KR,const int KG,const int KB)
{
  const int S= 256-Sat2;
  for (int p=0; p<datasize; p++)
  {
    int a= (*dst)&0xff000000;
    int r= (*dst>>16) & 0xff;
    int g= (*dst>> 8) & 0xff;
    int b= (*dst    ) & 0xff;
    int L= (KR*r + KG*g + KB*b)>>(16-SB);
    r+= ((L-(r<<SB))*S)>>(8+SB);
    g+= ((L-(g<<SB))*S)>>(8+SB);
    b+= ((L-(b<<SB))*S)>>(8+SB);
    Clipping (r,0,255);
    Clipping (g,0,255);
    Clipping (b,0,255);
    int R= (Color[L]>>16)&0xff;
    int G= (Color[L]>> 8)&0xff;
    int B= (Color[L]    )&0xff;
    r+= ((R-r)*Alpha)>>8;
    g+= ((G-g)*Alpha)>>8;
    b+= ((B-b)*Alpha)>>8;
    *dst++= a | (r<<16) | (g<<8) | b;
  }
}

void Colorize_MMX (Pixel32 *dst,const int datasize,Pixel32 *Color,const int Alpha,const int Sat2,__int64 KGray)
{
  static __int64 Alpha64,Sat64;
  const  __int64 Zero= 0;
  const  __int64 mask_RGB= 0x00ffffff00ffffff;
  const  __int64 mask_Y  = 0xff000000ff000000;
  __asm {
        movd      mm0,[Alpha]
        movd      mm1,[Sat2 ]
        punpcklwd mm0,mm0
        punpcklwd mm1,mm1
        punpckldq mm0,mm0
        punpckldq mm1,mm1
        psllw     mm0,5
        psllw     mm1,5
        movq      [Alpha64],mm0
        movq      [Sat64  ],mm1

        mov       ecx,[datasize]
        mov       edi,[dst]
        mov       esi,[Color]
        shr       ecx,1
        lea       edi,[edi+ecx*8]
        neg       ecx
        align     16
ColLoop:movq      mm0,[edi+ecx*8]
        movq      mm4,mm0
        // GrayScale

        punpcklbw mm0,[Zero]
        punpckhbw mm4,[Zero]
        movq      mm3,mm0
        movq      mm7,mm4

        psllw     mm0,3
        psllw     mm4,3

        pmulhw    mm0,[KGray]
        movq      mm1,mm0
        movq      mm2,mm0
        psrlq     mm1,16
        psrlq     mm2,32
        paddw     mm1,mm2
        paddw     mm0,mm1

        pmulhw    mm4,[KGray]
        movq      mm1,mm4
        movq      mm2,mm4
        psrlq     mm1,16
        psrlq     mm2,32
        paddw     mm1,mm2
        paddw     mm4,mm1

        punpcklwd mm4,mm4
        punpcklwd mm4,mm4
        movd      ebx,mm4
        and       ebx,1023

        punpcklwd mm0,mm0
        punpcklwd mm0,mm0
        movd      eax,mm0
        and       eax,1023

        psrlw      mm0,2
        psrlw      mm4,2
        // update source saturation
        psubw     mm3,mm0
        psubw     mm7,mm4
        psllw      mm3,3
        psllw      mm7,3
        pmulhw    mm3,[Sat64]
        pmulhw    mm7,[Sat64]
        paddw     mm3,mm0
        paddw     mm7,mm4


        packuswb  mm3,mm7
        movq      mm7,mm3
        punpcklbw mm3,[Zero]
        punpckhbw mm7,[Zero]

        // PseudoColor (part B)
        movd      mm0,[esi+eax*4]
        movd      mm4,[esi+ebx*4]
        punpcklbw mm0,[Zero]
        punpcklbw mm4,[Zero]

        // Source Blend
        psubw     mm0,mm3
        psubw     mm4,mm7
        psllw     mm0,3
        psllw     mm4,3
        pmulhw    mm0,[Alpha64]
        pmulhw    mm4,[Alpha64]
        paddw     mm0,mm3
        paddw     mm4,mm7

        // Store Pixels
        packuswb  mm0,mm4
        movq      mm1,[edi+ecx*8]
        pand      mm0,[mask_RGB]
        pand      mm1,[mask_Y]
        por          mm0,mm1
        movq      [edi+ecx*8],mm0
        inc       ecx
        jnz       ColLoop
        emms
   }
}

void Colorize_iSSE (Pixel32 *dst,const int datasize,Pixel32 *Color,const int Alpha,const int Sat2,__int64 KGray)
{
  static __int64 Alpha64,Sat64;
  const  __int64 Zero = 0;
  const  __int64 mask_RGB= 0x00ffffff00ffffff;
  const  __int64 mask_Y  = 0xff000000ff000000;
  __asm {

        pshufw    mm0,[Alpha],0
        pshufw    mm1,[Sat2 ],0
        psllw     mm0,5
        psllw     mm1,5
        movq      [Alpha64],mm0
        movq      [Sat64  ],mm1

        mov       ecx,[datasize]
        mov       edi,[dst]
        mov       esi,[Color]
        shr       ecx,1
        lea       edi,[edi+ecx*8]
        neg       ecx
        align     16
ColLoop:movq      mm0,[edi+ecx*8]
        prefetchnta  [edi+ecx*8+192]
        movq      mm4,mm0

        // GrayScale
        punpcklbw mm0,[Zero]
        punpckhbw mm4,[Zero]

        movq      mm3,mm0
        movq      mm7,mm4

        psllw      mm0,2
        psllw      mm4,2

        pmulhuw   mm0,[KGray]
        pmulhuw   mm4,[KGray]
        pshufw    mm1,mm0,0
        pshufw    mm5,mm4,0
        pshufw    mm2,mm0,0x55
        pshufw    mm6,mm4,0x55
        pshufw    mm0,mm0,0xaa
        pshufw    mm4,mm4,0xaa
        paddw     mm1,mm2
        paddw     mm5,mm6
        paddw     mm0,mm1
        paddw     mm4,mm5

        // PseudoColor (part A)
        pextrw    eax,mm0,0
        pextrw    ebx,mm4,0

        psrlw      mm0,2
        psrlw      mm4,2

        // update source saturation
        psubw     mm3,mm0
        psubw     mm7,mm4
        psllw     mm3,3
        psllw     mm7,3
        pmulhw    mm3,[Sat64]
        pmulhw    mm7,[Sat64]
        paddw     mm3,mm0
        paddw     mm7,mm4

        // clipping ???
        packuswb  mm3,mm7
        movq      mm7,mm3
        punpcklbw mm3,[Zero]
        punpckhbw mm7,[Zero]
        // PseudoColor (part B)
        movd      mm0,[esi+eax*4]
        movd      mm4,[esi+ebx*4]
        punpcklbw mm0,[Zero]
        punpcklbw mm4,[Zero]

        // Source Blend
        psubw     mm0,mm3
        psubw     mm4,mm7
        psllw     mm0,3
        psllw     mm4,3
        pmulhw    mm0,[Alpha64]
        pmulhw    mm4,[Alpha64]
        paddw     mm0,mm3
        paddw     mm4,mm7
        // Store Pixels
        packuswb  mm0,mm4
        movq      mm1,[edi+ecx*8]
        pand      mm0,[mask_RGB]
        pand      mm1,[mask_Y]
        por          mm0,mm1
        movq      [edi+ecx*8],mm0
        inc       ecx
        jnz       ColLoop
        emms
  }
}

__int64 BuildQ (short A,short R,short G,short B)
{
  __int64 Quadword;
  *(((short *)&Quadword)+0)= B;
  *(((short *)&Quadword)+1)= G;
  *(((short *)&Quadword)+2)= R;
  *(((short *)&Quadword)+3)= A;
  return Quadword;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  if (!Detect_VirtualDub) return 0;
  if (mfd->filteroff) return 0;
  const int datasize= fa->dst.size>>2;

  if (datasize<16) return 0;
  Clipping (mfd->Alpha, 0, 256);
  Clipping (mfd->Sat2 , 0, 512);
  if ((mfd->Alpha==0) && (mfd->Sat2==256)) return 0;
  int KR,KG,KB;
  __int64 KGRAY;

  switch (mfd->graymode)
  {
     case ITU601:
         KR= (int)(65536.0*0.298912);
         KG= (int)(65536.0*0.586611);
         KB= 65536-(KR+KG);
         KGRAY= BuildQ (0,KR,KG,KB);
         break;
    case ITU709:
         KR= (int)(65536.0*0.212671);
         KG= (int)(65536.0*0.715160);
         KB= 65536-(KR+KG);
         KGRAY= BuildQ (0,KR,KG,KB);
         break;
    case ITUGRAY:
         KR= (int)(65536.0*0.222015);
         KG= (int)(65536.0*0.706655);
         KB= 65536-(KR+KG);
         KGRAY= BuildQ (0,KR,KG,KB);
         break;
    case LINEAR:
         KR= (int)(65536.0*0.3086);
         KG= (int)(65536.0*0.6094);
         KB= 65536-(KR+KG);
         KGRAY= BuildQ (0,KR,KG,KB);
         break;
    case AVERAGE:
         KR= (int)(65536.0*1.0/3.0);
         KG= (int)(65536.0*1.0/3.0);
         KB= 65536-(KR+KG);
         KGRAY= BuildQ (0,KR,KG,KB);
         break;
  }


  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
    Colorize_iSSE (fa->dst.data,datasize,mfd->Color,mfd->Alpha,mfd->Sat2,KGRAY);
   else
  if ((CPUF_SUPPORTS_MMX & ff->getCPUFlags()))
    Colorize_MMX (fa->dst.data,datasize,mfd->Color,mfd->Alpha,mfd->Sat2,KGRAY>>1);
   else
    Colorize_386 (fa->dst.data,datasize,mfd->Color,mfd->Alpha,mfd->Sat2,KR,KG,KB);

  return 0;
}

//=========================== VIRTUALDUB INTERFACE =========================

bool FssProc (FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *) fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d, %d, %d, %d, %d, %d)"
            ,mfd->Sat2,mfd->SHue,mfd->EHue,mfd->Sat,mfd->Luma,mfd->Alpha,mfd->graymode);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->Sat2 = argv[0].asInt();
  mfd->SHue = argv[1].asInt();
  mfd->EHue = argv[2].asInt();
  mfd->Sat  = argv[3].asInt();
  mfd->Luma = argv[4].asInt();
  mfd->Alpha= argv[5].asInt();
  mfd->graymode= argv[6].asInt();
  Clipping (mfd->Sat2 ,0, 512);
  Clipping (mfd->SHue ,0,1791);
  Clipping (mfd->EHue ,0,1791);
  Clipping (mfd->Sat  ,0, 512);
  Clipping (mfd->Luma ,0, 512);
  Clipping (mfd->Alpha,0, 256);
  Clipping (mfd->graymode,ITU601,AVERAGE);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiiiiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  switch (mfd->mode)
  {
    case  0: _snprintf (str,64," (NO FILTER)"); break;
    case  1: _snprintf (str,64," (GOLD)"); break;
    case  2: _snprintf (str,64," (GRAYSCALE)"); break;
    case  3: _snprintf (str,64," (GRAY BLUE)"); break;
    case  4: _snprintf (str,64," (COLOR BLUE)"); break;
    case  5: _snprintf (str,64," (COLOR SEPPIA)"); break;
    case  6: _snprintf (str,64," (SEPPIA)"); break;
    case  7: _snprintf (str,64," (MARS)"); break;
    case  8: _snprintf (str,64," (MATRIX)"); break;
    case  9: _snprintf (str,64," (50%% GRAY)"); break;
    case 10: _snprintf (str,64," (SOFT GOLD)"); break;
    case 11: _snprintf (str,64," (GOLD GRAY)"); break;
    case 12: _snprintf (str,64," (FIRE)"); break;
    default: _snprintf (str,64," (SH:%d  EH:%d  IS:%d S:%d  L:%d  A:%d%%)",mfd->Sat2,mfd->SHue,mfd->EHue,mfd->Sat,mfd->Luma,mfd->Alpha);
  }

}

#define UPDATE \
  SendMessage(GetDlgItem(hdlg,IDC_SHUE  ),TBM_SETPOS,(WPARAM)TRUE,mfd->SHue  );\
  SendMessage(GetDlgItem(hdlg,IDC_EHUE  ),TBM_SETPOS,(WPARAM)TRUE,mfd->EHue  );\
  SendMessage(GetDlgItem(hdlg,IDC_SAT  ),TBM_SETPOS,(WPARAM)TRUE,mfd->Sat  );\
  SendMessage(GetDlgItem(hdlg,IDC_SAT2 ),TBM_SETPOS,(WPARAM)TRUE,mfd->Sat2 );\
  SendMessage(GetDlgItem(hdlg,IDC_LUMA ),TBM_SETPOS,(WPARAM)TRUE,mfd->Luma );\
  SendMessage(GetDlgItem(hdlg,IDC_ALPHA),TBM_SETPOS,(WPARAM)TRUE,mfd->Alpha);

#define SHOW \
  _snprintf (tmp,128,"%1.2f",((mfd->SHue)*360.0)/1791); \
  SetDlgItemText(hdlg,IDC_VSHUE  ,tmp);\
  _snprintf (tmp,128,"%1.2f",((mfd->EHue)*360.0)/1791); \
  SetDlgItemText(hdlg,IDC_VEHUE  ,tmp);\
  _snprintf (tmp,128,"%1.2f",((mfd->Sat)*2.0)/512); \
  SetDlgItemText(hdlg,IDC_VSAT  ,tmp);\
  _snprintf (tmp,128,"%1.2f",((mfd->Luma)*1.0)/256); \
  SetDlgItemText(hdlg,IDC_VLUMA ,tmp);  \
  _snprintf (tmp,128,"%1.2f",((mfd->Alpha)*1.0)/256);\
  SetDlgItemText(hdlg,IDC_VALPHA,tmp);\
  _snprintf (tmp,128,"%1.2f",((mfd->Sat2)*2.0)/512);\
  SetDlgItemText(hdlg,IDC_VSAT2 ,tmp);

#define PRESET(ss,sh,eh,s,l,a) mfd->SHue= sh; mfd->EHue=eh; mfd->Sat= s; mfd->Luma= l; mfd->Alpha= a; mfd->Sat2= ss;

void LOAD_FILE (MyFilterData *mfd,HWND hdlg)
{
  char filename[1024];
  OPENFILENAME ofn;
  filename[0]= NULL;
  ofn.lStructSize      = sizeof(OPENFILENAME);
  ofn.hwndOwner        = hdlg;
  ofn.lpTemplateName   = NULL;
  ofn.lpstrFilter      = "Colorize settings (*.cst)\0*.cst\0All files\0*.*\0";
  ofn.lpstrCustomFilter= NULL;
  ofn.nFilterIndex     = NULL;
  ofn.lpstrFile        = filename;
  ofn.nMaxFile         = 1024;
  ofn.lpstrFileTitle   = NULL;
  ofn.lpstrInitialDir  = NULL;
  ofn.lpstrTitle       = NULL;
  ofn.Flags            = OFN_FILEMUSTEXIST | OFN_EXPLORER | OFN_PATHMUSTEXIST;
  ofn.nFileOffset      = 0;
  ofn.nFileExtension   = 0;
  ofn.lpstrDefExt      = "cst";
  ofn.lCustData        = 0;
  ofn.lpfnHook         = NULL;
  if ((GetOpenFileName(&ofn)) && (filename[0]!=0))
    {
      int ss=0,sh=0,eh=0,s=0,l=0,a=0,id=0;
      FILE *f;
      if (f= fopen (filename,"r"))
        {
          fscanf (f,"%d %d %d %d %d %d %d",&ss,&sh,&eh,&s,&l,&a,&id);
          fclose (f);
          if (id==0xEFEF)
            {
              Clipping (ss,0, 512);
              Clipping (sh ,0,1791);
              Clipping (eh ,0,1791);
              Clipping (s ,0, 512);
              Clipping (l ,0, 512);
              Clipping (a ,0, 256);
              mfd->Sat2 = ss;
              mfd->SHue  = sh;
              mfd->EHue  = eh;
              mfd->Sat  = s;
              mfd->Luma = l;
              mfd->Alpha= a;
              UPDATE;
              char tmp[20];
              SHOW;
              BuildTables(mfd);
              mfd->ifp->RedoFrame();
            }
        }
    }
}

void SAVE_FILE (MyFilterData *mfd,HWND hdlg)
{
  static char filename[1024];
  OPENFILENAME ofn;
  filename[0]= NULL;
  ofn.lStructSize      = sizeof(OPENFILENAME);
  ofn.hwndOwner        = hdlg;
  ofn.lpTemplateName   = NULL;
  ofn.lpstrFilter      = "Colorize settings (*.cst)\0*.cst\0All files\0*.*\0";
  ofn.lpstrCustomFilter= NULL;
  ofn.nFilterIndex     = NULL;
  ofn.lpstrFile        = filename;
  ofn.nMaxFile         = 1024;
  ofn.lpstrFileTitle   = NULL;
  ofn.lpstrInitialDir  = NULL;
  ofn.lpstrTitle       = NULL;
  ofn.Flags            = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_PATHMUSTEXIST;
  ofn.nFileOffset      = 0;
  ofn.nFileExtension   = 0;
  ofn.lpstrDefExt      = "cst";
  ofn.lCustData        = 0;
  ofn.lpfnHook         = NULL;
  if (GetSaveFileName(&ofn))
    {
       FILE *f;
       if (f= fopen (filename,"w"))
         {
            fprintf (f,"%d %d %d %d %d %d %d\n",
                     mfd->Sat2,mfd->SHue,mfd->EHue,mfd->Sat,mfd->Luma,mfd->Alpha,0xEFEF);
            fprintf (f,"//ISat SHue LHue Sat Luma Alpha FileID\n");
            fclose (f);
         }
    }
}


void SAVE_GRADIENT_FILE (MyFilterData *mfd,HWND hdlg)
{
  static char filename[1024];
  OPENFILENAME ofn;
  filename[0]= NULL;
  ofn.lStructSize      = sizeof(OPENFILENAME);
  ofn.hwndOwner        = hdlg;
  ofn.lpTemplateName   = NULL;
  ofn.lpstrFilter      = "C source (*.c)\0*.c\0All files\0*.*\0";
  ofn.lpstrCustomFilter= NULL;
  ofn.nFilterIndex     = NULL;
  ofn.lpstrFile        = filename;
  ofn.nMaxFile         = 1024;
  ofn.lpstrFileTitle   = NULL;
  ofn.lpstrInitialDir  = NULL;
  ofn.lpstrTitle       = NULL;
  ofn.Flags            = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_PATHMUSTEXIST;
  ofn.nFileOffset      = 0;
  ofn.nFileExtension   = 0;
  ofn.lpstrDefExt      = "c";
  ofn.lCustData        = 0;
  ofn.lpfnHook         = NULL;
  if (GetSaveFileName(&ofn))
    {
       FILE *f;
       if (f= fopen (filename,"w"))
         {
           fprintf (f,"// Input Saturation = %d\n",mfd->Sat2);
           fprintf (f,"// Alpha            = %d\n",mfd->Alpha);
           fprintf (f,"// H1,H2,L,S        = %d,%d,%d,%d\n",mfd->SHue,mfd->EHue,mfd->Luma,mfd->Sat);

           fprintf (f,"Pixel32 data[%d]={",LUMASIZE);

            for (int i=0; i<LUMASIZE; i++)
            {
               if ((i%8)==0) fprintf (f,"\n        ");
               fprintf (f,"0x%06x",mfd->Color[i]&0xffffff);
               if (i<(LUMASIZE-1)) fprintf (f,",");
            }
            fprintf (f,"};\n");
            fclose (f);
         }
    }
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char tmp[20];

  switch(msg)
    {
      case WM_INITDIALOG:
        SetWindowLong(hdlg, DWL_USER, lParam);
        mfd= (MyFilterData *)lParam;

        switch (mfd->graymode)
        {
          case ITU601:  CheckMenuRadioItem(GetMenu (hdlg),IDM_ITU601,IDM_AVERAGE,IDM_ITU601,MF_BYCOMMAND); break;
          case ITU709:  CheckMenuRadioItem(GetMenu (hdlg),IDM_ITU601,IDM_AVERAGE,IDM_ITU709,MF_BYCOMMAND); break;
          case ITUGRAY: CheckMenuRadioItem(GetMenu (hdlg),IDM_ITU601,IDM_AVERAGE,IDM_ITUGRAY,MF_BYCOMMAND); break;
          case LINEAR:  CheckMenuRadioItem(GetMenu (hdlg),IDM_ITU601,IDM_AVERAGE,IDM_LINEAR,MF_BYCOMMAND);  break;
          case AVERAGE: CheckMenuRadioItem(GetMenu (hdlg),IDM_ITU601,IDM_AVERAGE,IDM_AVERAGE,MF_BYCOMMAND);    break;
        }

        SendMessage(GetDlgItem(hdlg,IDC_SHUE  ),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,1791));
        SendMessage(GetDlgItem(hdlg,IDC_EHUE  ),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0,1791));
        SendMessage(GetDlgItem(hdlg,IDC_SAT  ),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0, 512));
        SendMessage(GetDlgItem(hdlg,IDC_LUMA ),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0, 512));
        SendMessage(GetDlgItem(hdlg,IDC_ALPHA),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0, 256));
        SendMessage(GetDlgItem(hdlg,IDC_SAT2 ),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(0, 512));
        CheckDlgButton(hdlg, IDC_HUELINK, mfd->huelink ? BST_CHECKED : BST_UNCHECKED);
        CheckDlgButton(hdlg, IDC_ONOFF, mfd->filteroff ? BST_CHECKED : BST_UNCHECKED);
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, 0,(LPARAM)"NO FILTER");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"GOLD");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"GRAYSCALE");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"GRAY BLUE");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"COLOR BLUE");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"COLOR SEPPIA");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"SEPPIA");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"MARS");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"MATRIX");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"50% GRAY");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"SOFT GOLD");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"GOLD GRAY");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"FIRE");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_INSERTSTRING, -1,(LPARAM)"CUSTOM");
        SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_SETCURSEL,(WPARAM)mfd->mode,0);
        UPDATE;
        SHOW;
        mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
        return TRUE;

      case WM_HSCROLL:
          mfd->mode= 13;
          SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_SETCURSEL,(WPARAM)mfd->mode,0);
        int SH,EH,L,S;
        SH= mfd->SHue; EH= mfd->EHue; L= mfd->Luma; S= mfd->Sat;

        mfd->SHue  = SendMessage(GetDlgItem(hdlg,IDC_SHUE  ),TBM_GETPOS,0,0);
        mfd->EHue  = SendMessage(GetDlgItem(hdlg,IDC_EHUE  ),TBM_GETPOS,0,0);

        if (mfd->huelink)
        {
        if (SH!=mfd->SHue)
        {
            mfd->EHue=mfd->SHue;
            SendMessage(GetDlgItem(hdlg,IDC_EHUE ),TBM_SETPOS,(WPARAM)TRUE,mfd->EHue );
        }
        if (EH!=mfd->EHue)
        {
            mfd->SHue=mfd->EHue;
            SendMessage(GetDlgItem(hdlg,IDC_SHUE ),TBM_SETPOS,(WPARAM)TRUE,mfd->SHue );
        }
        }

        mfd->Sat  = SendMessage(GetDlgItem(hdlg,IDC_SAT  ),TBM_GETPOS,0,0);
        mfd->Luma = SendMessage(GetDlgItem(hdlg,IDC_LUMA ),TBM_GETPOS,0,0);
        mfd->Alpha= SendMessage(GetDlgItem(hdlg,IDC_ALPHA),TBM_GETPOS,0,0);
        mfd->Sat2 = SendMessage(GetDlgItem(hdlg,IDC_SAT2 ),TBM_GETPOS,0,0);
        SHOW;
        if ((SH!=mfd->SHue) || (EH!=mfd->EHue) || (L!=mfd->Luma) || (S!=mfd->Sat)) BuildTables(mfd);
        mfd->ifp->RedoFrame();
        break;


      case WM_CONTEXTMENU:
      case WM_COMMAND:
        switch (LOWORD(wParam))
          {
            case IDC_MODE:
                {
                  mfd->mode= SendMessage (GetDlgItem(hdlg,IDC_MODE),CB_GETCURSEL,0,0);
                  switch (mfd->mode)
                    {
                        case 0: PRESET(256,0,  0,256,256,  0); break;
                        case 1: PRESET(512,200,200,210,240,150); break;
                        case 2: PRESET(256,0,  0,  0,256,256); break;
                        case 3: PRESET(256,980,980, 50,246,256); break;
                        case 4: PRESET(256,960,960, 50,246,182); break;
                        case 5: PRESET(512,126,126,200,208,128); break;
                        case 6: PRESET(256,126,126,177,232,200); break;
                        case 7: PRESET(256,0,  0,326,256,134); break;
                        case 8: PRESET(347,588,588,256,224, 38); break;
                        case 9: PRESET(256,0,  0,  0,256,128); break;
                        case 10: PRESET(256,163,163, 93,256,128); break;
                        case 11: PRESET(  0,163,163,130,256,132); break;
                        case 12: PRESET(512,  0,460,256,497,195); break;
                        case 13: break;
                    }
                  UPDATE;
                  SHOW;
                  BuildTables(mfd);
                  mfd->ifp->RedoFrame();
                }; break;


            case IDM_ITU601:  CheckMenuRadioItem(GetMenu (hdlg),IDM_ITU601,IDM_AVERAGE,IDM_ITU601,MF_BYCOMMAND); mfd->graymode=ITU601; mfd->ifp->RedoFrame(); break;
            case IDM_ITU709:  CheckMenuRadioItem(GetMenu (hdlg),IDM_ITU601,IDM_AVERAGE,IDM_ITU709,MF_BYCOMMAND); mfd->graymode=ITU709; mfd->ifp->RedoFrame(); break;
            case IDM_ITUGRAY: CheckMenuRadioItem(GetMenu (hdlg),IDM_ITU601,IDM_AVERAGE,IDM_ITUGRAY,MF_BYCOMMAND); mfd->graymode=ITUGRAY; mfd->ifp->RedoFrame(); break;
            case IDM_LINEAR:  CheckMenuRadioItem(GetMenu (hdlg),IDM_ITU601,IDM_AVERAGE,IDM_LINEAR,MF_BYCOMMAND); mfd->graymode=LINEAR; mfd->ifp->RedoFrame(); break;
            case IDM_AVERAGE: CheckMenuRadioItem(GetMenu (hdlg),IDM_ITU601,IDM_AVERAGE,IDM_AVERAGE,MF_BYCOMMAND); mfd->graymode=AVERAGE; mfd->ifp->RedoFrame(); break;

            case IDC_HUELINK:  mfd->huelink     = !!IsDlgButtonChecked(hdlg, IDC_HUELINK);break;
            case IDC_ONOFF:    mfd->filteroff    = !!IsDlgButtonChecked(hdlg, IDC_ONOFF); mfd->ifp->RedoFrame(); break;

            case IDPREVIEW   : mfd->ifp->Toggle(hdlg); break;
            case IDOK        : EndDialog(hdlg,0); return TRUE;
            case IDCANCEL    : EndDialog(hdlg,1); return TRUE;
            case IDC_LOAD:
                LOAD_FILE (mfd,hdlg);
                mfd->mode= 13;
                SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_SETCURSEL,(WPARAM)mfd->mode,0);
                break;
            case IDC_SAVE: SAVE_FILE (mfd,hdlg); break;
            case IDC_SAVE_GRADIENT: SAVE_GRADIENT_FILE (mfd,hdlg); break;

            case IDC_SAT2RESET: mfd->Sat2= 256; mfd->ifp->RedoFrame();
                mfd->mode= 13;
                SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_SETCURSEL,(WPARAM)mfd->mode,0);
                SendMessage(GetDlgItem(hdlg,IDC_SAT2 ),TBM_SETPOS,(WPARAM)TRUE,mfd->Sat2 );
                SHOW;
                    break;
            case IDC_SATRESET : mfd->Sat = 256; BuildTables(mfd);
                mfd->mode= 13;
                SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_SETCURSEL,(WPARAM)mfd->mode,0);
                SendMessage(GetDlgItem(hdlg,IDC_SAT ),TBM_SETPOS,(WPARAM)TRUE,mfd->Sat );
                SHOW;
              mfd->ifp->RedoFrame(); break;
            case IDC_LUMARESET: mfd->Luma= 256; BuildTables(mfd);
                mfd->mode= 13;
                SendMessage(GetDlgItem(hdlg,IDC_MODE),CB_SETCURSEL,(WPARAM)mfd->mode,0);
                SendMessage(GetDlgItem(hdlg,IDC_LUMA ),TBM_SETPOS,(WPARAM)TRUE,mfd->Luma );
                SHOW;
              mfd->ifp->RedoFrame(); break;

          }
    }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
 MyFilterData *mfd= (MyFilterData *)fa->filter_data;
 MyFilterData mfd_old= *mfd;
 mfd->ifp= fa->ifp;
 int ret= DialogBoxParam(fa->filter->module->hInstModule,
                         MAKEINTRESOURCE(IDD_FILTER_COLORIZE),
                         hwnd, ConfigDlgProc, (LPARAM) mfd);
 if (ret) *mfd= mfd_old;
 return !!ret;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
    MyFilterData *mfd= (MyFilterData *)fa->filter_data;
    char prog[1024];

    GetModuleFileName (NULL,prog,sizeof(prog));

    for (unsigned i=0; i<strlen(prog); i++)
     if ((prog[i]>='a') && (prog[i]<='z')) prog[i]+= 'A'-'a';

    for (unsigned j=0; j<strlen(prog); j++)
        if (strncmp (&prog[j],"VIRTUALDUB",10)==0) Detect_VirtualDub=true;

  return 0;
}

struct FilterDefinition filterDef_Colorize=
{
  NULL,NULL,NULL,                   // next, prev, module
  "Colorize",                       // name
  "Version " VERSION " " VER_DATE " " VER_OPT "\n"
  VER_COPY "\n"
  E_MAIL,                            // desc
  "Emiliano Ferrari",               // maker
  NULL,                             // private_data
  sizeof(MyFilterData),             // inst_data_size
  InitProc,                         // initProc
  NULL,                             // deinitProc
  RunProc,                          // runProc
  ParamProc,                        // paramProc
  ConfigProc,                       // configProc
  StringProc,                       // stringProc
  StartProc,                        // startProc
  NULL,                             // endProc
  &script_obj,                      // script_obj
  FssProc,                          // fssProc
};

static FilterDefinition *fd_colorize;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_colorize=ff->addFilter(fm,&filterDef_Colorize,sizeof(FilterDefinition));
  if (!fd_colorize) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_colorize);
}
