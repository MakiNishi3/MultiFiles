/*  Fader 3.0 - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari    <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "ScriptValue.h"
#include "resource.h"

typedef struct
{
  bool fadein;
  bool interlaced;
  bool odd;
  int  after_black;
  int  start;
  int  length;
  int  before_black;
  IFilterPreview *ifp;
} MyFilterData;

inline void Clipping (int &value,const int min,const int max)
{
  if (value<min) value=min; else if (value>max) value=max;
}

void iFader_386 (Pixel32 *dst,int odd,int even,int pitch,int h)
{
  for (int y=0; y<h; y++)
  for (int p=0; p<pitch; p++)
  {
    int opacity= (y&1==1)?odd:even;
    int rb= (*dst)&0xff00ff;
    int g = (*dst)&0x00ff00;
    rb= ((rb*opacity)>>8)&0xff00ff;
    g = ((g *opacity)>>8)&0x00ff00;
    *dst++= rb|g;
  }
}

void Fader_386(Pixel32 *dst,int opacity,int psize)
{
  for (int p=0; p<psize; p++)
  {
    int rb= (*dst)&0xff00ff;
    int g = (*dst)&0x00ff00;
    rb= ((rb*opacity)>>8)&0xff00ff;
    g = ((g *opacity)>>8)&0x00ff00;
    *dst++= rb|g;
  }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  int frame= fa->pfsi->lCurrentSourceFrame;
  int start=mfd->start;
  int length= mfd->length;
  int end= start+length;
  int black;

  if (mfd->fadein)
  {
    black= mfd->before_black;
    if (black<0 && frame<start) { memset (fa->dst.data,0,fa->dst.size); return 0; }
    if (black<0) black=0;
    if (frame<start-black || frame>end) return 0;
    if (frame>=start-black && frame<start) { memset (fa->dst.data,0,fa->dst.size); return 0; }
    if (mfd->interlaced)
    {
      int odd_opacity,even_opacity;
      if (mfd->odd)
      {
        odd_opacity= (int)((256.0*(frame+0.5-start))/length);
        if (odd_opacity>256) odd_opacity=256;
        even_opacity= (int)((256.0*(frame-start))/length);
      }
      else
      {
        even_opacity= (int)((256.0*(frame+0.5-start))/length);
        if (even_opacity>256) even_opacity=256;
        odd_opacity= (int)((256.0*(frame-start))/length);
      }
      iFader_386 (fa->dst.data,odd_opacity,even_opacity,fa->dst.pitch>>2,fa->dst.h);
    }
    else
    {
    int opacity= (256*(frame-start))/length;
    Fader_386 (fa->dst.data,opacity,fa->dst.size>>2);
    }

  }
  else
  {
    black= mfd->after_black;
    if (black<0 && frame>=end) { memset (fa->dst.data,0,fa->dst.size); return 0; }
    if (black<0) black=0;
    if (frame<start || frame>end+black) return 0;
    if (frame>end && frame<=end+black) { memset (fa->dst.data,0,fa->dst.size); return 0; }
    if (mfd->interlaced)
    {
      int odd_opacity,even_opacity;
      if (!mfd->odd)
      {
        odd_opacity= (int)((256.0*(frame+0.5-start))/length);
        if (odd_opacity>256) odd_opacity=256;
        even_opacity= (int)((256.0*(frame-start))/length);
      }
      else
      {
        even_opacity= (int)((256.0*(frame+0.5-start))/length);
        if (even_opacity>256) even_opacity=256;
        odd_opacity= (int)((256.0*(frame-start))/length);
      }
      iFader_386 (fa->dst.data,256-odd_opacity,256-even_opacity,fa->dst.pitch>>2,fa->dst.h);
    }
    else
    {
    int opacity= (256*(frame-start))/length;
    Fader_386 (fa->dst.data,256-opacity,fa->dst.size>>2);
    }
  }

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->fadein= true;
  mfd->after_black= -1;
  mfd->start= 0;
  mfd->length= 50;
  mfd->before_black= -1;
  mfd->interlaced= false;
  mfd->odd= true;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      CheckDlgButton(hdlg,IDC_FADEIN , mfd->fadein? BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_FADEOUT,!mfd->fadein? BST_CHECKED:BST_UNCHECKED);
      SetDlgItemInt (hdlg,IDC_AFTER,mfd->after_black,true);
      SetDlgItemInt (hdlg,IDC_START,mfd->start,false);
      SetDlgItemInt (hdlg,IDC_LENGTH,mfd->length,false);
      SetDlgItemInt (hdlg,IDC_BEFORE,mfd->before_black,true);
      CheckDlgButton(hdlg,IDC_PROGRESSIVE,!mfd->interlaced? BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_INTERLACED ,mfd->interlaced? BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_ODD , mfd->odd? BST_CHECKED:BST_UNCHECKED);
      CheckDlgButton(hdlg,IDC_EVEN,!mfd->odd? BST_CHECKED:BST_UNCHECKED);
      EnableWindow (GetDlgItem (hdlg,IDC_AFTER) ,!mfd->fadein);
      EnableWindow (GetDlgItem (hdlg,IDC_BEFORE),mfd->fadein);
      EnableWindow (GetDlgItem (hdlg,IDC_ODD),mfd->interlaced);
      EnableWindow (GetDlgItem (hdlg,IDC_EVEN),mfd->interlaced);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW:mfd->ifp->Toggle(hdlg);  break;
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;
        case IDC_FADEIN:
            mfd->fadein= !!IsDlgButtonChecked(hdlg,IDC_FADEIN);
            EnableWindow (GetDlgItem (hdlg,IDC_AFTER) ,!mfd->fadein);
            EnableWindow (GetDlgItem (hdlg,IDC_BEFORE),mfd->fadein);
            mfd->ifp->RedoFrame();
            break;
        case IDC_FADEOUT:
            mfd->fadein= !IsDlgButtonChecked(hdlg,IDC_FADEOUT);
            EnableWindow (GetDlgItem (hdlg,IDC_AFTER) ,!mfd->fadein);
            EnableWindow (GetDlgItem (hdlg,IDC_BEFORE),mfd->fadein);
            mfd->ifp->RedoFrame();
            break;
        case IDC_PROGRESSIVE:
            mfd->interlaced= !IsDlgButtonChecked(hdlg,IDC_PROGRESSIVE);
            EnableWindow (GetDlgItem (hdlg,IDC_ODD),mfd->interlaced);
            EnableWindow (GetDlgItem (hdlg,IDC_EVEN),mfd->interlaced);
            mfd->ifp->RedoFrame();
            break;
        case IDC_INTERLACED:
            mfd->interlaced= !!IsDlgButtonChecked(hdlg,IDC_INTERLACED);
            EnableWindow (GetDlgItem (hdlg,IDC_ODD),mfd->interlaced);
            EnableWindow (GetDlgItem (hdlg,IDC_EVEN),mfd->interlaced);
            mfd->ifp->RedoFrame();
            break;
        case IDC_ODD:
            mfd->odd= !!IsDlgButtonChecked(hdlg,IDC_ODD);
            mfd->ifp->RedoFrame();
            break;
        case IDC_EVEN:
            mfd->odd= !IsDlgButtonChecked(hdlg,IDC_EVEN);
            mfd->ifp->RedoFrame();
            break;

         case IDC_START:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int start= GetDlgItemInt(hdlg,IDC_START,NULL,false);
            if (start!=mfd->start)
            {
              mfd->start= start;
              mfd->ifp->RedoFrame();
            }
          }
          break;
          case IDC_LENGTH:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int length= GetDlgItemInt(hdlg,IDC_LENGTH,NULL,false);
            if (length!=mfd->length)
            {
              mfd->length= length;
              mfd->ifp->RedoFrame();
            }
          }
          break;
          case IDC_AFTER:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int black= GetDlgItemInt(hdlg,IDC_AFTER,NULL,true);
            if (black!=mfd->after_black)
            {
              mfd->after_black= black;
              mfd->ifp->RedoFrame();
            }
          }
          break;
          case IDC_BEFORE:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int black= GetDlgItemInt(hdlg,IDC_BEFORE,NULL,true);
            if (black!=mfd->before_black)
            {
              mfd->before_black= black;
              mfd->ifp->RedoFrame();
            }
          }
          break;
      }
      break;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp = fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_FADER),
                          hwnd,ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return ret;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d,%d,%d,%d,%d,%d)",
      mfd->start,mfd->length,mfd->fadein?mfd->after_black:mfd->before_black,mfd->fadein,
      mfd->interlaced,mfd->odd);

  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->start = argv[0].asInt();
  mfd->length= argv[1].asInt();
  mfd->after_black=mfd->before_black= argv[2].asInt();
  mfd->fadein= !!argv[3].asInt();
  mfd->interlaced= !!argv[4].asInt();
  mfd->odd= !!argv[5].asInt();
  if (mfd->start<0) mfd->start=0;
  if (mfd->length<0) mfd->length=0;
  if (mfd->after_black<-1) mfd->after_black=-1;
  if (mfd->before_black<-1) mfd->before_black=-1;
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiiiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->fadein)
  {
    if (mfd->before_black<0)
      _snprintf(str,64," (Fade In [infinite %d-%d]%s)",mfd->start,mfd->start+mfd->length,mfd->interlaced?(mfd->odd?" interlaced:odd":" interlaced:even"):"");
    else
      _snprintf(str,64," (Fade In [%d %d-%d]%s)", mfd->before_black,mfd->start,mfd->start+mfd->length,mfd->interlaced?(mfd->odd?" interlaced:odd":" interlaced:even"):"");
  }
  else
  {
      if (mfd->after_black<0)
      _snprintf(str,64," (Fade Out [%d-%d infinite]%s)",mfd->start,mfd->start+mfd->length,mfd->interlaced?(mfd->odd?" interlaced:odd":" interlaced:even"):"");
    else
      _snprintf(str,64," (Fade Out [%d-%d %d]%s)", mfd->start,mfd->start+mfd->length,mfd->before_black,mfd->interlaced?(mfd->odd?" interlaced:odd":" interlaced:even"):"");
  }
}

FilterDefinition filterDef_fader=
{
  NULL,NULL,NULL,            // next, prev, module
  "Fader 3.1",               // name
  "Fades the movie at specified frames.\n"
  "Version 3.1 (02-10-2003)\n"
  "Copyright (C) 2003 by Emiliano Ferrari\n"
  "macinapepe@tiscali.it",   // desc
  "Emiliano Ferrari",        // maker
  NULL,                      // private_data
  sizeof(MyFilterData),      // inst_data_size
  InitProc,                  // initProc
  NULL,                      // deinitProc
  RunProc,                   // runProc
  ParamProc,                 // paramProc
  ConfigProc,                // configProc
  StringProc,                // stringProc
  NULL,                      // startProc
  NULL,                      // endProc
  &script_obj,               // script_obj
  FssProc,                   // fssProc
};

static FilterDefinition *fd_fader;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm,const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_fader= ff->addFilter(fm, &filterDef_fader, sizeof(FilterDefinition));
  if (!fd_fader) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_fader);
}
