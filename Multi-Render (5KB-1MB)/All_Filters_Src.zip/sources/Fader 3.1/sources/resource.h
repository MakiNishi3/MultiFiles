//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_FADER                101
#define IDC_START                       1001
#define IDC_LENGTH                      1002
#define IDC_BLACK                       1003
#define IDC_AFTER                       1003
#define IDC_BEFORE                      1004
#define IDC_FADEIN                      1010
#define IDC_FADEOUT                     1012
#define IDC_PROGRESSIVE                 1013
#define IDC_INTERLACED                  1014
#define IDC_EVEN                        1015
#define IDC_ODD                         1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
