/*  Smoother - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari <macinapepe@tiscali.it>

    based on Vertical Smoother, Copyright 2002 Valentim Batista

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.        */

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "resource.h"
#include "ScriptValue.h"

typedef struct 
{
  IFilterPreview *ifp;
  int Pow,Vert,Horz;
  Pixel32 *rows[3];
} MyFilterData;

#define RxB 0xff00ff
#define xGx 0x00ff00

void docol (Pixel32 *dst,Pixel32 *row1,Pixel32 *row2,Pixel32 *row3,int w,const int a,const int b,const int d)
{
  w= -w;
  row1-= w;
  row2-= w;
  row3-= w;
  dst-= w;
  do {
    Pixel32 s1, s2, s3;
    s1= row1[w];
    s2= row2[w];
    s3= row3[w];
    dst[w+0]= (((a*(s1&RxB) + b*(s2&RxB) + a*(s3&RxB))>>d) & RxB)
            + (((a*(s1&xGx) + b*(s2&xGx) + a*(s3&xGx))>>d) & xGx);
    } while(++w);
}

void HKernel (Pixel32 *dst,const int a,const int b,const int d,const int w,const int h,const int pitch)
{
  for (int y=0; y<h; y++)
    {
      Pixel32 p= *dst;
      *dst++= ((( (((*(dst+1))&RxB)<<1)*a + ((*dst&RxB))*b )>>d)&RxB)
             +((( (((*(dst+1))&xGx)<<1)*a + ((*dst&xGx))*b )>>d)&xGx);
      for (int x=1; x<(w-1); x++)
        {
          Pixel32 c= *dst;
          *dst++= ((((p&RxB)*a + ((*dst)&RxB)*b + ((*(dst+1))&RxB)*a)>>d)&RxB)
                 +((((p&xGx)*a + ((*dst)&xGx)*b + ((*(dst+1))&xGx)*a)>>d)&xGx);
          p= c;
        }
      *dst++= ((( ((p&RxB)<<1)*a + ((*dst)&RxB)*b )>>d)&RxB)
             +((( ((p&xGx)<<1)*a + ((*dst)&xGx)*b )>>d)&xGx);
      dst+= pitch-w;
    }
}

void VKernel (Pixel32 *dst,Pixel32 *rows[],const int a,const int b,const int d,const int w,const int h,const int pitch)
{
  int crow=2;
  memcpy (rows[0],dst,w);
  memcpy (rows[1],rows[0],w*sizeof(Pixel32));

  for (int y=h; y>1; y--)
  {
    memcpy (rows[crow],dst+pitch,w*sizeof(Pixel32));
    switch (crow)
    {
      case 0: docol (dst,rows[1],rows[2],rows[0],w,a,b,d); break;
      case 1: docol (dst,rows[2],rows[0],rows[1],w,a,b,d); break;
      case 2: docol (dst,rows[0],rows[1],rows[2],w,a,b,d); break;
    }
    if (++crow>=3) crow= 0;
    dst+= pitch;
  }

  // Last Line
  memcpy (rows[crow],rows[crow?crow-1:2],w*sizeof(Pixel32));
  switch (crow)
  {
     case 0: docol (dst,rows[1],rows[2],rows[0],w,a,b,d); break;
     case 1: docol (dst,rows[2],rows[0],rows[1],w,a,b,d); break;
     case 2: docol (dst,rows[0],rows[1],rows[2],w,a,b,d); break;
  }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  const int h= fa->dst.h;
  const int w= fa->dst.w;
  const int pitch= fa->dst.pitch>>2;

  if (h<4) return 0;
  switch (mfd->Pow)
    {
      case 0: break;
      case 1:
        if (mfd->Horz) HKernel (dst,1,14,4,w,h,pitch);
        if (mfd->Vert) VKernel (dst,mfd->rows,1,14,4,w,h,pitch);
        break;
      case 2:
        if (mfd->Horz) HKernel (dst,1, 6,3,w,h,pitch);
        if (mfd->Vert) VKernel (dst,mfd->rows,1,14,4,w,h,pitch);
        break;
      case 3:
        if (mfd->Horz) HKernel (dst,3,10,4,w,h,pitch);
        if (mfd->Vert) VKernel (dst,mfd->rows,1,14,4,w,h,pitch);
        break;
      case 4:
        if (mfd->Horz) HKernel (dst,1, 2,2,w,h,pitch);
        if (mfd->Vert) VKernel (dst,mfd->rows,1,14,4,w,h,pitch);
        break;
    }
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd =(MyFilterData *)fa->filter_data;
  mfd->Pow= 0;
  mfd->rows[0]= NULL;
  mfd->rows[1]= NULL;
  mfd->rows[2]= NULL;
  mfd->Horz= TRUE;
  mfd->Vert= TRUE;
  return 0;
}


long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;

  mfd->rows[0]= new Pixel32 [fa->dst.w];
  mfd->rows[1]= new Pixel32 [fa->dst.w];
  mfd->rows[2]= new Pixel32 [fa->dst.w];
  if (!mfd->rows[0]) return 1;
  if (!mfd->rows[1]) return 1;
  if (!mfd->rows[2]) return 1;
  return 0;
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;

  if (mfd->rows[0]) { delete[] mfd->rows[0]; mfd->rows[0]= NULL; }
  if (mfd->rows[1]) { delete[] mfd->rows[1]; mfd->rows[1]= NULL; }
  if (mfd->rows[2]) { delete[] mfd->rows[2]; mfd->rows[2]= NULL; }
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg,DWL_USER);

  switch(msg)
    {
      case WM_INITDIALOG:
        SetWindowLong(hdlg, DWL_USER, lParam);
        mfd= (MyFilterData *)lParam;
        CheckDlgButton(hdlg,IDC_NONE,(mfd->Pow==0)?BST_CHECKED:BST_UNCHECKED);
        CheckDlgButton(hdlg,IDC_1_14,(mfd->Pow==1)?BST_CHECKED:BST_UNCHECKED);
        CheckDlgButton(hdlg,IDC_1_06,(mfd->Pow==2)?BST_CHECKED:BST_UNCHECKED);
        CheckDlgButton(hdlg,IDC_3_10,(mfd->Pow==3)?BST_CHECKED:BST_UNCHECKED);
        CheckDlgButton(hdlg,IDC_1_02,(mfd->Pow==4)?BST_CHECKED:BST_UNCHECKED);
        CheckDlgButton(hdlg,IDC_HORZ,mfd->Horz?BST_CHECKED:BST_UNCHECKED);
        CheckDlgButton(hdlg,IDC_VERT,mfd->Vert?BST_CHECKED:BST_UNCHECKED);
        mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
        return TRUE;

      case WM_COMMAND:
        switch(LOWORD(wParam))
          {
            case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
            case IDOK     : EndDialog(hdlg,0); return TRUE;
            case IDCANCEL : EndDialog(hdlg,1); return TRUE;
            case IDC_NONE : mfd->Pow= 0; mfd->ifp->RedoFrame(); break;
            case IDC_1_14 : mfd->Pow= 1; mfd->ifp->RedoFrame(); break;
            case IDC_1_06 : mfd->Pow= 2; mfd->ifp->RedoFrame(); break;
            case IDC_3_10 : mfd->Pow= 3; mfd->ifp->RedoFrame(); break;
            case IDC_1_02 : mfd->Pow= 4; mfd->ifp->RedoFrame(); break;
            case IDC_HORZ : mfd->Horz= IsDlgButtonChecked(hdlg, IDC_HORZ); mfd->ifp->RedoFrame(); break;
            case IDC_VERT : mfd->Vert= IsDlgButtonChecked(hdlg, IDC_VERT); mfd->ifp->RedoFrame(); break;
          }
        break;
    }
 return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp = fa->ifp;
  int result= DialogBoxParam (fa->filter->module->hInstModule,
                              MAKEINTRESOURCE(IDD_FILTER_SMOOTHER),
                              hwnd,ConfigDlgProc,(LPARAM)mfd);
  if (result) *mfd= mfd_old;
  return !!result;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  char HH,VV;

  if (mfd->Horz) HH= 'H'; else HH=' ';
  if (mfd->Vert) VV= 'V'; else VV=' ';
  switch (mfd->Pow)
  {
    case 0: _snprintf(str,64," None"); break;
    case 1: _snprintf(str,64," %c %c [1,14,1]",HH,VV); break;
    case 2: _snprintf(str,64," %c %c [1, 6,1]",HH,VV); break;
    case 3: _snprintf(str,64," %c %c [3,10,3]",HH,VV); break;
    case 4: _snprintf(str,64," %c %c [1, 2,1]",HH,VV); break;
  }
}

inline void Clipping (int &dato,int min,int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d, %d, %d)",mfd->Pow,mfd->Horz,mfd->Vert);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa = (FilterActivation *)lpVoid;
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->Pow= argv[0].asInt();
  mfd->Horz= !!argv[1].asInt();
  mfd->Vert= !!argv[1].asInt();
  Clipping (mfd->Pow,0,4);
}

ScriptFunctionDef func_defs[]=
    {{(ScriptFunctionPtr)ScriptConfig,"Config","0iii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

struct FilterDefinition filterDef_Smoother=
{
  NULL,NULL,NULL,                     // next, prev, module
  "Smoother 1.2",                   // name
  "Blur effects\n"
  "Version 1.2 (07-10-2003)\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",            // desc
  "Emiliano Ferrari",                 // maker
  NULL,                               // private_data
  sizeof(MyFilterData),               // inst_data_size
  InitProc,                           // initProc
  NULL,                               // deinitProc
  RunProc,                            // runProc
  ParamProc,                          // paramProc
  ConfigProc,                         // configProc
  StringProc,                         // stringProc
  StartProc,                          // startProc
  EndProc,                            // endProc
  &script_obj,                        // script_obj
  FssProc,                            // fssProc
};

static FilterDefinition *fd_Smoother;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_Smoother = ff->addFilter(fm, &filterDef_Smoother, sizeof(FilterDefinition));
  if (!fd_Smoother) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
 ff->removeFilter(fd_Smoother);
}
