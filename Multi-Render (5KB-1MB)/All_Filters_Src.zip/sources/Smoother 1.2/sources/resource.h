//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_SMOOTHER             101
#define IDC_NONE                        1004
#define IDC_1_14                        1005
#define IDC_1_06                        1006
#define IDC_3_10                        1007
#define IDC_1_02                        1008
#define IDC_VERT                        1009
#define IDC_HORZ                        1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
