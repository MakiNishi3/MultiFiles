/*  Saturation Matrix - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari  <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.   */

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "resource.h"
#include "ScriptValue.h"

typedef struct
{
  IFilterPreview *ifp;
  int  Sat;
  bool Double,invert;
} MyFilterData;

#define RW 0.3086f
#define GW 0.6094f
#define BW 0.0820f

/*                         RW            GW          BW
ITU Rec. Luma 601:  Y= 0.298912*R + 0.586611*G + 0.114478*B
ITU Rec. Luma 709:  Y= 0.212671*R + 0.715160*G + 0.072169*B
ITU gray:           Y= 0.222015*R + 0.706655*G + 0.071330*B
Linear RGB Correct: Y= 0.3086  *R + 0.6094  *G + 0.0820  *B
YCrCb               Y= 0.257   *R + 0.504   *G + 0.098   *B
Average:            Y= 0.333333*R + 0.333333*G + 0.333333*B;
Red:                Y= 1       *R + 0       *G + 0       *B;
Green:              Y= 0       *R + 1       *G + 0       *B;
Blue:               Y= 0       *R + 0       *G + 1       *B;  */

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  float s= mfd->Sat/256.0f;
  if (mfd->Double) s*= 2;

  const int SR= (int)(65536.0f*s);
  const int SG= (int)(65536.0f*s);
  const int SB= (int)(65536.0f*s);
  const int TR= (int)(65536.0f*RW*(1.0f-s));
  const int TG= (int)(65536.0f*GW*(1.0f-s));
  const int TB= (int)(65536.0f*BW*(1.0f-s));
  const int  psize= fa->dst.size>>2;
  Pixel32 *dst= fa->dst.data;

  int MASK;
  if (mfd->invert) MASK= -1; else MASK= 0;

  for (int p=0; p<psize; p++)
    {
      int a= *dst & 0xff000000;  // alpha
      int r= (*dst>>16) & 0xff;
      int g= (*dst>> 8) & 0xff;
      int b= (*dst    ) & 0xff;
      int t= TR*r+TG*g+TB*b+32768;
      int r2= (t+SR*r)>>16;
      int g2= (t+SG*g)>>16;
      int b2= (t+SB*b)>>16;
      if ((unsigned)r2>255) r2=(~r2>>31)&255; // ATTENZIONE: questo tipo di clipping
      if ((unsigned)g2>255) g2=(~g2>>31)&255; // funziona solo su interi a 32bit
      if ((unsigned)b2>255) b2=(~b2>>31)&255; // altrimensi usare Clipping (valore,0,255);
      *dst++= (a | (r2<<16) | (g2<<8) | b2) ^ MASK;
    }

  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd =(MyFilterData *)fa->filter_data;

  mfd->Sat   = 256;
  mfd->Double= false;
  mfd->invert= false;
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg,DWL_USER);
  char t[128];

  switch(msg)
    {
      case WM_INITDIALOG:
        SetWindowLong(hdlg, DWL_USER, lParam);
        mfd= (MyFilterData *)lParam;
        SendMessage(GetDlgItem(hdlg, IDC_SAT),TBM_SETRANGE,(WPARAM)TRUE,MAKELONG(-256,512));
        SendMessage(GetDlgItem(hdlg,IDC_SAT   ),TBM_SETTICFREQ, 32, 0);
        SendMessage(GetDlgItem(hdlg, IDC_SAT),TBM_SETPOS,(WPARAM)TRUE,mfd->Sat);
        if (mfd->Double) _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/128.0); else _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/256.0);
        SetDlgItemText(hdlg, IDC_SATVAL,t);
        CheckDlgButton(hdlg, IDC_DOUBLE, mfd->Double ? BST_CHECKED : BST_UNCHECKED);
        CheckDlgButton(hdlg, IDC_INVERT, mfd->invert ? BST_CHECKED : BST_UNCHECKED);
        mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
        return TRUE;

      case WM_COMMAND:
        switch(LOWORD(wParam))
          {
            case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
            case IDOK     : EndDialog(hdlg,0); return TRUE;
            case IDCANCEL : EndDialog(hdlg,1); return TRUE;
            case IDC_RESET:
              mfd->Double= false;
              mfd->invert= false;
              mfd->Sat   = 256;
              SendMessage(GetDlgItem(hdlg, IDC_SAT),TBM_SETPOS,(WPARAM)TRUE,mfd->Sat);
              if (mfd->Double) _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/128.0); else _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/256.0);
              SetDlgItemText(hdlg, IDC_SATVAL,t);
              CheckDlgButton(hdlg, IDC_DOUBLE, mfd->Double ? BST_CHECKED : BST_UNCHECKED);
              CheckDlgButton(hdlg, IDC_INVERT, mfd->invert ? BST_CHECKED : BST_UNCHECKED);
              mfd->ifp->RedoFrame();
              break;
            case IDC_DOUBLE:
              mfd->Double= !!IsDlgButtonChecked(hdlg, IDC_DOUBLE);
              if (mfd->Double) _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/128.0); else _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/256.0);
              SetDlgItemText(hdlg, IDC_SATVAL,t);
              mfd->ifp->RedoFrame();
              break;
            case IDC_INVERT:
              mfd->invert= !!IsDlgButtonChecked(hdlg, IDC_INVERT);
              mfd->ifp->RedoFrame();
              break;
            case IDC_SET0:
              mfd->Sat= 0;
              SendMessage(GetDlgItem(hdlg,IDC_SAT),TBM_SETPOS,(WPARAM)TRUE,mfd->Sat);
              if (mfd->Double) _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/128.0); else _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/256.0);
              SetDlgItemText(hdlg, IDC_SATVAL,t);
              mfd->ifp->RedoFrame();
              return TRUE;
            case IDC_SET1:
              mfd->Sat= 256;
              SendMessage(GetDlgItem(hdlg,IDC_SAT),TBM_SETPOS,(WPARAM)TRUE,mfd->Sat);
              if (mfd->Double) _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/128.0); else _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/256.0);
              SetDlgItemText(hdlg, IDC_SATVAL,t);
              mfd->ifp->RedoFrame();
              return TRUE;
          }
        break;
      case WM_HSCROLL:
        mfd->Sat= SendMessage(GetDlgItem(hdlg, IDC_SAT), TBM_GETPOS, 0, 0);
        if (mfd->Double) _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/128.0); else _snprintf (t,128," Saturation (%1.2f) ",mfd->Sat/256.0);
        SetDlgItemText(hdlg, IDC_SATVAL,t);
        mfd->ifp->RedoFrame();
        break;
    }
 return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp = fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_SATURATION),
                          hwnd,ConfigDlgProc,(LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return !!ret;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf (str,64," (%1.2f)",mfd->Double?(mfd->Sat/128.0):(mfd->Sat/256.0));
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d, %d, %d)",mfd->Sat,mfd->Double,mfd->invert);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa = (FilterActivation *)lpVoid;
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  mfd->Sat   =   argv[0].asInt();
  mfd->Double= !!argv[1].asInt();
  mfd->Double= !!argv[2].asInt();
  Clipping (mfd->Sat,-256,512);
}

ScriptFunctionDef func_defs[]=
{{(ScriptFunctionPtr)ScriptConfig,"Config","0iii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};


struct FilterDefinition filterDef_Saturation =
{
  NULL,NULL,NULL,                     // next, prev, module
  "Saturation 2.1",                   // name
  "adjust the saturation of colors in the image.\n"
  "Version 2.1 (High Quality) (30-10-2004)\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",            // desc
  "Emiliano Ferrari",                 // maker
  NULL,                               // private_data
  sizeof(MyFilterData),               // inst_data_size
  InitProc,                           // initProc
  NULL,                               // deinitProc
  RunProc,                            // runProc
  ParamProc,                          // paramProc
  ConfigProc,                         // configProc
  StringProc,                         // stringProc
  NULL,                               // startProc
  NULL,                               // endProc
  &script_obj,                        // script_obj
  FssProc,                            // fssProc
};

static FilterDefinition *fd_Saturation;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_Saturation= ff->addFilter(fm, &filterDef_Saturation, sizeof(FilterDefinition));
  if (!fd_Saturation) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_Saturation);
}
