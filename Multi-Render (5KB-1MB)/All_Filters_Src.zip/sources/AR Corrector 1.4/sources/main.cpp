/* AspectRatio - filter for VirtualDub
   ONLY FOR MMX and ISSE CPU.
   Copyright (C) 2003,2004 Emiliano Ferrari   <macinapepe@tiscali.it>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

  Version 1.3 (27-09-2003): ?
  Version 1.4 (17-03-2004): aggiunto aspect ratio 1:1
*/

#include <math.h>
#include <stdio.h>
#include "resource.h"
#include "filter.h"
#include "ScriptValue.h"

#define PAL_43   0 //0.9375
#define PAL_169  1 //0.703125
#define NTSC_43  2 //1.125
#define NTSC_169 3 //0.84375
#define ORG_11     4 //1.0000

typedef Pixel32 *PPixel32;

typedef struct MyFilterData
{
  IFilterPreview *ifp;
  int ar;
  double A;
  PPixel32 *S;
  PPixel32 *D;
  __int64 *V;
} MyFilterData;

inline void Clipping (int &dato,int min,int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;

  double AR=1.0;
  switch (mfd->ar)
  {
     case ORG_11  : AR=1.0; break;
     case PAL_43  : AR=0.9375; break;
     case PAL_169 : AR=0.703125; break;
     case NTSC_43 : AR=1.125; break;
     case NTSC_169: AR=0.84375; break;
  }
  fa->dst.h= (int)(0.5+fa->src.h*AR);
  return FILTERPARAM_SWAP_BUFFERS;
}

int xClipping (int dato,const int min,const int max)
{
  if (dato<min) return min; else if (dato>max) return max; else return dato;
}

__int64 BuildQ (short A,short R,short G,short B)
{
  __int64 Quadword;
  *(((short *)&Quadword)+0)= B;
  *(((short *)&Quadword)+1)= G;
  *(((short *)&Quadword)+2)= R;
  *(((short *)&Quadword)+3)= A;
  return Quadword;
}

void BuildTables (PPixel32 S[],PPixel32 D[],__int64 V[],int hdst,int hsrc,int psrc,int pdst,PPixel32 source,PPixel32 dest)
{ // Tutti i calcoli vengono effettuati in questa procedura una sola volta per tutto il film.

    int p;
  double v1,v2,v3,v4;
  int vc,vd,ve,vb;
  const double A= -1.00; //(A= -0.75 per un'immagine leggermente sfumato)
  for (int y=0; y<hdst; y++)
    {
      double j= 0.5+((double)(y)*hsrc)/hdst;
      // Indice dei 4 pixel sorgenti da calcolare
      p= (int)j;
      S[y*4+0]= source + psrc*xClipping (p-1,0,hsrc-1);
      S[y*4+1]= source + psrc*xClipping (p  ,0,hsrc-1);
      S[y*4+2]= source + psrc*xClipping (p+1,0,hsrc-1);
      S[y*4+3]= source + psrc*xClipping (p+2,0,hsrc-1);
      // Costanti per la moltiplicazione
      double d= j-p;

      v1= A*d-2.0*A*d*d+A*d*d*d;
      v2= 1.0-(A+3.0)*d*d+(A+2.0)*d*d*d;
      v3= -A*d+(2.0*A+3.0)*d*d-(A+2.0)*d*d*d;
      v4= A*d*d-A*d*d*d;
      vb= (int)floor(16384.0*v1);
      vc= (int)floor(16384.0*v2);
      vd= (int)floor(16384.0*v3);
      ve= (int)floor(16384.0*v4);
      vc+= (16384-(vb+vc+vd+ve));
      V[y*4+0]= BuildQ(vb,vb,vb,vb);
      V[y*4+1]= BuildQ(vc,vc,vc,vc);
      V[y*4+2]= BuildQ(vd,vd,vd,vd);
      V[y*4+3]= BuildQ(ve,ve,ve,ve);
      D[y]= dest+y*pdst;  // Genera offset per i pixel destinazione
    }
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  if (mfd->S) { delete[] mfd->S; mfd->S=NULL; }
  if (mfd->D) { delete[] mfd->D; mfd->D=NULL; }
  if (mfd->V) { delete[] mfd->V; mfd->V=NULL; }

  mfd->S= new PPixel32[fa->dst.h*4]; if (!mfd->S) return -1; //ff->ExceptOutOfMemory();
  mfd->D= new PPixel32[fa->dst.h*4]; if (!mfd->D) { delete[]mfd->S; mfd->S=NULL; return -1; /*ff->ExceptOutOfMemory();*/ }
  mfd->V= new __int64[fa->dst.h*4];  if (!mfd->V) { delete[]mfd->S; mfd->S=NULL; delete[]mfd->D; mfd->D=NULL; return -1; /* ff->ExceptOutOfMemory(); */}

  BuildTables (mfd->S,mfd->D,mfd->V,fa->dst.h,fa->src.h,fa->src.pitch>>2,fa->dst.pitch>>2,fa->src.data,fa->dst.data);
  return 0;
}

void Row_iSSE (Pixel32 *src1,Pixel32 *src2,Pixel32 *src3,Pixel32 *src4,Pixel32 *dst,int pSize,__int64 v1,__int64 v2,__int64 v3,__int64 v4)
{//  for (int x=0; x<(fa->dst.w*4); x++)
 //   *dst++= Clipping((((*s1++)*v1 +(*s2++)*v2 +(*s3++)*v3 +(*s4++)*v4)>>14),0,255);
  __asm { mov         ecx,[pSize]
          mov         eax,[src1]
          mov         ebx,[src2]
          mov         edx,[src3]
          mov         esi,[src4]
          mov         edi,[dst]
          pxor        mm7,mm7
          lea         eax,[eax+ecx*4]
          lea         ebx,[ebx+ecx*4]
          lea         edx,[edx+ecx*4]
          lea         edi,[edi+ecx*4]
          lea         esi,[esi+ecx*4]
          neg         ecx
          movq        mm6,[v1]
          movq        mm5,[v2]
          movq        mm4,[v3]
          align       16
MainLoop: movd        mm0,[eax+ecx*4]
          movd        mm1,[ebx+ecx*4]
          movd        mm2,[edx+ecx*4]
          punpcklbw   mm0,mm7
          movd        mm3,[esi+ecx*4]
          punpcklbw   mm1,mm7
          psllw       mm0,6
          punpcklbw   mm2,mm7
          psllw       mm1,6
          punpcklbw   mm3,mm7
          psllw       mm2,6
          pmulhw      mm0,mm6
          psllw       mm3,6
          pmulhw      mm1,mm5
          prefetchnta [edx+ecx*4]
          prefetchnta [esi+ecx*4]
          pmulhw      mm2,mm4
          prefetchnta [eax+ecx*4]
          prefetchnta [ebx+ecx*4]
          pmulhw      mm3,[v4]
          paddw       mm0,mm1
          paddw       mm2,mm3
          paddw       mm0,mm2
          psraw       mm0,4
          packuswb    mm0,mm0
          movd        [edi+ecx*4],mm0
          inc         ecx
          jnz         MainLoop
          emms
    }
}

void Row_MMX (Pixel32 *src1,Pixel32 *src2,Pixel32 *src3,Pixel32 *src4,Pixel32 *dst,int pSize,__int64 v1,__int64 v2,__int64 v3,__int64 v4)
{//  for (int x=0; x<(fa->dst.w*4); x++)
 //   *dst++= Clipping((((*s1++)*v1 +(*s2++)*v2 +(*s3++)*v3 +(*s4++)*v4)>>14),0,255);
  __asm { mov         ecx,[pSize]
          mov         eax,[src1]
          mov         ebx,[src2]
          mov         edx,[src3]
          mov         esi,[src4]
          mov         edi,[dst]
          pxor        mm7,mm7
          lea         eax,[eax+ecx*4]
          lea         ebx,[ebx+ecx*4]
          lea         edx,[edx+ecx*4]
          lea         edi,[edi+ecx*4]
          lea         esi,[esi+ecx*4]
          neg         ecx
          movq        mm6,[v1]
          movq        mm5,[v2]
          movq        mm4,[v3]
          align       16
MainLoop: movd        mm0,[eax+ecx*4]
          movd        mm1,[ebx+ecx*4]
          movd        mm2,[edx+ecx*4]
          punpcklbw   mm0,mm7
          movd        mm3,[esi+ecx*4]
          punpcklbw   mm1,mm7
          psllw       mm0,6
          punpcklbw   mm2,mm7
          psllw       mm1,6
          punpcklbw   mm3,mm7
          psllw       mm2,6
          pmulhw      mm0,mm6
          psllw       mm3,6
          pmulhw      mm1,mm5
          pmulhw      mm2,mm4
          pmulhw      mm3,[v4]
          paddw       mm0,mm1
          paddw       mm2,mm3
          paddw       mm0,mm2
          psraw       mm0,4
          packuswb    mm0,mm0
          movd        [edi+ecx*4],mm0
          inc         ecx
          jnz         MainLoop
          emms
    }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
    for (int y=0; y<fa->dst.h; y++)
        Row_iSSE (mfd->S[y*4+0],mfd->S[y*4+1],mfd->S[y*4+2],mfd->S[y*4+3],mfd->D[y],fa->dst.w,mfd->V[y*4+0],mfd->V[y*4+1],mfd->V[y*4+2],mfd->V[y*4+3]);
  else
    if ((CPUF_SUPPORTS_MMX & ff->getCPUFlags()))
      for (int y=0; y<fa->dst.h; y++)
          Row_MMX (mfd->S[y*4+0],mfd->S[y*4+1],mfd->S[y*4+2],mfd->S[y*4+3],mfd->D[y],fa->dst.w,mfd->V[y*4+0],mfd->V[y*4+1],mfd->V[y*4+2],mfd->V[y*4+3]);
    else
      ff->Except("MMX CPU required.");
  return 0;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      switch (mfd->ar)
      {
        case ORG_11  : CheckDlgButton(hdlg, IDC_ORIGINAL,BST_CHECKED); break;
        case PAL_43  : CheckDlgButton(hdlg, IDC_PAL43  ,BST_CHECKED); break;
        case PAL_169 : CheckDlgButton(hdlg, IDC_PAL169 ,BST_CHECKED); break;
        case NTSC_43 : CheckDlgButton(hdlg, IDC_NTSC43 ,BST_CHECKED); break;
        case NTSC_169: CheckDlgButton(hdlg, IDC_NTSC169,BST_CHECKED); break;
      }
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW:mfd->ifp->Toggle(hdlg);  break;
        case IDOK:     EndDialog(hdlg,0); return TRUE;
        case IDCANCEL: EndDialog(hdlg,1); return TRUE;

        case IDC_ORIGINAL:
        case IDC_PAL43:
        case IDC_PAL169:
        case IDC_NTSC43:
        case IDC_NTSC169:
            {
            mfd->ifp->UndoSystem();
            if (IsDlgButtonChecked(hdlg,IDC_ORIGINAL)) mfd->ar= ORG_11;  else
            if (IsDlgButtonChecked(hdlg,IDC_PAL43))   mfd->ar= PAL_43;  else
            if (IsDlgButtonChecked(hdlg,IDC_PAL169))  mfd->ar= PAL_169; else
            if (IsDlgButtonChecked(hdlg,IDC_NTSC43))  mfd->ar= NTSC_43; else
            if (IsDlgButtonChecked(hdlg,IDC_NTSC169)) mfd->ar= NTSC_169;
            mfd->ifp->RedoSystem();
            mfd->ifp->RedoFrame();
            break;
            }
      }
  }
  return FALSE;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->ar= ORG_11;
  mfd->A= -1.0;
  mfd->S= NULL;
  mfd->D= NULL;
  mfd->V= NULL;
  return 0;
}

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  switch (mfd->ar)
  {
  case ORG_11:   _snprintf(str,64,"  ORIGINAL 1:1  "); break;
  case PAL_43:   _snprintf(str,64,"  PAL 4:3  "); break;
  case PAL_169:  _snprintf(str,64,"  PAL 16:9 "); break;
  case NTSC_43:  _snprintf(str,64,"  NTSC 4:3 "); break;
  case NTSC_169: _snprintf(str,64,"  NTSC 16:9"); break;
  }
}

int EndProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  if (mfd->S) { delete[] mfd->S; mfd->S=NULL; }
  if (mfd->D) { delete[] mfd->D; mfd->D=NULL; }
  if (mfd->V) { delete[] mfd->V; mfd->V=NULL; }
  return 0;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_ASPECTRATIO),
                          hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd= mfd_old;
  return !!ret;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(buf, buflen, "Config(%d)",mfd->ar);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->ar= argv[0].asInt();
  Clipping (mfd->ar,0,4);
}

ScriptFunctionDef func_defs[]=
    {{(ScriptFunctionPtr)ScriptConfig,"Config","0i"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

struct FilterDefinition filterDef_AR=
{ NULL,NULL,NULL,           // next, prev, module
  "Aspect Ratio (MMX only)",// name
  "Correct aspect ratio for NTSC/PAL DV/DVD video.\n"
  "Version 1.4 (17-03-2004) [MMX/iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",  // desc
  "Emiliano Ferrari",       // maker
  NULL,                     // private_data
  sizeof(MyFilterData),     // inst_data_size
  InitProc,                 // initProc
  NULL,                     // deinitProc
  RunProc,                  // runProc
  ParamProc,                // paramProc
  ConfigProc,               // configProc
  StringProc,               // stringProc
  StartProc,                // startProc
  EndProc,                  // endProc
  &script_obj,             // script_obj
  FssProc,                  // fssProc
};

static FilterDefinition *fd_AR;

extern "C" int __declspec(dllexport) __cdecl
  VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_AR= ff->addFilter(fm, &filterDef_AR, sizeof(FilterDefinition));
  if (!fd_AR) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl
  VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_AR);
}
