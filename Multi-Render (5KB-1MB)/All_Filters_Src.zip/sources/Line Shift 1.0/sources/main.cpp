/*  Line Shift - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari   <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA */

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "filter.h"
#include "ScriptValue.h"
#include "resource.h"

#pragma warning(disable:4035)
#include "memcpy_amd.cpp"

typedef void *(MEMCPY) (void *,const void *,size_t);
MEMCPY *_memcpy;

typedef struct
{
  int x,y;
  int red,green,blue;
  COLORREF color_ref;
  HBRUSH   color_brush;
  IFilterPreview *ifp;
} MyFilterData;

void memfill (Pixel32 *dst,Pixel32 color,int size)
{
  for (int i=0; i<size; i++) *dst++= color;
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  Pixel32 *dst= fa->dst.data;
  Pixel32 color= (mfd->red<<16) | (mfd->green<<8) | mfd->blue;
  const int pitch= fa->dst.pitch>>2;
  const int w    = fa->dst.w;
  const int h    = fa->dst.h;
  int x= mfd->x;
  int y= (h-1)-mfd->y;

  if (y<0 || y>=h) return 0;
  dst+= y*pitch;
  if (x+w<0 || x>w) { memfill (dst,color,w); return 0; }

  if (x>=0)
  {
    for (int i= (w-x)-1; i>=0; i--) dst[x+i]=dst[i];
    memfill (dst,color,x);
  }
  else
  {
    x= -x;
    memcpy (dst,dst+x,(w-x-1)*4);
    memfill (dst+(w-x-1),color,x);
  }
  return 0;
}

int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  mfd->x= 0;
  mfd->y= 0;
  mfd->color_ref= RGB (0,0,0);
  mfd->red= mfd->green= mfd->blue= 0;
  mfd->color_brush= CreateSolidBrush (mfd->color_ref);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

int StartProc(FilterActivation *fa, const FilterFunctions *ff)
{
  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags())) _memcpy= memcpy_amd; else _memcpy= memcpy;
  return 0;
}

void MyChooseColor(COLORREF &Color,HWND hdlg)
{
  CHOOSECOLOR cc;
  static COLORREF Custom[16];

  cc.lStructSize= sizeof(CHOOSECOLOR);
  cc.hwndOwner= hdlg;
  cc.rgbResult= Color;
  cc.lpCustColors= Custom;
  cc.Flags= CC_RGBINIT | CC_FULLOPEN;
  cc.lCustData= 0L;
  cc.lpfnHook= NULL;
  cc.lpTemplateName= NULL;
  ChooseColor(&cc);
  Color= cc.rgbResult;
}

void BuildBrush(MyFilterData *mfd,HWND hdlg)
{
  DeleteObject (mfd->color_brush);
  mfd->color_brush= CreateSolidBrush (mfd->color_ref);
  RedrawWindow (GetDlgItem(hdlg,IDC_COLORBOX),NULL,NULL,RDW_ERASE|RDW_INVALIDATE|RDW_UPDATENOW);
}

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

  switch(msg)
  {

    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SetDlgItemInt (hdlg,IDC_X,mfd->x,true);
      SetDlgItemInt (hdlg,IDC_Y,mfd->y,true);
      SendMessage(GetDlgItem(hdlg, IDC_XSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(8192,-8192));
      SendMessage(GetDlgItem(hdlg, IDC_YSPIN), UDM_SETRANGE, 0, (LPARAM)MAKELONG(0,8192));
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg,0); return TRUE;
        case IDCANCEL:  EndDialog(hdlg,1); return TRUE;

        case IDC_X:
            if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int x= GetDlgItemInt(hdlg,IDC_X,NULL,true);
            if (x!=mfd->x)
            {
              mfd->x= x;
              mfd->ifp->RedoFrame();
            }
          }
          break;

        case IDC_Y:
          if ((HIWORD(wParam)==EN_CHANGE) && (mfd!=NULL))
          {
            int y= GetDlgItemInt(hdlg,IDC_Y,NULL,true);
            if (y!=mfd->y)
            {
              mfd->y= y;
              mfd->ifp->RedoFrame();
            }
          }
          break;

        case IDC_COLORBOX:
            if (HIWORD(wParam)!=STN_DBLCLK) return TRUE;
        case IDC_PICCOLOR:
            MyChooseColor(mfd->color_ref,hdlg);
            BuildBrush (mfd,hdlg);
            mfd->red= GetRValue(mfd->color_ref);
            mfd->green= GetGValue(mfd->color_ref);
            mfd->blue= GetBValue(mfd->color_ref);
            mfd->ifp->RedoFrame();
            return TRUE;
      }
      break;

    case WM_VSCROLL:
    case WM_HSCROLL:
    {
      int x= GetDlgItemInt(hdlg,IDC_X,NULL,true);
      int y= GetDlgItemInt(hdlg,IDC_Y,NULL,true);
      if (x!=mfd->x || y!=mfd->y)
      {
        mfd->x= x;
        mfd->y= y;
        mfd->ifp->RedoFrame();
      }
      break;
    }

    case WM_CTLCOLORSTATIC:
          if (GetWindowLong((HWND)lParam,GWL_ID)== IDC_COLORBOX) return (BOOL)mfd->color_brush;
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old= *mfd;
  mfd->ifp= fa->ifp;

  int res=DialogBoxParam(fa->filter->module->hInstModule,
                        MAKEINTRESOURCE(IDD_FILTER_SHIFT),
                        hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (res) *mfd= mfd_old;
  return res;
}

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d, %d, %d)",
      mfd->y,mfd->x,(mfd->red<<16)|(mfd->green<<8)|mfd->blue);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->y= argv[0].asInt();
  mfd->x= argv[1].asInt();
  if (mfd->y<0) mfd->y=0;
  mfd->red  = (argv[2].asInt()>>16)&0xff;
  mfd->green= (argv[2].asInt()>> 8)&0xff;
  mfd->blue = (argv[2].asInt()    )&0xff;
  mfd->color_ref= RGB(mfd->red,mfd->blue,mfd->green);
}

ScriptFunctionDef func_defs[]= {{(ScriptFunctionPtr)ScriptConfig,"Config","0iii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
   _snprintf(str,64," (Line:%d: %d,#%06X)", mfd->y,mfd->x,(mfd->red<<16)|(mfd->green<<8)|mfd->blue);
}

FilterDefinition filterDef_lshift=
{
  NULL, NULL, NULL,            // next, prev, module
  "Line Shift",                // name
  "adjust position of single line\n"
  "Version 1.0 (27-09-2003)\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it\n",   // desc
  "Emiliano Ferrari",          // maker
  NULL,                        // private_data
  sizeof(MyFilterData),        // inst_data_size
  InitProc,                    // initProc
  NULL,                        // deinitProc
  RunProc,                     // runProc
  ParamProc,                   // paramProc
  ConfigProc,                  // configProc
  StringProc,                  // stringProc
  StartProc,                   // startProc
  NULL,                        // endProc
  &script_obj,                 // script_obj
  FssProc,                     // fssProc
};

static FilterDefinition *fd_lshift;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_lshift= ff->addFilter(fm, &filterDef_lshift, sizeof(FilterDefinition));
  if (!fd_lshift) return 1;
  vdfd_ver   = VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_lshift);
}
