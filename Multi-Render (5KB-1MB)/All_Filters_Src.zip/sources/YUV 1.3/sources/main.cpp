/*  RGB <-> YUV Color Space - filter for VirtualDub
    Copyright (C) 2003 Emiliano Ferrari  <macinapepe@tiscali.it>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details. */

// + merged YUV2RGB and RGB2YUV in YUV,and change U/V to U/V.
// 08-10-2003 v. 1.3
// + now Y,U,V change from 0 to 255

#include <stdio.h>
#include "filter.h"
#include <windows.h>
#include <commctrl.h>

inline void Clipping (int &dato,int min,int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

void RGB2YUV(int r,int g,int b,int &Y,int &U,int &V)
{
 // input:  r,g,b [0..255]
 // output: Y,U,V [0..255]
 const int Yr= (int)( 0.257*65536.0*255.0/219.0);
 const int Yg= (int)( 0.504*65536.0*255.0/219.0);
 const int Yb= (int)( 0.098*65536.0*255.0/219.0);
 const int Ur= (int)( 0.439*65536.0*255.0/223.0);
 const int Ug= (int)(-0.368*65536.0*255.0/223.0);
 const int Ub= (int)(-0.071*65536.0*255.0/223.0);
 const int Vr= (int)(-0.148*65536.0*255.0/223.0);
 const int Vg= (int)(-0.291*65536.0*255.0/223.0);
 const int Vb= (int)( 0.439*65536.0*255.0/223.0);

 Y= ((int)(Yr * r + Yg * g + Yb * b+32767)>>16);
 U= ((int)(Ur * r + Ug * g + Ub * b+32767)>>16)+128;
 V= ((int)(Vr * r + Vg * g + Vb * b+32767)>>16)+128;
 if ((unsigned)U>255) U=(~U>>31)&0xff;
 if ((unsigned)V>255) V=(~V>>31)&0xff;
}

void YUV2RGB(int Y,int U,int V,int &r,int &g,int &b)
{
  // input:  Y,U,V [0..255]
  // output: r,g,b [0..255]

 const int YK= (int)(1.164*65536.0*219.0/255.0);
 const int k1= (int)(1.596*65536.0*223.0/255.0);
 const int k2= (int)(0.813*65536.0*223.0/255.0);
 const int k3= (int)(2.018*65536.0*223.0/255.0);
 const int k4= (int)(0.391*65536.0*223.0/255.0);

 Y*= YK;
 U-= 128;
 V-= 128;

 r= (Y+k1*U+32768)>>16;
 g= (Y-k2*U-k4*V+32768)>>16;
 b= (Y+k3*V+32768)>>16;

 if ((unsigned)r>255) r=(~r>>31)&0xff;
 if ((unsigned)g>255) g=(~g>>31)&0xff;
 if ((unsigned)b>255) b=(~b>>31)&0xff;
}


int YUV_to_RGB_RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  Pixel32 *dst=fa->dst.data;
  const int psize= fa->dst.size>>2;

  for (int p=0; p<psize; p++)
  {
    int r,g,b;
    int U= (*dst>>16) & 0xff;
    int Y= (*dst>> 8) & 0xff;
    int V= (*dst    ) & 0xff;

    YUV2RGB (Y,U,V,r,g,b);
    *dst++= (r<<16) | (g<<8) | b;
  }
  return 0;
}
int RGB_to_YUV_RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  Pixel32 *dst;
  const int psize= fa->dst.size>>2;

  dst = fa->dst.data;
  for (int p=0; p<psize; p++)
  {
    int Y,U,V;
    int r= (*dst>>16) & 0xff;
    int g= (*dst>> 8) & 0xff;
    int b= (*dst    ) & 0xff;

    RGB2YUV (r,g,b,Y,U,V);

    *dst++= (U<<16) | (Y<<8) | V;
  }
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

struct FilterDefinition filterDef_RGB2YUV=
{
  NULL, NULL, NULL,               // next, prev, module
  "RGB to YUV",                   // name
  "Red= U, Green= Y, Blue= V\n"
  "Version 1.3 (08-10-2003)\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",        // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  0,                              // inst_data_size
  NULL,                           // initProc
  NULL,                           // deinitProc
  RGB_to_YUV_RunProc,             // runProc
  ParamProc,                      // paramProc
  NULL,                           // configProc
  NULL,                           // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  NULL,                           // script_obj
  NULL,                           // fssProc
};

struct FilterDefinition filterDef_YUV2RGB=
{
  NULL, NULL, NULL,               // next, prev, module
  "YUV to RGB",                   // name
  "inverse of RGB to YUV filter\n"
  "Version 1.3 (08-10-2003)\n"
  "Copyright (C) 2003  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",        // desc
  "Emiliano Ferrari",             // maker
  NULL,                           // private_data
  0,                              // inst_data_size
  NULL,                           // initProc
  NULL,                           // deinitProc
  YUV_to_RGB_RunProc,             // runProc
  ParamProc,                      // paramProc
  NULL,                           // configProc
  NULL,                           // stringProc
  NULL,                           // startProc
  NULL,                           // endProc
  NULL,                           // script_obj
  NULL,                           // fssProc
};

static FilterDefinition *fd_YUV2RGB,*fd_RGB2YUV;

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_YUV2RGB= ff->addFilter(fm, &filterDef_YUV2RGB, sizeof(FilterDefinition));
  fd_RGB2YUV= ff->addFilter(fm, &filterDef_RGB2YUV, sizeof(FilterDefinition));
  if (!fd_YUV2RGB) return 1;
  if (!fd_RGB2YUV) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_YUV2RGB);
  ff->removeFilter(fd_RGB2YUV);
}
