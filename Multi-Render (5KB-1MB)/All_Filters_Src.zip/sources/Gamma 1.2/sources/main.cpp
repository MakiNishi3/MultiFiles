/*  Gamma - filter for VirtualDub
    Copyright (C) 2003,2004 Emiliano Ferrari

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA

    Emiliano Ferrari
    e-mail: macinapepe@tiscali.it                                */

// Version 1.2 (23-09-2003) [iSSE]
// Version 1.3 (30-10-2004): rimossi alcuni possibili buffer overflow

#include <math.h>
#include <stdio.h>
#include "filter.h"
#include <commctrl.h>
#include "resource.h"
#include "ScriptValue.h"

#define GMIN 0
#define GMAX 400

typedef struct
{
  IFilterPreview *ifp;
  int red,green,blue;
  int RGBLut[256*3];
  int link;
} MyFilterData;

inline void Clipping (int &dato,const int min,const int max)
{
  if (dato<min) dato=min; else if (dato>max) dato=max;
}

int Gamma (int data,double gamma)
{
  double igamma,fdata,result;

  igamma= 1.0/gamma;
  fdata = data/255.0;
  result= 255.0*pow(fdata,igamma);
  return (int)(result+0.5);
}

void BuildTables (MyFilterData *mfd)
{
  for (int l=0; l<256; l++)
  {
    mfd->RGBLut[l]    = Gamma (l,mfd->red  /100.0)<<16;
    mfd->RGBLut[l+256]= Gamma (l,mfd->green/100.0)<<8;
    mfd->RGBLut[l+512]= Gamma (l,mfd->blue /100.0);
  }
}

void Gamma_iSSE (Pixel32 *dst,int *Tab,int psize)
{
  __asm {
            mov     edi,[dst]
            mov     esi,[Tab]
            mov     ecx,[psize]

            align     16
GLoop:      mov     eax,[edi]
            xor     ebx,ebx
            mov     edx,eax
            mov     bl,ah
            and     edx,0xff0000
            and     eax,0xff
            shr     edx,16
            movd    mm0,[esi+eax*4+(512*4)]
            prefetchnta [edi+512]
            por     mm0,[esi+ebx*4+(256*4)]
            por     mm0,[esi+edx*4        ]
            movd    [edi],mm0
            add     edi,4
            dec     ecx
            jnz     GLoop
            emms
  }
}

int RunProc(const FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  const int psize= fa->dst.size>>2;
  Pixel32 *dst= fa->dst.data;

  if ((CPUF_SUPPORTS_INTEGER_SSE & ff->getCPUFlags()))
  {
    Gamma_iSSE (dst,mfd->RGBLut,psize);
    return 0;
  }

  for (int p=0; p<psize; p++)
  {
    int r,g,b;
    r= (*dst>>16)&0xff;
    g= (*dst>> 8)&0xff;
    b= (*dst    )&0xff;
    *dst++= mfd->RGBLut[r] | mfd->RGBLut[g+256] | mfd->RGBLut[b+512];
  }
  return 0;
}


int InitProc(FilterActivation *fa, const FilterFunctions *ff)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;

  mfd->red  = 100;
  mfd->green= 100;
  mfd->blue = 100;
  mfd->link = true;
  BuildTables (mfd);
  return 0;
}

long ParamProc(FilterActivation *fa, const FilterFunctions *ff)
{
  fa->dst.offset= fa->src.offset;
  return 0;
}

// ===============================================================

void StringProc(const FilterActivation *fa, const FilterFunctions *ff, char *str)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  _snprintf(str,64," (%1.2f  %1.2f  %1.2f)", mfd->red/100.0,mfd->green/100.0,mfd->blue/100.0);
}

BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  MyFilterData *mfd= (MyFilterData *)GetWindowLong(hdlg, DWL_USER);
  char t[128];

  switch(msg)
  {
    case WM_INITDIALOG:
      SetWindowLong(hdlg, DWL_USER, lParam);
      mfd = (MyFilterData *)lParam;
      SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(GMIN,GMAX));
      SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETPOS, (WPARAM)TRUE, mfd->red);
      SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(GMIN,GMAX));
      SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETPOS, (WPARAM)TRUE, mfd->green);
      SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(GMIN,GMAX));
      SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETPOS, (WPARAM)TRUE, mfd->blue);
      _snprintf (t,128,"%1.2f",mfd->red/100.0);
      SetDlgItemText(hdlg,IDC_REDVAL,t);
      _snprintf (t,128,"%1.2f",mfd->green/100.0);
      SetDlgItemText(hdlg,IDC_GREENVAL,t);
      _snprintf (t,128,"%1.2f",mfd->blue/100.0);
      SetDlgItemText(hdlg,IDC_BLUEVAL,t);
      CheckDlgButton(hdlg, IDC_LINK, mfd->link ? BST_CHECKED : BST_UNCHECKED);
      mfd->ifp->InitButton(GetDlgItem(hdlg, IDPREVIEW));
      return TRUE;

    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDPREVIEW: mfd->ifp->Toggle(hdlg);  break;
        case IDOK:      EndDialog(hdlg, 0);  return TRUE;
        case IDCANCEL:  EndDialog(hdlg, 1);  return TRUE;
        case IDC_LINK: mfd->link = IsDlgButtonChecked(hdlg, IDC_LINK);break;
        case IDC_RESET:
          mfd->red  = 100;
          mfd->blue = 100;
          mfd->green= 100;
          SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETPOS, (WPARAM)TRUE, mfd->red);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETPOS, (WPARAM)TRUE, mfd->green);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETPOS, (WPARAM)TRUE, mfd->blue);
          _snprintf (t,128,"%1.2f",mfd->red/100.0);
          SetDlgItemText(hdlg,IDC_REDVAL,t);
          _snprintf (t,128,"%1.2f",mfd->green/100.0);
          SetDlgItemText(hdlg,IDC_GREENVAL,t);
          _snprintf (t,128,"%1.2f",mfd->blue/100.0);
          SetDlgItemText(hdlg,IDC_BLUEVAL,t);
          BuildTables (mfd);
          mfd->ifp->RedoFrame();
          return TRUE;
      }
      break;

    case WM_HSCROLL:
      {
        int r,g,b;
        r= SendMessage(GetDlgItem(hdlg, IDC_RED),   TBM_GETPOS, 0, 0);
        g= SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_GETPOS, 0, 0);
        b= SendMessage(GetDlgItem(hdlg, IDC_BLUE),  TBM_GETPOS, 0, 0);

        if (mfd->link) // link
        {
          int d= (r - mfd->red) + (g - mfd->green) + (b - mfd->blue);
          r= mfd->red + d;
          g= mfd->green + d;
          b= mfd->blue + d;
          Clipping (r,GMIN,GMAX);
          Clipping (g,GMIN,GMAX);
          Clipping (b,GMIN,GMAX);
          SendMessage(GetDlgItem(hdlg, IDC_RED), TBM_SETPOS, (WPARAM)TRUE, r);
          SendMessage(GetDlgItem(hdlg, IDC_GREEN), TBM_SETPOS, (WPARAM)TRUE, g);
          SendMessage(GetDlgItem(hdlg, IDC_BLUE), TBM_SETPOS, (WPARAM)TRUE, b);
        }
        _snprintf (t,128,"%1.2f",mfd->red/100.0);
        SetDlgItemText(hdlg,IDC_REDVAL,t);
        _snprintf (t,128,"%1.2f",mfd->green/100.0);
        SetDlgItemText(hdlg,IDC_GREENVAL,t);
        _snprintf (t,128,"%1.2f",mfd->blue/100.0);
        SetDlgItemText(hdlg,IDC_BLUEVAL,t);
        mfd->red= r;
        mfd->green= g;
        mfd->blue= b;
        BuildTables (mfd);
        mfd->ifp->RedoFrame();
        break;
      }
  }
  return FALSE;
}

int ConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd)
{
  MyFilterData *mfd = (MyFilterData *)fa->filter_data;
  MyFilterData mfd_old = *mfd;
  mfd->ifp = fa->ifp;
  int ret= DialogBoxParam(fa->filter->module->hInstModule,
                          MAKEINTRESOURCE(IDD_FILTER_GAMMA),
                          hwnd, ConfigDlgProc, (LPARAM)mfd);
  if (ret) *mfd = mfd_old;
  return !!ret;
}

// ======================================================

bool FssProc(FilterActivation *fa, const FilterFunctions *ff, char *buf, int buflen)
{
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;
  _snprintf(buf,buflen,"Config(%d,%d,%d,%d)",mfd->red,mfd->green,mfd->blue,mfd->link);
  return true;
}

void ScriptConfig(IScriptInterpreter *isi, void *lpVoid, CScriptValue *argv, int argc)
{
  FilterActivation *fa= (FilterActivation *)lpVoid;
  MyFilterData *mfd= (MyFilterData *)fa->filter_data;

  mfd->red  =   argv[0].asInt();
  mfd->green=   argv[1].asInt();
  mfd->blue =   argv[2].asInt();
  mfd->link = !!argv[3].asInt();
  Clipping (mfd->red  ,GMIN,GMAX);
  Clipping (mfd->green,GMIN,GMAX);
  Clipping (mfd->blue ,GMIN,GMAX);
}

ScriptFunctionDef func_defs[]=
  {{(ScriptFunctionPtr)ScriptConfig,"Config","0iiii"},{NULL},};
CScriptObject script_obj= {NULL,func_defs};

// ==========================================================

FilterDefinition filterDef_gamma=
{
  NULL,NULL,NULL,            // next, prev, module
  "Gamma Correction",        // name
  "Gamma Correction for RGB channels.\n"
  "Version 1.3 (30-10-2004) [iSSE]\n"
  "Copyright (C) 2003,2004  Emiliano Ferrari\n"
  "macinapepe@tiscali.it",   // desc
  "Emiliano Ferrari",        // maker
  NULL,                      // private_data
  sizeof(MyFilterData),      // inst_data_size
  InitProc,                  // initProc
  NULL,                      // deinitProc
  RunProc,                   // runProc
  ParamProc,                 // paramProc
  ConfigProc,                // configProc
  StringProc,                // stringProc
  NULL,                      // startProc
  NULL,                      // endProc
  &script_obj,               // script_obj
  FssProc,                   // fssProc
};

static FilterDefinition *fd_gamma;

extern "C" int __declspec(dllexport) __cdecl
  VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
  fd_gamma= ff->addFilter(fm, &filterDef_gamma, sizeof(FilterDefinition));
  if (!fd_gamma) return 1;
  vdfd_ver= VIRTUALDUB_FILTERDEF_VERSION;
  vdfd_compat= VIRTUALDUB_FILTERDEF_COMPATIBLE;
  return 0;
}

extern "C" void __declspec(dllexport) __cdecl
  VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff)
{
  ff->removeFilter(fd_gamma);
}
