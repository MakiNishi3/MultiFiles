//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDPREVIEW                       3
#define IDD_FILTER_GAMMA                101
#define IDC_RED                         1001
#define IDC_GREEN                       1002
#define IDC_BLUE                        1003
#define IDC_REDVAL                      1004
#define IDC_GREENVAL                    1005
#define IDC_BLUEVAL                     1006
#define IDC_RESET                       1007
#define IDC_LINK                        1008
#define IDC_EDIT1                       1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
