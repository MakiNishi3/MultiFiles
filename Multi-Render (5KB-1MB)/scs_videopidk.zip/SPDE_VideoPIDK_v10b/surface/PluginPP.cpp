//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#include "stdafx.h"
#include "commctrl.h"
#include "Main.h"
#include "PluginPP.h"

#define SLIDER_SCALE 100

/////////////////////////////////////////////////////////////////////////////
// CPluginPP

CPluginPP::CPluginPP() 
{
	m_pUnkMarshaler = NULL;
	m_dwTitleID = IDS_TITLEPluginPP;
	m_dwHelpFileID = IDS_HELPFILEPluginPP;
	m_dwDocStringID = IDS_DOCSTRINGPluginPP;
    m_dwHelpContext = 1;

    // TODO: Properly initialize your m_Props here with default values,
    //       and delete the ZeroMemory function
    ZeroMemory (&m_Props, sizeof(m_Props));
}

void CPluginPP::Update()
{
    CComQIPtr<ISfExchangeProps<PLUGINPROPS>, &IID_ISfExchangeProps> pFilter( m_ppUnk[0] );
    pFilter->GetAll(&m_Props);

    // TODO: Update your controls here with values from m_Props
	SendMessage(::GetDlgItem(m_hWnd, IDC_AMOUNTSLIDER), TBM_SETPOS, (WPARAM)TRUE, (LPARAM)(m_Props.dAmount * SLIDER_SCALE));
}

LRESULT CPluginPP::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    // TODO: Initialize any UI elements here (such as setting of slider ranges)
	HWND hSlider = ::GetDlgItem(m_hWnd, IDC_AMOUNTSLIDER);
	SendMessage(hSlider, TBM_SETRANGEMIN, (WPARAM)FALSE, (LPARAM)0);
	SendMessage(hSlider, TBM_SETRANGEMAX, (WPARAM)TRUE, (LPARAM)SLIDER_SCALE);

    CComQIPtr<ISfExchangeProps<PLUGINPROPS>, &IID_ISfExchangeProps> pFilter( m_ppUnk[0] );
    pFilter->SetNotifyWindow(m_hWnd, ID_NOTIFYCHANGE);
    Update();

	return 0;
}

LRESULT CPluginPP::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    CComQIPtr<ISfExchangeProps<PLUGINPROPS>, &IID_ISfExchangeProps> pFilter( m_ppUnk[0] );
    pFilter->SetNotifyWindow(m_hWnd, NULL);

	return 0;
}

LRESULT CPluginPP::OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    UINT    uId     = LOWORD(wParam);

    switch(uId)
    {
        case ID_NOTIFYCHANGE:
            Update();
            bHandled = TRUE;
            break;
    }

    return 0;
}

// TODO: Update your m_Props members whenever a control changes its
//       values, and call the Apply() method.
//       Eg:  Slider controls would do this on an WM_HSCROLL or WM_VSCROLL message 
//                  (see the "Offset" sample included in this SDK)
//            Edit boxes would do this on an EN_KILLFOCUS command message 
//                  (see the "Mask" sample included in this SDK)

LRESULT CPluginPP::OnHScroll(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	HWND    hctl = (HWND)lParam;
    if (hctl == ::GetDlgItem(m_hWnd, IDC_AMOUNTSLIDER))
	{
        LONG lPos = SendMessage(hctl, TBM_GETPOS, (WPARAM)0, (LPARAM)0);
        if ( (LONG)(m_Props.dAmount * SLIDER_SCALE) != lPos)
        {
            m_Props.dAmount = (DOUBLE)lPos / SLIDER_SCALE;
            Apply();
        }
	}
	return 0;
}