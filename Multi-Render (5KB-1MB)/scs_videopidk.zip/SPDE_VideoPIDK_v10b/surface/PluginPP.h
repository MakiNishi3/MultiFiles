//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#ifndef __PLUGINPP_H_
#define __PLUGINPP_H_

#include "resource.h"       // main symbols
#include "Plugin.h"

EXTERN_C const CLSID CLSID_PluginPP;

/////////////////////////////////////////////////////////////////////////////
// CPluginPP
class ATL_NO_VTABLE CPluginPP :
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CPluginPP, &CLSID_PluginPP>,
	public IPropertyPageImpl<CPluginPP>,
	public CDialogImpl<CPluginPP>
{
public:
	CPluginPP();

	enum {IDD = IDD_PLUGINPP};

DECLARE_GET_CONTROLLING_UNKNOWN()
DECLARE_REGISTRY_RESOURCEID(IDR_PLUGINPP)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CPluginPP) 
	COM_INTERFACE_ENTRY(IPropertyPage)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

BEGIN_MSG_MAP(CPluginPP)
	CHAIN_MSG_MAP(IPropertyPageImpl<CPluginPP>)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
    MESSAGE_HANDLER( WM_COMMAND, OnCommand )
	MESSAGE_HANDLER( WM_HSCROLL, OnHScroll )
END_MSG_MAP()

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnHScroll(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

    void Update();

    STDMETHOD(Help)(LPCOLESTR pszHelpDir) {return E_FAIL;}

	STDMETHOD(Apply)(void)
	{
		ATLTRACE(_T("CPluginPP::Apply\n"));
        CComQIPtr<ISfExchangeProps<PLUGINPROPS>, &IID_ISfExchangeProps> pScreen( m_ppUnk[0] );
        pScreen->PutAll(&m_Props);

		m_bDirty = FALSE;
		return S_OK;
	}

protected:
    PLUGINPROPS     m_Props;
};

#endif //__PLUGINPP_H_
