//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#include "stdafx.h"
#include "Main.h"
#include "Plugin.h"

/////////////////////////////////////////////////////////////////////////////
// CPlugin

// TODO: Update this array with the correct values for members of your
//       PLUGINPROPS structure.  If you add presets be sure to add
//       resource strings into the resource string table.  The strings
//       must be consecutive and start at id IDS_FIRSTPRESET_ENGLISH.
static const PLUGINPROPS g_aPresetProps[] = 
{
    {    0  }     // Default
};
#define PRESETPROPCOUNT   ( sizeof(g_aPresetProps) / sizeof(g_aPresetProps[0]) )


CPlugin::CPlugin()
    : CSFVideoPlugin< PLUGINPROPS > (g_aPresetProps, _Module.GetResourceInstance(), IDS_FIRSTPRESET_ENGLISH, PRESETPROPCOUNT, &CLSID_Plugin)
{
	m_pUnkMarshaler = NULL;

#if(_ATL_VER >= 0x0300)
    m_bRequiresSave = FALSE;
#endif

    // TODO: Uncomment the appropriate block of code depending on
    //       the plugin type you are creating.  By default an 
    //       in-place filter will be created.
    
    // Used for transitions
    m_ulMaxInputs       = 2;
    m_ulNumInRequired   = 2;
    m_dwMiscFlags      |= 0;
    m_PluginInfo.eCategory  = VIDEOPLUGINTYPE_TRANSITION;
    
    /*
    // Used for mask fitlers
    m_ulMaxInputs       = 1;
    m_ulNumInRequired   = 1;
    m_dwMiscFlags      |= 0;
    m_PluginInfo.eCategory  = VIDEOPLUGINTYPE_MASK_FILTER;
    */
    /*
    // Used for surface fitlers
    // (only an output surface is needed, since the content is generated)
    m_ulMaxInputs       = 0;
    m_ulNumInRequired   = 0;
    m_dwMiscFlags      |= 0;
    m_PluginInfo.eCategory  = VIDEOPLUGINTYPE_SURFACE;
    */
    /*
    // Used for non in-place fitlers
    m_ulMaxInputs       = 1;
    m_ulNumInRequired   = 1;
    m_dwMiscFlags      |= 0;
    m_PluginInfo.eCategory  = VIDEOPLUGINTYPE_FILTER;
    */

    // Used for in-place filters 
    // (the output surface acts as an input and output for the data)
    /*
    m_ulMaxInputs       = 0;
    m_ulNumInRequired   = 0;
    m_dwMiscFlags      |= DXTMF_INPLACE_OPERATION;
    m_PluginInfo.eCategory  = VIDEOPLUGINTYPE_FILTER;
    */


    // TODO: Modify these flags if you need to.
    m_dwOptionFlags     = DXBOF_SAME_SIZE_INPUTS | DXBOF_CENTER_INPUTS;
    m_Duration          = .5;

    m_PluginInfo.dQualitySteps = 1;
    m_PluginInfo.ulMinInput = m_ulNumInRequired;
    m_PluginInfo.ulMaxInput = m_ulMaxInputs;

	// TODO: Set the proper capabilities flags based on what operation
	// your filter will need to perform:
	// SFVIDEOPLUGIN_CAPS_ASPECTRATIO - 
	//	    Should be set if the plugin doesn't require aspect ratio 
	//      information to work properly, or it uses the provided aspect
	//      ratio to properly render its output. (If this flag is not
	//      set, Vegas will stretch all inputs to an aspect ratio of 1
	//      prior to executing this filter.
	// SFVIDEOPLUGIN_CAPS_NOALPHAGENERATION -
	//	    Should be set if the plugin doesn't introduce any transparency
    //      in the output surface if all input surfaces don't contain any 
    //      transparency.
	// SFVIDEOPLUGIN_CAPS_PIXELOPERATION -
	//	    Should be set if the plugin operates on individual pixels without 
	//      the need to consider neighbouring pixels.  (Specifying this
	//      flag will allow Vegas to pass both fields of interlaced 
	//      frames at the same time to this filter.)

    m_PluginInfo.dwCaps = SFVIDEOPLUGIN_CAPS_ASPECTRATIO       |
                          SFVIDEOPLUGIN_CAPS_NOALPHAGENERATION |
                          SFVIDEOPLUGIN_CAPS_PIXELOPERATION;
}

HRESULT CPlugin::WorkProc
(
    const CDXTWorkInfoNTo1& WI, 
    BOOL*                   pbContinue
)
{
    HRESULT     hr = S_OK;

    ULONG uXSize = WI.OutputBnds.Width();
    ULONG uYSize = WI.OutputBnds.Height();

    AutoUpdateProps();

    // For simplicity, the progress variable is used to dictate 
    // the size of the expanding square.
    DOUBLE      dProgress = (DOUBLE)GetEffectProgress();

    CSFARGBReadPtr In1(hr, InputSurface(0), &WI.DoBnds);
    if( FAILED( hr ) ) return hr;
    CSFARGBReadPtr In2(hr, InputSurface(1), &WI.DoBnds);
    if( FAILED( hr ) ) return hr;
    CSFARGBReadWritePtr Out(hr, OutputSurface(), &WI.OutputBnds);
    if( FAILED( hr ) ) return hr;

    DXSAMPLE* pDstRow = Out.GetFirstSample();
    const DXSAMPLE* pSrc1Row = In1.GetFirstSample();
    const DXSAMPLE* pSrc2Row = In2.GetFirstSample();

    DOUBLE dAspectRatio = Out.GetVideoStreamInfo().dPixelAspect;

    // TODO: Use the GetWorkProps() member function to access your 
    //       PLUGINPROPS structure
    // eg: INT nSomeProperty = GetWorkProps().nSomeProperty;


    // Retrieve the actual size of the output surface
    CDXDBnds Bounds(OutputSurface(), hr);
    if (FAILED(hr)) return hr;

    ULONG cXDstSize = Bounds.Width();
    ULONG cYDstSize = Bounds.Height();

    ULONG uXSquarePixels;
    ULONG uYSquarePixels;

    // Determine whether X or Y is larger (accounting for pixel aspect ratio)
    // and calculate the pixel size of the expanding rectangle
    if (cXDstSize * dAspectRatio > cYDstSize)
    {
        // X is larger
        uXSquarePixels = (ULONG)(cXDstSize * dProgress);
        uYSquarePixels = (ULONG)(uXSquarePixels * dAspectRatio);
    }
    else
    {
        // Y is larger
        uYSquarePixels = (ULONG)(cYDstSize * dProgress);
        uXSquarePixels = (ULONG)(uYSquarePixels / dAspectRatio);
    }

    // Now calculate the bounding rectangle values
    LONG lX1 = (LONG)cXDstSize / 2 - uXSquarePixels / 2;
    LONG lX2 = (LONG)cXDstSize - cXDstSize / 2 + uXSquarePixels - uXSquarePixels / 2;
    LONG lY1 = (LONG)cYDstSize / 2 - uYSquarePixels / 2;
    LONG lY2 = (LONG)cYDstSize - cYDstSize / 2 + uYSquarePixels - uYSquarePixels / 2;

    LONG lStartX = (LONG)WI.OutputBnds.Left();
    LONG lStartY = (LONG)WI.OutputBnds.Top();
    for (ULONG uY = 0; uY < uYSize; uY++)
    {
        for (ULONG uX = 0; uX < uXSize; uX++)
        {
            // Determine if each pixel is inside or outside of the
            // calculated bounding rect, and select the appropriate
            // source surface for copying of that pixel.
            // NOTE:  This sample is for demonstration purposes only.
            //        It is not optimized for performance.
            if ( ((LONG)uX + lStartX < lX1) || ((LONG)uX + lStartX > lX2) ||
                 ((LONG)uY + lStartY < lY1) || ((LONG)uY + lStartY > lY2) )
            {
                pDstRow[uX] = pSrc1Row[uX];
            }
            else
            {
                pDstRow[uX] = pSrc2Row[uX];
            }
        }
        pDstRow += Out.GetWidth();
        pSrc1Row += In1.GetWidth();
        pSrc2Row += In2.GetWidth();
    }

    return hr;
}

HRESULT CPlugin::InterpolateProps
(
    PLUGINPROPS*        pOutProps,
    const PLUGINPROPS*  pFromProps,
    const PLUGINPROPS*  pToProps,
    DOUBLE              dProgress
)
{
    // TODO: Add interpolation code here if any properties can be interpolated
    return NOERROR;
}
