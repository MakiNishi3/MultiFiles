//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software, Inc. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;
// Note: Proxy/Stub Information
//      To build a separate proxy/stub DLL, 
//      run nmake -f Mainps.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include <initguid.h>
#include "Main.h"

#include "Main_i.c"
#include "sfdxext.h"
#include "sfdxext_i.c"
#include "Plugin.h"
#include "PluginPP.h"


CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_Plugin, CPlugin)
OBJECT_ENTRY(CLSID_PluginPP, CPluginPP)
END_OBJECT_MAP()

/////////////////////////////////////////////////////////////////////////////
// DLL Entry Point

extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        _Module.Init(ObjectMap, hInstance, &LIBID_MAINLib);
        DisableThreadLibraryCalls(hInstance);
    }
    else if (dwReason == DLL_PROCESS_DETACH)
        _Module.Term();
    return TRUE;    // ok
}

/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
    return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _Module.GetClassObject(rclsid, riid, ppv);
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    return _Module.RegisterServer(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
    return _Module.UnregisterServer(TRUE);
}


