/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.02.88 */
/* at Thu May 14 18:43:01 1998
 */
/* Compiler settings for dxtlipi.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __dxtlipi_h__
#define __dxtlipi_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ILPsurface_FWD_DEFINED__
#define __ILPsurface_FWD_DEFINED__
typedef interface ILPsurface ILPsurface;
#endif 	/* __ILPsurface_FWD_DEFINED__ */


#ifndef __LPsurface_FWD_DEFINED__
#define __LPsurface_FWD_DEFINED__

#ifdef __cplusplus
typedef class LPsurface LPsurface;
#else
typedef struct LPsurface LPsurface;
#endif /* __cplusplus */

#endif 	/* __LPsurface_FWD_DEFINED__ */


#ifndef __CLPSurfacePropPage_FWD_DEFINED__
#define __CLPSurfacePropPage_FWD_DEFINED__

#ifdef __cplusplus
typedef class CLPSurfacePropPage CLPSurfacePropPage;
#else
typedef struct CLPSurfacePropPage CLPSurfacePropPage;
#endif /* __cplusplus */

#endif 	/* __CLPSurfacePropPage_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ILPsurface_INTERFACE_DEFINED__
#define __ILPsurface_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: ILPsurface
 * at Thu May 14 18:43:01 1998
 * using MIDL 3.02.88
 ****************************************/
/* [unique][helpstring][dual][uuid][object] */ 



EXTERN_C const IID IID_ILPsurface;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("201EA563-A6F6-11D1-811D-00C04FB6BD36")
    ILPsurface : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SourceUrl( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SourceUrl( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TopLeft_RI_x( 
            /* [retval][out] */ float __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_TopLeft_RI_x( 
            /* [in] */ float newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TopLeft_RI_y( 
            /* [retval][out] */ float __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_TopLeft_RI_y( 
            /* [in] */ float newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_BottomRight_RI_x( 
            /* [retval][out] */ float __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_BottomRight_RI_x( 
            /* [in] */ float newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_BottomRight_RI_y( 
            /* [retval][out] */ float __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_BottomRight_RI_y( 
            /* [in] */ float newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Width( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Width( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Height( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Height( 
            /* [in] */ long newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILPsurfaceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ILPsurface __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ILPsurface __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ILPsurface __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SourceUrl )( 
            ILPsurface __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SourceUrl )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TopLeft_RI_x )( 
            ILPsurface __RPC_FAR * This,
            /* [retval][out] */ float __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_TopLeft_RI_x )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ float newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TopLeft_RI_y )( 
            ILPsurface __RPC_FAR * This,
            /* [retval][out] */ float __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_TopLeft_RI_y )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ float newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BottomRight_RI_x )( 
            ILPsurface __RPC_FAR * This,
            /* [retval][out] */ float __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BottomRight_RI_x )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ float newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BottomRight_RI_y )( 
            ILPsurface __RPC_FAR * This,
            /* [retval][out] */ float __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BottomRight_RI_y )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ float newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Width )( 
            ILPsurface __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Width )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Height )( 
            ILPsurface __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Height )( 
            ILPsurface __RPC_FAR * This,
            /* [in] */ long newVal);
        
        END_INTERFACE
    } ILPsurfaceVtbl;

    interface ILPsurface
    {
        CONST_VTBL struct ILPsurfaceVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILPsurface_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILPsurface_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILPsurface_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILPsurface_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ILPsurface_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ILPsurface_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ILPsurface_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ILPsurface_get_SourceUrl(This,pVal)	\
    (This)->lpVtbl -> get_SourceUrl(This,pVal)

#define ILPsurface_put_SourceUrl(This,newVal)	\
    (This)->lpVtbl -> put_SourceUrl(This,newVal)

#define ILPsurface_get_TopLeft_RI_x(This,pVal)	\
    (This)->lpVtbl -> get_TopLeft_RI_x(This,pVal)

#define ILPsurface_put_TopLeft_RI_x(This,newVal)	\
    (This)->lpVtbl -> put_TopLeft_RI_x(This,newVal)

#define ILPsurface_get_TopLeft_RI_y(This,pVal)	\
    (This)->lpVtbl -> get_TopLeft_RI_y(This,pVal)

#define ILPsurface_put_TopLeft_RI_y(This,newVal)	\
    (This)->lpVtbl -> put_TopLeft_RI_y(This,newVal)

#define ILPsurface_get_BottomRight_RI_x(This,pVal)	\
    (This)->lpVtbl -> get_BottomRight_RI_x(This,pVal)

#define ILPsurface_put_BottomRight_RI_x(This,newVal)	\
    (This)->lpVtbl -> put_BottomRight_RI_x(This,newVal)

#define ILPsurface_get_BottomRight_RI_y(This,pVal)	\
    (This)->lpVtbl -> get_BottomRight_RI_y(This,pVal)

#define ILPsurface_put_BottomRight_RI_y(This,newVal)	\
    (This)->lpVtbl -> put_BottomRight_RI_y(This,newVal)

#define ILPsurface_get_Width(This,pVal)	\
    (This)->lpVtbl -> get_Width(This,pVal)

#define ILPsurface_put_Width(This,newVal)	\
    (This)->lpVtbl -> put_Width(This,newVal)

#define ILPsurface_get_Height(This,pVal)	\
    (This)->lpVtbl -> get_Height(This,pVal)

#define ILPsurface_put_Height(This,newVal)	\
    (This)->lpVtbl -> put_Height(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILPsurface_get_SourceUrl_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ILPsurface_get_SourceUrl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILPsurface_put_SourceUrl_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ILPsurface_put_SourceUrl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILPsurface_get_TopLeft_RI_x_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [retval][out] */ float __RPC_FAR *pVal);


void __RPC_STUB ILPsurface_get_TopLeft_RI_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILPsurface_put_TopLeft_RI_x_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [in] */ float newVal);


void __RPC_STUB ILPsurface_put_TopLeft_RI_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILPsurface_get_TopLeft_RI_y_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [retval][out] */ float __RPC_FAR *pVal);


void __RPC_STUB ILPsurface_get_TopLeft_RI_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILPsurface_put_TopLeft_RI_y_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [in] */ float newVal);


void __RPC_STUB ILPsurface_put_TopLeft_RI_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILPsurface_get_BottomRight_RI_x_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [retval][out] */ float __RPC_FAR *pVal);


void __RPC_STUB ILPsurface_get_BottomRight_RI_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILPsurface_put_BottomRight_RI_x_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [in] */ float newVal);


void __RPC_STUB ILPsurface_put_BottomRight_RI_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILPsurface_get_BottomRight_RI_y_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [retval][out] */ float __RPC_FAR *pVal);


void __RPC_STUB ILPsurface_get_BottomRight_RI_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILPsurface_put_BottomRight_RI_y_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [in] */ float newVal);


void __RPC_STUB ILPsurface_put_BottomRight_RI_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILPsurface_get_Width_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILPsurface_get_Width_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILPsurface_put_Width_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ILPsurface_put_Width_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILPsurface_get_Height_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILPsurface_get_Height_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILPsurface_put_Height_Proxy( 
    ILPsurface __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ILPsurface_put_Height_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILPsurface_INTERFACE_DEFINED__ */



#ifndef __DXTLIPILib_LIBRARY_DEFINED__
#define __DXTLIPILib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: DXTLIPILib
 * at Thu May 14 18:43:01 1998
 * using MIDL 3.02.88
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_DXTLIPILib;

EXTERN_C const CLSID CLSID_LPsurface;

#ifdef __cplusplus

class DECLSPEC_UUID("201EA564-A6F6-11D1-811D-00C04FB6BD36")
LPsurface;
#endif

EXTERN_C const CLSID CLSID_CLPSurfacePropPage;

#ifdef __cplusplus

class DECLSPEC_UUID("827438A0-EA90-11D1-ABF8-004033D0A390")
CLPSurfacePropPage;
#endif
#endif /* __DXTLIPILib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
