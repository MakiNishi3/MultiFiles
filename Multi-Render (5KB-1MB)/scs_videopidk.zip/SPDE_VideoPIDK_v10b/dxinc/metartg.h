/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.02.88 */
/* at Wed Jun 17 16:25:19 1998
 */
/* Compiler settings for metartg.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __metartg_h__
#define __metartg_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IDXTMetaStream_FWD_DEFINED__
#define __IDXTMetaStream_FWD_DEFINED__
typedef interface IDXTMetaStream IDXTMetaStream;
#endif 	/* __IDXTMetaStream_FWD_DEFINED__ */


#ifndef __DXTMetaStream_FWD_DEFINED__
#define __DXTMetaStream_FWD_DEFINED__

#ifdef __cplusplus
typedef class DXTMetaStream DXTMetaStream;
#else
typedef struct DXTMetaStream DXTMetaStream;
#endif /* __cplusplus */

#endif 	/* __DXTMetaStream_FWD_DEFINED__ */


#ifndef __DXTMetaStreamProp_FWD_DEFINED__
#define __DXTMetaStreamProp_FWD_DEFINED__

#ifdef __cplusplus
typedef class DXTMetaStreamProp DXTMetaStreamProp;
#else
typedef struct DXTMetaStreamProp DXTMetaStreamProp;
#endif /* __cplusplus */

#endif 	/* __DXTMetaStreamProp_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "dxtrans.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IDXTMetaStream_INTERFACE_DEFINED__
#define __IDXTMetaStream_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IDXTMetaStream
 * at Wed Jun 17 16:25:19 1998
 * using MIDL 3.02.88
 ****************************************/
/* [unique][helpstring][local][dual][uuid][object] */ 



EXTERN_C const IID IID_IDXTMetaStream;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("48654BC0-E51F-11D1-AA1C-00600895FB99")
    IDXTMetaStream : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_DXTurl( 
            /* [retval][out] */ BSTR __RPC_FAR *pURL) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_DXTurl( 
            /* [in] */ BSTR newURL) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_DXTAutoScale( 
            /* [in] */ VARIANT_BOOL flag) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_DXTAutoScale( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *flag) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_DXTquality( 
            /* [in] */ float flag) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_DXTquality( 
            /* [retval][out] */ float __RPC_FAR *flag) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDXTMetaStreamVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDXTMetaStream __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDXTMetaStream __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DXTurl )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pURL);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DXTurl )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [in] */ BSTR newURL);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DXTAutoScale )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL flag);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DXTAutoScale )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *flag);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DXTquality )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [in] */ float flag);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DXTquality )( 
            IDXTMetaStream __RPC_FAR * This,
            /* [retval][out] */ float __RPC_FAR *flag);
        
        END_INTERFACE
    } IDXTMetaStreamVtbl;

    interface IDXTMetaStream
    {
        CONST_VTBL struct IDXTMetaStreamVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDXTMetaStream_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDXTMetaStream_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDXTMetaStream_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDXTMetaStream_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDXTMetaStream_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDXTMetaStream_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDXTMetaStream_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDXTMetaStream_get_DXTurl(This,pURL)	\
    (This)->lpVtbl -> get_DXTurl(This,pURL)

#define IDXTMetaStream_put_DXTurl(This,newURL)	\
    (This)->lpVtbl -> put_DXTurl(This,newURL)

#define IDXTMetaStream_put_DXTAutoScale(This,flag)	\
    (This)->lpVtbl -> put_DXTAutoScale(This,flag)

#define IDXTMetaStream_get_DXTAutoScale(This,flag)	\
    (This)->lpVtbl -> get_DXTAutoScale(This,flag)

#define IDXTMetaStream_put_DXTquality(This,flag)	\
    (This)->lpVtbl -> put_DXTquality(This,flag)

#define IDXTMetaStream_get_DXTquality(This,flag)	\
    (This)->lpVtbl -> get_DXTquality(This,flag)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDXTMetaStream_get_DXTurl_Proxy( 
    IDXTMetaStream __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pURL);


void __RPC_STUB IDXTMetaStream_get_DXTurl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDXTMetaStream_put_DXTurl_Proxy( 
    IDXTMetaStream __RPC_FAR * This,
    /* [in] */ BSTR newURL);


void __RPC_STUB IDXTMetaStream_put_DXTurl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDXTMetaStream_put_DXTAutoScale_Proxy( 
    IDXTMetaStream __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL flag);


void __RPC_STUB IDXTMetaStream_put_DXTAutoScale_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDXTMetaStream_get_DXTAutoScale_Proxy( 
    IDXTMetaStream __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *flag);


void __RPC_STUB IDXTMetaStream_get_DXTAutoScale_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDXTMetaStream_put_DXTquality_Proxy( 
    IDXTMetaStream __RPC_FAR * This,
    /* [in] */ float flag);


void __RPC_STUB IDXTMetaStream_put_DXTquality_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDXTMetaStream_get_DXTquality_Proxy( 
    IDXTMetaStream __RPC_FAR * This,
    /* [retval][out] */ float __RPC_FAR *flag);


void __RPC_STUB IDXTMetaStream_get_DXTquality_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDXTMetaStream_INTERFACE_DEFINED__ */



#ifndef __DXTMetaStreamLib_LIBRARY_DEFINED__
#define __DXTMetaStreamLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: DXTMetaStreamLib
 * at Wed Jun 17 16:25:19 1998
 * using MIDL 3.02.88
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_DXTMetaStreamLib;

EXTERN_C const CLSID CLSID_DXTMetaStream;

#ifdef __cplusplus

class DECLSPEC_UUID("60A0C080-E505-11D1-AA1C-00600895FB99")
DXTMetaStream;
#endif

EXTERN_C const CLSID CLSID_DXTMetaStreamProp;

#ifdef __cplusplus

class DECLSPEC_UUID("E3D77340-E505-11D1-AA1C-00600895FB99")
DXTMetaStreamProp;
#endif
#endif /* __DXTMetaStreamLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
