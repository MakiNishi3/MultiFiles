//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.

//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//
//  This code serves as a base class implementation for Sony Media Software 
//  DirectX Transform Video Plug-in extensions and their use.
//
//==========================================================================;

#ifndef _SFBASE_H_
#define _SFBASE_H_

#include "sfdxext.h"

#ifndef __SFIFACE__
#include "sfiface.h"
#endif
interface DECLSPEC_UUID("36A22460-0CC9-11D0-8574-00A0C9053912") IStaticFilterPreset;

// ****************************************************************

#ifndef ID_NOTIFYCHANGE
#define ID_NOTIFYCHANGE     (0x7f00)    // SF extension
#endif

// ****************************************************************
//EXTERN_C const IID IID_ISfExchangeProps;

template <class PROPTYPE> interface DECLSPEC_UUID("0CC91747-EF4A-11D3-8258-00802968502D") ISfExchangeProps : public IUnknown
{
    public:
        virtual HRESULT STDMETHODCALLTYPE GetAll
        ( 
            PROPTYPE*           pProps
        ) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE PutAll
        ( 
            const PROPTYPE*     pProps
        ) = 0;

        virtual HRESULT STDMETHODCALLTYPE SetNotifyWindow
        ( 
            /* [in] */ HWND hwnd,
            /* [in] */ UINT id
        ) = 0;
};


// interface DECLSPEC_UUID("0CC91747-EF4A-11D3-8258-00802968502D") ISfExchangeProps;

DEFINE_GUID(IID_ISfExchangeProps,
            0x0CC91747, 0xEF4A, 0x11D3, 0x85, 0x58,
            0x00, 0x80, 0x29, 0x68, 0x50, 0x2D);

// ****************************************************************

// Helper template function for interpolation of parameters
template <class TYPE> inline TYPE Interpolate
(
    TYPE    nFrom,
    TYPE    nTo,
    DOUBLE  dProgress
)
{
    if (dProgress < 0.0)
        dProgress = 0.0;
    if (dProgress > 1.0)
        dProgress = 1.0;

    return (TYPE)(( (DOUBLE)nTo - nFrom) * dProgress + nFrom);
}

// ****************************************************************
// ****************************************************************
// *** Read and Write pointer classes for ARGB32 and SFARGBFLOAT
// ****************************************************************

inline void GetSurfaceBounds
(
    IDXSurface*         pDXSurf,
    CDXDBnds*           pBndsToSet,
    const CDXDBnds*     pBnds
)
{
    if (NULL == pBnds)
    {
        DXBNDS Bounds;
        pDXSurf->GetBounds(&Bounds);
        pBndsToSet->Copy(Bounds);
    }
    else
        *pBndsToSet = *pBnds;
}

// Extra parameters for SF surfaces
inline void GetSurfaceStreamInfo
(
    IDXSurface*         pDXSurface,
    VIDEOSTREAMINFO*    pVSInfo
)
{
    ISfVideoSurfaceExtension *pIVidSurfEx;
    HRESULT hr;

    hr = pDXSurface->QueryInterface(IID_ISfVideoSurfaceExtension, (void **)&pIVidSurfEx);
    if (SUCCEEDED(hr))
    {
        pIVidSurfEx->get_VideoStreamInfo(pVSInfo, sizeof(VIDEOSTREAMINFO));
        pIVidSurfEx->Release();
    }
    else
    {   //Best guess of the video settings
        CreateDefaultVideoStreamInfo(pVSInfo);
    }
}

// ****************************************************************
class CSFARGBReadPtr
{
public:
    CSFARGBReadPtr
    (
        /* out */   HRESULT&        hr,
        /* in */    IDXSurface*     pDXSurf,
        /* in */    const CDXDBnds* pBnds = NULL,
        /* in */    BOOL            fPremultiplied = TRUE
    )
    : m_pData(NULL), m_fAllocated(FALSE), m_lPitch(0)
    {
        hr = pDXSurf->LockSurface( pBnds, 0, DXLOCKF_READ,
                                   IID_IDXARGBReadPtr, (void**)&m_pIn, NULL );
        if ( FAILED( hr ) ) return;

        GetSurfaceBounds(pDXSurf, &m_Bnds, pBnds);

        GUID guidPixelType;
        DXSAMPLEFORMATENUM eSample;
        hr = pDXSurf->GetPixelFormat(&guidPixelType, &eSample);
        if ( FAILED( hr ) ) return;

        if ( ((DXPF_ARGB32 == eSample) && (!fPremultiplied)) ||
             ((DXPF_PMARGB32 == eSample) && (fPremultiplied)) )
        {
            DXNATIVETYPEINFO NI;
            m_pIn->GetNativeType(&NI);
            m_lPitch = NI.lPitch;
            m_pData = (DXSAMPLE*)NI.pFirstByte;
        }
        else
        {
            m_lPitch = m_Bnds.Width() * sizeof(DXSAMPLE);
            m_pData = new DXSAMPLE[m_Bnds.Width() * m_Bnds.Height()];
            if (NULL == m_pData)
            {
                hr = E_OUTOFMEMORY;
                return;
            }
            m_fAllocated = TRUE;
            DXPACKEDRECTDESC RectDesc;
            RectDesc.pSamples = (DXBASESAMPLE*)m_pData;
            RectDesc.bPremult = fPremultiplied;
            m_Bnds.GetXYRect(RectDesc.rect);
            OffsetRect(&RectDesc.rect, -m_Bnds.Left(), -m_Bnds.Top());
            RectDesc.lRowPadding = 0;
            m_pIn->UnpackRect(&RectDesc);
        }

        GetSurfaceStreamInfo(pDXSurf, &m_VSInfo);

        hr = NOERROR;
    }

    ~CSFARGBReadPtr()
    {
        if (m_fAllocated)
            delete[] m_pData;
    }

    LONG GetPitch()
    {
        return m_lPitch;
    }

    LONG GetWidth()
    {
        return m_lPitch / (LONG)sizeof(DXSAMPLE);
    }

    const DXSAMPLE* GetFirstSample()
    {
        return m_pData;
    }

    const VIDEOSTREAMINFO& GetVideoStreamInfo()
    {
        return m_VSInfo;
    }

protected:
    CComPtr<IDXARGBReadPtr>     m_pIn;
    CDXDBnds                    m_Bnds;
    DXSAMPLE*                   m_pData;
    BOOL                        m_fAllocated;
    LONG                        m_lPitch;       // Row length
    VIDEOSTREAMINFO             m_VSInfo;       // Extra stream info
};

// ****************************************************************

class CSFARGBReadWritePtr
{
public:
    CSFARGBReadWritePtr
    (
        /* out */   HRESULT&        hr,
        /* in */    IDXSurface*     pDXSurf,
        /* in */    const CDXDBnds* pBnds = NULL,
        /* in */    BOOL            fPremultiplied = TRUE
    )
    : m_pData(NULL), m_fAllocated(FALSE), m_lPitch(0)
    {
        hr = pDXSurf->LockSurface( pBnds, 0, DXLOCKF_READWRITE,
                                   IID_IDXARGBReadWritePtr, (void**)&m_pIn, NULL );
        if ( FAILED( hr ) ) return;

        GetSurfaceBounds(pDXSurf, &m_Bnds, pBnds);

        GUID guidPixelType;
        DXSAMPLEFORMATENUM eSample;
        hr = pDXSurf->GetPixelFormat(&guidPixelType, &eSample);
        if ( FAILED( hr ) ) return;

        if ( ((DXPF_ARGB32 == eSample) && (!fPremultiplied)) ||
             ((DXPF_PMARGB32 == eSample) && (fPremultiplied)) )
        {
            DXNATIVETYPEINFO NI;
            m_pIn->GetNativeType(&NI);
            m_lPitch = NI.lPitch;
            m_pData = (DXSAMPLE*)NI.pFirstByte;
        }
        else
        {
            m_lPitch = m_Bnds.Width() * sizeof(DXSAMPLE);
            m_pData = new DXSAMPLE[m_Bnds.Width() * m_Bnds.Height()];
            if (NULL == m_pData)
            {
                hr = E_OUTOFMEMORY;
                return;
            }
            m_fAllocated = TRUE;
            m_RectDesc.pSamples = (DXBASESAMPLE*)m_pData;
            m_RectDesc.bPremult = fPremultiplied;
            m_Bnds.GetXYRect(m_RectDesc.rect);
            OffsetRect(&m_RectDesc.rect, -m_Bnds.Left(), -m_Bnds.Top());
            m_RectDesc.lRowPadding = 0;
            m_pIn->UnpackRect(&m_RectDesc);
        }

        GetSurfaceStreamInfo(pDXSurf, &m_VSInfo);

        hr = NOERROR;
    }

    ~CSFARGBReadWritePtr()
    {
        if (m_fAllocated)
        {
            m_pIn->PackRect(&m_RectDesc);
            delete[] m_pData;
        }
    }

    LONG GetPitch()
    {
        return m_lPitch;
    }

    LONG GetWidth()
    {
        return m_lPitch / (LONG)sizeof(DXSAMPLE);
    }

    DXSAMPLE* GetFirstSample()
    {
        return m_pData;
    }

    const VIDEOSTREAMINFO& GetVideoStreamInfo()
    {
        return m_VSInfo;
    }

protected:
    CComPtr<IDXARGBReadWritePtr> m_pIn;
    CDXDBnds                    m_Bnds;
    DXSAMPLE*                   m_pData;
    BOOL                        m_fAllocated;
    LONG                        m_lPitch;       // Row length

    // Write pointers use this to pack data back for out of surface buffers
    DXPACKEDRECTDESC            m_RectDesc;
    VIDEOSTREAMINFO             m_VSInfo;       // Extra stream info
};

// ****************************************************************


// ****************************************************************
// ****************************************************************

template <class PROPTYPE > class CSFVideoPlugin 
    :   public IStaticFilterPreset,         // SF extension
        public ISfVideoPluginExtension,     // SF extension
        public IDXTSfAutomation,            // SF extension
        public ISfExchangeProps< PROPTYPE >,
        public IPersistStreamInit
{
public:
    CSFVideoPlugin
    (
        const PROPTYPE*     pPresetProps,
        HINSTANCE           hResourceInstance,
        UINT                uFirstPresetStringID,
        long                cPresets,
        const CLSID*        pPluginCLSID
    );
    ~CSFVideoPlugin();

    // Use this function to set a preset name string ID base during 
    // execution.  (For plugins that support multiple languages.)
    void SetPresetStringID
    (
        UINT    uFirstPresetStringID
    )
    {
        m_uFirstPresetStringID = uFirstPresetStringID;
    }

    // ************************************************************
    // *** Start of IStaticFilterPreset methods
    virtual HRESULT __stdcall GetPresetCount
    (
        /* [out] */ long __RPC_FAR *piCount
    )
    {
        *piCount = m_cPresets;
        return NOERROR;
    }
    
    virtual HRESULT __stdcall GetPresetName
    (
        /* [in] */  long     index,
        /* [out] */ LPOLESTR pszName,
        /* [in] */  DWORD    cchName
    )
    {
        if ( (index < 0) || (index >= m_cPresets) )
            return E_INVALIDARG;

        TCHAR szPresetName[MAX_PATH];
        int nRet = LoadString(m_hResourceInstance, m_uFirstPresetStringID + (UINT)index, szPresetName, MAX_PATH);
        if (nRet <= 0)
        {
            pszName[0] = 0;     // Null character to prevent bad string returns
            return E_FAIL;
        }

        #ifdef UNICODE
            wcsncpy(pszName, szPresetName, cchName);
        #else
            mbstowcs(pszName, szPresetName, cchName);
        #endif

        return NOERROR;
    }
    
    virtual HRESULT __stdcall UsePreset
    (
        /* [in] */  long     index
    )
    {
        if ( (index < 0) || (index >= m_cPresets) )
            return E_INVALIDARG;

        HRESULT hr = InitPropsFromPreset(index);

        if (m_hwndNotify)
            PostMessage(m_hwndNotify, WM_COMMAND, m_idNotify, 0);
        if (m_pAutoSink)
            m_pAutoSink->ParamsChanged();                        

        return hr;
    }

protected:
    const PROPTYPE*     m_pPresetProps;
    UINT                m_uFirstPresetStringID;
    long                m_cPresets;
    HINSTANCE           m_hResourceInstance;

    // *** End of IStaticFilterPreset methods and data
    // ************************************************************



    // ************************************************************
    // *** Start of ISfVideoPluginExtension
public:
    virtual HRESULT STDMETHODCALLTYPE get_Info
    ( 
        PSFVIDEOPLUGININFO  pPluginInfo,
        DWORD               cbStruct
    )
    {
        if (NULL == pPluginInfo)
            return E_POINTER;

        CopyMemory(pPluginInfo, &m_PluginInfo, min(sizeof(m_PluginInfo), cbStruct));
        return NOERROR;
    }
    
    virtual HRESULT STDMETHODCALLTYPE set_Quality
    ( 
        double dQuality
    )
    {
        // Make sure the Quality is between 0 and 1
        m_dQuality = min(max(dQuality, 0), 1);
        return NOERROR;
    }
    

protected:
    SFVIDEOPLUGININFO   m_PluginInfo;
    double              m_dQuality;

    // *** End of ISfVideoPluginExtension
    // ************************************************************


    // ************************************************************
    // *** Start of IPersistStreamInit
    HRESULT STDMETHODCALLTYPE GetClassID
    (
        CLSID *pClassID
    )
    {
        if (NULL == pClassID)
            return E_POINTER;

        *pClassID = *m_pPluginCLSID;

        return S_OK;
    };

    HRESULT STDMETHODCALLTYPE IsDirty(void)
    {                                       
        return (m_fDirty) ? S_OK : S_FALSE; 
    };

    HRESULT STDMETHODCALLTYPE GetSizeMax
    (
        ULARGE_INTEGER* pcbSize
    );


    HRESULT STDMETHODCALLTYPE InitNew(void)
    {
        InitPropsFromPreset();

        m_fDirty = TRUE;                   
        if (m_hwndNotify)                                    
            PostMessage(m_hwndNotify, WM_COMMAND, m_idNotify, 0);

        if (m_pAutoSink)
            m_pAutoSink->ParamsChanged();                        

        return S_OK;                                             
    }

    HRESULT STDMETHODCALLTYPE Load 
    (
        LPSTREAM pStm
    ) 
    {
        // Double check these critical sections for deadlock
        Enter();

		// Plugins may need to implement version checking at this point
        HRESULT hr = ReadProps(pStm, &m_Props);
        m_fDirty = TRUE;                
                                                                 
        if (SUCCEEDED(hr) && m_hwndNotify)                       
            PostMessage(m_hwndNotify, WM_COMMAND, m_idNotify, 0);

        if (SUCCEEDED(hr) && m_pAutoSink)                        
            m_pAutoSink->ParamsChanged();

        Leave();
        return hr;                                               
    }

    HRESULT STDMETHODCALLTYPE Save
    (
        LPSTREAM pStm, 
        BOOL fClearDirty
    )
    {
        Enter();

		// Plugins may need to implement version checking at this point
        HRESULT hr = WriteProps(pStm, &m_Props);

        if ( SUCCEEDED(hr) )
        {                                                           
            m_fDirty = !fClearDirty;                                
            if (m_hwndNotify)                                       
                PostMessage(m_hwndNotify, WM_COMMAND, m_idNotify, 0);
        }
        Leave();

        return hr;                                                   
    }

protected:
    // This is here so that the template can return the appropriate
    // class ID when it is requested by the Sony Media Software extensions.
    const CLSID*  m_pPluginCLSID;

    // *** End of IPersistStreamInit
    // ************************************************************


    // ************************************************************
    // *** Start of IDXTSfAutomation

public:
    HRESULT STDMETHODCALLTYPE EnablePlayback
    (                                       
        BOOL fEnable                        
    )
    {                                       
        m_fAutoEnabled = fEnable;           
                                            
        return S_OK;                        
    }

    HRESULT STDMETHODCALLTYPE GetParam
    (
        IStream __RPC_FAR *pIStream
    )
    {
        Enter();
        HRESULT hr = WriteProps(pIStream, &m_Props);
        Leave();

        return hr;
    }

    HRESULT STDMETHODCALLTYPE SetParam
    (
        IStream __RPC_FAR *pIStream
    )
    {
        HRESULT     hr;
        Enter();

        hr = ReadProps(pIStream, &m_Props);

        if (FAILED (hr))
            InitPropsFromPreset();

        if (m_hwndNotify)
            PostMessage(m_hwndNotify, WM_COMMAND, m_idNotify, 0);

        m_fDirty = TRUE;
        Leave();

        return hr;
    }

    HRESULT STDMETHODCALLTYPE InterpolateParams
    (
        IStream __RPC_FAR*  pIStreamOut,
        IStream __RPC_FAR*  pIStreamFrom,
        IStream __RPC_FAR*  pIStreamTo,
        DOUBLE              dProgress
    )
    {
        HRESULT hr;

        PROPTYPE PropFrom, PropTo, PropOut;

        hr = ReadProps(pIStreamFrom, &PropFrom);

        if (SUCCEEDED(hr))
        {
            hr = ReadProps(pIStreamTo, &PropTo);

            if (SUCCEEDED(hr))
            {
                InterpolateProps(&PropOut, &PropFrom, &PropTo, dProgress);
                hr = WriteProps(pIStreamOut, &PropOut);
            }
        }
                                               
        return hr;                              
    }
    
    HRESULT STDMETHODCALLTYPE SetPlaybackParams
    (
        IStream __RPC_FAR *pIStreamFrom,
        IStream __RPC_FAR *pIStreamTo
    )                           
    {                           
        HRESULT hr;             

        Enter();
                                
        hr = ReadProps(pIStreamFrom, &m_PropsFrom);
        if (SUCCEEDED(hr))
        {
            hr = ReadProps(pIStreamTo, &m_PropsTo);
        }

        if (FAILED(hr))
        {
            // Note: m_Props is being modified here...
            InitPropsFromPreset();
            CopyProps(&m_PropsFrom, &m_Props);
            CopyProps(&m_PropsTo, &m_Props);
        }
        Leave();

        return hr;                  
    }

    HRESULT STDMETHODCALLTYPE SetPlaybackProgress
    (                                            
        DOUBLE dProgress                         
    )                                            
    {                                            
        m_dAutoProgress = dProgress;             
        return S_OK;                             
    }


    HRESULT STDMETHODCALLTYPE SetChangeCallback
    (
        IDXTSfAutomationCallback __RPC_FAR *pICallback
    )
    {
        if (m_pAutoSink)
            m_pAutoSink->Release();

        m_pAutoSink = pICallback;

        if (m_pAutoSink)
            m_pAutoSink->AddRef();

        return S_OK;
    }

protected:
    IDXTSfAutomationCallback   *m_pAutoSink;
    BOOL                        m_fAutoEnabled;
    DOUBLE                      m_dAutoProgress;

    PROPTYPE                    m_PropsFrom;
    PROPTYPE                    m_PropsTo;

    // *** End of IDXTSfAutomation
    // ************************************************************


public:
    // Call this from your property page to set up notification
    HRESULT STDMETHODCALLTYPE SetNotifyWindow
    (
        HWND hwnd, 
        UINT id
    )
    {
        m_hwndNotify = hwnd;
        m_idNotify   = id;

        return S_OK;
    };

    HRESULT STDMETHODCALLTYPE PutAll
    (
        const PROPTYPE*     pProps
    )
    {
        if (NULL == pProps)
            return E_FAIL;

        Enter();
        HRESULT hr = CopyProps(&m_Props, pProps);
        m_fDirty = TRUE;
        Leave();
        if (m_pAutoSink)
            m_pAutoSink->ParamsChanged();                        

        return hr;
    }

    HRESULT STDMETHODCALLTYPE GetAll
    (
        PROPTYPE*           pProps
    )
    {
        if (NULL == pProps)
            return E_FAIL;

        Enter();
        HRESULT hr = CopyProps(pProps, &m_Props);
        Leave();

        return hr;
    }

    void AutoUpdateProps()
    {
        Enter();
        if (m_fAutoEnabled)
            InterpolateProps (&m_WorkProps, &m_PropsFrom, &m_PropsTo, m_dAutoProgress);
        else
            CopyProps(&m_WorkProps, &m_Props);
        Leave();
    }

    PROPTYPE& GetWorkProps()    {   return m_WorkProps;  }

protected:
    virtual HRESULT InitPropsFromPreset
    (
        long    lPreset = 0
    );
    virtual HRESULT ReadProps
    (
        LPSTREAM        pStm,
        PROPTYPE*       pProps
    );
    virtual HRESULT WriteProps
    (
        LPSTREAM        pStm,
        PROPTYPE*       pProps
    );

    virtual HRESULT CopyProps
    (
        PROPTYPE*       pDstProps,
        const PROPTYPE* pSrcProps
    );

    virtual HRESULT InterpolateProps
    (
        PROPTYPE*       pOutProps,
        const PROPTYPE* pFromProps,
        const PROPTYPE* pToProps,
        DOUBLE          dProgress
    );

protected:
    // Helper functions for entering and leaving critical section
    void Enter()
    {
        EnterCriticalSection(&m_Lock);
    }
    void Leave()
    {
        LeaveCriticalSection(&m_Lock);
    }


protected:
    HWND                m_hwndNotify;       // Notification window for updating of parameters
    UINT                m_idNotify;         // Notification WM_COMMAND id for the notify window
    BOOL                m_fDirty;           // Flag indicating that parameters have been modified
    CRITICAL_SECTION    m_Lock;             // Needed to ensure thread safe parameter modifications

    PROPTYPE            m_Props;            // Properties used for exchange with host and for UI updates
    PROPTYPE            m_WorkProps;        // Properties used for work purposes inside WorkProc(...)
};


template< class PROPTYPE >
CSFVideoPlugin<PROPTYPE>::CSFVideoPlugin
(
    const PROPTYPE*     pPresetProps,
    HINSTANCE           hResourceInstance,
    UINT                uFirstPresetStringID,
    long                cPresets,
    const CLSID*        pPluginCLSID
)
{
    InitializeCriticalSection(&m_Lock);

    // *** Start of IStaticFilterPreset code
    m_pPresetProps = pPresetProps;

    m_hResourceInstance = hResourceInstance;
    m_uFirstPresetStringID = uFirstPresetStringID;

    m_cPresets = cPresets;
    // *** End of IStaticFilterPreset code

    m_hwndNotify = NULL;
    m_idNotify = 0;


    // *** Start of ISfVideoPluginExtension
    ZeroMemory(&m_PluginInfo, sizeof(m_PluginInfo));

    m_PluginInfo.eCategory     = VIDEOPLUGINTYPE_FILTER; //VIDEOPLUGINTYPE_INVALID; 
    m_PluginInfo.dQualitySteps = 1;
    m_PluginInfo.ulMinInput    = 1; //m_ulNumInRequired;
    m_PluginInfo.ulMaxInput    = 1; //m_ulMaxInputs;
    m_PluginInfo.dwCaps        = 0;

    m_dQuality = 1.0;
    // *** End of ISfVideoPluginExtension

    // *** Start of IPersistStreamInit
    m_pPluginCLSID = pPluginCLSID;
    // *** End of IPersistStreamInit

    // *** Start of IDXTSfAutomation
    m_fAutoEnabled = FALSE;
    m_pAutoSink = NULL;
    m_dAutoProgress = 0;
    // *** End of IDXTSfAutomation

    // Initialize the properties structure if we have a default preset
    // to initialize it from, else ZERO is out
    if (cPresets > 0)
        InitPropsFromPreset();
    else
        ZeroMemory(&m_Props, sizeof(m_Props));
}


template< class PROPTYPE >
CSFVideoPlugin<PROPTYPE>::~CSFVideoPlugin()
{
    DeleteCriticalSection(&m_Lock);

    // *** Start of IDXTSfAutomation
    SetChangeCallback(NULL);
    // *** End of IDXTSfAutomation
}


// ****************************************************************
// ****************************************************************
// *** Virtual functions that can be overridden for more complex
// *** property data control (for variable property length structures
// *** and pointer allocations within the property structure)
// ****************************************************************


// ****************************************************************
// *** Start of IPersistStreamInit

/////////////////////////////////////////////////////////////////////
// Override this member if variable size properties need to be stored.
// This default implementation works for preset properties that store 
// and retrieve the property structure itself byte for byte.
template< class PROPTYPE >
HRESULT CSFVideoPlugin<PROPTYPE>::GetSizeMax
(
    ULARGE_INTEGER* pcbSize
)
{                             
    if (NULL == pcbSize)      
        return E_INVALIDARG;  
                              
    pcbSize->HighPart = 0;    
    pcbSize->LowPart = sizeof(PROPTYPE);
                              
    return S_OK;              
};
// *** End of IPersistStreamInit


// ****************************************************************
template< class PROPTYPE >
HRESULT CSFVideoPlugin<PROPTYPE>::InitPropsFromPreset
(
    long    lPreset
)
{
    // This default implementation works for all simple fixed length
    // parameter structures.  It copies the content of the static 
    // preset data into the property structure.
    HRESULT hr = CopyProps(&m_Props, &m_pPresetProps[lPreset]);
    return hr;
}

template< class PROPTYPE >
HRESULT CSFVideoPlugin<PROPTYPE>::ReadProps
(
    LPSTREAM    pStm,
    PROPTYPE*   pProps
)
{
    // This default implementation works for all simple fixed length
    // parameter structures.  It copies the stream content 
    // into the structure.
    HRESULT hr = pStm->Read(pProps, sizeof(m_Props), NULL);
    return hr;
}

template< class PROPTYPE >
HRESULT CSFVideoPlugin<PROPTYPE>::WriteProps
(
    LPSTREAM    pStm,
    PROPTYPE*   pProps
)
{
    // This default implementation works for all simple fixed length
    // parameter structures.  It copies the content of the
    // structure into the stream.
    HRESULT hr = pStm->Write(pProps, sizeof(m_Props), NULL);
    return hr;
}

template< class PROPTYPE >
HRESULT CSFVideoPlugin<PROPTYPE>::CopyProps
(
    PROPTYPE*       pDstProps,
    const PROPTYPE* pSrcProps
)
{
    // This default implementation works for all simple fixed length
    // parameter structures that don't use pointers and allocate memory.
    *pDstProps = *pSrcProps;
    return NOERROR;
}

template< class PROPTYPE >
HRESULT CSFVideoPlugin<PROPTYPE>::InterpolateProps
(
    PROPTYPE*       pOutProps,
    const PROPTYPE* pFromProps,
    const PROPTYPE* pToProps,
    DOUBLE          dProgress
)
{
    // This default implementation can only be used for non-varying
    // properties such as check boxes or combos, since it only copies
    // the 'From' parameters to the output.

    // *** IMPORTANT ***
    // If your properties contain sliders or other types of varying
    // properties, you MUST override this member function!!!
    HRESULT hr = CopyProps(pOutProps, pFromProps);
    return hr;
}

#endif // _SFBASE_H_
