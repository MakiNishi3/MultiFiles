
#define DX_DECLARE_GUID(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8) \
        EXTERN_C const GUID name \
                = { l, w1, w2, { b1, b2,  b3,  b4,  b5,  b6,  b7,  b8 } }

// {8DC5B514-BEA6-11d1-9AA3-00A0C99B12C5}
DX_DECLARE_GUID(SFPF_ARGB64, 
0x8dc5b514, 0xbea6, 0x11d1, 0x9a, 0xa3, 0x0, 0xa0, 0xc9, 0x9b, 0x12, 0xc5);


// {EC385932-2D38-11d2-99D3-00C04F8EDC2D}
DX_DECLARE_GUID(SFPF_PMARGBFLOAT, 
0xec385932, 0x2d38, 0x11d2, 0x99, 0xd3, 0x0, 0xc0, 0x4f, 0x8e, 0xdc, 0x2d);


//{8A1693F9-4830-11d2-95C6-00C04F8EDC2D}
DX_DECLARE_GUID(IID_ISFTransformFactory,
0x8A1693F9, 0x4830, 0x11d2, 0x95, 0xC6, 0x0, 0xc0, 0x4f, 0x8e, 0xdc, 0x2d);
