//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#ifdef __cplusplus
extern "C"
{
#endif

//
//  IStaticFilterPreset GUID
//
//  {36A22460-0CC9-11D0-8574-00A0C9053912}
//
DEFINE_GUID(IID_IStaticFilterPreset,
            0x36A22460, 0xCC9, 0x11D0, 0x85, 0x74,
            0x00, 0xA0, 0xC9, 0x05, 0x39, 0x12);

//DEFINE_GUID(IID_ISfAudioTransformFloat,
//            0x36A22400, 0xCC9, 0x11D0, 0x85, 0x74,
//            0x00, 0xA0, 0xC9, 0x05, 0x39, 0x12);

// {8568D2A1-2A86-11d3-9E94-00C04F68BE44}
DEFINE_GUID(IID_ISfAudioTransformFloat, 
            0x8568d2a1, 0x2a86, 0x11d3, 0x9e, 0x94, 
            0x0, 0xc0, 0x4f, 0x68, 0xbe, 0x44);

// the rest of this need be included only once.
//
#ifndef __SFIFACE__
#define __SFIFACE__

//
//  This is a new format tag defined by Microsoft that is in new MMREG.H
//  header files.. but most people do not have the new MMREG.H yet, so we
//  redefine it here.
//
//  This new data type is for passing native 32-bit and 64-bit floats as
//  audio data. It is _highly_ recommended that all ActiveMovie audio
//  plug-ins support this format (at least for 32-bit floats) for maintaining
//  precision necessary for 24-bit capable applications.
//
//  This new data type is used like this (and should be written to .WAV
//  files with this 'fmt' header):
//  
//      LPWAVEFORMATEX pwfx;
//
//      pwfx->wFormatTag      = WAVE_FORMAT_IEEE_FLOAT;
//      pwfx->nChannels       = cChannels;
//      pwfx->nSamplesPerSec  = dwSampleRate;
//      pwfx->wBitsPerSample  = 32;
//      pwfx->nBlockAlign     = pwfx->nChannels * (pwfx->wBitsPerSample/8);
//      pwfx->nAvgBytesPerSec = pwfx->nBlockAlign *
//                              pwfx->nSamplesPerSec;
//      pwfx->cbSize          = 0;
//  
//  The above example is for floats. Doubles (perhaps overkill, but
//  possible) can be supported by setting wBitsPerSample to 64.
//  
//  Now the really important stuff:
//  
//    - The floats are _normalized_ -1.0 to 1.0
//    - Overdriven samples are valid and must be bounded by the playback
//      (renderer) device (normally an application transforms this data
//      on the fly to 8, 16, or 24 bit PCM before sending it to a wave
//      device).
//  
//  By doing this, 24 bits of precision can be maintained even with an
//  overdriven signal to +/-1.9999... You start losing precision after
//  that, but hopefully that's a result of the user applying too much gain.
//  If you have a chain of plug-ins, one plug-in can overdrive the signal
//  and the next plug-in may cause a gain reduction bringing it back to a
//  normal range. This is good.
//
#ifndef WAVE_FORMAT_IEEE_FLOAT
#define WAVE_FORMAT_IEEE_FLOAT 3
#endif

// forward reference interface declarations
//
typedef interface IStaticFilterPreset    IStaticFilterPreset;
typedef interface IAudioTransformMetrics IAudioTransformMetrics;
typedef interface ISfAudioTransformFloat ISfAudioTransformFloat;

/*+
 *
 *  // IStaticFilterPreset. This interface exists so that an application can
 *  // get use presets defined statically in an ActiveMovie filter. (The term
 *  // preset refers to a collection of filter properties that have a
 *  // descriptive name).  This interface is for static presets only; that
 *  // is, presets defined when the filter is compiled. Dynamic presets are
 *  // managed using the IPersistStream interface.
 *
 *  //
 *  // This member returns the number of static presets that are available
 *  //
 *  STDMETHOD(GetPresetCount) (THIS_
 *      int * piCount     // [out] returns number of static presets
 *      ) PURE;
 *
 *  //
 *  // This member returns the name of a preset in the current language
 *  // the input 'index' identifies which preset to name
 *  //
 *  STDMETHOD(GetPresetName) (THIS_
 *      int      index,   // [in]  identifies which preset
 *      LPOLESTR pszName, // [out] preset name returned here
 *      DWORD    cchName  // [in]  size of output buffer in characters
 *      ) PURE;
 *
 *  //
 *  // This member causes the filter to begin using the preset indicated
 *  // by 'index' as its current property settings.
 *  //
 *  STDMETHOD(UsePreset) (THIS_
 *      int      index    // [in] identifies the preset to use
 *      ) PURE;
 *
 *-======================================================================*/

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface IStaticFilterPreset : public IUnknown
    {
    public:
        virtual HRESULT __stdcall GetPresetCount (
            /* [out] */ long __RPC_FAR *piCount) = 0;
        
        virtual HRESULT __stdcall GetPresetName (
            /* [in] */  long     index,
            /* [out] */ LPOLESTR pszName,
            /* [in] */  DWORD    cchName) = 0;
        
        virtual HRESULT __stdcall UsePreset (
            /* [in] */  long     index) = 0;
    };
    
#else   /* C style interface */

    typedef struct IStaticFilterPresetVtbl
    {
        HRESULT ( __stdcall __RPC_FAR *QueryInterface )( 
            IStaticFilterPreset __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( __stdcall __RPC_FAR *AddRef )( 
            IStaticFilterPreset __RPC_FAR * This);
        
        ULONG ( __stdcall __RPC_FAR *Release )( 
            IStaticFilterPreset __RPC_FAR * This);
        
        HRESULT ( __stdcall __RPC_FAR *GetPresetCount )(
            IStaticFilterPreset __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *piCount);
        
        HRESULT ( __stdcall __RPC_FAR *GetPresetName )(
            IStaticFilterPreset __RPC_FAR * This,
            /* [in] */  long     index,
            /* [out] */ LPOLESTR pszName,
            /* [in] */  DWORD    cchName);

        HRESULT ( __stdcall __RPC_FAR *UsePreset)(
            IStaticFilterPreset __RPC_FAR * This,
            /* [in] */  long     index);
        
    } IStaticFilterPresetVtbl;

    interface IStaticFilterPreset
    {
        CONST_VTBL struct IStaticFilterPresetVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define IStaticFilterPreset_QueryInterface(This,riid,ppvObject) \
    (This)->lpVtbl->QueryInterface(This,riid,ppvObject)

#define IStaticFilterPreset_AddRef(This) \
    (This)->lpVtbl->AddRef(This)

#define IStaticFilterPreset_Release(This) \
    (This)->lpVtbl->Release(This)


#define IStaticFilterPreset_GetPresetCount(This,piCount) \
    (This)->lpVtbl->GetPresetCount(This,piCount)

#define IStaticFilterPreset_GetPresetName(This,index,psz,cch) \
    (This)->lpVtbl->GetPresetName(This,index,psz,cch)

#define IStaticFilterPreset_UsePreset(This,index) \
    (This)->lpVtbl->UsePreset(This,index)

#endif /* COBJMACROS */

#endif  /* C style interface */

/*+
 *
 *  // ISfAudioTransformFloat.  This interface provides a more effecient
 *  // mechanism for applications to call the Transform function for udio
 *  // ActiveMovie Audio Transform filters.
 *
 *  NOTE: cells == (bytes / sizeof(float) / cChannels)
 *
 *-======================================================================*/

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface ISfAudioTransformFloat : public IUnknown
    {
    public:
        virtual HRESULT __stdcall FloatStart (
            /* [in]     */  UINT cChannels,
            /* [in]     */  UINT nSamplesPerSec)=0;

        virtual HRESULT __stdcall FloatTransform (
            /* [in,out] */ float __RPC_FAR * pfBuffer,       // in/out buffer
            /* [in]     */ long              ccBuffer,       // buffer cell count
            /* [in]     */ BOOL              fSilence)=0;    // buffer is silence, hr reflects whether the filter does anything

        virtual HRESULT __stdcall FloatEndOfStream (
            /* [in,out] */ float __RPC_FAR * pfBuffer,     // in/out buffer
            /* [in,out] */  long __RPC_FAR * pccBuffer)=0; // buffer cell count (cells = bytes/sizeof(float)/cChannels)

        virtual HRESULT __stdcall FloatStop (void)=0;

        virtual HRESULT __stdcall FloatHaveParamsChanged (void)=0;

        virtual HRESULT __stdcall FloatCookParams (
            /* [in]     */ BOOL fDiscontinuity,         // reset internal state
            /* [in]     */ double dTempo)=0;            // for future implementations
    };
    
#else   /* C style interface */

    typedef struct ISfAudioTransformFloatVtbl
    {
        HRESULT ( __stdcall __RPC_FAR *QueryInterface )( 
            ISfAudioTransformFloat __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( __stdcall __RPC_FAR *AddRef )( 
            ISfAudioTransformFloat __RPC_FAR * This);
        
        ULONG ( __stdcall __RPC_FAR *Release )( 
            ISfAudioTransformFloat __RPC_FAR * This);
        
        HRESULT ( __stdcall __RPC_FAR *FloatStart )(
            ISfAudioTransformFloat __RPC_FAR * This,
            /* [in]     */  UINT cChannels,
            /* [in]     */  UINT nSamplesPerSec);

        HRESULT ( __stdcall __RPC_FAR *FloatTransform )(
            ISfAudioTransformFloat __RPC_FAR * This,
            /* [in,out] */ float __RPC_FAR * pfBuffer,     // in/out buffer
            /* [in]     */ long              ccBuffer,     // buffer cell count
            /* [in]     */ BOOL              fSilence);    // buffer is silence, hr reflects whether the filter does anything

        HRESULT ( __stdcall __RPC_FAR *FloatEndOfStream )(
            ISfAudioTransformFloat __RPC_FAR * This,
            /* [in,out] */ float __RPC_FAR * pfBuffer,   // in/out buffer
            /* [in,out] */ long  __RPC_FAR * pccBuffer); // buffer cell count (cells = bytes/sizeof(float)/cChannels)

        HRESULT ( __stdcall __RPC_FAR *FloatStop )(
            ISfAudioTransformFloat __RPC_FAR * This);

        HRESULT ( __stdcall __RPC_FAR *FloatHaveParamsChanged )(
            ISfAudioTransformFloat __RPC_FAR * This);

        HRESULT (__stdcall __RPC_FAR *FloatCookParams)(
            /* [in]     */ BOOL fDiscontinuity,         // reset internal state
            /* [in]     */ double dTempo);              // for future implementation

    } ISfAudioTransformFloatVtbl;

    interface ISfAudioTransformFloat
    {
        CONST_VTBL struct ISfAudioTransformFloatVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define ISfAudioTransformFloat_QueryInterface(This,riid,ppvObject) \
    (This)->lpVtbl->QueryInterface(This,riid,ppvObject)

#define ISfAudioTransformFloat_AddRef(This) \
    (This)->lpVtbl->AddRef(This)

#define ISfAudioTransformFloat_Release(This) \
    (This)->lpVtbl->Release(This)

#endif /* COBJMACROS */

#endif  /* C style interface */
#endif // __SFIFACE__
#ifdef __cplusplus
} // extern "C"
#endif
