//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Main.rc
//
#define IDS_PROJNAME                    100
#define IDR_OFFSET                      101
#define IDS_TITLEOffsetPP               102
#define IDS_HELPFILEOffsetPP            103
#define IDS_DOCSTRINGOffsetPP           104
#define IDR_OFFSETPP                    105
#define IDS_FIRSTPRESET_ENGLISH         105
#define IDD_OFFSETPP                    106
#define IDS_STRING106                   106
#define IDS_STRING107                   107
#define IDC_OFFSETSLIDER                201

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
