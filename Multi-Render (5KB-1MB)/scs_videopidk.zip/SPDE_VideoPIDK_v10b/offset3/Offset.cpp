//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#include "stdafx.h"
#include "Main.h"
#include "Offset.h"

/////////////////////////////////////////////////////////////////////////////
// COffset

static const OFFSETPROPS g_aPresetProps[] = 
{
    {    0.0  },    // Default
    {   -0.1  },    // Darker
    {    0.1  }     // Lighter
};

#define PRESETPROPCOUNT   ( sizeof(g_aPresetProps) / sizeof(g_aPresetProps[0]) )

COffset::COffset()
    : CSFVideoPlugin< OFFSETPROPS > (g_aPresetProps, _Module.GetResourceInstance(), IDS_FIRSTPRESET_ENGLISH, PRESETPROPCOUNT, &CLSID_Offset)
{
	m_pUnkMarshaler = NULL;

    m_ulMaxInputs       = 0;
    m_ulNumInRequired   = 0;
    m_dwOptionFlags     = DXBOF_SAME_SIZE_INPUTS | DXBOF_CENTER_INPUTS;
    m_dwMiscFlags      |= DXTMF_INPLACE_OPERATION;
    m_Duration          = .5;

    m_PluginInfo.eCategory  = VIDEOPLUGINTYPE_FILTER;
    m_PluginInfo.dQualitySteps = 1;
    m_PluginInfo.ulMinInput = m_ulNumInRequired;
    m_PluginInfo.ulMaxInput = m_ulMaxInputs;
    m_PluginInfo.dwCaps     = SFVIDEOPLUGIN_CAPS_ASPECTRATIO;

#if(_ATL_VER >= 0x0300)
    m_bRequiresSave = FALSE;
#endif
}

HRESULT COffset::DetermineBnds(CDXDBnds & bnds)
{ 
    HRESULT hr;

    if (0 == m_ulNumInputs)
    {
        if (OutputSurface())
        {
            CDXDBnds SurfBnds(OutputSurface(), hr);
            bnds = SurfBnds;
        }
    }
    return S_OK; 
}

HRESULT COffset::WorkProc( const CDXTWorkInfoNTo1& WI, BOOL* pbContinue )
{
    HRESULT     hr = S_OK;

    ULONG uXSize = WI.OutputBnds.Width();
    ULONG uYSize = WI.OutputBnds.Height();

    AutoUpdateProps();

    // 32 bit ARGB
    CSFARGBReadWritePtr Out(hr, OutputSurface(), &WI.OutputBnds);
    if( FAILED( hr ) ) return hr;

    INT nRedAdd   = (INT)(255 * m_WorkProps.dOffset);
    INT nGreenAdd = (INT)(255 * m_WorkProps.dOffset);
    INT nBlueAdd  = (INT)(255 * m_WorkProps.dOffset);

    DXSAMPLE* pDstRow = Out.GetFirstSample();

    for (ULONG uY = 0; uY < uYSize; uY++)
    {
        for (ULONG uX = 0; uX < uXSize; uX++)
        {
            // This is NOT optimized, it serves for demonstration purposes only!
            BYTE bA = pDstRow[uX].Alpha;
            pDstRow[uX].Red   = (BYTE)min(bA, max(0, (pDstRow[uX].Red   + nRedAdd)));
            pDstRow[uX].Green = (BYTE)min(bA, max(0, (pDstRow[uX].Green + nGreenAdd)));
            pDstRow[uX].Blue  = (BYTE)min(bA, max(0, (pDstRow[uX].Blue  + nBlueAdd)));
        }
        pDstRow += Out.GetWidth();
    }

    return hr;
}

HRESULT COffset::InterpolateProps
(
    OFFSETPROPS*        pOutProps,
    const OFFSETPROPS*  pFromProps,
    const OFFSETPROPS*  pToProps,
    DOUBLE              dProgress
)
{
    pOutProps->dOffset = Interpolate< DOUBLE >(pFromProps->dOffset, pToProps->dOffset, dProgress);

    return NOERROR;
}
