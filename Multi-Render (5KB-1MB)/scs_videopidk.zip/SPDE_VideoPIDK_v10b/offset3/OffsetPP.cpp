//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#include "stdafx.h"
#include "commctrl.h"
#include "Main.h"
#include "OffsetPP.h"

/////////////////////////////////////////////////////////////////////////////
// COffsetPP

#define SLIDER_SCALE 1000

void COffsetPP::Update()
{
    CComQIPtr<ISfExchangeProps<OFFSETPROPS>, &IID_ISfExchangeProps> pFilter( m_ppUnk[0] );
    pFilter->GetAll(&m_Props);

    SendMessage(::GetDlgItem(m_hWnd, IDC_OFFSETSLIDER), TBM_SETPOS, (WPARAM)TRUE, (LPARAM)(m_Props.dOffset * SLIDER_SCALE));
}

LRESULT COffsetPP::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    HWND hSlider = ::GetDlgItem(m_hWnd, IDC_OFFSETSLIDER);
    SendMessage(hSlider, TBM_SETRANGEMIN, (WPARAM)FALSE, (LPARAM)-SLIDER_SCALE);
    SendMessage(hSlider, TBM_SETRANGEMAX, (WPARAM)TRUE, (LPARAM)SLIDER_SCALE);

    CComQIPtr<ISfExchangeProps<OFFSETPROPS>, &IID_ISfExchangeProps> pFilter( m_ppUnk[0] );
    pFilter->SetNotifyWindow(m_hWnd, ID_NOTIFYCHANGE);
    Update();

	return 0;
}

LRESULT COffsetPP::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    CComQIPtr<ISfExchangeProps<OFFSETPROPS>, &IID_ISfExchangeProps> pFilter( m_ppUnk[0] );
    pFilter->SetNotifyWindow(m_hWnd, NULL);

	return 0;
}

LRESULT COffsetPP::OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    UINT    uId     = LOWORD(wParam);

    switch(uId)
    {
        case ID_NOTIFYCHANGE:
            Update();
            bHandled = TRUE;
            break;
    }

    return 0;
}

LRESULT COffsetPP::OnHScroll(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{ 
    HWND    hctl = (HWND)lParam;

    if (hctl == ::GetDlgItem(m_hWnd, IDC_OFFSETSLIDER))
    {
        LONG lPos = SendMessage(hctl, TBM_GETPOS, (WPARAM)0, (LPARAM)0);
        if ( (LONG)(m_Props.dOffset * SLIDER_SCALE) != lPos)
        {
            m_Props.dOffset = (DOUBLE)lPos / SLIDER_SCALE;
            Apply();
        }
    }
    return 0;
}
