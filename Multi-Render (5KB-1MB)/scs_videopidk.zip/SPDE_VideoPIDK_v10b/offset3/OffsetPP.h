//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#ifndef __OFFSETPP_H_
#define __OFFSETPP_H_

#include "resource.h"       // main symbols
#include "Offset.h"

EXTERN_C const CLSID CLSID_OffsetPP;

/////////////////////////////////////////////////////////////////////////////
// COffsetPP
class ATL_NO_VTABLE COffsetPP :
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<COffsetPP, &CLSID_OffsetPP>,
	public IPropertyPageImpl<COffsetPP>,
	public CDialogImpl<COffsetPP>
{
public:
	COffsetPP() 
	{
		m_pUnkMarshaler = NULL;
		m_dwTitleID = IDS_TITLEOffsetPP;
		m_dwHelpFileID = IDS_HELPFILEOffsetPP;
		m_dwDocStringID = IDS_DOCSTRINGOffsetPP;
	}

	enum {IDD = IDD_OFFSETPP};

DECLARE_GET_CONTROLLING_UNKNOWN()
DECLARE_REGISTRY_RESOURCEID(IDR_OFFSETPP)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(COffsetPP) 
	COM_INTERFACE_ENTRY(IPropertyPage)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

BEGIN_MSG_MAP(COffsetPP)
	CHAIN_MSG_MAP(IPropertyPageImpl<COffsetPP>)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
    MESSAGE_HANDLER( WM_COMMAND, OnCommand )
    MESSAGE_HANDLER( WM_HSCROLL, OnHScroll )
END_MSG_MAP()

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

	STDMETHOD(Apply)(void)
	{
        CComQIPtr<ISfExchangeProps<OFFSETPROPS>, &IID_ISfExchangeProps> pScreen( m_ppUnk[0] );
        pScreen->PutAll(&m_Props);

		m_bDirty = FALSE;
		return S_OK;
	}

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnHScroll(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

    void Update();

    STDMETHOD(Help)(LPCOLESTR pszHelpDir) {return E_FAIL;}

protected:
    OFFSETPROPS     m_Props;
};

#endif //__OFFSETPP_H_
