//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#ifndef __PLUGIN_H_
#define __PLUGIN_H_

#include "resource.h"       // main symbols
#include "SFBase.h"

#include "dxsurfb.h"

/////////////////////////////////////////////////////////////////////////////
typedef struct tPLUGINPROPS
{
    INT nSomeProperty;      // TODO: Place your actual property variables here
} PLUGINPROPS;

/////////////////////////////////////////////////////////////////////////////
// A read pointer for surface data

class CDXSReadPtr : public CDXBaseARGBPtr
{
public:

    CDXSReadPtr(CDXBaseSurface * pSurface) : CDXBaseARGBPtr(pSurface) {}
    void    FillSamples(const DXPtrFillInfo & FillInfo);
};


/////////////////////////////////////////////////////////////////////////////
// CPlugin
class ATL_NO_VTABLE CPlugin : 

    public CDXBaseSurface,
    public IDXTScaleOutput,
	public CComCoClass<CPlugin, &CLSID_Plugin>,
	public IDispatchImpl<IPlugin, &IID_IPlugin, &LIBID_MAINLib>,
#if(_ATL_VER < 0x0300)
    public CComPropertySupport<CPlugin>,
#endif
    public IObjectSafetyImpl2<CPlugin>,
    public IPersistStorageImpl<CPlugin>,
    public ISpecifyPropertyPagesImpl<CPlugin>,
    public IPersistPropertyBagImpl<CPlugin>,
    public CSFVideoPlugin< PLUGINPROPS >            // SF extension
{
public:
	CPlugin();

    HRESULT WorkProc( const CDXTWorkInfoNTo1& WI, BOOL* pbContinue )
    {
        // We need to do this to make sure parameters get properly 
        // updated prior to rendering.
        AutoUpdateProps();
        return CDXBaseSurface::WorkProc(WI, pbContinue);
    }

    HRESULT InterpolateProps
    (
        PLUGINPROPS*        pOutProps,
        const PLUGINPROPS*  pFromProps,
        const PLUGINPROPS*  pToProps,
        DOUBLE              dProgress
    );

    HRESULT DetermineBnds(CDXDBnds & bnds)
    { 
        HRESULT hr = S_OK;

        if ((0 == m_ulNumInputs) && OutputSurface())
        {
            CDXDBnds SurfBnds(OutputSurface(), hr);
            bnds = SurfBnds;
        }
        return hr; 
    }

    // Surface specific code
    const   GUID & SurfaceCLSID() { return GetObjectCLSID(); }
    HRESULT CreateARGBPointer(CDXBaseSurface * pSurface, CDXBaseARGBPtr ** ppPtr)
    {
        *ppPtr = new CDXSReadPtr(this);
        if (NULL == *ppPtr)
            return E_OUTOFMEMORY;
        return S_OK;
    }
    void    DeleteARGBPointer(CDXBaseARGBPtr *pPtr)
    {
        if (pPtr)
            delete (CDXSReadPtr*)pPtr;
    }
    // Scaling
    STDMETHODIMP SetOutputSize(const SIZE OutputSize, BOOL bMaintainAspect)
    {
        HRESULT hr = S_OK;
        if ( (OutputSize.cx < 1) || (OutputSize.cy < 1) )
            return E_INVALIDARG;

        _EnterCritWith0PtrLocks();
        hr = OnSetSize(OutputSize.cx, OutputSize.cy);
        Unlock();

        return hr;
    }

DECLARE_IDXEFFECT_METHODS(0)
DECLARE_POLY_AGGREGATABLE(CPlugin)

DECLARE_REGISTER_DX_SURFACE(IDR_PLUGIN);

DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CPlugin)
    COM_INTERFACE_ENTRY(ISfVideoPluginExtension)    // SF extension
    COM_INTERFACE_ENTRY(IDXTSfAutomation)           // SF extension
    COM_INTERFACE_ENTRY(IStaticFilterPreset)        // SF extension
    COM_INTERFACE_ENTRY(IPersistStreamInit)         // SF implemented in CSfVideoPlugin
    COM_INTERFACE_ENTRY_IID(IID_ISfExchangeProps, ISfExchangeProps<PLUGINPROPS>)

    COM_INTERFACE_ENTRY(IPlugin)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)

    COM_INTERFACE_ENTRY_IID(IID_IObjectSafety, IObjectSafetyImpl2<CPlugin>)
#if(_ATL_VER <= 0x0200)
        COM_INTERFACE_ENTRY_IMPL(IPersistStorage)
        COM_INTERFACE_ENTRY_IMPL(ISpecifyPropertyPages)
        COM_INTERFACE_ENTRY_IMPL(IPersistPropertyBag)
#else
        COM_INTERFACE_ENTRY(IPersistStorage)
        COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
        COM_INTERFACE_ENTRY(IPersistPropertyBag)
#endif
    COM_INTERFACE_ENTRY(IDXTScaleOutput)
    COM_INTERFACE_ENTRY_CHAIN(CDXBaseSurface)
END_COM_MAP()

#if(_ATL_VER <= 0x0200)
BEGIN_PROPERTY_MAP( CPlugin )
#else
BEGIN_PROP_MAP( CPlugin )
#endif
    //PROP_ENTRY("Description", DISPID_MyProperty, CLSID_PluginPP )
    PROP_PAGE( CLSID_PluginPP )
#if(_ATL_VER <= 0x0200)
    END_PROPERTY_MAP()
#else
    END_PROP_MAP()
#endif

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
        // Free all allocated read pointers
        while (m_pFreePtr)
        {
            CDXBaseARGBPtr *pNext = m_pFreePtr->m_pNext;
            DeleteARGBPointer(m_pFreePtr);
            m_pFreePtr = pNext;
        }

		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

// IPlugin
public:
#if(_ATL_VER >= 0x0300)
    BOOL            m_bRequiresSave;
#endif
};

#endif //__PLUGIN_H_
