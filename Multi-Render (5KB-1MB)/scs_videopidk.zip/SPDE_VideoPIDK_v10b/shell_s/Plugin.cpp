//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#include "stdafx.h"
#include "Main.h"
#include "Plugin.h"

/////////////////////////////////////////////////////////////////////////////
// CPlugin

// TODO: Update this array with the correct values for members of your
//       PLUGINPROPS structure.  If you add presets be sure to add
//       resource strings into the resource string table.  The strings
//       must be consecutive and start at id IDS_FIRSTPRESET_ENGLISH.
static const PLUGINPROPS g_aPresetProps[] = 
{
    {    0  }     // Default
};
#define PRESETPROPCOUNT   ( sizeof(g_aPresetProps) / sizeof(g_aPresetProps[0]) )


CPlugin::CPlugin()
    : CSFVideoPlugin< PLUGINPROPS > (g_aPresetProps, _Module.GetResourceInstance(), IDS_FIRSTPRESET_ENGLISH, PRESETPROPCOUNT, &CLSID_Plugin)
{
	m_pUnkMarshaler = NULL;

#if(_ATL_VER >= 0x0300)
    m_bRequiresSave = FALSE;
#endif

    // Used for surface fitlers
    // (only an output surface is needed, since the content is generated)
    m_ulMaxInputs       = 0;
    m_ulNumInRequired   = 0;
    m_dwMiscFlags      |= 0;
    m_PluginInfo.eCategory  = VIDEOPLUGINTYPE_SURFACE;

    // TODO: Modify these flags if you need to.
    m_dwOptionFlags     = DXBOF_SAME_SIZE_INPUTS | DXBOF_CENTER_INPUTS;
    m_Duration          = .5;

    m_PluginInfo.dQualitySteps = 1;
    m_PluginInfo.ulMinInput = m_ulNumInRequired;
    m_PluginInfo.ulMaxInput = m_ulMaxInputs;

	// TODO: Set the proper capabilities flags based on what operation
	// your filter will need to perform:
	// SFVIDEOPLUGIN_CAPS_ASPECTRATIO - 
	//	    Should be set if the plugin doesn't require aspect ratio 
	//      information to work properly, or it uses the provided aspect
	//      ratio to properly render its output. (If this flag is not
	//      set, Vegas will stretch all inputs to an aspect ratio of 1
	//      prior to executing this filter.
	// SFVIDEOPLUGIN_CAPS_NOALPHAGENERATION -
	//	    Should be set if the plugin doesn't introduce any transparency
    //      in the output surface if all input surfaces don't contain any 
    //      transparency.
	// SFVIDEOPLUGIN_CAPS_PIXELOPERATION -
	//	    Should be set if the plugin operates on individual pixels without 
	//      the need to consider neighbouring pixels.  (Specifying this
	//      flag will allow Vegas to pass both fields of interlaced 
	//      frames at the same time to this filter.)

    m_PluginInfo.dwCaps = // SFVIDEOPLUGIN_CAPS_ASPECTRATIO |
	                      // SFVIDEOPLUGIN_CAPS_NOALPHAGENERATION |
	                      // SFVIDEOPLUGIN_CAPS_PIXELOPERATION |
						0;
}

HRESULT CPlugin::InterpolateProps
(
    PLUGINPROPS*        pOutProps,
    const PLUGINPROPS*  pFromProps,
    const PLUGINPROPS*  pToProps,
    DOUBLE              dProgress
)
{
    // TODO: Add interpolation code here if any properties can be interpolated
    return S_OK;
}



void CDXSReadPtr::FillSamples(const DXPtrFillInfo & FillInfo)
{
    DXSAMPLE* pDstRow = (DXSAMPLE*)FillInfo.pSamples;

    // TODO: This is where your plugin processing should be implemented
    //       The following sample code demonstrates how to loop through
    //       all requested surface pixels.
	/*
    ULONG uXSize = m_pSurface->m_Width;
    ULONG uYSize = m_pSurface->m_Height;

    // NOTE: Retrieve the video stream info if you need aspect ratio and 
    //       other information about the stream
    VIDEOSTREAMINFO VSInfo;
    GetSurfaceStreamInfo(m_pSurface->OutputSurface(), &VSInfo);


    // TODO: Use the GetWorkProps() member function of the CPlugin class
    //       to access your PLUGINPROPS structure
    // eg: INT nSomeProperty = ((CPlugin*)m_pSurface)->GetWorkProps().nSomeProperty;

    for (ULONG uIdx = 0; uIdx < FillInfo.cSamples; uIdx++)
    {
		pDstRow[uIdx].Red = 0;
		pDstRow[uIdx].Green = 0;
		pDstRow[uIdx].Blue = 0;
		pDstRow[uIdx].Alpha = 255;
    }
	*/
}

