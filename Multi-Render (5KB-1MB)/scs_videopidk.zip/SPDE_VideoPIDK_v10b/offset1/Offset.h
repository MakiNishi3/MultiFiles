//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#ifndef __OFFSET_H_
#define __OFFSET_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// COffset
class ATL_NO_VTABLE COffset : 
	public CDXBaseNTo1,
	public CComCoClass<COffset, &CLSID_Offset>,
	public IDispatchImpl<IOffset, &IID_IOffset, &LIBID_MAINLib>,
#if(_ATL_VER < 0x0300)
    public CComPropertySupport<COffset>,
#endif
    public IObjectSafetyImpl2<COffset>,
    public IPersistStorageImpl<COffset>,
    public ISpecifyPropertyPagesImpl<COffset>,
    public IPersistPropertyBagImpl<COffset>

{
public:
	COffset()
	{
		m_pUnkMarshaler = NULL;
	}

DECLARE_IDXEFFECT_METHODS(0)
DECLARE_POLY_AGGREGATABLE(COffset)
DECLARE_REGISTER_DX_TRANSFORM(IDR_OFFSET, CATID_DXImageTransform)
//DECLARE_REGISTRY_RESOURCEID(IDR_OFFSET)


DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(COffset)
	COM_INTERFACE_ENTRY(IOffset)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)

    COM_INTERFACE_ENTRY(IDXEffect)
    COM_INTERFACE_ENTRY_IID(IID_IObjectSafety,
    IObjectSafetyImpl2<COffset>)
    COM_INTERFACE_ENTRY_IMPL(IPersistStorage)
    COM_INTERFACE_ENTRY_IMPL(ISpecifyPropertyPages)
    COM_INTERFACE_ENTRY_IMPL(IPersistPropertyBag)
    COM_INTERFACE_ENTRY_CHAIN(CDXBaseNTo1)
END_COM_MAP()


#if(_ATL_VER <= 0x0200)
BEGIN_PROPERTY_MAP( COffset )
#else
BEGIN_PROP_MAP( COffset )
#endif
    //PROP_ENTRY("Description", DISPID_MyProperty, CLSID_OffsetPP )
    PROP_PAGE( CLSID_OffsetPP )
#if(_ATL_VER <= 0x0200)
    END_PROPERTY_MAP()
#else
    END_PROP_MAP()
#endif


	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

// IOffset
public:
#if(_ATL_VER >= 0x0300)
    BOOL            m_bRequiresSave;
#endif
};

#endif //__OFFSET_H_
