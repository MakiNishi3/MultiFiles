Sony Media Software Digital DirectX Transform Video PIDK V1.0b (for Microsoft Visual Studio 2005)
-------------------------------------------------------------------------------------------------

Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.

Please extract this PIDK with directory information.  It is necessary for correct operation
of the samples included in this PIDK.  To do this enable the "Use Folder Names" option in
WinZip, or its equivalent if using other ZIP archiving software.


What's in this SDK:

[include] 	- Contains include files for Sony Media Software DXTransform plug-in extensions

[dxinc]         - Contains modified DirectX header files that work with Microsoft Visual Studio 2005

[manual]	- Contains documentation for creation of DX plug-ins with Sony Media Software extensions

[mask]		- Sample mask generation plug-in

[ellipse]	- A sample surface generator plug-in with Sony Media Software extensions

[offset1]	- Intermediate state of the "Offset" plug-in located in the [offset] directory

[offset2]	- Second intermediate state of the "Offset" plug-in located in the [offset] directory

[offset3]	- Completed sample DXTransform filter plug-in (steps for creation of this plug-in are included in the documentation)

[shell]		- DX plug-in shell that can be used for creation of DX plug-ins with Sony Media Software extensions

[shell_s]	- DX plug-in shell that can be used for creation of DX surface generator plug-ins with Sony Media Software extensions

[simple]	- A simple "Flip" DX plugin with no property page elements

[square]        - A sample transition plug-in that demonstrates handling of pixel aspect ratio

[surface]	- A sample surface generator plug-in with Sony Media Software extensions (steps for creation of this plug-in are included in the documentation)

