//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#ifndef __SCREENPP_H_
#define __SCREENPP_H_

#include "resource.h"       // main symbols
#include "Screen.h"

EXTERN_C const CLSID CLSID_ScreenPP;

/////////////////////////////////////////////////////////////////////////////
// CScreenPP
class ATL_NO_VTABLE CScreenPP :
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CScreenPP, &CLSID_ScreenPP>,
	public IPropertyPageImpl<CScreenPP>,
	public CDialogImpl<CScreenPP>
{
public:
	CScreenPP() 
	{
		m_pUnkMarshaler = NULL;
		m_dwTitleID = IDS_TITLEScreenPP;
		m_dwHelpFileID = IDS_HELPFILEScreenPP;
		m_dwDocStringID = IDS_DOCSTRINGScreenPP;
	}

	enum {IDD = IDD_SCREENPP};

DECLARE_GET_CONTROLLING_UNKNOWN()
DECLARE_REGISTRY_RESOURCEID(IDR_SCREENPP)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CScreenPP) 
	COM_INTERFACE_ENTRY(IPropertyPage)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

BEGIN_MSG_MAP(CScreenPP)
	CHAIN_MSG_MAP(IPropertyPageImpl<CScreenPP>)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	MESSAGE_HANDLER(WM_CTLCOLORBTN, OnCtlColorStatic)
	COMMAND_HANDLER(IDC_COLOR_RED, EN_KILLFOCUS, OnPropsChanged)
	COMMAND_HANDLER(IDC_COLOR_GREEN, EN_KILLFOCUS, OnPropsChanged)
	COMMAND_HANDLER(IDC_COLOR_BLUE, EN_KILLFOCUS, OnPropsChanged)
	COMMAND_HANDLER(IDC_TOLERANCE, EN_KILLFOCUS, OnPropsChanged)
    MESSAGE_HANDLER( WM_COMMAND, OnCommand )
	MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
END_MSG_MAP()
	//COMMAND_HANDLER(IDC_COLOR_RED, EN_CHANGE, OnChangeProps)
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

	STDMETHOD(Apply)(void)
	{
		ATLTRACE(_T("CScreenPP::Apply\n"));

        CComQIPtr<ISfExchangeProps<SCREENPROPS>, &IID_ISfExchangeProps> pScreen( m_ppUnk[0] );
        pScreen->PutAll(&m_Props);

        for (UINT i = 0; i < m_nObjects; i++)
		{
			// Do something interesting here
			// ICircCtl* pCirc;
			// m_ppUnk[i]->QueryInterface(IID_ICircCtl, (void**)&pCirc);
			// pCirc->put_Caption(CComBSTR("something special"));
			// pCirc->Release();
		}
		m_bDirty = FALSE;
		return S_OK;
	}

	LRESULT OnCtlColorStatic(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
        HWND hWnd = (HWND)lParam;
        if (GetDlgItem(IDC_COLOR) == hWnd)
        {
            DeleteObject(m_hBrush);
            LOGBRUSH Brush;
            Brush.lbStyle = BS_SOLID;
            Brush.lbColor = RGB(m_Props.bR, m_Props.bG, m_Props.bB);
            m_hBrush = ::CreateBrushIndirect(&Brush);

            bHandled = TRUE;
            return (LRESULT)m_hBrush;
        }
		return 0;
	}

    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
        LOGBRUSH Brush;
        Brush.lbStyle = BS_SOLID;
        Brush.lbColor = RGB(0, 0, 255);
        m_hBrush = ::CreateBrushIndirect(&Brush);

        //m_Props.dTolerance = 0.01;

        CComQIPtr<ISfExchangeProps<SCREENPROPS>, &IID_ISfExchangeProps> pScreen( m_ppUnk[0] );
        pScreen->SetNotifyWindow(m_hWnd, ID_NOTIFYCHANGE);
        Update();

		return 0;
	}

    void Update()
    {
        CComQIPtr<ISfExchangeProps<SCREENPROPS>, &IID_ISfExchangeProps> pScreen( m_ppUnk[0] );
        pScreen->GetAll(&m_Props);

        SetCtlValue(GetDlgItem(IDC_COLOR_RED), m_Props.bR);
        SetCtlValue(GetDlgItem(IDC_COLOR_GREEN), m_Props.bG);
        SetCtlValue(GetDlgItem(IDC_COLOR_BLUE), m_Props.bB);
        SetCtlValue(GetDlgItem(IDC_TOLERANCE), (int)(m_Props.dTolerance * 100));

        ::InvalidateRect(GetDlgItem(IDC_COLOR), NULL, TRUE);
    }

    void SetCtlValue
    (
        HWND    hWndCtl,
        int     nValue
    )
    {
        TCHAR szText[20];
        _itot (nValue, szText, 10);
        ::SetWindowText(hWndCtl, szText);
    }

    int GetVerifyCtlValue
    (
        HWND    hWndCtl,
        int     nMin,
        int     nMax
    )
    {
        TCHAR szText[20];
        int nRet = ::GetWindowText(hWndCtl, szText, sizeof(szText)/sizeof(TCHAR));
        int nValue = nMin - 1;  // Force control update
        if (nRet > 0)
            nValue = _ttoi(szText);
        if (nValue < nMin)
        {
            nValue = nMin;
            SetCtlValue(hWndCtl, nValue);
        }
        if (nValue > nMax)
        {
            nValue = nMax;
            SetCtlValue(hWndCtl, nValue);
        }
        return nValue;
    }

	LRESULT OnPropsChanged(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
        // NOTE: Special care is taken here to not call the Apply() method
        //       unless the paramter values of controls are changed.  This
        //       ensures that a new key-frame is not inserted by Vegas Video
        //       unless it is needed.
        BYTE bTmp;
        switch (wID)
        {
        case IDC_COLOR_RED:
            bTmp = GetVerifyCtlValue(hWndCtl, 0, 255);
            if (m_Props.bR != bTmp)
            {
                m_Props.bR = bTmp;
                ::InvalidateRect(GetDlgItem(IDC_COLOR), NULL, TRUE);
                Apply();
            }
            bHandled = TRUE;
            break;
        case IDC_COLOR_GREEN:
            bTmp = GetVerifyCtlValue(hWndCtl, 0, 255);
            if (m_Props.bG != bTmp)
            {
                m_Props.bG = bTmp;
                ::InvalidateRect(GetDlgItem(IDC_COLOR), NULL, TRUE);
                Apply();
            }
            bHandled = TRUE;
            break;
        case IDC_COLOR_BLUE:
            bTmp = GetVerifyCtlValue(hWndCtl, 0, 255);
            if (m_Props.bB != bTmp)
            {
                m_Props.bB = bTmp;
                ::InvalidateRect(GetDlgItem(IDC_COLOR), NULL, TRUE);
                Apply();
            }
            bHandled = TRUE;
            break;
        case IDC_TOLERANCE:
            bTmp = GetVerifyCtlValue(hWndCtl, 0, 100);
            if ( (BYTE)(m_Props.dTolerance * 100.0) != bTmp )
            {
                m_Props.dTolerance = (DOUBLE)bTmp / 100.0;
                ::InvalidateRect(GetDlgItem(IDC_COLOR), NULL, TRUE);
                Apply();
            }
            bHandled = TRUE;
            break;
        }
		return 0;
	}

protected:
    SCREENPROPS     m_Props;
    HBRUSH          m_hBrush;       // For color control drawing

	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
        // SF extensions
        CComQIPtr<ISfExchangeProps<SCREENPROPS>, &IID_ISfExchangeProps> pScreen( m_ppUnk[0] );
        pScreen->SetNotifyWindow(m_hWnd, 0);
        // SF extensions

        ::DeleteObject(m_hBrush);
        m_hBrush = NULL;
		return 0;
	}

    LRESULT OnCommand
    ( 
        UINT uMsg, 
        WPARAM wParam, 
        LPARAM lParam, 
        BOOL& bHandled 
    )
    {
        UINT    uId     = LOWORD(wParam);

        switch(uId)
        {
            case ID_NOTIFYCHANGE:
                Update();
                bHandled = TRUE;
            break;
        }

        return 0;
    }
};

#endif //__SCREENPP_H_
