//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Mask.rc
//
#define IDS_PROJNAME                    100
#define IDR_SCREEN                      101
#define IDS_TITLEScreenPP               102
#define IDS_HELPFILEScreenPP            103
#define IDS_DOCSTRINGScreenPP           104
#define IDR_SCREENPP                    105
#define IDD_SCREENPP                    106
#define IDC_COLOR_RED                   201
#define IDC_COLOR_GREEN                 202
#define IDC_COLOR_BLUE                  203
#define IDC_TOLERANCE                   204
#define IDC_COLOR                       206
#define IDS_FIRSTPRESET_ENGLISH         2000
#define IDS_STRING2001                  2001
#define IDS_STRING2002                  2002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         208
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
