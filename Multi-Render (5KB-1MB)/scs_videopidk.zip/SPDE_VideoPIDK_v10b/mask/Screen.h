//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#ifndef __SCREEN_H_
#define __SCREEN_H_

#include "resource.h"       // main symbols

#include "SFBase.h"         // SF extension

/////////////////////////////////////////////////////////////////////////////
typedef struct tSCREENPROPS
{
    BYTE    bR;
    BYTE    bG;
    BYTE    bB;
    DOUBLE  dTolerance;
} SCREENPROPS;


/////////////////////////////////////////////////////////////////////////////
// CScreen
class ATL_NO_VTABLE CScreen : 
	public CDXBaseNTo1,
	public CComCoClass<CScreen, &CLSID_Screen>,
	public IDispatchImpl<IScreen, &IID_IScreen, &LIBID_MASKLib>,
#if(_ATL_VER < 0x0300)
    public CComPropertySupport<CScreen>,
#endif
    public IObjectSafetyImpl2<CScreen>,
    public IPersistStorageImpl<CScreen>,
    public ISpecifyPropertyPagesImpl<CScreen>,
    public IPersistPropertyBagImpl<CScreen>,
    public CSFVideoPlugin< SCREENPROPS >            // SF extension


{
public:
	CScreen();

//DECLARE_REGISTRY_RESOURCEID(IDR_SCREEN)
DECLARE_REGISTER_DX_TRANSFORM(IDR_SCREEN, CATID_DXImageTransform)
DECLARE_POLY_AGGREGATABLE(CScreen)
DECLARE_IDXEFFECT_METHODS(0)

DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CScreen)
	COM_INTERFACE_ENTRY(IScreen)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)

    COM_INTERFACE_ENTRY(ISfVideoPluginExtension)    // SF extension
    COM_INTERFACE_ENTRY(IDXTSfAutomation)           // SF extension
    COM_INTERFACE_ENTRY(IStaticFilterPreset)        // SF extension
    COM_INTERFACE_ENTRY(IPersistStreamInit)         // SF implemented in CSfVideoPlugin
    COM_INTERFACE_ENTRY_IID(IID_ISfExchangeProps,
    ISfExchangeProps<SCREENPROPS>)

    COM_INTERFACE_ENTRY(IDXEffect)
    COM_INTERFACE_ENTRY_IID(IID_IObjectSafety,
    IObjectSafetyImpl2<CScreen>)
    COM_INTERFACE_ENTRY_IMPL(IPersistStorage)
    COM_INTERFACE_ENTRY_IMPL(ISpecifyPropertyPages)
    COM_INTERFACE_ENTRY_IMPL(IPersistPropertyBag)
    COM_INTERFACE_ENTRY_CHAIN(CDXBaseNTo1)
END_COM_MAP()


#if(_ATL_VER <= 0x0200)
    BEGIN_PROPERTY_MAP(CScreen)
#else
    BEGIN_PROP_MAP(CScreen)
#endif
    //PROP_ENTRY("Color Screen Sample", DISPID_SCREEN, CLSID_ScreenPP )
    PROP_PAGE( CLSID_ScreenPP )
#if(_ATL_VER <= 0x0200)
    END_PROPERTY_MAP()
#else
    END_PROP_MAP()
#endif

    HRESULT OnSetup( DWORD dwFlags );
    HRESULT WorkProc( const CDXTWorkInfoNTo1& WI, BOOL* pbContinue );

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

    HRESULT InterpolateProps
    (
        SCREENPROPS*        pOutProps,
        const SCREENPROPS*  pFromProps,
        const SCREENPROPS*  pToProps,
        DOUBLE              dProgress
    );

	CComPtr<IUnknown> m_pUnkMarshaler;

// IScreen
public:
#if(_ATL_VER >= 0x0300)
    BOOL            m_bRequiresSave;
#endif

};

#endif //__SCREEN_H_
