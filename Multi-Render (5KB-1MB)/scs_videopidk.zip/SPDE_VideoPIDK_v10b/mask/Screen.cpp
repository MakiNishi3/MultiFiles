//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#include "stdafx.h"
#include "Mask.h"
#include "Screen.h"

/////////////////////////////////////////////////////////////////////////////

static const SCREENPROPS g_aPresetProps[] = 
{
    {   0,   0,   0, 0.0  },    // Default
    {   0, 255,   0, 0.0  },    // Green screen
    {   0,   0, 255, 0.0  }     // Blue Screen
};

#define PRESETPROPCOUNT   ( sizeof(g_aPresetProps) / sizeof(g_aPresetProps[0]) )

/////////////////////////////////////////////////////////////////////////////
// CScreen

CScreen::CScreen()
    : CSFVideoPlugin< SCREENPROPS > (g_aPresetProps, _Module.GetResourceInstance(), IDS_FIRSTPRESET_ENGLISH, PRESETPROPCOUNT, &CLSID_Screen)       // SF extension
{
	m_pUnkMarshaler = NULL;
    m_PluginInfo.eCategory     = VIDEOPLUGINTYPE_MASK_FILTER; //VIDEOPLUGINTYPE_INVALID; 
}


HRESULT CScreen::InterpolateProps
(
    SCREENPROPS*        pOutProps,
    const SCREENPROPS*  pFromProps,
    const SCREENPROPS*  pToProps,
    DOUBLE              dProgress
)
{
    pOutProps->bR = Interpolate< BYTE >(pFromProps->bR, pToProps->bR, dProgress);
    pOutProps->bG = Interpolate< BYTE >(pFromProps->bG, pToProps->bG, dProgress);
    pOutProps->bB = Interpolate< BYTE >(pFromProps->bB, pToProps->bB, dProgress);

    pOutProps->dTolerance = Interpolate< DOUBLE >(pFromProps->dTolerance, pToProps->dTolerance, dProgress);

    return NOERROR;
}


HRESULT CScreen::OnSetup( DWORD dwFlags )
{
    HRESULT hr = S_OK;

    return hr;
}

HRESULT CScreen::WorkProc( const CDXTWorkInfoNTo1& WI, BOOL* pbContinue )
{
    HRESULT     hr = S_OK;

    // Retrieve the output bounds of the output surface
    CDXDBnds Bounds(InputSurface( 0 ), hr);

    if (FAILED(hr)) return hr;

    ULONG cXSrcSize = Bounds.Width();
    ULONG cYSrcSize = Bounds.Height();

    ULONG uWidth = WI.DoBnds.Width();
    ULONG uStartX = WI.DoBnds.Left();
    ULONG uStartY = WI.DoBnds.Top();

    AutoUpdateProps();

    CSFARGBReadPtr InA(hr, InputSurface(0), &WI.DoBnds, FALSE);
    if( FAILED( hr ) ) return hr;

    CSFARGBReadWritePtr Out(hr, OutputSurface(), &WI.OutputBnds, FALSE);
    if( FAILED( hr ) ) return hr;

    INT nMaxDiff =  (INT)(m_WorkProps.dTolerance * m_WorkProps.dTolerance * 255 * 255);
    DXSAMPLE TransparentSample;
    DXSAMPLE SolidSample;
    TransparentSample.Red   = 0;
    TransparentSample.Green = 0;
    TransparentSample.Blue  = 0;
    TransparentSample.Alpha = 0;
    SolidSample.Red   = 255;
    SolidSample.Green = 255;
    SolidSample.Blue  = 255;
    SolidSample.Alpha = 255;

    const DXSAMPLE* pSrcRow = InA.GetFirstSample();
    DXSAMPLE* pDstRow = Out.GetFirstSample();

    // Now do the work of the filter
    ULONG cRows = WI.DoBnds.Height();
    for (ULONG uRow = 0; uRow < cRows; uRow++)
    {
        for (ULONG uX = 0; uX < uWidth; uX++)
        {
            INT nRDiff = (INT)pSrcRow[uX].Red - m_WorkProps.bR;
            INT nGDiff = (INT)pSrcRow[uX].Green - m_WorkProps.bG;
            INT nBDiff = (INT)pSrcRow[uX].Blue - m_WorkProps.bB;
            INT nDiff = nRDiff * nRDiff + nGDiff * nGDiff + nBDiff * nBDiff;

            if (nDiff <= nMaxDiff)
                pDstRow[uX] = TransparentSample;
            else
                pDstRow[uX] = SolidSample;
        }

        pSrcRow += InA.GetWidth();
        pDstRow += Out.GetWidth();
    }

    return hr;
}
