//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#ifndef __FLIP_H_
#define __FLIP_H_

#include "resource.h"       // main symbols

#include "SFBase.h"

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// Preset type
typedef struct tFLIPPROP
{
    double      dAmount;

    // DEFINE_COMMONPROPMETHODS();
    
    HRESULT Interpolate
    (
        const struct tFLIPPROP *pProp1,
        const struct tFLIPPROP *pProp2,
        DOUBLE                 dProgress
    )
    {
        return S_OK;
    };

    HRESULT SetToDefault()
    {
        dAmount = 0.0;

        return S_OK;
    }

} FLIPPROP;


/////////////////////////////////////////////////////////////////////////////
// CFlip
class ATL_NO_VTABLE CFlip : 
	public CDXBaseNTo1,
	public CComCoClass<CFlip, &CLSID_Flip>,
	public IDispatchImpl<IFlip, &IID_IFlip, &LIBID_SIMPLELib>,
#if(_ATL_VER < 0x0300)
    public CComPropertySupport<CFlip>,
#endif
    public IObjectSafetyImpl2<CFlip>,
    public IPersistStorageImpl<CFlip>,
    public ISpecifyPropertyPagesImpl<CFlip>,
    public IPersistPropertyBagImpl<CFlip>,

    public CSFVideoPlugin<FLIPPROP>
{
public:
	CFlip();

    DECLARE_REGISTER_DX_TRANSFORM(IDR_FLIP, CATID_DXImageTransform)
DECLARE_POLY_AGGREGATABLE(CFlip)
DECLARE_IDXEFFECT_METHODS(0)
//DECLARE_REGISTRY_RESOURCEID(IDR_FLIP)

DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CFlip)
	COM_INTERFACE_ENTRY(IFlip)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)

    COM_INTERFACE_ENTRY(ISfVideoPluginExtension)    // SF extension
    COM_INTERFACE_ENTRY(IDXTSfAutomation)           // SF extension
    COM_INTERFACE_ENTRY(IStaticFilterPreset)        // SF extension
    COM_INTERFACE_ENTRY(IPersistStreamInit)         // SF implemented in CSfVideoPlugin

    COM_INTERFACE_ENTRY(IDXEffect)
    COM_INTERFACE_ENTRY_IID(IID_IObjectSafety,
    IObjectSafetyImpl2<CFlip>)
    COM_INTERFACE_ENTRY_IMPL(IPersistStorage)
    COM_INTERFACE_ENTRY_IMPL(ISpecifyPropertyPages)
    COM_INTERFACE_ENTRY_IMPL(IPersistPropertyBag)
    COM_INTERFACE_ENTRY_CHAIN(CDXBaseNTo1)

END_COM_MAP()

#if(_ATL_VER <= 0x0200)
    BEGIN_PROPERTY_MAP(CFlip)
#else
    BEGIN_PROP_MAP(CFlip)
#endif
    //PROP_ENTRY("Description", DISPID_MyProperty, CLSID_FlipPP )
    PROP_PAGE( CLSID_FlipPP )
#if(_ATL_VER <= 0x0200)
    END_PROPERTY_MAP()
#else
    END_PROP_MAP()
#endif

    //--- Base class overrides
    HRESULT WorkProc( const CDXTWorkInfoNTo1& WI, BOOL* pbContinue );

    HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

// IFlip
public:
#if(_ATL_VER >= 0x0300)
    BOOL            m_bRequiresSave;
#endif
};

#endif //__FLIP_H_
