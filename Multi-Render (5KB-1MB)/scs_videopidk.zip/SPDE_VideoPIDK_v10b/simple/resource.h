//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by simple.rc
//
#define IDS_PROJNAME                    100
#define IDR_FLIP                        101
#define IDS_TITLEFlipPP                 102
#define IDS_HELPFILEFlipPP              103
#define IDS_DOCSTRINGFlipPP             104
#define IDR_FLIPPP                      105
#define IDD_FLIPPP                      106
#define IDS_FIRSTPRESET_ENGLISH         2000
#define IDS_STRING2001                  2001
#define IDS_STRING2002                  2002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
