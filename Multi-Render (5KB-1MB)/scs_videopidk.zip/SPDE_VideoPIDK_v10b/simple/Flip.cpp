//==========================================================================;
//
//  This material has been supplied as part of the Sony Media Software Plug-In
//  Development Kit (PIDK) for DirectX Transform Video Plug-Ins. Under 
//  copyright laws, this material may not be duplicated in whole or in part, 
//  except for personal use, without the express written consent of 
//  Sony Media Software. 
//  Refer to the license agreement contained with the PIDK before using any 
//  part of this material.
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  Web:    http://www.sony.com/mediasoftware
//  Email:  md-videopidk@sonymediasoftware.com
//
//  Copyright � 2006  Madison Media Software, Inc., a subsidiary of Sony Corporation of America. All rights reserved.
//  Portions Copyright � 1992-2000 Microsoft Corporation.
//
//--------------------------------------------------------------------------;
//==========================================================================;

#include "stdafx.h"
#include "Simple.h"
#include "Flip.h"

static const FLIPPROP g_aPresetProps[] = 
{
    { 1.0 },
    { 2.0 },
    { 3.0 }
};
#define PRESETPROPCOUNT   ( sizeof(g_aPresetProps) / sizeof(g_aPresetProps[0]) )


/////////////////////////////////////////////////////////////////////////////
// CFlip

CFlip::CFlip()
    : CSFVideoPlugin< FLIPPROP > (g_aPresetProps, _Module.GetResourceInstance(), IDS_FIRSTPRESET_ENGLISH, PRESETPROPCOUNT, &CLSID_Flip )
{
	m_pUnkMarshaler = NULL;
}

HRESULT CFlip::WorkProc( const CDXTWorkInfoNTo1& WI, BOOL* pbContinue )
{
    HRESULT     hr = S_OK;

    GUID        guidDstPixelType;

    // Retrieve the format to determine if the output is requested in float precision
    DXSAMPLEFORMATENUM eSample;
    hr = OutputSurface()->GetPixelFormat(&guidDstPixelType, &eSample);

    if (FAILED(hr)) return hr;

    // Retrieve the output bounds of the output surface
    CDXDBnds Bounds(InputSurface( 0 ), hr);

    if (FAILED(hr)) return hr;

    ULONG cXSrcSize = Bounds.Width();
    ULONG cYSrcSize = Bounds.Height();

    ULONG uWidth = WI.DoBnds.Width();
    ULONG uStartX = WI.DoBnds.Left();
    ULONG uStartY = WI.DoBnds.Top();

    // 32 bit ARGB
    CComPtr<IDXARGBReadPtr> pInA;
    hr = InputSurface( 0 )->LockSurface( NULL, 0, DXLOCKF_READ,
                                         IID_IDXARGBReadPtr, (void**)&pInA, NULL );
    if( FAILED( hr ) ) return hr;

    CComPtr<IDXARGBReadWritePtr> pOut;
    hr = OutputSurface()->LockSurface( &WI.OutputBnds, 0, DXLOCKF_READWRITE,
                                       IID_IDXARGBReadWritePtr, (void**)&pOut, NULL );
    if( FAILED( hr ) ) return hr;

    // Now allocate the source and destination buffers for
    // one row of data.
    DXSAMPLE* pSrcRow = new DXSAMPLE[uWidth];

    if (NULL == pSrcRow) return E_OUTOFMEMORY;

    // Now do the work of the filter
    ULONG cRows = WI.DoBnds.Height();
    for (ULONG uRow = 0; uRow < cRows; uRow++)
    {
        // Get a row from the other side
        pInA->MoveToXY( uStartX, cYSrcSize - uRow - uStartY - 1 );
        pInA->Unpack( pSrcRow, uWidth, FALSE );

        // And place it to the current row
        pOut->MoveToRow( uRow );
        pOut->PackAndMove( pSrcRow, uWidth );
    }

    // All done, delete the allocated row buffer memory
    delete[] pSrcRow;

    return hr;
}
