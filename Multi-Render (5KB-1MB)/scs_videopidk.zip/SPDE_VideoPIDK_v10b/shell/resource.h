//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Main.rc
//
#define IDS_PROJNAME                    100
#define IDR_PLUGIN                      101
#define IDS_TITLEPluginPP               102
#define IDS_HELPFILEPluginPP            103
#define IDS_DOCSTRINGPluginPP           104
#define IDR_PLUGINPP                    105
#define IDD_PLUGINPP                    106
#define IDS_FIRSTPRESET_ENGLISH         10000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
