// Filaments by nimitz (twitter: @stormoid)
// https://www.shadertoy.com/view/4lcSWs
// License Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// Contact the author for other licensing options

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
    vec2 q = fragCoord.xy/iResolution.xy;
    float fft  = texture( iChannel0, vec2(q.x,0.25) ).x;
	float nwave = texture( iChannel0, vec2(q.x,0.75) ).x;
    vec4 lData = texture( iChannel1, vec2(q.x,0.25) );
    
    float fwave = mix(nwave,lData.z, 0.5);

    float nfft = 0.;
    for (float i = 0.; i < 1.; i += 0.02)
    {
        nfft += texture( iChannel1, vec2(i,0.25) ).x; 
    }
    nfft = clamp(nfft/50.,0.,1.);
    
    float ffts = mix(nfft, lData.w, 0.);
    
    if (iFrame < 5) 
    {
        fft = 0.;
        fwave= .5;
        ffts = 0.;
    }
    
    fragColor = vec4(fft, 0, fwave, ffts);
}