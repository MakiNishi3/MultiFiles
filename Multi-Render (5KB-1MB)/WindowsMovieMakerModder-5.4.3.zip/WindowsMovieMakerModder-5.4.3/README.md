# WindowsMovieMakerModder
Windows Movie Maker 2.6/6.0 effects made by XML, App made by HTML
